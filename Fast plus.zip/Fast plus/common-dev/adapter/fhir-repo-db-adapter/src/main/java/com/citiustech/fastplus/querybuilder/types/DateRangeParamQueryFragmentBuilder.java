package com.citiustech.fastplus.querybuilder.types;


import java.lang.reflect.Field;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;

import ca.uhn.fhir.model.api.TemporalPrecisionEnum;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;

/**
 *
 * This is a class for DateRangeParamQueryFragmentBuilder which used to build
 * query fragments for date range search parameters
 *
 */

@Component
public class DateRangeParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<DateParam> {

    /**
     * This is a DATE_FORMAT field used to define a constant to hold date format
     * "yyyy-MM-dd HH:mm"
     */
    private static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";

    /**
     * This is a LASTUPDATED_DATE field used to define a constant to hold
     * _lastupdated string
     */
    private static final String LASTUPDATED_DATE = "_lastUpdated";

    /**
     * This is a SERACH_PARAM_PREFIX field used to define a constant to hold "SP_"
     * string
     */
    private static final String SERACH_PARAM_PREFIX = "SP_";
	
    /**
     * This is a customResourceUtil field used to hold CustomResourceUtil object
     */
    private CustomResourceUtil customResourceUtil;
    
    /**
     * This is a commonQueryUtil field used to hold CommonQueryUtil object
     */
    private CommonQueryUtil commonQueryUtil;

    /**
     * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
     */
    private FHIRErrorHandler fhirErrorHandler;


    /**
     * This is a fhirRepositoryTableConfiguration field used to hold
     * FHIRRepositoryTableConfiguration object
     */
    private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

    @Autowired
    public DateRangeParamQueryFragmentBuilder(CustomResourceUtil customResourceUtil, CommonQueryUtil commonQueryUtil,
			FHIRErrorHandler fhirErrorHandler, FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration) {
		super();
		this.customResourceUtil = customResourceUtil;
		this.commonQueryUtil = commonQueryUtil;
		this.fhirErrorHandler = fhirErrorHandler;
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
	}
    
    public DateRangeParamQueryFragmentBuilder() {
    	
    }
    
	/**
     * returns format of input date as string
     *
     * @param date
     */
    private String formatDate(Date date) {
    	ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(date.toInstant(),
                ZoneId.systemDefault());
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATEFORMAT);
        return zonedDateTime.format(formatter);
    }
    
    /**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
    @Override
    public Condition frameQueryFragment(QueryBuilder queryBuilder, String resurceType, String resourceTypeAlias, DateParam paramType, String paramName) {
    	
    	String tempParamName = paramName;
    	if(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString()))
    	{
    		throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_DATE_FORMAT);
    	}
    	
    	boolean isLastUpdated = LASTUPDATED_DATE.equalsIgnoreCase(tempParamName);
		boolean isEndColumn = false;
		boolean isEqualOperation = false; // this flag is used only for eq operation in period param

		if (customResourceUtil.isCustomResource(resurceType) && !isLastUpdated) {
			String subPath = extractPath(resurceType, tempParamName);
			if (subPath.contains(":")) {
				tempParamName = subPath.split(":")[1];
				 isEndColumn = (subPath.split(":")[0]).contains("end");
			}
		}
		
		Condition attributeCondition = createAttributeCondition(isLastUpdated, tempParamName, resourceTypeAlias);
		
		List<String> periodSearchAttribute= fhirRepositoryTableConfiguration.getSearchTableMap().get(resurceType).getPeriodSearchAttribute();
		
		// for handling dates with Period param
		if(periodSearchAttribute != null && periodSearchAttribute.contains(tempParamName)) {
			 if (paramType.getPrefix().equals(ParamPrefixEnum.LESSTHAN) ||paramType.getPrefix().equals(ParamPrefixEnum.LESSTHAN_OR_EQUALS)) {
				isEndColumn = true;
			} else if (paramType.getPrefix().equals(ParamPrefixEnum.EQUAL)) {
				// this else if required because to filter equal modifier from eq,ge,gt (le/lt already filtered in above statement)
				isEqualOperation = true;
			}
		} 
		
		TemporalPrecisionEnum precision = getPrecision(paramType);
		
		CustomSql customSql = null;
		if(isLastUpdated) {
			customSql = fhirRepositoryTableConfiguration.getSearchColumnForDate(
					ParamType.DATE.getValue(), resurceType, precision, resourceTypeAlias, paramType.getPrefix()).get(2);
		}else if(isEndColumn){
			customSql = fhirRepositoryTableConfiguration.getSearchColumnForDate(
					ParamType.DATE.getValue(), resurceType, precision, resourceTypeAlias, paramType.getPrefix()).get(1);
		} else{
			customSql = fhirRepositoryTableConfiguration.getSearchColumnForDate(
					ParamType.DATE.getValue(), resurceType, precision, resourceTypeAlias, paramType.getPrefix()).get(0);
		}
		
		ComboCondition comboCondition = ComboCondition.and(attributeCondition, getDateCondition(customSql,paramType));
		if(isEqualOperation) {
			customSql = fhirRepositoryTableConfiguration.getSearchColumnForDate(
					ParamType.DATE.getValue(), resurceType, precision, resourceTypeAlias, paramType.getPrefix()).get(1);
			
			List<Condition> orConditionb = new ArrayList<>();
			orConditionb.add(comboCondition);
			orConditionb.add(ComboCondition.and(attributeCondition, getDateCondition(customSql,paramType)));
			comboCondition = (ComboCondition) queryBuilder.frameOrQueryAndReturn(orConditionb);
		}
		
		return  comboCondition; 
    }
    
    /**
     * 
     * @param isLastUpdated
     * @param paramName
     * @param resourceTypeAlias
     * @return Condition of attribute column
     */
    private Condition createAttributeCondition(boolean isLastUpdated, String paramName, String resourceTypeAlias)
    {
    	Condition attributeCondition;
		if(isLastUpdated) {
			attributeCondition = BinaryCondition.equalTo(
					fhirRepositoryTableConfiguration.getSearchAttributeColumn(resourceTypeAlias), "_id");
		} else {
			attributeCondition = BinaryCondition.equalTo(
					fhirRepositoryTableConfiguration.getSearchAttributeColumn(resourceTypeAlias), paramName);
		}
		return attributeCondition;
    }
    
	private TemporalPrecisionEnum getPrecision(DateParam paramType) {
		return paramType.getPrecision().equals(TemporalPrecisionEnum.MILLI) ? TemporalPrecisionEnum.SECOND
				: paramType.getPrecision();
	}
    

	/**
	 * returns date conditions based on input parameters
	 *
	 * @param param
	 * @param paramType
	 */
	private Condition getDateCondition(CustomSql param, DateParam paramType) {
		switch (paramType.getPrefix()) {
		case GREATERTHAN_OR_EQUALS:
			return BinaryCondition.greaterThanOrEq(param, formatDate(paramType.getValue()));
		case GREATERTHAN:
			return BinaryCondition.greaterThan(param, formatDate(paramType.getValue()));
		case LESSTHAN:
			return BinaryCondition.lessThan(param, formatDate(paramType.getValue()));
		case LESSTHAN_OR_EQUALS:
			return BinaryCondition.lessThanOrEq(param, formatDate(paramType.getValue()));
		default:
			return BinaryCondition.equalTo(param, formatDate(paramType.getValue()));
		}
	}

	/**
	 * returns extracted path from parameter
	 *
	 * @param resurceType
	 * @param paramName
	 * @return String
	 */
	private String extractPath(String resurceType, String paramName) {
		String subPath = "";
		try {
			Field field = Class.forName(customResourceUtil.getCustomResource(resurceType))
					.getField(SERACH_PARAM_PREFIX + (paramName.contains("-") ? paramName.replace("-", "_").toUpperCase(Locale.ROOT) : paramName.toUpperCase(Locale.ROOT)));
			SearchParamDefinition searchParamDefinition = field.getDeclaredAnnotation(SearchParamDefinition.class);
			String path = searchParamDefinition.path();
			int index = path.indexOf('.');
			subPath = path.substring(index + 1);
		} catch (NoSuchFieldException | SecurityException | ClassNotFoundException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR,
					"ERROR while extracting path from parameter date param", e);
		}
		return subPath;

	}
}

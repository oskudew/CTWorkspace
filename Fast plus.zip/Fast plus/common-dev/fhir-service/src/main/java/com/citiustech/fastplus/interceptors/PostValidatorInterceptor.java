package com.citiustech.fastplus.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import ca.uhn.fhir.rest.server.exceptions.PayloadTooLargeException;
import ca.uhn.fhir.rest.server.servlet.ServletRequestDetails;

@Component
@Interceptor
public class PostValidatorInterceptor {

	@Value("${server.max-payload-size:1024}")
	private Long maxPayloadSizeInMB;
	
	@Value("${server.max-payload-size.enable:false}")
	private boolean payloadSizeEnabled;

	@Hook(Pointcut.SERVER_INCOMING_REQUEST_POST_PROCESSED)
	public boolean audit(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		
		if(httpServletRequest.getMethod().equals("POST") && payloadSizeEnabled)
		{
			Long contentLengthInBytes = httpServletRequest.getContentLengthLong();
			
			if(contentLengthInBytes > (maxPayloadSizeInMB * 1024 * 1024)) {
				throw new PayloadTooLargeException("payload size exceeds. Expected size is " + maxPayloadSizeInMB + "bytes");
			}
		}
	
		return true;
	}

}

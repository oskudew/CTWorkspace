package com.citiustech.fastplus.filereader;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

import org.apache.commons.io.FileUtils;
import org.hl7.fhir.r4.model.Attachment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;

/**
 * 
 * This class is used to support the file reading operation from shared location.
 *
 */
@Component
public class FileReaderUtils {

	private static final Logging LOGGER = LoggerFactory.getLogger(FileReaderUtils.class.getName());

	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object
	 */
	@Autowired
	private FHIRErrorHandler fhirErrorHandler;

	/**
	 * This is the maximum allowed attachment size(in MB) per each request. 
	 */
	@Value("${attachments.response.max.size.mb: 10}")
	private int maxAllowedAttachmentSize;

	/**
	 * This is the shared staging folder path where the attachment file located.
	 */
	@Value("${attachments.staging.folder.path: }")
	private String sharedLocation;
	
	/**
	 * This is the shared staging folder path where the attachment file located.
	 */
	@Value("${attachments.default.url: }")
	private String defaultURL;
	
	
	public void setSharedLocation(String sharedLocation) {
		this.sharedLocation = sharedLocation;
	}
	

	public void setMaxAllowedAttachmentSize(int maxAllowedAttachmentSize) {
		this.maxAllowedAttachmentSize = maxAllowedAttachmentSize;
	}


	/**
	 * returns boolean value for checking file exits or not.
	 * 
	 * @param filepath
	 * @param filename
	 * @return boolean
	 */
	public boolean isFileExists(String filepath, String filename) {
		Path path = Paths.get(filepath, filename);
		boolean fileExists  = false;
		try {
			fileExists = path.toFile().exists();
		}catch(SecurityException se) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"You dont have access to the file or directory");
		}
	
		if (!fileExists)
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Failed to load document (Paths:[" + path.toString() + "],Reason:[File not found])");
		return fileExists;
	}

	/**
	 * returns filedata in byte[] if file available at given location.
	 * 
	 * @param filepath
	 * @param filename
	 * @return byte[]
	 */
	public byte[] readFileContent(String filepath, String filename) {
		byte[] fileContent = null;
		String filelocation = null;
		File file = new File(filepath, filename);
		try {
			filelocation = file.getCanonicalPath();
			fileContent = 	FileUtils.readFileToByteArray(file);
		} catch (IOException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Failed to load document (Paths:[" + filelocation + "],Reason:[" + e.getMessage() + "])");
		}
		return fileContent;
	}
	
	/**
	 * returns filesize in long.
	 * 
	 * @param fileContent
	 * @return long
	 */
	public long getFileSize(byte[] fileContent) {
		return fileContent.length;
	}

	/**
	 * returns boolean value for checking maximum allowed attachment size exceeded or not.
	 * 
	 * @param totalAttachmentSize
	 * @return boolean
	 */
	public boolean isMaxAllowedSizeExceeded(long totalAttachmentSize) {
		boolean maxAllowedSizeExceeded = totalAttachmentSize > (maxAllowedAttachmentSize * 1024 * 1024);

		if (maxAllowedSizeExceeded) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Max allowed attachment " + (maxAllowedAttachmentSize * 1024 * 1024) + " size exceeded.");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.MAX_FILE_SIZE_EXCEEDED);
		}
		return maxAllowedSizeExceeded;
	}

	/**
	 * read the the file from URL and set it into attachment data.
	 * 
	 * @param attachment
	 * @param totalAttachmentSize
	 * @return
	 */
	public long setAttachmentdata(Attachment attachment, long totalAttachmentSize) {
		long tempAttachmentSize = totalAttachmentSize;
		if (Objects.nonNull(attachment) && Objects.nonNull(attachment.getUrl()) && !attachment.getUrl().isEmpty()) {
			String attachmentUrl = attachment.getUrl();
			attachment.setUrl(defaultURL);
			if (isFileExists(sharedLocation, attachmentUrl)) {
				byte[] fileContent = readFileContent(sharedLocation, attachmentUrl);
				long fileSize = getFileSize(fileContent);
				tempAttachmentSize += fileSize;

				if (!isMaxAllowedSizeExceeded(tempAttachmentSize)) {
					attachment.setData(fileContent);
					return tempAttachmentSize;
				}
			}
		}
		return 0;
	}

}

package com.employee;

import static org.hamcrest.CoreMatchers.instanceOf;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class OptionalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = null;
		List<Employee> l= Arrays.asList( new Employee(1,"sachin","IT"),
				 new Employee(2,"Dravid","IT"),
				 new Employee(3,"Dhoni","Security"),
				 new Employee(4,null,"Security"),e1);
		
		//static method-->of,empty(),ofNullable
		//boolean isPresent()
		Optional<String> op = Optional.ofNullable
				(l.get(2).getName());
		//System.out.println(op.isPresent());
		
		//Methods
		//get()
		Optional<String> op1= Optional.ofNullable(l.get(2).getName());
		//System.out.println(op1.get());
		
		//ifPresent()
		Optional<String> op2= Optional.ofNullable(l.get(3).getName());
		op2.ifPresent(x->l.get(2).setName("krish"));
		//System.out.println(l.get(2).getName());
		
		//filter
		System.out.println(op2.filter(x->x.length()<7));
		
		//orElse
		System.out.println("OrElse-->"+op2.orElse("Oh stree kl ana"));
		
		//orElseGet
			
			System.out.println("orElseGet-->"+op2.orElseGet(()->"Prithvi"));
			
			//Supplier
			Supplier<String> supplier=()->l.get(1).getDeptName();
			String s=supplier.get();
			System.out.println("Supplier:-->"+s);
			
			//Consumer
			
			//////////////////////////////////////
			Consumer<List<Integer>> multiply = list->
				{list.stream().map(i->i*2).collect(Collectors.toList()).forEach(x->System.out.println(x));};
				
				 Consumer<List<Integer> > modify = list1 ->
			        {
			            for (int i = 0; i < list1.size(); i++) {
			                list1.set(i, 2 * list1.get(i));
			            System.out.println(list1.get(i));
			            }
			        };
			
				Consumer<List<Integer>> disp = list->list.stream().forEach(x->System.out.print(x+ " "));
				
				List<Integer> list =Arrays.asList(1,3,4); 
			
			//modify.accept(list);
			
			multiply.andThen(disp).accept(list);
			
	}
			
		

	}



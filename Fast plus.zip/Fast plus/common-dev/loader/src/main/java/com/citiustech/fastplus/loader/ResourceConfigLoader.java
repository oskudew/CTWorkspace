package com.citiustech.fastplus.loader;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;

@Configuration
public class ResourceConfigLoader {
	
	/**
	 * Used to hold json config file by resource name as key 
	 */
	private Map<String, String> resourceConfig = new HashMap<>();
	
	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object
	 */
	@Autowired
	private FHIRErrorHandler fhirErrorHandler;
	
	private static final Logging LOGGER = LoggerFactory.getLogger(ResourceConfigLoader.class.getName());

	String configLocation = "configuration/";
	
	List<String> jsonConfigs = new ArrayList<>(Arrays.asList(
			"AllergyIntolerance.json",
	 		"CarePlan.json",
			"CareTeam.json",
			"Condition.json",
			"Contract.json",
			"Coverage.json",
			"Device.json",
			"DiagnosticReport.json",
			"DocumentReference.json",
			"Encounter.json",
			"Endpoint.json",
			"ExplanationOfBenefit.json",
			"Goal.json",
			"HealthcareService.json",
			"Immunization.json",
			"InsurancePlan.json",
			"List.json",
			"Location.json",
			"Medication.json",
			"MedicationDispense.json",
			"MedicationKnowledge.json",
			"MedicationRequest.json",
			"Observation.json",
			"Organization.json",
			"OrganizationAffiliation.json",
			"Patient.json",
			"Practitioner.json",
			"PractitionerRole.json",
			"Procedure.json",
			"Provenance.json",
			"RelatedPerson.json",
			"Subscription.json"));
	
	public ResourceConfigLoader() throws IOException, URISyntaxException {
		LOGGER.logInfo(LoggingMarkers.APPLICATION.getValue(),"Inserting resource config by key" );
		for (String jsonConfigName : jsonConfigs) {
			StringBuilder currentBuilder = new StringBuilder(configLocation).append(jsonConfigName);
			try (InputStream cis = this.getClass().getClassLoader()
					.getResourceAsStream(currentBuilder.toString())) {
				resourceConfig.put(jsonConfigName,IOUtils.toString(cis,StandardCharsets.UTF_8 ));
			}catch (IllegalArgumentException | IOException e) {
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_DATA, e);
			}
		}
	}
	
	
	public Map<String, String> getResourceConfig() {
		return resourceConfig;
	}

	public void setResourceConfig(Map<String, String> resourceConfig) {
		this.resourceConfig = resourceConfig;
	}
	
	
	
}

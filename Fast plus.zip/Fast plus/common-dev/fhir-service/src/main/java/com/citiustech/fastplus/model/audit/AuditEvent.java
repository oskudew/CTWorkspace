package com.citiustech.fastplus.model.audit;

import java.time.ZonedDateTime;
import java.util.UUID;

import lombok.Getter;
import lombok.Setter;

/**
 * This is a class for AuditEvent used to hold Audit entries
 */
@Getter
@Setter
public class AuditEvent {
    /**
     * This is a requestId field used to hold id of request
     */
    private String requestId;

    /**
     * This is a timestamp field used to hold current time stamp value
     */
    private ZonedDateTime timestamp;

    /**
     * This is a service field used to hold service information
     */
    private String service;

    /**
     * This is a node field used to hold node information
     */
    private String node;

    /**
     * This is a user field used to hold user information
     */
    private String user;

    /**
     * This is a resourceType field used to hold type of a resource
     */
    private String resourceType;


    /**
     * This is a serialVersionUID field used to hold resource ids in the form of string
     */
    private String resourceIdsString;

    /**
     * This is a action field used to hold action information
     */
    private String action;

    /**
     * This is a remoteIp field used to hold ip of remote
     */
    private String remoteIp;

    /**
     * This is a statusCode field used to hold code for status
     */
    private String statusCode;

    /**
     * This is a errorCode field used to hold code for error
     */
    private String errorCode;

    /**
     * This is a errorMsg field used to hold message for error
     */
    private String errorMsg;

    /**
     * This is a responseTime field used to hold time taken for response
     */
    private Integer responseTime;
    
    /**
     * request URI
     */
    private String requestURI;

    /**
     * No argument constructor
     */
    public AuditEvent() {
        this.requestId = UUID.randomUUID().toString();
    }

    
    // Added custom implementation as per requirement
	@Override
	public String toString() {
		return "[ requestId=" + requestId + ", timestamp=" + timestamp + ", service=" + service + ", node="
				+ node + ", user=" + user + ", resourceType=" + resourceType + ", resourceIdsString="
				+ resourceIdsString + ", action=" + action + ", remoteIp=" + remoteIp + ", statusCode=" + statusCode
				+ ", errorCode=" + errorCode + ", errorMsg=" + errorMsg + ", responseTime=" + responseTime
				+ ", requestURI=" + requestURI + " ]";
	}

}

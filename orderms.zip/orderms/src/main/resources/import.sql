insert into order_ms (name) values ('Poco F1')
insert into order_ms (name) values ('Nokia C3')
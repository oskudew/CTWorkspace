import java.util.Arrays;

public class infinite {
	
	//In given array find if there is a triplet in array whose sum is equal to the given value.
	//If there is such a triplet present in array, then print all the possible triplet 
	//Input: array = {12, 3, 4, 1, 6, 9}, sum = 24; 
	//Output: 12, 3, 9
	
	/*
	 * Function check if strings are rotations of each other or not ? 
	 * String s1="DOCASAP" String s2 ="ASAPDOC"
	 */



	public static void main(String[] args) {
		
		/*
		 * int[] arr = {12,3,4,1,6,9}; int op =24; int sum =0; Arrays.sort(arr);
		 * while(sum!=op) { for(int i =0;i<arr.length;i++) {
		 * 
		 * }
		 * 
		 * }
		 */
		
		String s1= "DOCASAP";
		String s2 = "OCASAPD";
		//String s3=s1;
		String s3="abc";
		String s4 ="abc";
		System.out.println(s3==s4);
		for(int i =0;i<s1.length();i++) {
		
			s1=s1.substring(1)+s1.charAt(0);
			//System.out.println(s1);
			if(s1.equals(s2)) {
				System.out.println("rotating string");
			}
		}
	}
}

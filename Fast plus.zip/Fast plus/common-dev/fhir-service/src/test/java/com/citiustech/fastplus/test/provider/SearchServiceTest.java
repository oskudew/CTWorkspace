package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.ExplanationOfBenefit;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.Adapter;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.filereader.attachment.IAttachmentReader;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.service.impl.SearchService;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.citiustech.fastplus.util.exception.SearchServiceException;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;

@ExtendWith(MockitoExtension.class)
class SearchServiceTest {

	@InjectMocks
	SearchService searchService;

	@Mock
	private Adapter fhirRepositoryAdapter;

	@Spy
	private FHIRErrorHandler fhirErrorHandler;

	@Spy
	private FhirContext fhirContext;

	@Spy
	IAttachmentReader attachmentReader;

	@Mock
	private CommonQueryUtil commonQueryUtil;

	@DisplayName("Test case for findResourceIds")
	@Test
	void test_findResourceIds() {
		String resourceType = ResourceType.Organization.name();
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam addressCity = new StringAndListParam();
		addressCity.addAnd(new StringParam("Thailand"));
		parameterMap.add(Organization.SP_ADDRESS_CITY, addressCity);

		List<IdProjectionRow> projectionRows = new ArrayList<>();
		projectionRows.add(new IdProjectionRow("Organization", "Kern-coveragetest", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-ntwk-Net501", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org201", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org201_nw", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org202", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org203_nw", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org204_nw", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org205_nw", null));
		projectionRows.add(new IdProjectionRow("Organization", "Kern-org-Org50011", null));

		when(fhirRepositoryAdapter.getIdsForResource(resourceType, parameterMap)).thenReturn(projectionRows);

		List<IdProjectionRow> actualValue = searchService.findResourceIds(resourceType, parameterMap);
		List<IdProjectionRow> expectedValue = projectionRows;

		assertEquals(expectedValue.toString(), actualValue.toString());

	}

	@DisplayName("Test case for findResourceIds for InvalidRequestException For Parameter_MISSING")
	@Test
	void test_findResourceIdsForInvalidRequestExceptionForParameterMissing() {
		String resourceType = ResourceType.Organization.name();
		SearchParameterRequest parameterMap = new SearchParameterRequest();

		InvalidRequestException exception = Assertions.assertThrows(InvalidRequestException.class,
				() -> searchService.findResourceIds(resourceType, parameterMap));
		assertEquals(ExceptionCodes.PARAMETER_MISSING.getCode(), exception.getMessage());
	}

	@DisplayName("Test case for findResourceIds for InvalidRequestException For INVALID_PARAMETER_VALUE")
	@Test
	void test_findResourceIdsForInvalidRequestExceptionForInvalidParameterValue() {
		String resourceType = ResourceType.Organization.name();

		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam addressCity = new StringAndListParam();
		addressCity.addAnd(new StringParam("//*Thailand"));
		parameterMap.add(Organization.SP_ADDRESS_CITY, addressCity);

		when(fhirRepositoryAdapter.getIdsForResource(resourceType, parameterMap))
				.thenThrow(new FHIRException("FPE-3003"));
		InvalidRequestException exception = Assertions.assertThrows(InvalidRequestException.class,
				() -> searchService.findResourceIds(resourceType, parameterMap));
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());

	}

	@DisplayName("Test case for findResourceIds for SearchServiceException")
	@Test
	void test_findResourceIdsForSearchServiceException() {
		String resourceType = ResourceType.Organization.name();

		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam addressCity = new StringAndListParam();
		addressCity.addAnd(new StringParam("Thailand"));
		parameterMap.add(Organization.SP_ADDRESS_CITY, addressCity);

		when(fhirRepositoryAdapter.getIdsForResource(resourceType, parameterMap))
				.thenThrow(new FHIRException("FPE-1002"));

		SearchServiceException exception = assertThrows(SearchServiceException.class,
				() -> searchService.findResourceIds(resourceType, parameterMap));
		assertEquals(ExceptionCodes.DB_CONNECTION_ERROR.getCode(), exception.getMessage());
	}

	@DisplayName("Test case for getResource method")
	@Test
	void test_getResource() {
		String resourceType = ResourceType.Organization.name();
		String resourceId = "Kern-coveragetest";
		String resourceIdWithPrefix = "Kern-coveragetest";

		List<String> jsons = new ArrayList<>();
		String json = "{\"id\": \"Kern-coveragetest\", \"meta\": {\"versionId\": \"1\", \"lastUpdated\": \"2020-12-01T09:44:45.268+00:00\"}, \"name\": \"BAYSIDE ENDOSCOPY,Garrettside\", \"type\": [{\"coding\": [{\"code\": \"atyprv\", \"system\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/OrgTypeCS\", \"display\": \"Atypical Provider\"}]}], \"alias\": [\"Alternate Location Name\"], \"active\": true, \"address\": [{\"city\": \"Thailand\", \"line\": [\"80288 Susan Isle New Jacobfort, IL 00729\", \"Garrettside\"], \"state\": \"State C\", \"district\": \"Thailand\", \"extension\": [{\"url\": \"http://hl7.org/fhir/StructureDefinition/geolocation\", \"extension\": [{\"url\": \"latitude\", \"valueDecimal\": -71.41177}, {\"url\": \"longitude\", \"valueDecimal\": 41.809006}]}], \"postalCode\": \"73848\"}], \"telecom\": [{\"rank\": 1, \"value\": \"-4796\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"mon\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"tue\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"wed\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"thu\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"fri\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sat\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sun\"}, {\"url\": \"allDay\", \"valueBoolean\": false}, {\"url\": \"availableStartTime\", \"valueTime\": \"08:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 2, \"value\": \"377-582-4948x803\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"wed\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"thu\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"fri\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sat\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sun\"}, {\"url\": \"allDay\", \"valueBoolean\": false}, {\"url\": \"availableStartTime\", \"valueTime\": \"20:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 3, \"value\": \"369.518.7681x4340\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"mon\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"tue\"}, {\"url\": \"allDay\", \"valueBoolean\": true}, {\"url\": \"availableStartTime\", \"valueTime\": \"20:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 1, \"value\": \"wilsondonna@yahoo.com\", \"system\": \"email\"}, {\"rank\": 2, \"value\": \"bryantnicholas@jones.com\", \"system\": \"email\"}], \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/location-reference\", \"valueReference\": {\"reference\": \"Location/QA-test-xyz\"}}], \"identifier\": [{\"type\": {\"coding\": [{\"code\": \"NPI\"}]}, \"value\": \"NPI22\", \"system\": \"http://hl7.org/fhir/sid/us-npi\"}, {\"type\": {\"coding\": [{\"code\": \"TAX\"}]}, \"value\": \"TIN2101\", \"system\": \"urn:oid:2.16.840.1.113883.4.4\"}, {\"type\": {\"coding\": [{\"code\": \"CLIA\"}]}, \"value\": \"CLIA1\", \"system\": \"urn:oid:2.16.840.1.113883.4.7\"}, {\"type\": {\"coding\": [{\"code\": \"Additionalids\"}]}, \"value\": \"ABC101\", \"system\": \"http://www.acme.com/identifiers/patient\"}, {\"type\": {\"coding\": [{\"code\": \"Additionalids\"}]}, \"value\": \"XYZ101\", \"system\": \"http://www.acme.com/identifiers/patient\"}], \"resourceType\": \"Organization\"}";
		jsons.add(json);

		when(fhirRepositoryAdapter.getResourceJsons(Arrays.asList(resourceIdWithPrefix), resourceType))
				.thenReturn(jsons);
		when(commonQueryUtil.findPrefixValue(resourceType, resourceId.trim())).thenReturn(resourceIdWithPrefix);
		IBaseResource actualValue = searchService.getResource(resourceId, resourceType);
		assertTrue(!actualValue.isEmpty());

	}

	@DisplayName("Test case getResource method for json null")
	@Test
	void test_getResourceForJsonNull() {
		String resourceType = ResourceType.Organization.name();
		String resourceId = "Kern-coveragetest";
		String resourceIdWithPrefix = "Kern-coveragetest";

		List<String> jsons = new ArrayList<>();
		when(commonQueryUtil.findPrefixValue(resourceType, resourceId.trim())).thenReturn(resourceIdWithPrefix);
		when(fhirRepositoryAdapter.getResourceJsons(Arrays.asList(resourceIdWithPrefix.trim()), resourceType))
				.thenReturn(jsons);
		IBaseResource actualValue = searchService.getResource(resourceId, resourceType);
		IBaseResource expectedValue = null;
		assertEquals(expectedValue, actualValue);

	}

	@DisplayName("Test case getResource method for SearchServiceException")
	@Test
	void test_getResourceForException() {
		String resourceType = ResourceType.Organization.name();
		String resourceId = "Kern-coveragetest";
		String resourceIdWithPrefix = "Kern-coveragetest";

		when(commonQueryUtil.findPrefixValue(resourceType, resourceId.trim())).thenReturn(resourceIdWithPrefix);
		when(fhirRepositoryAdapter.getResourceJsons(Arrays.asList(resourceIdWithPrefix.trim()), resourceType))
				.thenThrow(new FHIRException("FPE-1002"));
		SearchServiceException exception = assertThrows(SearchServiceException.class,
				() -> searchService.getResource(resourceId, resourceType));
		assertEquals(ExceptionCodes.DB_CONNECTION_ERROR.getCode(), exception.getMessage());

	}

	@DisplayName("Test case getResource method for Json size zero")
	@Test
	void test_getResourceForJsonSizeZero() {
		String resourceType = ResourceType.Organization.name();
		String resourceId = "Kern-coveragetest";
		String resourceIdWithPrefix = "Kern-coveragetest";

		List<String> jsons = new ArrayList<>(0);
		when(commonQueryUtil.findPrefixValue(resourceType, resourceId.trim())).thenReturn(resourceIdWithPrefix);
		when(fhirRepositoryAdapter.getResourceJsons(Arrays.asList(resourceIdWithPrefix.trim()), resourceType))
				.thenReturn(jsons);
		IBaseResource actualValue = searchService.getResource(resourceId, resourceType);
		IBaseResource expectedValue = null;
		assertEquals(expectedValue, actualValue);

	}

	@DisplayName("Test case getResourcesByIds method")
	@Test
	void test_getResourcesByIds() {
		String resourceType = ResourceType.DocumentReference.name();
		String resourceId = "Kern-coveragetest";
		List<IdProjectionRow> listOfResourceIds = new ArrayList<>();
		listOfResourceIds.add(new IdProjectionRow(resourceType, resourceId, null));
		Set<String> setOfIncludes = new HashSet<String>();
		Set<String> setOfRevIncludes = new HashSet<String>();
		SearchResult searchResult = new SearchResult(listOfResourceIds, setOfIncludes, setOfRevIncludes);

		Map<String, List<Serializable>> resourceIdsMap = new HashMap<>();
		List<Serializable> value = new ArrayList<>();
		value.add(resourceId);
		resourceIdsMap.put(resourceType, value);

		Map<String, List<String>> jsons = new HashMap<>();
		List<String> jsonValues = new ArrayList<>();
		String jsonValue = "{\"id\": \"kern-documentreference-0012446\", \"date\": \"1937-01-12T16:21:00-05:00\", \"meta\": {\"tag\": [{\"code\": \"actionable\", \"system\": \"http://terminology.hl7.org/CodeSystem/common-tags\", \"display\": \"Actionable\"}], \"source\": \"http://hl7.org/fhir/us/core/StructureDefinition/us-core-documentreference\", \"profile\": [\"https://www.hl7.org/fhir/us/core/StructureDefinition-us-core-documentreference.html\"], \"security\": [{\"code\": \"L\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-Confidentiality\", \"display\": \"low\", \"userSelected\": true}], \"versionId\": \"1\", \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"}, \"type\": {\"coding\": [{\"code\": \"34117-2\", \"system\": \"http://loinc.org\", \"display\": \"History and physical note\"}, {\"code\": \"51847-2\", \"system\": \"http://loinc.org\", \"display\": \"Evaluation+Plan note\"}]}, \"author\": [{\"display\": \"Dr. Breanne585 Welch179\", \"reference\": \"urn:uuid:b1e8c868-9426-3d8c-850b-08b9c6e75b71\"}], \"status\": \"superseded\", \"content\": [{\"format\": {\"code\": \"urn:ihe:iti:xds:2017:mimeTypeSufficient\", \"system\": \"http://ihe.net/fhir/ValueSet/IHE.FormatCode.codesystem\", \"display\": \"mimeType Sufficient\"}, \"attachment\": {\"data\": \"CjIwMTktMDEtMDEKCiMgQ2hpZWYgQ29tcGxhaW50Ck5vIGNvbXBsYWludHMuCgojIEhpc3Rvcnkgb2YgUHJlc2VudCBJbGxuZXNzCkhpZW45OCBpcyBhIDE0IHllYXItb2xkIG5vbi1oaXNwYW5pYyBhc2lhbiBmZW1hbGUuIFBhdGllbnQgaGFzIGEgaGlzdG9yeSBvZiBzdHJlcHRvY29jY2FsIHNvcmUgdGhyb2F0IChkaXNvcmRlciksIGFjdXRlIGJhY3RlcmlhbCBzaW51c2l0aXMgKGRpc29yZGVyKSwgbGFjZXJhdGlvbiBvZiBmb290LCBhY3V0ZSB2aXJhbCBwaGFyeW5naXRpcyAoZGlzb3JkZXIpLgoKIyBTb2NpYWwgSGlzdG9yeQogUGF0aWVudCBoYXMgbmV2ZXIgc21va2VkLgoKUGF0aWVudCBjb21lcyBmcm9tIGEgbWlkZGxlIHNvY2lvZWNvbm9taWMgYmFja2dyb3VuZC4gUGF0aWVudCBjdXJyZW50bHkgaGFzIENpZ25hIEhlYWx0aC4KCiMgQWxsZXJnaWVzCk5vIEtub3duIEFsbGVyZ2llcy4KCiMgTWVkaWNhdGlvbnMKcGVuaWNpbGxpbiB2IHBvdGFzc2l1bSAyNTAgbWcgb3JhbCB0YWJsZXQ7IGlidXByb2ZlbiAxMDAgbWcgb3JhbCB0YWJsZXQ7IGFtb3hpY2lsbGluIDI1MCBtZyAvIGNsYXZ1bGFuYXRlIDEyNSBtZyBvcmFsIHRhYmxldAoKIyBBc3Nlc3NtZW50IGFuZCBQbGFuClBhdGllbnQgaXMgcHJlc2VudGluZyB3aXRoIGJvZHkgbWFzcyBpbmRleCAzMCsgLSBvYmVzaXR5IChmaW5kaW5nKS4gCgojIyBQbGFuClBhdGllbnQgd2FzIGdpdmVuIHRoZSBmb2xsb3dpbmcgaW1tdW5pemF0aW9uczogaW5mbHVlbnphLCBzZWFzb25hbCwgaW5qZWN0YWJsZSwgcHJlc2VydmF0aXZlIGZyZWUuIAo=\", \"contentType\": \"text/plain\"}}], \"context\": {\"period\": {\"end\": \"1937-01-12T16:38:00-05:00\", \"start\": \"1937-01-12T16:21:00-05:00\"}, \"encounter\": [{\"reference\": \"urn:uuid:d3b34687-666a-77e9-1e28-e183304fd554\"}]}, \"subject\": {\"reference\": \"urn:uuid:7b7709ff-a107-49ea-8211-56771b65cd19\"}, \"category\": [{\"coding\": [{\"code\": \"clinical-note\", \"system\": \"http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category\", \"display\": \"Clinical Note\"}]}], \"custodian\": {\"display\": \"PCP34976\", \"reference\": \"urn:uuid:9d73e9e1-4826-3ee7-bef6-717056636ceb\"}, \"identifier\": [{\"value\": \"05245b11-7e9e-c5f0-cbf1-359b0bf87df7\", \"system\": \"urn:ietf:rfc:3986\"}], \"resourceType\": \"DocumentReference\"}";
		jsonValues.add(jsonValue);
		jsons.put(resourceType, jsonValues);
		when(fhirRepositoryAdapter.getResourceJsons(resourceIdsMap)).thenReturn(jsons);

		Map<String, List<Serializable>> includedIdsMap = new HashMap<>();
		Map<String, List<String>> includedJsons = new HashMap<>();
		when(fhirRepositoryAdapter.getResourceJsons(includedIdsMap)).thenReturn(includedJsons);
		List<IBaseResource> result = searchService.getResourcesByIds(searchResult);
		int actualValue = result.size();
		int expectedValue = jsonValues.size() + includedJsons.size();
		assertEquals(expectedValue, actualValue);

	}

	@DisplayName("Test case getResourcesByIds method for include")
	@Test
	void test_getResourcesByIdsForInclude() {
		String resourceType = ResourceType.Coverage.name();
		String resourceId = "27b407a1-80ee-89bc-267f-710e578e7625";
		String includeValue = "Coverage:payor";
		String includedIdValue = "Kern-org-Org-101";

		List<IdProjectionRow> listOfResourceIds = new ArrayList<>();
		listOfResourceIds.add(new IdProjectionRow(resourceType, resourceId, null));
		Set<String> setOfIncludes = new HashSet<String>();
		setOfIncludes.add(includeValue);
		Set<String> setOfRevIncludes = new HashSet<String>();
		SearchResult searchResult = new SearchResult(listOfResourceIds, setOfIncludes, setOfRevIncludes);

		Map<String, List<Serializable>> resourceIdsMap = new HashMap<>();
		List<Serializable> value = new ArrayList<>();
		value.add(resourceId);
		resourceIdsMap.put(resourceType, value);

		Set<Include> includeSet = Collections.emptySet();
		includeSet = searchResult.getSetOfIncludes().stream().map(Include::new).collect(Collectors.toSet());

		Map<String, List<String>> jsons = new HashMap<>();
		List<String> jsonValues = new ArrayList<>();
		String jsonValue = "{\"id\": \"27b407a1-80ee-89bc-267f-710e578e7625\", \"meta\": {\"profile\": [\"http://hl7.org/fhir/us/carin-bb/StructureDefinition/C4BB-Coverage\"], \"lastUpdated\": \"2021-01-16T00:00:00.000+00:00\"}, \"type\": {\"coding\": [{\"code\": \"RETIRE\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-ActCode\"}]}, \"class\": [{\"name\": \"Emp_group name3\", \"type\": {\"coding\": [{\"code\": \"group\", \"system\": \"http://terminology.hl7.org/CodeSystem/coverage-class\"}]}, \"value\": \"Emp_group_103\"}, {\"name\": \"sub group name3\", \"type\": {\"coding\": [{\"code\": \"subgroup\", \"system\": \"http://terminology.hl7.org/CodeSystem/coverage-class\"}]}, \"value\": \"subgroup-103\"}, {\"name\": \"Plan name 3\", \"type\": {\"coding\": [{\"code\": \"plan\", \"system\": \"http://terminology.hl7.org/CodeSystem/coverage-class\"}]}, \"value\": \"Plan-103\"}], \"payor\": [{\"reference\": \"Organization/Kern-org-Org-101\"}], \"period\": {\"end\": \"2016-07-12T00:00:00+00:00\", \"start\": \"2015-05-13T00:00:00+00:00\"}, \"status\": \"draft\", \"network\": \"Net-102\", \"identifier\": [{\"type\": {\"coding\": [{\"code\": \"Memberid\"}]}, \"value\": \"Mem-1001233\", \"system\": \"https://www.khp.com/fhir/memberidentifier\"}], \"beneficiary\": {\"reference\": \"urn:uuid:7b7709ff-a107-49ea-8211-56771b65cd19\"}, \"relationship\": {\"coding\": [{\"code\": \"spouse\", \"system\": \"http://terminology.hl7.org/CodeSystem/subscriber-relationship\"}]}, \"resourceType\": \"Coverage\", \"subscriberId\": \"Subscriber103\", \"costToBeneficiary\": [{\"valueMoney\": {\"value\": 127.23, \"currency\": \"USD\"}}, {\"valueMoney\": {\"value\": 25.25, \"currency\": \"USD\"}}, {\"valueMoney\": {\"value\": 30, \"currency\": \"USD\"}}, {\"valueMoney\": {\"value\": 100.25, \"currency\": \"USD\"}}, {\"valueMoney\": {\"value\": 105, \"currency\": \"USD\"}}, {\"valueMoney\": {\"value\": 225, \"currency\": \"USD\"}}, {\"valueMoney\": {\"currency\": \"USD\"}}, {\"valueMoney\": {\"currency\": \"USD\"}}, {\"valueMoney\": {\"currency\": \"USD\"}}]}";
		jsonValues.add(jsonValue);
		jsons.put(resourceType, jsonValues);
		when(fhirRepositoryAdapter.getResourceJsons(resourceIdsMap)).thenReturn(jsons);

		Map<String, List<Serializable>> includedIdsMap = new HashMap<>();
		List<Serializable> includedIdsMapValues = new ArrayList<>();
		includedIdsMapValues.add(includedIdValue);
		includedIdsMap.put(resourceType, includedIdsMapValues);

		when(fhirRepositoryAdapter.getIncludedIds(listOfResourceIds, includeSet, resourceType))
				.thenReturn(includedIdsMap);

		Map<String, List<String>> includedJsons = new HashMap<>();
		List<String> includedJsonsValues = new ArrayList<>();
		includedJsons.put(resourceType, includedJsonsValues);
		when(fhirRepositoryAdapter.getResourceJsons(includedIdsMap)).thenReturn(includedJsons);

		List<IBaseResource> result = searchService.getResourcesByIds(searchResult);
		int actualValue = result.size();
		int expectedValue = jsonValues.size() + includedJsonsValues.size();
		assertEquals(expectedValue, actualValue);

	}

	@DisplayName("Test case getResourcesByIds method for revinclude provenance")
	@Test
	void test_getResourcesByIdsForRevIncludeProvenance() {
		String resourceType = ResourceType.Encounter.name();
		String resourceId = "kern-encounter-111";
		List<IdProjectionRow> listOfResourceIds = new ArrayList<>();
		listOfResourceIds.add(new IdProjectionRow(resourceType, resourceId, null));
		Set<String> setOfIncludes = new HashSet<String>();
		Set<String> setOfRevIncludes = new HashSet<String>();
		setOfRevIncludes.add("Provenance:target");
		SearchResult searchResult = new SearchResult(listOfResourceIds, setOfIncludes, setOfRevIncludes);

		Map<String, List<Serializable>> resourceIdsMap = new HashMap<>();
		List<Serializable> value = new ArrayList<>();
		value.add(resourceId);
		resourceIdsMap.put(resourceType, value);

		Set<Include> setOfRevIncludesProvenance = Collections.emptySet();
		setOfRevIncludesProvenance = searchResult.getSetOfRevIncludes().stream()
				.filter(str -> str.contains(ResourceType.Provenance.name())).map(Include::new)
				.collect(Collectors.toSet());

		Map<String, List<String>> jsons = new HashMap<>();
		List<String> jsonValues = new ArrayList<>();
		String jsonValue1 = "{\"id\": \"kern-encounter-111\", \"meta\": {\"profile\": [\"http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter\"], \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"}, \"type\": [{\"text\": \"Encounter for problem\", \"coding\": [{\"code\": \"185347001\", \"system\": \"http://snomed.info/sct\", \"display\": \"Encounter for problem\"}]}], \"class\": {\"code\": \"AMB\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-ActCode\"}, \"period\": {\"end\": \"1937-01-12T16:37:00-05:00\", \"start\": \"1937-01-12T16:22:00-05:00\"}, \"status\": \"finished\", \"subject\": {\"display\": \"Mr. Jamey282 Tromp100\", \"reference\": \"urn:uuid:7b7709ff-a107-49ea-8211-56771b65cd19\"}, \"location\": [{\"location\": {\"display\": \"HEYWOOD HOSPITAL -\", \"reference\": \"urn:uuid:e62fdb75-bbce-46e8-a993-6d92fe6065de\"}}], \"identifier\": [{\"use\": \"official\", \"value\": \"2f0f059f-97b9-4e94-871f-dbba5a694b0a\", \"system\": \"https://github.com/synthetichealth/synthea\"}], \"participant\": [{\"type\": [{\"text\": \"primary performer\", \"coding\": [{\"code\": \"PPRF\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-ParticipationType\", \"display\": \"primary performer\"}]}], \"period\": {\"end\": \"1937-01-12T16:37:00-05:00\", \"start\": \"1937-01-12T16:22:00-05:00\"}, \"individual\": {\"display\": \"Dr. Allyn942 Rohan584\", \"reference\": \"urn:uuid:392189dc-eb85-3f0a-b7d5-f7d9d5abadb9\"}}], \"resourceType\": \"Encounter\", \"hospitalization\": {\"dischargeDisposition\": {\"text\": \"Discharged to home care or self care (routine discharge)\", \"coding\": [{\"code\": \"01\", \"system\": \"http://www.nubc.org/patient-discharge\", \"display\": \"Discharged to home care or self care (routine discharge)\"}]}}, \"serviceProvider\": {\"display\": \"HEYWOOD HOSPITAL -\", \"reference\": \"urn:uuid:e44f438a-601b-30fb-85eb-bfaf8ddcb5ad\"}}";
		String jsonValue2 = "{\"id\": \"kern-encounter-111\", \"meta\": {\"profile\": [\"http://hl7.org/fhir/us/core/StructureDefinition/us-core-encounter\"], \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"}, \"type\": [{\"text\": \"Encounter for problem\", \"coding\": [{\"code\": \"185347001\", \"system\": \"http://snomed.info/sct\", \"display\": \"Encounter for problem\"}]}], \"class\": {\"code\": \"AMB\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-ActCode\"}, \"period\": {\"end\": \"1937-01-12T16:37:00-05:00\", \"start\": \"1937-01-12T16:22:00-05:00\"}, \"status\": \"finished\", \"subject\": {\"display\": \"Mr. Jamey282 Tromp100\", \"reference\": \"urn:uuid:7b7709ff-a107-49ea-8211-56771b65cd19\"}, \"location\": [{\"location\": {\"display\": \"HEYWOOD HOSPITAL -\", \"reference\": \"Location/QA-Loc-12444444444\"}}], \"identifier\": [{\"use\": \"official\", \"value\": \"2f0f059f-97b9-4e94-871f-dbba5a694b0a\", \"system\": \"https://github.com/synthetichealth/synthea\"}], \"participant\": [{\"type\": [{\"text\": \"primary performer\", \"coding\": [{\"code\": \"PPRF\", \"system\": \"http://terminology.hl7.org/CodeSystem/v3-ParticipationType\", \"display\": \"primary performer\"}]}], \"period\": {\"end\": \"1937-01-12T16:37:00-05:00\", \"start\": \"1937-01-12T16:22:00-05:00\"}, \"individual\": {\"display\": \"Dr. Allyn942 Rohan584\", \"reference\": \"Practitioner/Kern-pract-902235555554\"}}], \"resourceType\": \"Encounter\", \"hospitalization\": {\"dischargeDisposition\": {\"text\": \"Discharged to home care or self care (routine discharge)\", \"coding\": [{\"code\": \"01\", \"system\": \"http://www.nubc.org/patient-discharge\", \"display\": \"Discharged to home care or self care (routine discharge)\"}]}}, \"serviceProvider\": {\"display\": \"HEYWOOD HOSPITAL -\", \"reference\": \"urn:uuid:e44f438a-601b-30fb-85eb-bfaf8ddcb5ad\"}}";
		jsonValues.add(jsonValue1);
		jsonValues.add(jsonValue2);
		jsons.put(resourceType, jsonValues);
		when(fhirRepositoryAdapter.getResourceJsons(resourceIdsMap)).thenReturn(jsons);

		Map<String, List<Serializable>> includedIdsMap = new HashMap<>();
		List<Serializable> includedIdsMapValues = new ArrayList<>();

		includedIdsMapValues.add("Provenance_GrouPBulk1");
		includedIdsMapValues.add("Kern-provtimezone-2034333888889998");
		includedIdsMapValues.add("Kern-provtimezone-John");
		includedIdsMapValues.add("Kern-provtimezone-Jane");
		includedIdsMapValues.add("Kern-provtimezone-Denver");
		includedIdsMapValues.add("Kern-provtimezone-Sagi");
		includedIdsMapValues.add("Kern-provtimezone-Jenny");
		includedIdsMap.put("Provenance", includedIdsMapValues);

		when(fhirRepositoryAdapter.getRevIncludedIds(listOfResourceIds, setOfRevIncludesProvenance,
				ResourceType.Provenance.name())).thenReturn(includedIdsMap);

		Map<String, List<String>> includedJsons = new HashMap<>();
		List<String> includedJsonsValues = new ArrayList<>();
		String includedJsonValue1 = "{\"id\": \"Kern-provtimezone-2034333888889998\",\"meta\": {\"profile\": [\"http://hl7.org/fhir/us/core/StructureDefinition/us-core-provenance\"    ], \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"},\"agent\": [{     \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Author\",        \"coding\": [          {            \"code\": \"author\",            \"system\": \"http://terminology.hl7.org/CodeSystem/provenance-participant-type\",            \"display\": \"Author\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    },    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Transmitter\",        \"coding\": [          {            \"code\": \"transmitter\",            \"system\": \"http://hl7.org/fhir/us/core/CodeSystem/us-core-provenance-participant-type\",            \"display\": \"Transmitter\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    }  ],  \"target\": [    {      \"reference\": \"MedicationDispense/MD7777\"    },    {      \"reference\": \"Organization/plannet-organization-1230085657\"    },    {      \"reference\": \"Observation/Kern-obs-Obs116332\"    },    {      \"reference\": \"ExplanationOfBenefit/8d38f846-b98a-3010-565c-4f91be9ff3fc\"    },    {      \"reference\": \"Patient/Kern-pat-90001339\"    },    {      \"reference\": \"Location/Kern-loc-2110\"    },    {      \"reference\": \"DocumentReference/kern-documentreference-0012\"    }  ],  \"recorded\": \"2020-03-11T07:52:01.561-04:00\",  \"resourceType\": \"Provenance\"}";
		String includedJsonValue2 = "{\"id\": \"Kern-provtimezone-John\",  \"meta\": {    \"profile\": [      \"http://hl7.org/fhir/us/core/StructureDefinition/us-core-provenance\"    ],    \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"  },  \"agent\": [    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Author\",        \"coding\": [          {            \"code\": \"author\",            \"system\": \"http://terminology.hl7.org/CodeSystem/provenance-participant-type\",            \"display\": \"Author\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    },    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Transmitter\",        \"coding\": [          {            \"code\": \"transmitter\",            \"system\": \"http://hl7.org/fhir/us/core/CodeSystem/us-core-provenance-participant-type\",            \"display\": \"Transmitter\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    }  ],  \"target\": [    {      \"reference\": \"MedicationDispense/MD7777\"    },    {      \"reference\": \"Organization/plannet-organization-1230085657\"    },    {      \"reference\": \"Observation/Kern-obs-Obs116332\"    },    {      \"reference\": \"ExplanationOfBenefit/8d38f846-b98a-3010-565c-4f91be9ff3fc\"    },    {      \"reference\": \"Patient/0de6ac5a-5d21-497f-9301-a4bb1344ba31\"    }  ],  \"recorded\": \"2020-03-11T07:52:01.561-04:00\",  \"resourceType\": \"Provenance\"}";
		String includedJsonValue3 = "{\"id\": \"Kern-provtimezone-Jane\",\"meta\": {\"profile\": [\"http://hl7.org/fhir/us/core/StructureDefinition/us-core-provenance\" ],\"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"}, \"agent\": [    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Author\",        \"coding\": [          {            \"code\": \"author\",            \"system\": \"http://terminology.hl7.org/CodeSystem/provenance-participant-type\",            \"display\": \"Author\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    },    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Transmitter\",        \"coding\": [          {            \"code\": \"transmitter\",            \"system\": \"http://hl7.org/fhir/us/core/CodeSystem/us-core-provenance-participant-type\",            \"display\": \"Transmitter\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    }  ],  \"target\": [    {      \"reference\": \"MedicationDispense/MD7777\"    },    {      \"reference\": \"Organization/plannet-organization-1230085657\"    },    {      \"reference\": \"Observation/Kern-obs-Obs116332\"    },    {      \"reference\": \"ExplanationOfBenefit/8d38f846-b98a-3010-565c-4f91be9ff3fc\"    },    {      \"reference\": \"Patient/abc\"    },    {      \"reference\": \"Location/Kern-loc-2110\"    },    {      \"reference\": \"DocumentReference/kern-documentreference-0012\"    }  ],  \"recorded\": \"2020-03-11T07:52:01.561-04:00\",  \"resourceType\": \"Provenance\"}";
		String includedJsonValue4 = "{  \"id\": \"Kern-provtimezone-Denver\",  \"meta\": {    \"profile\": [      \"http://hl7.org/fhir/us/core/StructureDefinition/us-core-provenance\"    ],    \"lastUpdated\": \"2020-05-15T00:00:00.000+00:00\"  },  \"agent\": [    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Author\",        \"coding\": [          {            \"code\": \"author\",            \"system\": \"http://terminology.hl7.org/CodeSystem/provenance-participant-type\",            \"display\": \"Author\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    },    {      \"who\": {        \"display\": \"Dr. Elyse324 VonRueden376\",        \"reference\": \"Practitioner/73af8f22-a835-32fd-9001-229d102d1373\"      },      \"type\": {        \"text\": \"Transmitter\",        \"coding\": [          {            \"code\": \"transmitter\",            \"system\": \"http://hl7.org/fhir/us/core/CodeSystem/us-core-provenance-participant-type\",            \"display\": \"Transmitter\"          }        ]      },      \"onBehalfOf\": {        \"display\": \"COMMUNITY PHYSICIANS ASSOC INC\",        \"reference\": \"Organization/8353e249-3e71-31f5-9656-7e4826a48810\"      }    }  ],  \"target\": [    {      \"reference\": \"MedicationDispense/MD7777\"    },    {      \"reference\": \"Organization/plannet-organization-1230085657\"    },    {      \"reference\": \"Observation/Kern-obs-Obs116332\"    },    {      \"reference\": \"ExplanationOfBenefit/8d38f846-b98a-3010-565c-4f91be9ff3fc\"    },    {      \"reference\": \"Patient/NotPresent\"    },    {      \"reference\": \"Location/Kern-loc-2110\"    },    {      \"reference\": \"DocumentReference/kern-documentreference-0012\"    }  ],  \"recorded\": \"2020-03-11T07:52:01.561-04:00\",  \"resourceType\": \"Provenance\"}";
		includedJsonsValues.add(includedJsonValue1);
		includedJsonsValues.add(includedJsonValue2);
		includedJsonsValues.add(includedJsonValue3);
		includedJsonsValues.add(includedJsonValue4);
		includedJsons.put("Provenance", includedJsonsValues);
		when(fhirRepositoryAdapter.getResourceJsons(includedIdsMap)).thenReturn(includedJsons);

		List<IBaseResource> result = searchService.getResourcesByIds(searchResult);
		int actualValue = result.size();
		int expectedValue = jsonValues.size() + includedJsonsValues.size();
		assertEquals(expectedValue, actualValue);

	}

	@DisplayName("Test case for getPaginatedIdsForResource")
	@Test
	void test_getPaginatedIdsForResource() {
		String resourceType = ResourceType.ExplanationOfBenefit.name();
		String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		TokenAndListParam param = new TokenAndListParam();
		param.addAnd(new TokenParam(value));
		parameterMap.add(IAnyResource.SP_RES_ID, param);
		parameterMap.setPatientSearchParam(ExplanationOfBenefit.SP_PATIENT);

		List<IdProjectionRow> projectionRows = new ArrayList<>();

		when(fhirRepositoryAdapter.getPaginatedIdsForResource(resourceType, parameterMap)).thenReturn(projectionRows);

		List<IdProjectionRow> actualValue = searchService.getPaginatedIdsForResource(resourceType, parameterMap);
		List<IdProjectionRow> expectedValue = projectionRows;

		assertEquals(expectedValue.toString(), actualValue.toString());

	}

	  @DisplayName("Test case for getPaginatedIdsForResource for InvalidRequestException")
	  @Test 
	  void test_getPaginatedIdsForResourceForInvalidRequestException() { 
		  String resourceType = ResourceType.ExplanationOfBenefit.name(); 
		  SearchParameterRequest parameterMap = new SearchParameterRequest();
	  
		  InvalidRequestException exception = assertThrows(InvalidRequestException.class, () -> searchService.getPaginatedIdsForResource(resourceType, parameterMap));
		  assertEquals(ExceptionCodes.PARAMETER_MISSING.getCode(), exception.getMessage());
	  }

	@DisplayName("Test case for getPaginatedIdsForResource for SearchServiceException")
	@Test
	void test_getPaginatedIdsForResourceForSearchServiceException() {
		String resourceType = ResourceType.ExplanationOfBenefit.name();
		String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		TokenAndListParam param = new TokenAndListParam();
		param.addAnd(new TokenParam(value));
		parameterMap.add(IAnyResource.SP_RES_ID, param);
		parameterMap.setPatientSearchParam(ExplanationOfBenefit.SP_PATIENT);

		when(fhirRepositoryAdapter.getPaginatedIdsForResource(resourceType, parameterMap))
				.thenThrow(new FHIRException("FPE-1002"));

		SearchServiceException exception = assertThrows(SearchServiceException.class,
				() -> searchService.getPaginatedIdsForResource(resourceType, parameterMap));
		assertEquals(ExceptionCodes.DB_CONNECTION_ERROR.getCode(), exception.getMessage());

	}

}

package com.citiustech.fastplus.services;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.server.exceptions.InternalErrorException;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.service.ISearchService;
import com.citiustech.fastplus.service.pagination.CustomBundleProvider;
import com.citiustech.fastplus.util.exception.SearchServiceException;
import com.citiustech.fastplus.util.springcontext.SpringContext;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 
 * This is the service class which will
 * provide read and search methods to all the providers
 *
 */
@Component
public class ProviderDirectoryService {

	/**
	 * This field is interface instance which is used to 
	 * call implemented methods
	 */
    @Autowired
    private ISearchService searchService;
    
    /**
     * This field is used for resolving messages, with support for the 
     * parameterization and internationalization of messages.
     */
    @Autowired
    private MessageSource messageSource;

    /**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(ProviderDirectoryService.class.getName());

    /**
     * This method will return a single resource based on
     * the provided id and resource type
     * @param theId
     * @param resourceType
     * @return a single resource
     */
    public IBaseResource getResourceById(String theId, String resourceType){
        try {
            return searchService.getResource(theId, resourceType);
        } catch (SearchServiceException e) {
            LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error in read operation ");
            throw new InternalErrorException(messageSource.getMessage(e.getMessage(),null, Locale.getDefault()));
        }
    }

    /**
     * This method will return bundle of resources based on
     * the provided search parameter map and resource type
     * @param map
     * @param resourceType
     * @return bundle of resources
     */
    public IBundleProvider getResources(SearchParameterRequest map, String resourceType){
        try {
            List<IdProjectionRow> idProjectionRows = searchService.findResourceIds(resourceType, map);
            Set<String> include = null;
            Set<String> revInclude = null;

            if(Objects.nonNull(map.getIncludes())) {
            	include = map.getIncludes().stream().map(Include::getValue).collect(Collectors.toSet());
            }
            
            if(Objects.nonNull(map.getRevIncludes())) {
            	revInclude = map.getRevIncludes().stream().map(Include::getValue).collect(Collectors.toSet());
            }
            
            return SpringContext.getBeanUsingParameter(CustomBundleProvider.class, new SearchResult(idProjectionRows, include, revInclude));
        } catch (SearchServiceException e) {
            LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error fetching resourceIds for search operation ");
            throw new InternalErrorException(messageSource.getMessage(e.getMessage(),null, Locale.getDefault()));
        } catch (InvalidRequestException e){
            LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Invalid search request ");
            throw new InvalidRequestException(messageSource.getMessage(e.getMessage(),null, Locale.getDefault()));
        }
    }
}
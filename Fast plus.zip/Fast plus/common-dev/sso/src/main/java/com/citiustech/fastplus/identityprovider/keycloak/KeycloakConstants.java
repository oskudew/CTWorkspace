package com.citiustech.fastplus.identityprovider.keycloak;

/**
 * 
 * This is an enum for KeycloakConstants which provides constant values related
 * to keycloak
 * 
 */

public enum KeycloakConstants {

	/**
	 * enum objects to define string constants
	 */
	USERNAME("preferred_username"), CLIENT_NAME("azp"), ROLES("roles"), REALM_ACCESS("realm_access"),
	RESOURCE_ACCESS("resource_access"),SCOPE("scope"),USER_ATTRIBUTES("attributes");

	/**
	 * This is a field for value used to hold string value
	 */
	String value;

	/**
	 * parameterized constructor to initialize value field
	 * 
	 * @param value
	 */
	private KeycloakConstants(String value) {
		this.value = value;
	}

	/**
	 * returns value field
	 */
	@Override
	public String toString() {
		return value;
	}
}

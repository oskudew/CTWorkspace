package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.ExplanationOfBenefit;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.test.factory.ReferenceFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.AdapterConsentUtil;

import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;

@ExtendWith(MockitoExtension.class)
class AdapterConsentUtilTest {

	AdapterConsentUtil  adapterConsentUtil = new AdapterConsentUtil(); 
	
	@Test
	void test_setSearchParamForParmeterMapReferenceParam() {
		SearchParameterRequest searchParameterReq = new SearchParameterRequest();
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.newInstance();
		
		searchParameterReq.add(ExplanationOfBenefit.SP_PATIENT,referenceAndListParam);
		List<String> ids = new ArrayList<>();
		ids.add("john");
		ids.add("8d38f846-b98a-3010-565c-4f91be9ff3fc");
		searchParameterReq.setPatientIds(ids);
		searchParameterReq.setPatientSearchParam("patient");
		int oldValue = searchParameterReq.getParameterMap().size();
		
		adapterConsentUtil.setSearchParam(searchParameterReq, ids);
		
		int newValue = searchParameterReq.getParameterMap().size();
		assertTrue(oldValue > newValue);
		
	}
	
	@DisplayName("Test case for setSearchParam method for parameterMap tokenPram")
	@Test
	void test_setSearchParamForParmeterMapTokenParam() {
		
		TokenAndListParam tokenAndListParam = new TokenFactory().newInstance();
		SearchParameterRequest searchParameterReq = new SearchParameterRequest();
		
		searchParameterReq.add(ExplanationOfBenefit.SP_PATIENT,tokenAndListParam);
		List<String> ids = new ArrayList<>();
		ids.add("john");
		ids.add("8d38f846-b98a-3010-565c-4f91be9ff3fc");
		searchParameterReq.setPatientIds(ids);
		searchParameterReq.setPatientSearchParam("patient");
		int oldValue = searchParameterReq.getParameterMap().size();
		
		adapterConsentUtil.setSearchParam(searchParameterReq, ids);
		
		int newValue = searchParameterReq.getParameterMap().size();
		assertTrue(oldValue > newValue);
		
	}
	
	@DisplayName("Test case for setSearchParam method where patientSearchParam is id")
	@Test
	void test_setSearchParamForTokenParam() {
		SearchParameterRequest searchParameterReq = new SearchParameterRequest();
		List<String> ids = new ArrayList<>();
		ids.add("83b04146-da80-d342-6f37-d06cc4b3c770");
		searchParameterReq.setPatientIds(ids);
		searchParameterReq.setPatientSearchParam(IAnyResource.SP_RES_ID);
		int oldValue = searchParameterReq.getParameterMap().size();
		
		adapterConsentUtil.setSearchParam(searchParameterReq, ids);
		
		int newValue = searchParameterReq.getParameterMap().size();
		assertTrue(oldValue < newValue);
		
	}
	
	@DisplayName("Test case for setSearchParam method where patientSearchParam is not id")
	@Test
	void test_setSearchParamForReferenceParam() {
		SearchParameterRequest searchParameterReq = new SearchParameterRequest();
		List<String> ids = new ArrayList<>();
		ids.add("83b04146-da80-d342-6f37-d06cc4b3c770");
		searchParameterReq.setPatientIds(ids);
		searchParameterReq.setPatientSearchParam("patient");
		int oldValue = searchParameterReq.getParameterMap().size();
		
		adapterConsentUtil.setSearchParam(searchParameterReq, ids);
		
		int newValue = searchParameterReq.getParameterMap().size();
		assertTrue(oldValue < newValue);
		
	}
	
}

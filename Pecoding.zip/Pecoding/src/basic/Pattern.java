package basic;

import java.util.Scanner;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		int st=n/2+1,sp=1;
		for(int i=1;i<=n;i++) {
			
			for(int j=1;j<=st;j++) {
				System.out.print("*");
			}
			for(int k=1;k<=sp;k++) {
				System.out.print(" ");
			}
			
			for(int j=1;j<=st;j++) {
				System.out.print("*");
			}
			
			if(i<=n/2) {
				
				
				//System.out.println(st +" "+ sp+" "+st);
				st=st-1;
				sp=sp+2;
				
				
			}
			else {
				//System.out.println(st +" "+ sp+" "+st);
				st=st+1;
				sp=sp-2;
				
			}
			
			System.out.println();
			
			
		}
		

	}

}

package com.citiustech.fastplus.service.pagination;

import java.util.Locale;
import java.util.UUID;

import org.apache.commons.lang3.Validate;
import org.springframework.context.MessageSource;
import org.springframework.data.redis.core.RedisTemplate;

import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.springcontext.SpringContext;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.BasePagingProvider;
import ca.uhn.fhir.rest.server.IPagingProvider;
import ca.uhn.fhir.rest.server.exceptions.InternalErrorException;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;

public class CustomPagingProvider extends BasePagingProvider implements IPagingProvider {

	/**
	 * This is the logger field used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(CustomPagingProvider.class.getName());

	/**
	 * This field is a messageSource used for resolving messages, with support for
	 * the parameterization and internationalization of messages.
	 */
	private MessageSource messageSource;

	/**
	 * This is the redisTemplate field used to hold redisTemplate object
	 */
	private RedisTemplate<String, Object> redisTemplate;

	/**
	 * Single argument constructor
	 * @param theSize
	 */
	public CustomPagingProvider(int theSize) {
		Validate.isTrue(theSize > 0, "theSize must be greater than 0");

		redisTemplate = SpringContext.getBeanFromString("redisTemplate", RedisTemplate.class);
		messageSource = SpringContext.getBeanFromString("messageSource", MessageSource.class);
	}

	@Override
	public IBundleProvider retrieveResultList(RequestDetails theRequest, String theId) {
		SearchResult matchingResourceIds;
		CustomBundleProvider bundleProvider;
		try {
			matchingResourceIds = (SearchResult) redisTemplate.opsForHash().get("pagination", theId);
			if(matchingResourceIds == null) {
				throw new InvalidRequestException("Invalid Pagination Id");
			}
		}catch (InvalidRequestException e) {
			LOGGER.logError("Error occurred while retriving Custom bundle provider : Invalid Pagination Id",
					LoggingConstants.LoggingMarkers.APPLICATION.getValue(), e);
			throw new InvalidRequestException(messageSource.getMessage(ExceptionCodes.INVALID_REQUEST.toString(),
					null, Locale.getDefault()), e);
		} catch (Exception e) {
			LOGGER.logError("Error occurred while retriving Custom bundle provider :",
					LoggingConstants.LoggingMarkers.APPLICATION.getValue(), e);
			throw new InternalErrorException(messageSource.getMessage(ExceptionCodes.REDIS_CONNECTION_ERROR.toString(),
					null, Locale.getDefault()), e);
		}
		bundleProvider = SpringContext.getBeanUsingParameter(CustomBundleProvider.class, matchingResourceIds);
		return bundleProvider;
	}

	@Override
	public String storeResultList(RequestDetails theRequestDetails, IBundleProvider theList) {
		String key = UUID.randomUUID().toString();
		CustomBundleProvider bundleProvider = (CustomBundleProvider) theList;
		try {
			redisTemplate.opsForHash().put("pagination", key, bundleProvider.getMyMatchingResourceIds());
		} catch (Exception e) {
			LOGGER.logError("Error occurred while storing Custom bundle provider :" + theList.size(),
					LoggingConstants.LoggingMarkers.APPLICATION.getValue(), e);
			throw new InternalErrorException(messageSource.getMessage(ExceptionCodes.REDIS_CONNECTION_ERROR.toString(),
					null, Locale.getDefault()), e);
		}
		return key;
	}

}

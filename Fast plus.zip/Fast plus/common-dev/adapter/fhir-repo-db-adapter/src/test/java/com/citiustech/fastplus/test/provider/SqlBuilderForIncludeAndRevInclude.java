package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.ReferenceParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.UriParamQueryFragmentBuilder;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

@ExtendWith(MockitoExtension.class)
class SqlBuilderForIncludeAndRevIncludeTest {

	@InjectMocks
	private DeepNestedSqlBuilder deepNestedSqlBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Spy
	private static BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Spy
	private static ProjectionAndSortingHelper projectionAndSortingHelper;
	
	@Spy
	private static FHIRErrorHandler fhirErrorHandler;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;
		CustomResourceUtil customResourceUtil;
		TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;
		
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
        fhirErrorHandler = new FHIRErrorHandler();
        
        Map<String, String> customResourceMap = new HashMap<>();
        customResourceMap.put("FormularyDrug", "com.citiustech.fastplus.r4.model.DavinciFormularyDrug");
        customResourceMap.put("DocumentReference", "com.citiustech.fastplus.r4.model.USCoreDocumentReference");
        customResourceMap.put("ExplanationOfBenefit", "com.citiustech.fastplus.r4.model.USCoreExplanationOfBenefit");
        
		customResourceUtil = new CustomResourceUtil(customResourceMap);
		CommonQueryUtil commonQueryUtil = new CommonQueryUtil(fhirErrorHandler,customResourceUtil);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
        stringParamQueryFragmentBuilder =  new StringParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        tokenParamQueryFragmentBuilder = new TokenParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil,
        		fhirErrorHandler);
        referenceParamQueryFragmentBuilder = new ReferenceParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        dateRangeParamQueryFragmentBuilder = new DateRangeParamQueryFragmentBuilder(customResourceUtil, commonQueryUtil, fhirErrorHandler,
        		fhirRepositoryTableConfiguration);
        uriParamQueryFragmentBuilder = new UriParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        
        baseTypeQueryFragmentBuilder = new BaseTypeQueryFragmentBuilder(fhirRepositoryTableConfiguration,
        		stringParamQueryFragmentBuilder, tokenParamQueryFragmentBuilder, referenceParamQueryFragmentBuilder,
        		dateRangeParamQueryFragmentBuilder);
        
        baseTypeQueryFragmentBuilder.setCustomResourceUtil(customResourceUtil);
        baseTypeQueryFragmentBuilder.setFhirErrorHandler(fhirErrorHandler);
        baseTypeQueryFragmentBuilder.setUriParamQueryFragmentBuilder(uriParamQueryFragmentBuilder);
        
        projectionAndSortingHelper = new ProjectionAndSortingHelper(fhirRepositoryTableConfiguration, customResourceUtil,
        		fhirErrorHandler);
	}
	
	@DisplayName("Test case for String parameter and revinclude  with or condition")
	@Test
	void test_BuildNestedQueriesForStringAndRevInclude() {
		
		String resourceType =  ResourceType.Practitioner.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("john"))
				.addStringParam(new StringParam("johnie"))
				.newInstance();
		
		Set<Include> revIncludes = new HashSet<>();
		Include revInclude = new Include("PractitionerRole:practitioner",Boolean.TRUE);
		revIncludes.add(revInclude);
		
		searchParamMap.add(Practitioner.SP_GIVEN, stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		if (revIncludes != null && !revIncludes.isEmpty()){
			searchParamMap.setRevIncludes(revIncludes);
		}
		
		String randomAlphabeticString1 = "cAir";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT DISTINCT PractitionercAir.id FROM practitionersearch PractitionercAir WHERE (((PractitionercAir.attribute = 'given') AND (PractitionercAir.value ILIKE 'john%')) OR ((PractitionercAir.attribute = 'given') AND (PractitionercAir.value ILIKE 'johnie%'))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	
	@DisplayName("Test case for Token,Date parameter and includes")
	@Test
	void test_BuildNestedQueriesForStringAndInclude() {
		
		String resourceType =  ResourceType.ExplanationOfBenefit.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.addTokenParam(new TokenParam("", "Kern-EOB-Include-1")).newInstance();

		DateParam date = new DateParam("2020-10-21");
		DateRangeParam rangeParam = new DateRangeParam(date);
		
		Set<Include> includes = new HashSet<>();
		Include include1 = new Include("ExplanationOfBenefit:provider",Boolean.FALSE);
		Include include2 = new Include("ExplanationOfBenefit:insurer",Boolean.FALSE);
		Include include3 = new Include("ExplanationOfBenefit:careteam",Boolean.FALSE);
		includes.add(include1);
		includes.add(include2);
		includes.add(include3);
		
		searchParamMap.add(IAnyResource.SP_RES_ID, tokenAndListParam);
		searchParamMap.setIncludes(includes);
		searchParamMap.add(TestConstants.SP_LAST_UPDATED, rangeParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "JLiO";
		String randomAlphabeticString2 = "LfPr";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		String actualValue = deepNestedSqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT ExplanationOfBenefitJLiO.id,ExplanationOfBenefitJLiO.patient_id FROM explanationofbenefitsearch ExplanationOfBenefitJLiO WHERE (((ExplanationOfBenefitJLiO.attribute = '_id') AND (ExplanationOfBenefitJLiO.code = 'Kern-EOB-Include-1')) " + 
				"AND (EXISTS (SELECT 1 FROM explanationofbenefitsearch ExplanationOfBenefitLfPr WHERE (((ExplanationOfBenefitLfPr.attribute = '_id') AND (date_trunc('day',ExplanationOfBenefitLfPr.lastupdated) = '2020-10-21 00:00:00')) AND (ExplanationOfBenefitJLiO.id = ExplanationOfBenefitLfPr.id))))) ORDER BY ExplanationOfBenefitJLiO.id LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	    
}

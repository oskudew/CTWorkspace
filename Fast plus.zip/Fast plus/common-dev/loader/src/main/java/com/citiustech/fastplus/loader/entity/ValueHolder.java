package com.citiustech.fastplus.loader.entity;

public class ValueHolder {
    private String system;
    private String code;
    private String value;
    private String startvalue;
    private String endvalue;
    private String unit;
    private String trgtType;

    public String getTrgtType() {
        return trgtType;
    }

    public void setTrgtType(String trgtType) {
        this.trgtType = trgtType;
    }

    public String getSystem() { return system; }

    public void setSystem(String system) { this.system = system; }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() { return value; }

    public void setValue(String value) {
        this.value = value;
    }

    public String getStartvalue() {
        return startvalue;
    }

    public void setStartvalue(String startvalue) { this.startvalue = blankCheck(startvalue); }

    public String getEndvalue() {
        return endvalue;
    }

    public void setEndvalue(String endvalue) { this.endvalue = blankCheck(endvalue); }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return value;
    }

    public String blankCheck(String setValue) {
        String newVal = null;
        if (!setValue.equals("")) {
            newVal = setValue;
        }
        return newVal;
    }
}

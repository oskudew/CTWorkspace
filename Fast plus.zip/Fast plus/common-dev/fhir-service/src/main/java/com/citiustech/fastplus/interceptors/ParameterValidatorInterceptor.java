package com.citiustech.fastplus.interceptors;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;
import ca.uhn.fhir.rest.server.servlet.ServletRequestDetails;
import ca.uhn.fhir.util.UrlUtil;

@Component
@Interceptor
public class ParameterValidatorInterceptor {
	
	@Value("#{'${underscore.supported.parameter:}'.split(',')}")
	private List<String> underscoreParameterList;

	@Hook(Pointcut.SERVER_INCOMING_REQUEST_POST_PROCESSED)
	public boolean audit(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		if(httpServletRequest.getMethod().equals("GET")) {
			Map<String, String[]> params = UrlUtil.parseQueryString(httpServletRequest.getQueryString());
			for (String key : params.keySet()) {
				if (key.startsWith("_") && !underscoreParameterList.contains(key)) {
					String requestPath = StringUtils.defaultString(httpServletRequest.getRequestURI());
					
					if (requestPath.length() > 0 && requestPath.contains("/")) {
						requestPath = requestPath.substring(requestPath.lastIndexOf('/'));
						requestPath = requestPath.substring(1);
					}
					
					throw new InvalidRequestException(
							"Invalid request: The FHIR endpoint on this server does not know how to handle GET operation["
									+ requestPath + "] with parameters [[" + params.keySet() + "]]");
				}
			}
		}
		return true;
	}
}
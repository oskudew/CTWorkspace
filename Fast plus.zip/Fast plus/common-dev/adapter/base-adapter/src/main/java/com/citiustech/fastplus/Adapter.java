package com.citiustech.fastplus;

import ca.uhn.fhir.model.api.Include;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 
 * This is an interface for Adapter defines methods to interact with dao classes
 * to perform operations related to a resource
 * 
 */																						
public interface Adapter {
	/**
	 * returns identifiers for a resource based on resource type and search
	 * parameters
	 * 
	 * @param resourceType
	 * @param parameterMap
	 * @return list of identifiers
	 */
	List<IdProjectionRow> getIdsForResource(String resourceType, SearchParameterRequest parameterMap);

	/**
	 * returns resource in a json format based on resource id and type
	 * 
	 * @param ids
	 * @param resourceType
	 * @return String
	 */
	List<String> getResourceJsons(List<Serializable> ids, String resourceType);

	/**
	 * returns a map of resource id as a key and set of includes,for a input resource
	 * type
	 * 
	 * @param listOfBaseIds
	 * @param setOfIncludes
	 * @param resourceType
	 * @return Map
	 */
	Map<String, List<Serializable>> getIncludedIds(List<IdProjectionRow> listOfBaseIds, Set<Include> setOfIncludes,
			String resourceType);

	/**
	 * returns a map of resource id as a key and set of reverse includes,for a input resource
	 * type
	 * 
	 * @param listOfBaseIds
	 * @param setOfRevIncludes
	 * @param resourceType
	 * @return Map
	 */
	Map<String, List<Serializable>> getRevIncludedIds(List<IdProjectionRow> listOfBaseIds,
			Set<Include> setOfRevIncludes, String resourceType);

	/**
	 * returns map of resource id as a key and list of resources in json format
	 * based on input map
	 * 
	 * @param resourceIdsMap
	 * @return Map
	 */
	Map<String, List<String>> getResourceJsons(Map<String, List<Serializable>> resourceIdsMap);
	
	/**
	 * returns resource ids for a resource based on resource type, search
	 * parameters and offset
	 * 
	 * @param resourceType
	 * @param searchParameterReq
	 * @return list
	 */
	List<IdProjectionRow> getPaginatedIdsForResource(String resourceType, SearchParameterRequest searchParameterReq);
	
}

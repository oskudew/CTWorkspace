package com.citiustech.fastplus.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hl7.fhir.r4.model.ResourceType;

import ca.uhn.fhir.model.api.IQueryParameterAnd;
import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.model.api.TemporalPrecisionEnum;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.TokenParam;

/**
 * 
 * This is a class for AdapterUtil which provides utility methods for adapter
 * classes to frame a query
 * 
 */

public final class AdapterUtil {
	private AdapterUtil() {
	}
	
	/**
	 * returns alias column name
	 * 
	 * @param table
	 * @param column
	 * @return String
	 */
    public static String getAliasedColumn(String table, String column) {
        return table + "." + column;
    }

    /**
     * returns formatted string
     * 
     * @param input
     * @param args
     * @return String
     */
    public static String formattedString(String input, Object... args) {
        return String.format(input, Arrays.stream(args).map(q -> q.toString().toUpperCase(Locale.ROOT)).toArray());
    }
    
    /**
     * returns casted column name
     * 
     * @param table
     * @param column
     * @param precision
     * @return String
     */
    public static String getCastedColumn(String table, String column, TemporalPrecisionEnum precision) {
      	
    	return "date_trunc('"+precision.toString().toLowerCase()+"',"+ table + "." + column+ ")";
    }
    
    /**
     * returns a input date in a time stamp format
     * 
     * @param date
     * @return String
     */
    public static String getTimestampFnStr(Date date) {
    	return String.format("TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS')", String.valueOf(date));
    }

    /**
     * returns parameters in string format
     * 
     * @param input
     * @return List of String
     */
    @SuppressWarnings({ "rawtypes", "unchecked" }) 
    public static List<String> getParamList(IQueryParameterAnd input){
		List<String> queryParamTypes= new ArrayList<>();
		List<IQueryParameterOr> queryTokens = input.getValuesAsQueryTokens();
		for(IQueryParameterOr orParam : queryTokens) {
			for(Object queryParamType :orParam.getValuesAsQueryTokens()) {
				String param= queryParamType instanceof TokenParam?
    					((TokenParam) queryParamType).getValue(): null;	
				String ref= queryParamType instanceof ReferenceParam?
    					((ReferenceParam)queryParamType).getIdPart():
        				param;
				queryParamTypes.add(ref);
			}
					
		}
		return queryParamTypes;
    }
    
    
    /**
     * extracts package name from resource 
     * 
     * @param resourceName
     */
    public static String getResourcePkg(String resourceName) {
    	return ResourceType.valueOf(resourceName).getDeclaringClass().getPackage().getName();
    }
}

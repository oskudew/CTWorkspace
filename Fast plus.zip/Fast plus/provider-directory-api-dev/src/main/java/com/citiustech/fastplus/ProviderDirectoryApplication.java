package com.citiustech.fastplus;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.citiustech.fastplus.filereader.attachment.IAttachmentReader;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.context.FhirVersionEnum;

/**
 * This is the main application startup class, which will start the main
 * application and it will create servlet registration bean with
 * applicationContext which will configure the application
 */
@SpringBootApplication(exclude = { SecurityAutoConfiguration.class, UserDetailsServiceAutoConfiguration.class,
		ManagementWebSecurityAutoConfiguration.class })
@ServletComponentScan
public class ProviderDirectoryApplication {

	public static final String ALGORITHM = "PBEWITHSHA256AND256BITAES-CBC-BC";
	public static final String SECRET_KEY = "secretKey";

	@Autowired
	ApplicationContext applicationContext;

	/**
	 * This is fhirVersion field, which will be used to get fhirVersion
	 */
	@Value("${fhir.version:}")
	private String fhirVersion;
	
	/**
	 * This is fhirTimeZone field, which will be used to get Time zone 
	 */
	@Value("${fhir.timezone:}")
	private String fhirTimeZone;

	/**
	 * This is secreteKey field, which will be used to get secreteKey for encryption
	 */
	private static String secretKey;

	/**
	 * This is the logger field which will be used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(ProviderDirectoryApplication.class.getName());

	/**
	 * This is the main method from where application will start
	 *
	 * @param args
	 * @throws IOException
	 */

	/**
	 * This is the attachments reader field which will be used to register
	 * attachment reader bean.
	 */
	@Value("${attachments.reader:staging}")
	private String attachmentReader;
	
	@PostConstruct
	public void init() {
		
		if (!StringUtils.isBlank(fhirTimeZone)) {
			// Setting timeZone if available in properties file
			TimeZone.setDefault(TimeZone.getTimeZone(fhirTimeZone));
			LOGGER.logInfo(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Application Default timeZone : " + TimeZone.getTimeZone(fhirTimeZone).getID());
		}
	}
	
	public static void main(String[] args) throws Exception{
		secretKey = System.getenv(SECRET_KEY);
		if (secretKey == null) {
			throw new Exception("Secret key must be set before starting the application");
		}
		LOGGER.logInfo(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Starting application...");
		SpringApplication.run(ProviderDirectoryApplication.class, args);
	}

	/**
	 * This is secreteKey field, which will be used to get secreteKey for encryption
	 */
	@Bean("fhirContext")
	public FhirContext getFhirContext() {
		return new FhirContext(FhirVersionEnum.forVersionString(fhirVersion));
	}

	/**
	 * This will create custom encryption bean
	 *
	 * @return will return the custom encryptor
	 */
	@Bean("jasyptStringEncryptor")
	public StringEncryptor stringEncryptor() {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		SimpleStringPBEConfig config = new SimpleStringPBEConfig();
		encryptor.setProvider(new BouncyCastleProvider());
		encryptor.setAlgorithm(ALGORITHM);
		encryptor.setPassword(secretKey);
		encryptor.setConfig(config);
		return encryptor;
	}

	@Bean
	public IAttachmentReader attachmentReader() {
		return (IAttachmentReader) applicationContext.getBean(attachmentReader);
	}
}

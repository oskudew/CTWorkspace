package com.citiustech.fastplus.util.exception;

/**
 * 
 * This is a SearchServiceException class used as custom exception for exception handling 
 * 
 */

public class SearchServiceException extends FHIRException {

	/**
	 * This is a serialVersionUID field used to assign serial version uid to this
	 * class
	 */
	private static final long serialVersionUID = 266081170323723098L;

	/**
	 * parameterized constructor
	 * 
	 * @param message
	 */
	public SearchServiceException(String message) {
        super(message);
    }

	/**
	 * parameterized constructor
	 * 
	 * @param message
	 * @param throwable
	 */
    public SearchServiceException(String message, Throwable throwable) {
        super(message, throwable);
    }

    /**
     * parameterized constructor
     * 
     * @param throwable
     */
    public SearchServiceException(Throwable throwable) {
        super(throwable);
    }
}
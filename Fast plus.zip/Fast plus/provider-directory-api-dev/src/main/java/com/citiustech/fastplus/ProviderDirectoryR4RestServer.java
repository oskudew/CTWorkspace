package com.citiustech.fastplus;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.citiustech.fastplus.interceptors.CustomExceptionHandlingInterceptor;
import com.citiustech.fastplus.interceptors.FHIRAuditInterceptor;
import com.citiustech.fastplus.interceptors.FHIRBaseUrlInterceptor;
import com.citiustech.fastplus.interceptors.ParameterValidatorInterceptor;
import com.citiustech.fastplus.r4.resource.provider.ContractResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.CoveragePlanResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.EndpointResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.FormularyDrugResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.HealthcareServiceResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.InsurancePlanResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.LocationResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.OIDCProvider;
import com.citiustech.fastplus.r4.resource.provider.OrganizationAffiliationResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.OrganizationResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.PractitionerResourceProvider;
import com.citiustech.fastplus.r4.resource.provider.PractitionerRoleResourceProvider;
import com.citiustech.fastplus.service.pagination.CustomPagingProvider;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.rest.api.Constants;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.rest.server.RestfulServer;


/**
 * 
 * This class provides the configuration for R4RestServer. It will register all
 * the providers. Also adds the configuration for the pagination.
 *
 */
@WebServlet(urlPatterns= {"/*"}, displayName="ProviderDirectoryServlet")
public class ProviderDirectoryR4RestServer extends RestfulServer {

	private static final long serialVersionUID = 1L;

	/**
	 * This is ApplicationContext field, which will be used to get the required
	 * beans
	 */
	@Autowired
    private ApplicationContext appContext;
	
	/**
	 * This is fhirContext field, which will be used to get the fhirContext
	 */
	@Autowired
    private FhirContext fhirContext;

	@Override
	protected void initialize() throws ServletException {
		super.initialize();
		setFhirContext(fhirContext);
		int defaultPageSize;
		int maxPageSize;

		List<IResourceProvider> theProviders = Arrays.asList(appContext.getBean(LocationResourceProvider.class),
				appContext.getBean(PractitionerResourceProvider.class),
				appContext.getBean(PractitionerRoleResourceProvider.class),
				appContext.getBean(HealthcareServiceResourceProvider.class),
				appContext.getBean(EndpointResourceProvider.class),
				appContext.getBean(OrganizationResourceProvider.class),
				appContext.getBean(OrganizationAffiliationResourceProvider.class),
				appContext.getBean(InsurancePlanResourceProvider.class),
				appContext.getBean(CoveragePlanResourceProvider.class),
				appContext.getBean(FormularyDrugResourceProvider.class),
				appContext.getBean(ContractResourceProvider.class),
				appContext.getBean(OIDCProvider.class));
		
		registerProviders(theProviders);

		registerInterceptor(new FHIRAuditInterceptor(appContext));
		registerInterceptor(appContext.getBean(FHIRBaseUrlInterceptor.class));
		registerInterceptor(appContext.getBean(ParameterValidatorInterceptor.class));
		registerInterceptor(new CustomExceptionHandlingInterceptor());
		registerInterceptor(appContext.getBean(CapabilityStatementCustomizer.class));

		CustomPagingProvider pagingProvider = new CustomPagingProvider(10);
		defaultPageSize = Integer.parseInt(getProperty("page.default-size"));
		pagingProvider.setDefaultPageSize(defaultPageSize);
		maxPageSize = Integer.parseInt(getProperty("paging.max.size"));
		pagingProvider.setMaximumPageSize(maxPageSize);
		setPagingProvider(pagingProvider);

	}

	private String getProperty(String propertyName) {
		return appContext.getEnvironment().getProperty(propertyName);
	}

	@Override
	public void addHeadersToResponse(HttpServletResponse theHttpResponse) {
		theHttpResponse.addHeader("X-Frame-Options", "DENY");
		theHttpResponse.addHeader(Constants.POWERED_BY_HEADER,
				appContext.getEnvironment().getProperty("fhir.software.name"));
		theHttpResponse.addHeader("Content-Security-Policy","default-src 'self'");
		theHttpResponse.addHeader("Expect-CT","max-age=3600, enforce");
	}
}
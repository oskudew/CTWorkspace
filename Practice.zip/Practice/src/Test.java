import java.util.Scanner;

interface A{}
class C{}
class D extends C{}
class B extends D implements A{}
public class Test extends Thread{
	
	public void Method1(int i, float f) {
		System.out.println("1st");
	}
	public int Method1(float i, int f) {
		System.out.println("2st");
		return 0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Test t = new Test();
	//	t.Method1(2,5);
		System.out.println('a'+'b');
		B b= new B();
		if(b instanceof A)
			System.out.println("ba");
		if(b instanceof C)
			System.out.println("bc");
		
		String s1 = new String("poo");
		String s2 = s1;
		//s2="prime";
		System.out.println(s2);

	}

}

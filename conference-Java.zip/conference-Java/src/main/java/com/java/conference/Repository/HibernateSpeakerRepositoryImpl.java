package com.java.conference.Repository;

import java.util.ArrayList;
import java.util.List;

import com.java.conference.model.Speaker;
import org.springframework.stereotype.Component;

@Component("speakerRepository")
public class HibernateSpeakerRepositoryImpl implements SpeakerRepository {

	public List<Speaker> findAll() {
		// TODO Auto-generated method stub
		Speaker s = new Speaker();
		s.setId(1);
		s.setName("naveen");
		
		List<Speaker> l = new ArrayList<Speaker>();
		l.add(s);
		
		return l;
	}
	
	

}

package basic;

import java.util.Scanner;

public class Pattern18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		int is=1;
		int os=n/2;
		int st= 1;
		
		
		
		for(int i=1;i<=n;i++) {
			
			if(i==1) {
				for(int j=1;j<=n;j++) {
					System.out.print("*\t");
				}
			}
			
			else if(i<=n/2) {
				for(int j=1;j<=is;j++) {
					System.out.print("\t");
				}
				System.out.print("*"+ "\t");
				for(int j=1;j<=os;j++) {
					System.out.print("\t");
				}
				System.out.print("*\t");
				
			 is++;
			 os=os-2;
			}
			else {
				for(int j=1;j<=is;j++) {
					System.out.print("\t");
				}
				
				for(int j=1;j<=st;j++) {
					System.out.print("*\t");
				}
				
				
			 is--;
			 st=st+2;
			}
			
			System.out.println();
			
		}
	}

}

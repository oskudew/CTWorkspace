package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 
 * This class is the Location resource provider class
 * which will serves all supported read and search
 * requests for Location resource
 *
 */
@Component
public class LocationResourceProvider implements IResourceProvider {

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
    @Autowired
    private ProviderDirectoryService service;
    
    /**
   	 * This is the logger field which
   	 * will be used to logged the messages
   	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(LocationResourceProvider.class.getName());

    @Override
    public Class<? extends IBaseResource> getResourceType() {
        return Location.class;
    }

    /**
     * This method will return Location resource based on the provided id
     * @param theId
     * @return a single resource
     */
    @Read()
    public IBaseResource getLocationById(@IdParam IdType theId) {
        LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
        return service.getResourceById(theId.getIdPart(), ResourceType.Location.name());
    }

    /**
     * This method will return the bundle of resources based
     * on the search parameters passed in the request
     * @param theId
     * @param name
     * @param adderss
     * @param addressCity
     * @param addressState
     * @param addressPostalCode
     * @param organization,chainParameters{Organization.SP_IDENTIFIER, 
     * Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}
     * @param partOf,chainParameters{Location.SP_IDENTIFIER, 
     * Location.SP_TYPE, Location.SP_ADDRESS}
     * @param endpoint,chainParameters{Endpoint.SP_IDENTIFIER, 
     * Endpoint.SP_CONNECTION_TYPE}
     * @param type
     * @param includes{"Location:endpoint", "Location:organization", 
     * "Location:partof"}
     * @param revIncludes{"HealthcareService:location", 
     * "InsurancePlan:coverage-area", "OrganizationAffiliation:location", 
     * "PractitionerRole:location"}
     * @return bundle of resources
     */
    @Search()
    public IBundleProvider searchLocation(
            @OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
            @OptionalParam(name = Location.SP_NAME) StringAndListParam name,
            @OptionalParam(name = Location.SP_ADDRESS) StringAndListParam adderss,
            @OptionalParam(name = Location.SP_ADDRESS_CITY) StringAndListParam addressCity,
            @OptionalParam(name = Location.SP_ADDRESS_STATE) StringAndListParam addressState,
            @OptionalParam(name = Location.SP_ADDRESS_POSTALCODE) StringAndListParam addressPostalCode,
            @OptionalParam(name = Location.SP_ORGANIZATION , chainWhitelist = {"",Organization.SP_IDENTIFIER, Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}) ReferenceAndListParam organization,
            @OptionalParam(name = Location.SP_PARTOF , chainWhitelist = {"",Location.SP_IDENTIFIER, Location.SP_TYPE, Location.SP_ADDRESS}) ReferenceAndListParam partOf,
            @OptionalParam(name = Location.SP_ENDPOINT , chainWhitelist = {"",Endpoint.SP_IDENTIFIER, Endpoint.SP_CONNECTION_TYPE}) ReferenceAndListParam endpoint,
            @OptionalParam(name = Location.SP_TYPE) TokenAndListParam type,
            @OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
            @IncludeParam(allow = {"Location:endpoint", "Location:organization", "Location:partof"}) Set<Include> includes,
            @IncludeParam(reverse = true, allow = {
                    "HealthcareService:location", "InsurancePlan:coverage-area", "OrganizationAffiliation:location", "PractitionerRole:location"}) Set<Include> revIncludes
    ) {

    	SearchParameterRequest paramMap = new SearchParameterRequest();
            paramMap.add(IAnyResource.SP_RES_ID, theId);
            paramMap.add(Location.SP_NAME, name);
            paramMap.add(Location.SP_ADDRESS, adderss);
            paramMap.add(Location.SP_ADDRESS_CITY,addressCity);
            paramMap.add(Location.SP_ADDRESS_STATE,addressState);
            paramMap.add(Location.SP_ADDRESS_POSTALCODE,addressPostalCode);
            paramMap.add(Location.SP_ORGANIZATION, organization);
            paramMap.add(Location.SP_PARTOF, partOf);
            paramMap.add(Location.SP_ENDPOINT, endpoint);
            paramMap.add(Location.SP_TYPE, type);
            paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
        if (revIncludes != null && !revIncludes.isEmpty()) {
            paramMap.setRevIncludes(revIncludes);
        }
        if (includes != null && !includes.isEmpty()) {
            paramMap.setIncludes(includes);
        }
        LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
        return service.getResources(paramMap, ResourceType.Location.name());
    }

}
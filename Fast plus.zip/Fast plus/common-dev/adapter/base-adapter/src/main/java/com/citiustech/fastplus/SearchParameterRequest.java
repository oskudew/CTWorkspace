package com.citiustech.fastplus;

import ca.uhn.fhir.model.api.IQueryParameterAnd;
import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.api.SortSpec;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

/**
 * This is a class for SearchParameterRequest defines fields to hold the search
 * parameters for search operation
 */
public class SearchParameterRequest implements Serializable {
    /**
     * This is a serialVersionUID field used to assign serial version uid to class
     */
    private static final long serialVersionUID = 1L;

    /**
     * This is a parameterMap field used to hold search parameters
     */
	@SuppressWarnings("rawtypes")
    private Map<String, IQueryParameterAnd> parameterMap = new LinkedHashMap<>();

    /**
     * This is a revIncludes field used to hold reverse included resources
     */
    private Set<Include> revIncludes;

    /**
     * This is a includes field used to hold included resources
     */
    private Set<Include> includes;

    private SortSpec sort;

    /**
     * This is a limit field used to hold limit number
     */
    private Integer limit;

    /**
     * This is a lastUpdated field used to hold last updated date
     */
    private Date lastUpdated;

    /**
     * This is a patientIds field used to hold list of patient identifiers
     */
    private List<String> patientIds;

    /**
     * This is a patientSearchParam field used to search parameter for patient
     */
    private String patientSearchParam;

    /**
     * This is a accessToken field used to hold access token
     */
    private String accessToken;

    /**
     * This is a role field used to hold role
     */
    private String role;
    
    /**
     * This is id field
     * 
     */
    private String id;
    
    private Integer executionSequence;
    
    private String groupId;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public Set<Include> getIncludes() {
        return includes;
    }

    public SearchParameterRequest() {
    }

    /**
	 * @param groupId
	 */
	public SearchParameterRequest(String groupId) {
		super();
		this.groupId = groupId;
	}

	public void setIncludes(Set<Include> includes) {
        if (includes != null)
            this.includes = includes;
    }
	
	@SuppressWarnings("rawtypes")
    public SearchParameterRequest(Map<String, IQueryParameterAnd> parameterMap, Set<Include> revIncludes) {
        this.parameterMap = parameterMap;
        this.revIncludes = revIncludes;
    }

    public void add(String theName, IQueryParameterAnd<?> theAnd) {
        if (theAnd == null) {
            return;
        }
        parameterMap.put(theName, theAnd);
    }

    public Set<Include> getRevIncludes() {
        if (revIncludes == null) {
            revIncludes = new HashSet<>();
        }
        return revIncludes;
    }

    public void setRevIncludes(Set<Include> theRevIncludes) {
        if (theRevIncludes != null)
            revIncludes = theRevIncludes;
    }

    // Wrapper methods
    @SuppressWarnings("rawtypes")
    public IQueryParameterAnd get(String theName) {
        return parameterMap.get(theName);
    }

    public boolean containsKey(String theName) {
        return parameterMap.containsKey(theName);
    }

    public Set<String> keySet() {
        return parameterMap.keySet();
    }

    public boolean isEmpty() {
        return parameterMap.isEmpty();
    }

    @SuppressWarnings("rawtypes")
    public Set<Map.Entry<String, IQueryParameterAnd>> entrySet() {
        return parameterMap.entrySet();
    }

    @SuppressWarnings("rawtypes")
    public IQueryParameterAnd remove(String theName) {
        return parameterMap.remove(theName);
    }

    public int size() {
        return parameterMap.size();
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    @SuppressWarnings("rawtypes")
    public Map<String, IQueryParameterAnd> getParameterMap() {
        return parameterMap;
    }

    @SuppressWarnings("rawtypes")
    public void setParameterMap(Map<String, IQueryParameterAnd> parameterMap) {
        this.parameterMap = parameterMap;
    }

    public List<String> getPatientIds() {
        return patientIds;
    }

    public void setPatientIds(List<String> patientIds) {
        this.patientIds = patientIds;
    }

    public String getPatientSearchParam() {
        return patientSearchParam;
    }

    public void setPatientSearchParam(String patientSearchParam) {
        this.patientSearchParam = patientSearchParam;
    }

    public SortSpec getSort() {
        return sort;
    }

    public void setSort(SortSpec sort) {
        this.sort = sort;
    }
    
    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

    @Override
    public String toString() {
		Map<String,String> map = parameterMap.entrySet().stream().filter(e -> e.getValue() != null).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getKey));
        return "SearchParameterRequest [parameterMap=" + map + ", revIncludes=" + revIncludes + ", includes="
                + includes + "]";
    }

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public Integer getExecutionSequence() {
		return executionSequence;
	}

	public void setExecutionSequence(Integer executionSequence) {
		this.executionSequence = executionSequence;
	}
}

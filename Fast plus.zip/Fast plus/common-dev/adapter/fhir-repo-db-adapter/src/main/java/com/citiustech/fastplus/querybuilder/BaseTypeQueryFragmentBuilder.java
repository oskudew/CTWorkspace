package com.citiustech.fastplus.querybuilder;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.SelectQuery;

import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.model.api.IQueryParameterType;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;
import ca.uhn.fhir.rest.param.CompositeParam;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

/**
 * 
 * This is a class for BaseTypeQueryFragmentBuilder which used to build base
 * type query
 * 
 */

@Component
public class BaseTypeQueryFragmentBuilder {

	/**
	 * This is a SERACH_PARAM_PREFIX field used to define a constant to hold string
	 * value SP_
	 */
	private static final String SERACH_PARAM_PREFIX = "SP_";

	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
	private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	/**
	 * This is a stringParamQueryFragmentBuilder field used to hold
	 * StringParamQueryFragmentBuilder object
	 */
	private TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;

	/**
	 * This is a tokenParamQueryFragmentBuilder field used to hold
	 * TokenParamQueryFragmentBuilder object
	 */
	private TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;

	/**
	 * This is a referenceParamQueryFragmentBuilder field used to hold
	 * ReferenceParamQueryFragmentBuilder object
	 */
	private TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;

	/**
	 * This is a dateRangeParamQueryFragmentBuilder field used to hold
	 * DateRangeParamQueryFragmentBuilder object
	 */
	private TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;

    /**
	 * This is a compositeParamQueryFragmentBuilder field used to hold
	 * CompositeParamQueryFragmentBuilder object
	 */
    @SuppressWarnings("rawtypes")
	@Autowired
    private TypeQueryFragmentBuilder<CompositeParam> compositeParamQueryFragmentBuilder;
    
	/**
	 * This is a customResourceUtil field used to hold CustomResourceUtil object
	 */
	private CustomResourceUtil customResourceUtil;

	/**
	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
	 */
	private FHIRErrorHandler fhirErrorHandler;

	/**
	 * This is a uriParamQueryFragmentBuilder field used to hold
	 * UriParamQueryFragmentBuilder object
	 */
	private TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;

	@Autowired
	public BaseTypeQueryFragmentBuilder(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder,
			TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder,
			TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder,
			TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.stringParamQueryFragmentBuilder = stringParamQueryFragmentBuilder;
		this.tokenParamQueryFragmentBuilder = tokenParamQueryFragmentBuilder;
		this.referenceParamQueryFragmentBuilder = referenceParamQueryFragmentBuilder;
		this.dateRangeParamQueryFragmentBuilder = dateRangeParamQueryFragmentBuilder;
	}

	public BaseTypeQueryFragmentBuilder() {
		
	}
	public CustomResourceUtil getCustomResourceUtil() {
		return customResourceUtil;
	}

	@Autowired
	public void setCustomResourceUtil(CustomResourceUtil customResourceUtil) {
		this.customResourceUtil = customResourceUtil;
	}

	public FHIRErrorHandler getFhirErrorHandler() {
		return fhirErrorHandler;
	}

	@Autowired
	public void setFhirErrorHandler(FHIRErrorHandler fhirErrorHandler) {
		this.fhirErrorHandler = fhirErrorHandler;
	}

	public TypeQueryFragmentBuilder<UriParam> getUriParamQueryFragmentBuilder() {
		return uriParamQueryFragmentBuilder;
	}

	@Autowired
	public void setUriParamQueryFragmentBuilder(TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder) {
		this.uriParamQueryFragmentBuilder = uriParamQueryFragmentBuilder;
	}

	/**
	 * returns OR query condition by processing input parameters
	 * 
	 * @param selectQuery
	 * @param queryBuilder
	 * @param resourceType
	 * @param resourceTypeAlias
	 * @param parameterOr
	 * @param paramName
	 * @return Condition
	 */
    @SuppressWarnings("rawtypes")
	public Condition buildOrQuery(SelectQuery selectQuery,
								  FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
								  String resourceType,
								  String resourceTypeAlias,
								  IQueryParameterOr parameterOr,
								  String paramName) {
		List<Condition> orConditions = new ArrayList<>();
		for (Object parameterType : parameterOr.getValuesAsQueryTokens()) {
			orConditions.add(buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias,
					(IQueryParameterType) parameterType, paramName));
		}

		return queryBuilder.frameOrQueryAndReturn(orConditions);
	}

	/**
	 * returns TypeSerchRef by processing search parameter modifiers like exact,
	 * contains
	 * 
	 * @param attribute
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef processStringParam(String attribute, String value) {
		StringParam stringParam = new StringParam();
		String paramName;
		if (attribute.contains(":")) {
			String[] refAttributeFragments = attribute.split(":");
			paramName = refAttributeFragments[0];
			String modifier = refAttributeFragments[1];
			stringParam.setContains("contains".equals(modifier));
			stringParam.setExact("exact".equals(modifier));
			stringParam.setMissing("missing".equals(modifier));
			stringParam.setValue(value);
		} else {
			paramName = attribute;
			stringParam.setValue(value);
		}
		return new TypeSearchRef(stringParam, paramName);
	}

	/**
	 * returns TypeSearchRef by processing input value string
	 * 
	 * @param attribute
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef processTokenParam(String attribute, String value) {
		TokenParam tokenParam = new TokenParam();
		if (value.contains("|")) {
			String[] values = value.split("\\|");
			tokenParam.setSystem(values[0]);
			tokenParam.setValue(values.length == 2 && values[1] != null ? values[1] : "");
		} else {
			tokenParam.setValue(value);
		}
		return new TypeSearchRef(tokenParam, attribute);
	}

	/**
	 * returns a string for search filed name
	 * 
	 * @param incoming
	 * @return String
	 */
	private String getSearchFieldName(String incoming) {
		String incomingText = incoming;
		if (incomingText.contains(":")) {
			incomingText = incomingText.substring(0, incomingText.indexOf(':'));
		}
		return SERACH_PARAM_PREFIX + incomingText.replace("-", "_").toUpperCase(Locale.ROOT);
	}

	/**
	 * returns TypeSearchRef by determining parameter type for reference chain
	 * 
	 * @param query
	 * @param resource
	 * @param tresource
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef getParamType(String queryParam, String resource, String tresource, String value) {
		
		try {
			String queryParamName = queryParam;
			if (queryParam.contains(":")) {
				queryParamName = queryParam.split(":")[0].toUpperCase(Locale.ROOT);
			}

			SearchParamDefinition searchParamDefinition = customResourceUtil.getSearchParamDefinition(resource, tresource);
			Class<? extends IBaseResource> tresourceType = searchParamDefinition.target()[0];
			Field attributeType = tresourceType.getField(getSearchFieldName(queryParamName));
			ParamType targetType = ParamType
					.findByValue(attributeType.getAnnotation(SearchParamDefinition.class).type());
			TypeSearchRef typeSearchRef = null;

			if (ParamType.STRING.equals(targetType)) {
				typeSearchRef = processStringParam(queryParam, value);
			} else if (ParamType.TOKEN.equals(targetType)) {
				typeSearchRef = processTokenParam(queryParam, value);
			} else if (ParamType.REFERENCE.equals(targetType)) {
				typeSearchRef = processReferenceParam(queryParam, value);
            } else if (ParamType.DATE.equals(targetType)) {
				typeSearchRef = processDateParam(queryParam, value);
			} else if (ParamType.URI.equals(targetType)) {
				typeSearchRef = processUriParam(queryParam, value);
			} else { // default added to fix the sonar issue
				typeSearchRef = new TypeSearchRef(null, value);
			}
			typeSearchRef.setResource(searchParamDefinition.target()[0].getSimpleName());
			return typeSearchRef;
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR,
					String.format("ERROR while Detremining param Type for ref chain %s and %s", queryParam, value), e);
		}
	}

    /**
	 * returns TypeSearchRef object by building it based on input values
	 * 
	 * @param attribute
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef processDateParam(String attribute, String value) {
		
		ParamPrefixEnum thePrefix = ParamPrefixEnum.EQUAL; 
		String tempValue = value;
		if (tempValue.startsWith("ge")) {
			thePrefix = ParamPrefixEnum.GREATERTHAN_OR_EQUALS;
			tempValue = tempValue.replace("ge", "");
        } else if (tempValue.startsWith("gt")) {
			thePrefix = ParamPrefixEnum.GREATERTHAN;
			tempValue = tempValue.replace("gt", "");
        } else if (tempValue.startsWith("le")) {
			thePrefix = ParamPrefixEnum.LESSTHAN_OR_EQUALS;
			tempValue = tempValue.replace("le", "");
        } else if (tempValue.startsWith("lt")) {
			thePrefix = ParamPrefixEnum.LESSTHAN;
			tempValue = tempValue.replace("lt", "");
        } else if (tempValue.startsWith("eq")) {
			thePrefix = ParamPrefixEnum.EQUAL;
			tempValue = tempValue.replace("eq", "");
        }
        
        DateParam dateParam = new DateParam(thePrefix, tempValue);
		
        return new TypeSearchRef(dateParam, attribute);
	}

	/**
	 * returns TypeSearchRef object by building it based on input values
	 * 
	 * @param attribute
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef processReferenceParam(String attribute, String value) {
		ReferenceParam referenceParam = new ReferenceParam(value);
		return new TypeSearchRef(referenceParam, attribute);
	}

	/**
	 * returns TypeSearchRef object by building it based on input values
	 * 
	 * @param attribute
	 * @param value
	 * @return TypeSearchRef
	 */
	private TypeSearchRef processUriParam(String attribute, String value) {
		UriParam uriParam = new UriParam(value);
		return new TypeSearchRef(uriParam, attribute);
	}

	/**
	 * returns Condition by building chained parameter query
	 * 
	 * @param selectQuery
	 * @param queryBuilder
	 * @param resourceType
	 * @param resourceAlias
	 * @param referenceParam
	 * @param paramName
	 * @return Condition
	 */
	private Condition buildChainedParamsQuery(SelectQuery selectQuery, FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
			String resourceType, String resourceAlias, ReferenceParam referenceParam, String paramName) {
		TypeSearchRef typeSearchRef = getParamType(referenceParam.getChain(), resourceType, paramName,
				referenceParam.getValue());

		queryBuilder.addJoinMap(selectQuery, typeSearchRef.getResource(), typeSearchRef.getResource(), resourceType,
				resourceAlias);
		Condition condition = BinaryCondition
				.equalTo(fhirRepositoryTableConfiguration.getSearchAttributeColumn(resourceAlias), paramName);

		return ComboCondition.and(condition, buildQuery(selectQuery, queryBuilder, typeSearchRef.getResource(),
				typeSearchRef.getResource(), typeSearchRef.getParameterType(), typeSearchRef.getParamName()));

	}

	/**
	 * returns Condition by building query based on inputs
	 * 
	 * @param selectQuery
	 * @param queryBuilder
	 * @param resourceType
	 * @param resourceTypeAlias
	 * @param parameterType
	 * @param paramName
	 * @return Condition
	 */
	public Condition buildQuery(SelectQuery selectQuery, FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
			String resourceType, String resourceTypeAlias, IQueryParameterType parameterType, String paramName) {
		if (parameterType instanceof StringParam) {
			queryBuilder.setParamType(ParamType.STRING);
			return stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
					(StringParam) parameterType, paramName);

		} else if (parameterType instanceof TokenParam) {
			queryBuilder.setParamType(ParamType.TOKEN);
			return tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
					(TokenParam) parameterType, paramName);
		} else if (parameterType instanceof ReferenceParam) {
			ReferenceParam referenceParam = (ReferenceParam) parameterType;
			if (referenceParam.getChain() != null) {
				queryBuilder.setChainedParam(true);
				return buildChainedParamsQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias,
						referenceParam, paramName);
			} else {
				queryBuilder.setParamType(ParamType.REFERENCE);
				return referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType,
						resourceTypeAlias, (ReferenceParam) parameterType, paramName);
			}
		} else if (parameterType instanceof DateParam) {
			queryBuilder.setParamType(ParamType.DATE);
			return dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
					(DateParam) parameterType, paramName);
		} else if (parameterType instanceof UriParam) {
			queryBuilder.setParamType(ParamType.URI);
			return uriParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
					(UriParam) parameterType, paramName);
        	
        } else if(parameterType instanceof CompositeParam) {
        	queryBuilder.setParamType(ParamType.COMPOSITE);
        	return compositeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, (CompositeParam) parameterType, paramName);

		}
		return Condition.EMPTY;
	}
}

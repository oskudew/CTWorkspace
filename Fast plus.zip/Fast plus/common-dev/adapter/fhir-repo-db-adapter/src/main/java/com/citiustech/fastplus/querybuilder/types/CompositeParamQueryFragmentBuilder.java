package com.citiustech.fastplus.querybuilder.types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.UnaryCondition;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;
import ca.uhn.fhir.model.api.IQueryParameterType;
import ca.uhn.fhir.rest.param.CompositeParam;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

/**
 * 
 * This is a class for StringParamQueryFragmentBuilder which used to build
 * query fragments for Composite search parameters
 * 
 */

@SuppressWarnings("rawtypes")
@Component
public class CompositeParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<CompositeParam>{
	
	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
    @Autowired
    private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

    /**
     * This is a commonQueryUtil field used to hold CommonQueryUtil object
     */
    @Autowired
    private CommonQueryUtil commonQueryUtil;
    
  
    /**
	 * This is a stringParamBuilder field used to hold
	 * StringParamQueryFragmentBuilder object
	 */
    @Autowired
    private TypeQueryFragmentBuilder<StringParam> stringParamBuilder;

	/**
	 * This is a tokenParamBuilder field used to hold
	 * TokenParamQueryFragmentBuilder object
	 */
    @Autowired
    private TypeQueryFragmentBuilder<TokenParam> tokenParamBuilder;

	/**
	 * This is a referenceParamBuilder field used to hold
	 * ReferenceParamQueryFragmentBuilder object
	 */
    @Autowired
    private TypeQueryFragmentBuilder<ReferenceParam> referenceParamBuilder;
    
	/**
	 * This is a dateRangeParamBuilder field used to hold
	 * DateRangeParamQueryFragmentBuilder object
	 */
    @Autowired
    private TypeQueryFragmentBuilder<DateParam> dateRangeParamBuilder;
    
    /**
	 * This is a uriParamBuilder field used to hold
	 * UriParamQueryFragmentBuilder object
	 */
    @Autowired
    private TypeQueryFragmentBuilder<UriParam> uriParamBuilder;
	

	@Override
	public Condition frameQueryFragment(QueryBuilder queryBuilder, String resourceType, String alias,
			CompositeParam paramType, String paramName) {
		
		String[] paramNameList = paramName.split("-");
		String resourceTypeAlias = resourceType + fhirRepositoryTableConfiguration.getRandomString();
		Condition lowerCondition = getCondition(queryBuilder, resourceType, resourceTypeAlias, paramType.getRightValue(), paramNameList[1]);
		
		String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();
		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
		selectQuery.addCustomColumns(new CustomSql(1));
		selectQuery.addCondition(BinaryCondition.equalTo(
				new CustomSql(
						AdapterUtil.getAliasedColumn(alias, fhirRepositoryTableConfiguration.getIdColumn())),
				new CustomSql(
						AdapterUtil.getAliasedColumn(resourceTypeAlias, fhirRepositoryTableConfiguration.getIdColumn()))));
		selectQuery.addCondition(lowerCondition);
		
		Condition upperCondition = getCondition(queryBuilder, resourceType, alias, paramType.getLeftValue(), paramNameList[0]);
		return ComboCondition.and(upperCondition, UnaryCondition.exists(selectQuery));
	}



	/**
	 * @param queryBuilder
	 * @param resourceType
	 * @param alias
	 * @param paramType
	 * @param upperCondition
	 * @param paramNameList
	 * @return
	 */
	private Condition getCondition(QueryBuilder queryBuilder, String resourceType, String alias,
			IQueryParameterType paramType, String paramName) {
		
		Condition condition = null;
		if(paramType instanceof TokenParam) {
			condition = tokenParamBuilder.frameQueryFragment(queryBuilder, resourceType, alias, (TokenParam)paramType, paramName);
		} else if (paramType instanceof StringParam) {
			condition = stringParamBuilder.frameQueryFragment(queryBuilder, resourceType, alias, (StringParam)paramType, paramName);
		} else if (paramType instanceof DateParam) {
			condition = dateRangeParamBuilder.frameQueryFragment(queryBuilder, resourceType, alias, (DateParam)paramType, paramName);
		} else if (paramType instanceof ReferenceParam) {
			condition = referenceParamBuilder.frameQueryFragment(queryBuilder, resourceType, alias, (ReferenceParam)paramType, paramName);
		} else if (paramType instanceof UriParam) {
			condition = uriParamBuilder.frameQueryFragment(queryBuilder, resourceType, alias, (UriParam)paramType, paramName);
		}
		return condition;
	}

}

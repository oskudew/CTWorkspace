package com.citiustech.fastplus.identityprovider;

import java.util.List;
import java.util.Map;

import org.springframework.security.oauth2.jwt.Jwt;

/**
 * 
 * It is an interface used to define methods to extract access token
 *
 */
public interface IAccessTokenExtractor {

	/**
	 * returns issued for information from JWT token
	 * 
	 * @param jwt
	 * @return String
	 */
	String getIssuedFor(Jwt jwt);

	/**
	 * returns preferred user name from JWT token
	 * 
	 * @param jwt
	 * @return String
	 */
	String getPreferredUsername(Jwt jwt);

	List<String> getRoles(Jwt jwt);

	List<String> getScope(Jwt jwt);

	Map<String, Object> getUserAttributes(Jwt jwt);
	
	Object getClaimByKey(String key,Jwt jwt);


}

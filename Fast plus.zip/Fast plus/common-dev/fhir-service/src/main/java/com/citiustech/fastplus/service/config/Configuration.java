package com.citiustech.fastplus.service.config;

import ca.uhn.fhir.context.FhirContext;
import org.springframework.context.annotation.Bean;

/**
 * 
 * This is a class for Configuration used to configure fhir related classes as a
 * spring bean
 * 
 */

@org.springframework.context.annotation.Configuration
public class Configuration {
	
	/**
     * return fhir context object for R4
     * 
     * @return FhirContext
     */
    @Bean
    public FhirContext getFhirContext() {
        return FhirContext.forR4();
    }

}

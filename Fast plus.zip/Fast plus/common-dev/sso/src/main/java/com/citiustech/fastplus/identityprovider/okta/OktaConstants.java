package com.citiustech.fastplus.identityprovider.okta;

/**
 * 
 * This is an enum for OktaConstants which provides constant values related to
 * okta identity management
 * 
 */

public enum OktaConstants {

	/**
	 * enum objects to define string constants
	 */
	USERNAME("sub"), CLIENT_NAME("cid"), ROLES("groups"),SCOPE("scope");

	/**
	 * This is a field for value used to hold string value
	 */
	String value;

	/**
	 * parameterized constructor to initialize value field
	 * 
	 * @param value
	 */
	private OktaConstants(String value) {
		this.value = value;
	}

	/**
	 * returns value field
	 */
	@Override
	public String toString() {
		return value;
	}

}

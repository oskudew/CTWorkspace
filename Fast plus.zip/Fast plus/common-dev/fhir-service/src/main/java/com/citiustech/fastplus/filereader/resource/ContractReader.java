package com.citiustech.fastplus.filereader.resource;

import java.util.List;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Contract;
import org.hl7.fhir.r4.model.Contract.ComputableLanguageComponent;
import org.hl7.fhir.r4.model.Contract.LegalLanguageComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.filereader.FileReaderUtils;
/**
 * 
 * This is a class for Contract Resource used as implementation for IResourceReader
 * to read resource attachment data from shared location.
 *
 */
@Component(value = "ContractReader")
public class ContractReader implements IResourceReader {

	@Autowired
	FileReaderUtils readerUtil;

	@Override
	public void readAttachment(List<IBaseResource> resources) {
		List<Contract> contracts = resources.stream().filter(rs -> rs instanceof Contract).map(rs -> (Contract) rs)
				.collect(Collectors.toList());
		readContractAttachment(contracts);
	}

	/**
	 * iterate over Contract resources and set the attachment data using URL.
	 * 
	 * @param resources
	 */
	private void readContractAttachment(List<Contract> resources) {

		long totalAttachmentSize = 0;
		for (Contract contract : resources) {
			for (LegalLanguageComponent legalComponent : contract.getLegal()) {
				if(legalComponent.hasContentAttachment())
					totalAttachmentSize = readerUtil.setAttachmentdata(legalComponent.getContentAttachment(),
						totalAttachmentSize);
			}
			for (ComputableLanguageComponent ruleComponent : contract.getRule()) {
				if(ruleComponent.hasContentAttachment())
					totalAttachmentSize = readerUtil.setAttachmentdata(ruleComponent.getContentAttachment(),
						totalAttachmentSize);
			}
		}
	}

}

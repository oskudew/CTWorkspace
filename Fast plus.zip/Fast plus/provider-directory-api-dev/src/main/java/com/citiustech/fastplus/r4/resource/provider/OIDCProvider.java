package com.citiustech.fastplus.r4.resource.provider;

import java.io.IOException;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.IdType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.citiustech.fastplus.r4.model.OIDCConfiguration;

import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.server.IResourceProvider;

@Configuration
public class OIDCProvider implements IResourceProvider {

	@Value("${iam-oidc-metadata-path:}")
	private String oidcMetadataPath;

	@Value("${oidc-capabilities:sso-openid-connect}")
	private Set<String> capabilities;

	private static final RestTemplate rest = new RestTemplate();

	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return OIDCConfiguration.class;
	}

	@Read
	public OIDCConfiguration getResourceById(HttpServletResponse response, @IdParam IdType pId)
			throws IOException, JSONException {
		return getConfiguration(response);
	}

	private OIDCConfiguration getConfiguration(HttpServletResponse response) throws IOException, JSONException {
		String errorMessage = "Unable to resolve the Configuration with the provided Issuer of " + "\""
				+ oidcMetadataPath + "\"";

		try {

			ResponseEntity<String> metadata = rest.getForEntity(oidcMetadataPath, String.class);

			response.setStatus(HttpStatus.OK.value());
			response.setContentType("application/json");

			JSONObject oidcMetadata = new JSONObject(metadata.getBody());
			oidcMetadata.put("capabilities",new JSONArray(capabilities));
			
			response.getOutputStream().print(oidcMetadata.toString());
			response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
			response.getOutputStream().close();
			response.flushBuffer();
			return null;

		} catch (IllegalArgumentException ex) {
			throw ex;
		} catch (HttpClientErrorException ex) {
			if (!ex.getStatusCode().is4xxClientError()) {
				throw new IllegalArgumentException(errorMessage, ex);
			}
			// else try another endpoint
		}

		throw new IllegalArgumentException(errorMessage);
	}

}


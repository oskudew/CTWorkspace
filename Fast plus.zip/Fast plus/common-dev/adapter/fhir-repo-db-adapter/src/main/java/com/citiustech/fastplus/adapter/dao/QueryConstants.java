package com.citiustech.fastplus.adapter.dao;

public final class QueryConstants {

	private static final String BULKEXPORT = "bulkexport.";
	
	public static final String SUBSCRIPTIONS_SCHEMA = "subscriptions";

	public static final String INSERT_FHIRREPO_HDR_DATA_QUERY = new StringBuilder("Insert into ")
			.append(BULKEXPORT)
			.append("bulk_request_registration_header(requesturl, requestid, starttime,status,since,datakey) values (?,?,?,?,?,?)").toString();
	
	public static final String INSERT_RESOURCELVL_FHIRREPO_DATA_QUERY = new StringBuilder("Insert into ")
			.append(BULKEXPORT)
			.append("bulk_request_registration_detail(refid, resourcename, query, starttime, status, operation_type) values (?,?,?,?,?,?)").toString();
	
	public static final String UPDATE_BULK_HDR_STATUS_UPDATE_QUERY = new StringBuilder("Update ")
			.append(BULKEXPORT)
			.append("bulk_request_registration_header set status = ? where requestid = ?").toString();
	
	public static final String GET_BULK_HDR_STATUS_QUERY = new StringBuilder("SELECT * FROM  ")
			.append(BULKEXPORT)
			.append("bulk_request_registration_header WHERE requestid = ?").toString();
	
	public static final String DELETE_BULK_HDR_STATUS_QUERY = new StringBuilder("Update ")
			.append(BULKEXPORT)
			.append("bulk_request_registration_header set cancelflag = ? where requestid = ?").toString();
	
	private QueryConstants() {
		
	}
}

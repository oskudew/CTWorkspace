package com.citiustech.fastplus.r4.resource.provider;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.MedicationKnowledge;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.r4.model.DavinciFormularyDrug;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.OptionalParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

/**
 * 
 * This is a class for FormularyDrug resource provider used to serve all
 * supported read and search parameter requests for FormularyDrug resource
 * 
 */

@Component
public class FormularyDrugResourceProvider implements IResourceProvider {

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;
	
	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging logger = LoggerFactory.getLogger(FormularyDrugResourceProvider.class.getName());
	
	public Class<? extends IBaseResource> getResourceType() {
		return MedicationKnowledge.class;
	}

	/**
	 * returns FormularyDrug resource based on the provider id
	 * 
	 * @param pId
	 * @return single FormularyDrug resource
	 * @throws Exception
	 */
	@Read
	public IBaseResource getResourceById(@IdParam IdType pId) {
		logger.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Read operation for id " + pId.getIdPart());
		return service.getResourceById(pId.getIdPart(), ResourceType.MedicationKnowledge.name());
	}
	
	/**
	 * returns the bundle of resources based on the search parameters passed in the
	 * request
	 * 
	 * @param drugName
	 * @param drugPlan
	 * @param drugTier
	 * @param code
	 * @return bundle resource of FormularyDrug resources
	 * @throws Exception
	 */
	@Search
	public IBundleProvider getResourcesByParam(
			@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = DavinciFormularyDrug.SP_DRUGNAME) StringAndListParam drugName,
			@OptionalParam(name = DavinciFormularyDrug.SP_DRUGPLAN) TokenAndListParam drugPlan,
			@OptionalParam(name = DavinciFormularyDrug.SP_DRUGTIER) TokenAndListParam drugTier,
			@OptionalParam(name = MedicationKnowledge.SP_CODE) TokenAndListParam code,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdatedDate) {
		SearchParameterRequest searchMap = new SearchParameterRequest();

		searchMap.add(IAnyResource.SP_RES_ID, theId);
		searchMap.add(DavinciFormularyDrug.SP_DRUGNAME, drugName);
		searchMap.add(DavinciFormularyDrug.SP_DRUGPLAN, drugPlan);
		searchMap.add(DavinciFormularyDrug.SP_DRUGTIER, drugTier);
		searchMap.add(MedicationKnowledge.SP_CODE, code);
		searchMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdatedDate);

		logger.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Search operation for parameters " + searchMap.toString());
		return service.getResources(searchMap, ResourceType.MedicationKnowledge.name());
	}
}

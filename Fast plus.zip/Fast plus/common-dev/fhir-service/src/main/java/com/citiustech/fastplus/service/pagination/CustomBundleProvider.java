package com.citiustech.fastplus.service.pagination;

import ca.uhn.fhir.model.primitive.InstantDt;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.server.exceptions.InternalErrorException;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;

import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.service.ISearchService;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRException;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.instance.model.api.IPrimitiveType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 
 * This is a class for CustomBundleProvider used as custom bundle provider for
 * search operation
 * 
 */

@Component
@Scope(value = "prototype")
public class CustomBundleProvider implements IBundleProvider {

	/**
	 * This is a searchService field used to hold search service object
	 */
    @Autowired
    private ISearchService searchService;
    
	/**
	 * This field is a messageSource used for resolving messages, with support for
	 * the parameterization and internationalization of messages.
	 */
    @Autowired
    private MessageSource messageSource;

    /**
	 * This is the logger field used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(CustomBundleProvider.class.getName());

    /**
	 * This is the myUuid field used to hold unique identifier
	 */
    private final String myUuid;
    
	/**
	 * This is the myPreferredPageSize field used to define preferred page size
	 */
    private Integer myPreferredPageSize;
    
    /**
	 * This is the mySize field used to hold size of resource identifiers
	 */
    private Integer mySize;
    
    /**
	 * This is the myPublished field used to get current time with milliseconds precision
	 */
    private IPrimitiveType<Date> myPublished = InstantDt.withCurrentTime();

    /**
	 * This is the SearchResult field used to hold search result
	 */
    private final SearchResult myMatchingResourceIds;

    /**
     * Single argument constructor to pass matchingResourceIds
     * @param matchingResourceIds
     */
    public CustomBundleProvider(SearchResult matchingResourceIds) {
        this(matchingResourceIds, null);
    }

    /**
     * No argument constructor
     */
    public CustomBundleProvider() {
        this(null);
    }

    /**
     * two Arguments constructor
     * @param matchingResourceIds
     * @param theUuid
     */
    public CustomBundleProvider(SearchResult matchingResourceIds, String theUuid) {
    	 this.myMatchingResourceIds = matchingResourceIds;
         this.myUuid = theUuid;
         this.mySize =matchingResourceIds.getListOfResourceIds().size();
    }


    @Override
    public IPrimitiveType<Date> getPublished() {
        return myPublished;
    }

    /**
     * By default this class uses the object creation date/time (for this object)
     * to determine {@link #getPublished() the published date} but this
     * method may be used to specify an alternate date/time
     */
    public void setPublished(IPrimitiveType<Date> thePublished) {
        myPublished = thePublished;
    }

    @Nonnull
    @Override
    public List<IBaseResource> getResources(int theFromIndex, int theToIndex) {
        List<IBaseResource> resources = new ArrayList<>();
        try {
        	int end = Math.min(theToIndex, myMatchingResourceIds.getListOfResourceIds().size());
        	List<IdProjectionRow> idsToReturn = myMatchingResourceIds.getListOfResourceIds().subList(theFromIndex, end);
        	SearchResult searchResult = new SearchResult(idsToReturn, myMatchingResourceIds.getSetOfIncludes(), myMatchingResourceIds.getSetOfRevIncludes());
        	resources.addAll(searchService.getResourcesByIds(searchResult));
        } catch(FHIRException e) {
        	LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error fetching resourceIds for search operation ",e);
        	if(e.getMessage().contains(ExceptionCodes.INVALID_PARAMETER_VALUE.toString()))
        		throw new InvalidRequestException(messageSource.getMessage(e.getMessage(),null, Locale.getDefault()));
        	
            throw new InternalErrorException(messageSource.getMessage(e.getMessage(),null, Locale.getDefault()));
        } 
        return resources;
    }

    @Override
    public String getUuid() {
        return myUuid;
    }

    @Override
    public Integer preferredPageSize() {
        return myPreferredPageSize;
    }

    /**
     * Sets the preferred page size to be returned by {@link #preferredPageSize()}.
     * Default is <code>null</code>.
     * 
     * @param thePreferredPageSize
     */
    public void setPreferredPageSize(Integer thePreferredPageSize) {
        myPreferredPageSize = thePreferredPageSize;
    }

    /**
     * Sets the total number of results, if this provider
     * corresponds to a single page within a larger search result
     * 
     * @param theSize
     * @return this
     */
    public CustomBundleProvider setSize(Integer theSize) {
        mySize = theSize;
        return this;
    }

    /**
     * returns size of records to get
     */
    @Override
    public Integer size() {
        return mySize;
    }

    /**
     * Returns the matched id stored in this provider
     */
    public SearchResult getMyMatchingResourceIds() {
        return myMatchingResourceIds;
    }
}

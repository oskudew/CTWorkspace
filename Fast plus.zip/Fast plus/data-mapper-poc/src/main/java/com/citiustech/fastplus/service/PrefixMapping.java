package com.citiustech.fastplus.service;

/**
 * 
 * This is an enum PrefixMapping used to define constant codes for different
 * Abbreviation for each resources
 *
 */

public enum PrefixMapping {

    /**
     * constant for Practitioner
     */
	PRACTITIONER("pract"),

    /**
     * constant for PractitionerRole
     */
	PRACTITIONERROLE("practrole"),

    /**
     * constant for Organization
     */
	ORGANIZATION("org"),

    /**
     * constant for OrganizationAffiliation
     */
	ORGANIZATIONAFFILIATION("orgafl"),

    /**
     * constant for Location
     */
	LOCATION("loc"),

    /**
     * constant for RelatedPerson
     */
	RELATEDPERSON("rtdp"),

    /**
     * constant for List
     */
	LIST("lit"),

    /**
     * constant for InsurancePlan
     */
	INSURANCEPLAN("inspln"),

    /**
     * constant for Network
     */
	NETWORK("ntwk"),

    /**
     * constant for Contract
     */
	CONTRACT("cntr"),

    /**
     * constant for Encounter
     */
	ENCOUNTER("enc"),

    /**
     * constant for Patient
     */
	PATIENT("pat"),

    /**
     * constant for Coverage
     */
	COVERAGE("cvrg"),

    /**
     * constant for Endpoint
     */
	ENDPOINT("endpt"),

    /**
     * constant for SrcProvenance
     */
	SRCPROVENANCE("prov"),

    /**
     * constant for Provenance
     */
	PROVENANCE("prov"),

    /**
     * constant for Immunization
     */
	IMMUNIZATION("imm"),

    /**
     * constant for Appointment
     */
	APPOINTMENT("apt"),

    /**
     * constant for Group
     */
	GROUP("grp"),

    /**
     * constant for Condition
     */
	CONDITION("cond"),

    /**
     * constant for Procedure
     */
	PROCEDURE("proc"),

    /**
     * constant for Observation
     */
	OBSERVATION("obs"),

    /**
     * constant for AllergyIntolerance
     */
	ALLERGYINTOLERANCE("alit"),

    /**
     * constant for DiagnosticReport
     */
	DIAGNOSTICREPORT("dgrpt"),

    /**
     * constant for Medication
     */
	MEDICATION("med"),

    /**
     * constant for MedicationRequest
     */
	MEDICATIONREQUEST("mrq"),

    /**
     * constant for MedicationDispense
     */
	MEDICATIONDISPENSE("mdcd"),

    /**
     * constant for MedicationKnowledge
     */
	MEDICATIONKNOWLEDGE("mdk"),

    /**
     * constant for Goal
     */
	GOAL("gol"),

    /**
     * constant for CarePlan
     */
	CAREPLAN("crpl"),

    /**
     * constant for CareTeam
     */
	CARETEAM("crtm"),

    /**
     * constant for ExplanationOfBenefit
     */
	EXPLANATIONOFBENEFIT("eob"),

    /**
     * constant for HealthcareService
     */
	HEALTHCARESERVICE("hcs"),

    /**
     * constant for DocumentReference
     */
	DOCUMENTREFERENCE("docref"),
    
    /**
     * constant for Device
     */
	DEVICE("dev"),
    
    /**
     * constant for Claim
     */
	CLAIM("cla"),
    
	/**
	 * constant for Subscription
	 */
	SUBSCRIPTION("sub");

    /**
     * This is a prefix field used to hold Abbreviation code
     */
    private String prefix;

    /**
     * parameterized constructor
     * 
     * @param prefix
     */
    PrefixMapping(String prefix) {
	this.prefix = prefix;
    }

    /**
     * returns code
     */
    public String getPrefix() {
	return prefix;
    }

    /**
     * returns string representation for this class
     */
    @Override
    public String toString() {
	return this.prefix;
    }
}

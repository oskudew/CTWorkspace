package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.hl7.fhir.r4.model.Attachment;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
@ExtendWith(MockitoExtension.class)
class FileReaderUtilsTest {
	
	@InjectMocks
	FileReaderUtils fileReaderUtils;
	
	@Spy
	private FHIRErrorHandler fhirErrorHandler;

	static Path resourceDirectory ;
	
	static String filename;
	
	static int maxAllowedAttachmentSize;
	
	static String contentType;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration()  {
		filename = "SampleClinicalNotes.txt";
		maxAllowedAttachmentSize = 10;
		contentType = "text/plain";
		resourceDirectory = Paths.get("src","test","resources");
	}

	@DisplayName("Test case for setAttachmentdata method")
	@Test
	void test_setAttachmentdata() {
		long totalAttachmentSize = 0;
		fileReaderUtils.setSharedLocation(resourceDirectory.toString());
		fileReaderUtils.setMaxAllowedAttachmentSize(maxAllowedAttachmentSize);
		
		
		Attachment attachment = new Attachment();
		attachment.setUrl(filename);
		attachment.setContentType(contentType);
		
		long actualValue = fileReaderUtils.setAttachmentdata(attachment,totalAttachmentSize);
		long expectedValue = 1142;
		
		assertEquals(expectedValue,actualValue);
	}
	
	@DisplayName("Test case for setAttachmentdata method for null url")
	@Test
	void test_setAttachmentdataForNullUrl() {
		long totalAttachmentSize = 0;
		Attachment attachment = new Attachment();
		
		long actualValue = fileReaderUtils.setAttachmentdata(attachment,totalAttachmentSize);
		long expectedValue = 0;
		
		assertEquals(expectedValue,actualValue);
		
	}
	
	@DisplayName("Test case for isFileExists method for no file exist")
	@Test
	void test_isFileExistsForFileNotExists() {
		String filename = "Sample Clinical Notes_1";
		boolean actualValue = fileReaderUtils.isFileExists(resourceDirectory.toString(), filename);
		boolean expectedValue = false;
		
		assertEquals(expectedValue,actualValue);
	}
	
	
	@DisplayName("Test case for isMaxAllowedSizeExceeded method")
	@Test
	void test_isMaxAllowedSizeExceeded() {
		long totalAttachmentSize = 3386;
		fileReaderUtils.setMaxAllowedAttachmentSize(maxAllowedAttachmentSize);
		
		boolean actualValue = fileReaderUtils.isMaxAllowedSizeExceeded(totalAttachmentSize);
		boolean expectedValue = false;
	
		assertEquals(expectedValue,actualValue);
	}
	
	@DisplayName("Test case for isMaxAllowedSizeExceeded method for Exception")
	@Test
	void test_isMaxAllowedSizeExceededForException() {
		long totalAttachmentSize = 100000000;
		fileReaderUtils.setMaxAllowedAttachmentSize(maxAllowedAttachmentSize);
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> fileReaderUtils.isMaxAllowedSizeExceeded(totalAttachmentSize));
		assertEquals(ExceptionCodes.MAX_FILE_SIZE_EXCEEDED.getCode(), exception.getMessage());
	}

}


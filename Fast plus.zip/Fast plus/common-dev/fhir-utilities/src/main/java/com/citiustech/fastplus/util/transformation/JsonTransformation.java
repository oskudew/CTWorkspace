package com.citiustech.fastplus.util.transformation;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JsonUtils;
import com.bazaarvoice.jolt.exception.JsonUnmarshalException;
import com.bazaarvoice.jolt.exception.SpecException;
import com.bazaarvoice.jolt.exception.TransformException;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ClassUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * This is a JsonTransformation class used for transforming the Mixed JSONs to
 * either USCore or DaVinci specific profiles depending on the parameters passed
 */
public class JsonTransformation {

	/**
	 * This is a logger field used to logged the messages
	 */
     /**
	 * This is a fhirErrorHandler field used to perform error handling
	 */
    @Autowired
    private FHIRErrorHandler fhirErrorHandler;


    /**
     * using JOLT transformations transforms input JSON to output JSON
     * resourceName and guideName are using for creating the path from where the spec file is to be picked
     *
     * @param inputJson
     * @param resourceName
     * @param guideName
     * @return
     * @throws JsonUnmarshalException
     * @throws SpecException
     * @throws TransformException
     * @throws IOException
     */
    public String transform(String inputJson, String resourceName, String guideName) {
        String transformedJson =null;
        String jsonFile = guideName + "/" + resourceName + ".json";
        ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
        if(classLoader!=null) {
        	try (InputStream inputStream = classLoader.getResourceAsStream(jsonFile)) {
        		List<Object> specs1 = JsonUtils.jsonToList(inputStream);
        		
        		Chainr chainr = Chainr.fromSpec(specs1);
        		Object transformedOutput = chainr.transform(JsonUtils.jsonToObject(inputJson));
        		transformedJson = JsonUtils.toPrettyJsonString(transformedOutput);
        		
        	} catch (IOException | JsonUnmarshalException| SpecException | TransformException e) {
        		throw fhirErrorHandler.handleErrorCode(ExceptionCodes.PARSING_ERROR, e);
        	}
        }
        return transformedJson;
    }

}
package com.citiustech.fastplus.identityprovider;

public enum AuthorityPrefix {

	SCOPE("SCOPE_"), ROLE("ROLE_");

	String value;

	private AuthorityPrefix(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return this.value;
	}
}

package com.citiustech.fastplus.test.factory;

import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringOrListParam;
import ca.uhn.fhir.rest.param.StringParam;

public class StringFactory {

	
	StringAndListParam  stringAndListParam = new StringAndListParam();
	
	StringOrListParam stringOrListParam ;
	
	StringParam stringParam ;
	
	
	public StringFactory() {
	
		stringOrListParam = new StringOrListParam();
		stringAndListParam.addAnd(stringOrListParam);
	}
	
	
	
	public StringAndListParam newInstance(){
		return stringAndListParam;
	}
	
	public StringFactory setStringValue(String theValue) {
		stringParam = new StringParam(theValue);
		stringOrListParam.add(stringParam);
		return this;
	}
	
	public StringFactory addStringParam(StringParam stringParam) {
		stringOrListParam.add(stringParam);
		return this;
	}
	
	
}

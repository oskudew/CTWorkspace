package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.BulkExportSQLBuilder;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;

import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;

@ExtendWith(MockitoExtension.class)
class BulkExportSQLBuilderTest {

	@InjectMocks
	private static BulkExportSQLBuilder bulkExportSQLBuilder;

	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
	private DateRangeParamQueryFragmentBuilder dateRangeParamQueryFragmentBuilder;

	@Mock
	private TokenParamQueryFragmentBuilder tokenParamQueryFragmentBuilder;

	@Mock
	private StringParamQueryFragmentBuilder stringParamQueryFragmentBuilder;

	@Mock
	private BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;

	@Mock
	private ProjectionAndSortingHelper projectionAndSortingHelper;

	@Spy
	private FHIRErrorHandler fhirErrorHandler = new FHIRErrorHandler();


	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstantsBulk.tableConfigString,
				FHIRRepositoryTableConfiguration.class);
		fhirRepositoryTableConfiguration.duplicateTypeMap();
	}

	@DisplayName("Test case for query building with search parameter and grp id null")
	@Test
	void test_BuildNestedQueriesForSearchParamsGrpIdNull() {

		String resourceType = ResourceType.Observation.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();

		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("7b7709ff-a107-49ea-8211-56771b65cd19").newInstance();
		searchParamMap.add(Observation.SP_PATIENT, stringAndListParam);

		String randomAlphabeticString = "PKPR";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString);
		String resourceTypeAlias = resourceType + randomAlphabeticString;

		Condition condition = ComboCondition.or(
				"(ObservationPKPR.attribute = 'patient') AND (ObservationPKPR.value = '7b7709ff-a107-49ea-8211-56771b65cd19')");

		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class),
				any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType), eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Observation.SP_PATIENT))).thenReturn(condition);

		List<CustomSql> customSqls = new ArrayList<CustomSql>();
		customSqls.add(new CustomSql("ObservationPKPR.id"));
		customSqls.add(new CustomSql("ObservationPKPR.value AS patientObservationPKPR"));

		lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias), any(),
				eq(Observation.SP_PATIENT))).thenReturn(customSqls);

		lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class), eq(resourceType)))
				.thenReturn(Boolean.FALSE);

		String actualValue = bulkExportSQLBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);

		String expectedValue = "SELECT ObservationPKPR.id FROM fhirrepo.observationsearch ObservationPKPR WHERE ((ObservationPKPR.attribute = 'patient') AND (ObservationPKPR.value = '7b7709ff-a107-49ea-8211-56771b65cd19'))";

		assertEquals(expectedValue, actualValue);
	}

	@DisplayName("Test case for INVALID_PARAMETER_VALUE")
	@Test
	void test_BuildNestedQueriesForFhirException_InvalidParameterValue() {

		String resourceType = ResourceType.AllergyIntolerance.name();

		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringAndListParam();
		searchParamMap.add(AllergyIntolerance.SP_CLINICAL_STATUS, stringAndListParam);

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));

		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());

	}

	@DisplayName("Test case for QUERY_ERROR")
	@Test
	void test_BuildNestedQueriesForFhirException_QueryError() {

		String resourceType = ResourceType.AllergyIntolerance.name();
		StringAndListParam stringAndListParam = new StringFactory().setStringValue("complete").newInstance();

		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		searchParamMap.add(AllergyIntolerance.SP_CLINICAL_STATUS, stringAndListParam);
		searchParamMap.setGroupId("NewGroup_BULK");
		String randomAlphabeticString = "PKPR";
		String resourceTypeAlias = resourceType + randomAlphabeticString;

		Condition condition = ComboCondition.or(
				"(AllergyIntolerancePKPR.attribute = 'clinical-status') AND (AllergyIntolerancePKPR.code = 'complete')");

		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class),
				any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType), eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(AllergyIntolerance.SP_CLINICAL_STATUS))).thenReturn(condition);

		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString);

		List<CustomSql> customSqls = new ArrayList<CustomSql>();
		customSqls.add(new CustomSql("AllergyIntolerancePKPR.id"));
		customSqls.add(new CustomSql("AllergyIntolerancePKPR.value AS clinicalStatusAllergyIntolerancePKPR"));

		lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias), any(),
				eq(AllergyIntolerance.SP_CLINICAL_STATUS))).thenReturn(customSqls);

		lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class), eq(resourceType)))
				.thenThrow(new FHIRException(ExceptionCodes.QUERY_ERROR.getCode()));

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));

		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());
	}

	@DisplayName("Test case for query building with search parameter with group id not null")
	@Test
	void test_BuildNestedQueriesForSearchParamsForGrpIdNotNull() {

		String resourceType = ResourceType.AllergyIntolerance.name();
		StringAndListParam stringAndListParam = new StringFactory().setStringValue("complete").newInstance();

		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		searchParamMap.add(AllergyIntolerance.SP_CLINICAL_STATUS, stringAndListParam);
		searchParamMap.setGroupId("NewGroup_BULK");
		String randomAlphabeticString = "PKPR";
		String resourceTypeAlias = resourceType + randomAlphabeticString;

		Condition condition = ComboCondition.or(
				"(AllergyIntolerancePKPR.attribute = 'clinical-status') AND (AllergyIntolerancePKPR.code = 'complete')");

		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class),
				any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType), eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(AllergyIntolerance.SP_CLINICAL_STATUS))).thenReturn(condition);

		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString);

		List<CustomSql> customSqls = new ArrayList<CustomSql>();
		customSqls.add(new CustomSql("AllergyIntolerancePKPR.id"));
		customSqls.add(new CustomSql("AllergyIntolerancePKPR.value AS clinicalStatusAllergyIntolerancePKPR"));

		lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias), any(),
				eq(AllergyIntolerance.SP_CLINICAL_STATUS))).thenReturn(customSqls);

		lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class), eq(resourceType)))
				.thenReturn(Boolean.FALSE);

		String actualValue = bulkExportSQLBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);

		String expectedValue = "SELECT AllergyIntolerancePKPR.id FROM fhirrepo.allergyintolerancesearch AllergyIntolerancePKPR WHERE (((AllergyIntolerancePKPR.attribute = 'clinical-status') AND (AllergyIntolerancePKPR.code = 'complete')) AND (EXISTS (SELECT 1 FROM fhirrepo.allergyintolerancesearch AllergyIntolerance WHERE ((AllergyIntolerance.patient_id IN (SELECT resourcelink.trgtid FROM fhirrepo.resourcelink resourcelink WHERE ((resourcelink.srctype = 'Group') AND (resourcelink.trgttype = 'Patient') AND (resourcelink.srcid = 'NewGroup_BULK'))) ) AND (AllergyIntolerancePKPR.id = AllergyIntolerance.id)))))";

		assertEquals(expectedValue, actualValue);
	}

	@DisplayName("Test case for query building with search parameter Empty and group id not null")
	@Test
	void test_BuildNestedQueriesForEmptySearchParamsGrpIdNotNull() {

		String resourceType = ResourceType.Patient.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		searchParamMap.setGroupId("Kern-grp-101");

		String actualValue = bulkExportSQLBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);

		String expectedValue = "SELECT DISTINCT Patient.id FROM fhirrepo.patientsearch Patient WHERE (Patient.patient_id IN (SELECT resourcelink.trgtid FROM fhirrepo.resourcelink resourcelink WHERE ((resourcelink.srctype = 'Group') AND (resourcelink.trgttype = 'Patient') AND (resourcelink.srcid = 'Kern-grp-101'))) )";

		assertEquals(expectedValue, actualValue);
	}

	
	  @DisplayName("Test case for query building with search parameter to get json responce")
	  @Test 
	  void test_buildNestedQueriesToGetResponseJson() {
	  
		  String resourceType = ResourceType.Patient.name(); 
		  
		  DateParam theLowerBound = new DateParam("gt1934-01-01");
		  DateRangeParam birthDate = new DateRangeParam(theLowerBound,null);
		  
		  StringAndListParam stringAndListParam1 = new StringFactory()
				  .setStringValue("Tromp100").newInstance(); 
		  
		  StringAndListParam stringAndListParam2 = new StringFactory()
				  .setStringValue("Jamey282").newInstance();
		  
		  TokenAndListParam tokenAndListParam = new TokenFactory()
				  .setReferenceValue("MALE").newInstance();
		  
		  SearchParameterRequest searchParamMap = new SearchParameterRequest();
		  
		  searchParamMap.add(Patient.SP_BIRTHDATE, birthDate);
		  searchParamMap.add(Patient.SP_FAMILY, stringAndListParam1);
		  searchParamMap.add(Patient.SP_GIVEN, stringAndListParam2);
		  searchParamMap.add(Patient.SP_GENDER, tokenAndListParam);
		  
		  String randomAlphabeticString = "PKPR";
		  when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString); 
		  String resourceTypeAlias = resourceType + randomAlphabeticString; 
	  
		  Condition condition1 = ComboCondition.or("((PatientPKPR.attribute = 'birthdate') AND (date_trunc('day',PatientPKPR.startdate) = '1935-11-18 00:00:00')");
		  
		  lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
					eq(resourceTypeAlias),
					any(IQueryParameterOr.class), eq(Patient.SP_BIRTHDATE))).thenReturn(condition1);
		  
		  Condition condition2 = ComboCondition.or("((PatientPKPR.attribute = 'gender') AND (PatientPKPR.code = 'MALE')");
		  
		  lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
					eq(resourceTypeAlias),
					any(IQueryParameterOr.class), eq(Patient.SP_GENDER))).thenReturn(condition2);
		  
		  Condition condition3 = ComboCondition.or("((PatientPKPR.attribute = 'family') AND (PatientPKPR.value = 'Tromp100')");
		  
		  lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
					eq(resourceTypeAlias),
					any(IQueryParameterOr.class), eq(Patient.SP_FAMILY))).thenReturn(condition3);
		  
		  Condition condition4 = ComboCondition. or("((PatientPKPR.attribute = 'given') AND (PatientPKPR.value = 'Jamey282')" );
		  
		  lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
					eq(resourceTypeAlias),
					any(IQueryParameterOr.class), eq(Patient.SP_GIVEN))).thenReturn(condition4);
		  
		  List<CustomSql> customSqlsDate = new ArrayList<CustomSql>(); 
		  customSqlsDate.add(new CustomSql("PatientPKPR.id"));
		  customSqlsDate.add(new CustomSql("PatientPKPR.birthdate AS birthdatePatientPKPR"));
		  
		  lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(
		  resourceTypeAlias), any(),eq(Patient.SP_BIRTHDATE)))
		  .thenReturn(customSqlsDate);
		  
		  String actualValue = bulkExportSQLBuilder.buildNestedQueriesToGetResponseJson(resourceType,searchParamMap);
		  
		  String expectedValue ="SELECT id,resourcetext FROM resourceinfo resourceinfo WHERE ((resourceinfo.resourcetype = 'Patient') AND (resourceinfo.id IN (SELECT PatientPKPR.id FROM fhirrepo.patientsearch PatientPKPR WHERE ((((PatientPKPR.attribute = 'birthdate') AND (date_trunc('day',PatientPKPR.startdate) = '1935-11-18 00:00:00')) AND (EXISTS (SELECT 1 FROM fhirrepo.patientsearch PatientPKPR WHERE ((((PatientPKPR.attribute = 'family') AND (PatientPKPR.value = 'Tromp100')) AND (PatientPKPR.id = PatientPKPR.id)))) AND (EXISTS (SELECT 1 FROM fhirrepo.patientsearch PatientPKPR WHERE ((((PatientPKPR.attribute = 'given') AND (PatientPKPR.value = 'Jamey282')) AND (PatientPKPR.id = PatientPKPR.id)))) AND (EXISTS (SELECT 1 FROM fhirrepo.patientsearch PatientPKPR WHERE ((((PatientPKPR.attribute = 'gender') AND (PatientPKPR.code = 'MALE')) AND (PatientPKPR.id = PatientPKPR.id)))))) ))";
		  
		  assertEquals(expectedValue, actualValue); 
	  
	  }
	 

	@DisplayName("Test case for INVALID_PARAMETER_VALUE when search params are empty for buildNestedQueriesToGetResponseJson")
	@Test
	void test_buildNestedQueriesToGetResponseJsonForFhirException_InvalidParameterValue() {

		String resourceType = ResourceType.Patient.name();

		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringAndListParam();
		searchParamMap.add(Patient.SP_BIRTHDATE, stringAndListParam);
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.buildNestedQueriesToGetResponseJson(resourceType, searchParamMap));

		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());

	}

	@DisplayName("Test case for Exception Search param empty for buildNestedQueriesToGetResponseJson")
	@Test
	void test_buildNestedQueriesToGetResponseJsonForException() {

		String resourceType = ResourceType.AllergyIntolerance.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();

		when(fhirRepositoryTableConfiguration.getIdColumn()).thenThrow(new ArrayIndexOutOfBoundsException());

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.buildNestedQueriesToGetResponseJson(resourceType, searchParamMap));

		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());

	}

	@DisplayName("Test case for Exception when search params are not empty for buildNestedQueryFromSubQueriesToGetResponseJson")
	@Test
	void test_buildNestedQueryFromSubQueriesToGetResponseJsonForException() {

		String resourceType = ResourceType.AllergyIntolerance.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringFactory().setStringValue("complete").newInstance();
		searchParamMap.add(AllergyIntolerance.SP_CLINICAL_STATUS, stringAndListParam);

		when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class), eq(resourceType)))
				.thenThrow(new ArrayIndexOutOfBoundsException());

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.buildNestedQueriesToGetResponseJson(resourceType, searchParamMap));

		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());

	}
	
	@DisplayName("Test case for query building for frameJsonRetrievalQuery")
	@Test
	void test_frameJsonRetrievalQuery() {

		String resourceType = ResourceType.Organization.name();
		String id = "Kern-coveragetest";
		String resourceTypeAlias = resourceType;

		Condition condition = ComboCondition
				.or("(OrganizationPKPR.attribute = 'address-city') AND (OrganizationPKPR.value ILIKE 'Thailand%')");

		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class),
				any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType), eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Organization.SP_ADDRESS_CITY))).thenReturn(condition);
		String actualValue = bulkExportSQLBuilder.frameJsonRetrievalQuery(resourceType, id);

		String expectedValue = "SELECT id,resourcetext FROM resourceinfo resourceinfo WHERE ((resourceinfo.resourcetype = 'Organization') AND (resourceinfo.id IN ('Kern-coveragetest') ))";

		assertEquals(expectedValue, actualValue);
	}

	@DisplayName("Test case for query building for frameJsonRetrievalQuery with FHIRException")
	@Test
	void test_frameJsonRetrievalQueryFHIRException() {

		String resourceType = ResourceType.Organization.name();
		String id = "Kern-coveragetest";

		when(bulkExportSQLBuilder.frameJsonRetrievalQuery(resourceType, id))
				.thenThrow(new FHIRException(ExceptionCodes.QUERY_ERROR.getCode()));

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.frameJsonRetrievalQuery(resourceType, id));

		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());

	}

	@DisplayName("Test case for query building  for frameJsonRetrievalQuery with Normal Exception")
	@Test
	void test_frameJsonRetrievalQueryException() {

		String resourceType = ResourceType.Organization.name();
		String id = "Kern-coveragetest";

		when(bulkExportSQLBuilder.frameJsonRetrievalQuery(resourceType, id))
				.thenThrow(new ArrayIndexOutOfBoundsException());

		FHIRException exception = Assertions.assertThrows(FHIRException.class,
				() -> bulkExportSQLBuilder.frameJsonRetrievalQuery(resourceType, id));

		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());

	}

}

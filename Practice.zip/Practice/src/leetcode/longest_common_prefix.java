package leetcode;

public class longest_common_prefix {
	
	 public String longestCommonPrefix(String[] strs) {
		    if (strs.length == 0) return "";
		    String prefix = strs[0];
		    for (int i = 1; i < strs.length; i++)
		        while (strs[i].indexOf(prefix) != 0) {
		        	System.out.println("osh"+strs[i].indexOf(prefix));
		            prefix = prefix.substring(0, prefix.length() - 1);
		            System.out.println(prefix);
		            if (prefix.isEmpty()) return "";
		        }        
		    return prefix;
		}

	 public static void main(String[] args) {
		 longest_common_prefix o1= new longest_common_prefix();
		 String[] sarr= {"leetcode","leetcod","leets","lee"};
		 System.out.println(o1.longestCommonPrefix(sarr));
		 String s1="leetcode";
		 String s2="leet";
		 System.out.println(s1.indexOf(s2));
	 }
}

package Basic;

import java.util.Scanner;

public class Barchart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		int input = sc.nextInt();
		int[] arr= new int[input];
		for(int i=0;i<input;i++) {
			arr[i]=sc.nextInt();
		}
		int max=arr[0];
		
		for(int i=0;i<input;i++) {
			if(arr[i]>max) max=arr[i];
		}
		for(int i=max;i>0;i--) {
			for(int j=0;j<input;j++) {
				if(arr[j]>=i) System.out.print("*");
				else System.out.print(" ");
			}
			System.out.println();
		}

	}

}

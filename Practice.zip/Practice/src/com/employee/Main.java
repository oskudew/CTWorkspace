package com.employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee(1,"anil","IT");
		Employee e2 = new Employee(2,"chote","Business");
		Employee e3 = new Employee(3,null,null);
		Employee e4 = new Employee(4,"sakshi","IT");
		Employee e5 = new Employee(5,null,"IT");
		Employee e6 = new Employee(6,"shanu","Bank");
		Employee e7 = new Employee(7,"piyush","Bank");
		Employee e8 = new Employee(8,"anil","Business");
		
		List<Employee> l1=new ArrayList(); 
		l1.add(e1);
		l1.add(e2);
		l1.add(e3);
		l1.add(e4);
		l1.add(e5);
		l1.add(e6);
		l1.add(e7);
		l1.add(e8);
		
		//l1.stream().filter(x->x.getName()!=null).collect(Collectors.toList());
//		for(int i=0;i<l1.size();i++) {
//			if(l1.get(i).getName()==null) l1.remove(i);
//		}
		///////////
		
//		Optional<List<Employee>> op = Optional.ofNullable(l1)
//										.orElseGet(Collections::emptyList)
//										.stream().filter()
//										.map(x->)
//										.forEach(System.out::println);
//		
		////How to convert a list of objects to a Map in Java 8 by handling duplicate keys?
		
		l1.stream().collect(Collectors.toMap(Employee::getName, Employee::getId,
				(oldValue,newValue)->newValue)).forEach((x,y)->System.out.println(x+" : "+y));;
		
		
		////////////////////////////
		
		l1.removeIf(x->x.getName()==null);
		//////////
		l1=l1.stream().sorted((o1,o2)->!((o1.getName()).equals(o2.getName()))?
				(o1.getName().compareTo(o2.getName())):(o1.getId()>o2.getId()?1:-1))
				.collect(Collectors.toList());
		 		//.forEach(x->System.out.println(x.getId()+" : "+x.getName()))
		
		
		
		System.out.println("e1=e8 :"+ e1.equals(e8)+ "  ,\nHashcode of e1: "+e1.hashCode()+" \nHashcode of e8: "+e8.hashCode()
		+" \nHashcode is equal: "+ ( e1.hashCode()==e8.hashCode()));
		
		l1.forEach(x->System.out.println(x.getId()+" : "+x.getName()));

	}

}

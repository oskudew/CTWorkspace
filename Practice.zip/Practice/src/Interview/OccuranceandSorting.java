package Interview;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class OccuranceandSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//The program is have one string "java is a good java"
		//o/p should be a-1, is-1,good-1,java-2
		solution("java is ab a z a good java");
		
		

	}
	public static String solution(String str) {
		TreeMap<String,Integer> map = new TreeMap();
		String[] arr= str.split(" ");
		
		for(int i=0;i<arr.length;i++) {
			int value=1;
			if(map.containsKey(arr[i])) {
				value=map.get(arr[i]) +1;
			}
			map.put(arr[i],value);
		}
		
		
		List<Map.Entry<String,Integer>> list = new LinkedList<Map.Entry<String,Integer>>(map.entrySet());
		
		Collections.sort(list,(i1,i2)->i1.getValue().compareTo(i2.getValue()));
		
		HashMap<String,Integer> temp = new LinkedHashMap<String,Integer>();
		for(Map.Entry<String, Integer> aa : list) {
			temp.put(aa.getKey(), aa.getValue());
		}
		temp.forEach((x,y)->System.out.println(x+"-"+y));
		
		
		return null;
		
	}
	

}

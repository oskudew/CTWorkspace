package com.citiustech.fastplus.interceptors;

import java.util.Locale;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.MessageSource;

import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.springcontext.SpringContext;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.exceptions.AuthenticationException;
import ca.uhn.fhir.rest.server.exceptions.BaseServerResponseException;
import ca.uhn.fhir.rest.server.exceptions.InternalErrorException;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;
import ca.uhn.fhir.rest.server.interceptor.ExceptionHandlingInterceptor;

@Interceptor
public class CustomExceptionHandlingInterceptor extends ExceptionHandlingInterceptor {

	private MessageSource messageSource;

	public CustomExceptionHandlingInterceptor() {
		messageSource = SpringContext.getBeanFromString("messageSource", MessageSource.class);
	}

	private static final Logging LOGGER = LoggerFactory.getLogger(CustomExceptionHandlingInterceptor.class.getName());

	@Override
	@Hook(Pointcut.SERVER_PRE_PROCESS_OUTGOING_EXCEPTION)
	public BaseServerResponseException preProcessOutgoingException(RequestDetails theRequestDetails,
			Throwable theException, HttpServletRequest theServletRequest) throws ServletException {

		BaseServerResponseException retVal = super.preProcessOutgoingException(theRequestDetails, theException,
				theServletRequest);
		if (theException instanceof IllegalArgumentException) {
			retVal = new InternalErrorException(
					messageSource.getMessage(ExceptionCodes.ILLEGAL_ARGUMENT.toString(), null, Locale.getDefault()));
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), theException.toString(),
					theException);

		} else if (theException instanceof ResourceNotFoundException) {
			if ("/error".equals(theServletRequest.getPathInfo())
					&& "/download".equals(theServletRequest.getAttribute(RequestDispatcher.FORWARD_REQUEST_URI))
					&& theServletRequest.getHeader("Authorization") == null) {
				retVal = new AuthenticationException(String.format(messageSource
						.getMessage(ExceptionCodes.UNAUTHORIZED_USER.toString(), null, Locale.getDefault()), ""));
			}
		}
		return retVal;
	}

}

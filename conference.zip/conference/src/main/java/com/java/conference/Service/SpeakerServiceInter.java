package com.java.conference.Service;

import java.util.List;

import com.java.conference.model.Speaker;

public interface SpeakerServiceInter {
		public List<Speaker> findAll();
}
package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Endpoint;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/** 
 * 
 * This class is the Endpoint resource provider class
 * which will serves all supported
 * read and search parameter requests for Endpoint resource
 * 
 */
@Component
public class EndpointResourceProvider implements IResourceProvider{

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(EndpointResourceProvider.class.getName());
	
	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return Endpoint.class;
	}
	
	
	/**
	 * This method will return Endpoint resource based on the provided id
	 * @param theId
	 * @return a single resource
	 * 
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {

		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Read operation for id " + theId.getIdPart());
		return service.getResourceById(theId.getIdPart(), ResourceType.Endpoint.name());
	}

	/**
	 * This method will return the bundle of 
	 * resources based on the search 
	 * parameters passed in the request
	 * @param theId
	 * @param organization,chainParameters{
	 * Organization.SP_IDENTIFIER,Organization.SP_TYPE, 
	 * Organization.SP_NAME,Organization.SP_ADDRESS,
	 * Organization.SP_PARTOF}
	 * @param includes{Endpoint:organization}
	 * @return bundle of resources
	 * 
	 */
	@Search()
	public IBundleProvider getEndpoint(
			@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = Endpoint.SP_ORGANIZATION, chainWhitelist  = {"",Organization.SP_IDENTIFIER, Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS, Organization.SP_PARTOF}) ReferenceAndListParam organization,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@IncludeParam(allow = {"Endpoint:organization"}) Set<Include> includes
	) {

		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(IAnyResource.SP_RES_ID, theId);
		paramMap.add(Endpoint.SP_ORGANIZATION, organization);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		if (includes != null && !includes.isEmpty()) {
			paramMap.setIncludes(includes);
		}
		
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
        return service.getResources(paramMap, ResourceType.Endpoint.name());
	}
}

package com.citiustech.fastplus.util.springcontext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * 
 * This is a SpringContext class used to get spring beans from IOC container
 * 
 */

@Component
public class SpringContext implements ApplicationContextAware {

	/**
	 * This is a context field used to hold IOC container
	 */
    private static ApplicationContext context;

    /**
     * Returns the Spring managed bean instance of the given class type if it exists.
     * Returns null otherwise.
     *
     * @param beanClass
     * @return
     */

    /**
     * returns spring bean from IOC container based on input passed
     * 
     * @param <T>
     * @param beanName
     * @param beanClass
     * @return Object
     */
    public static <T extends Object> T getBeanFromString(String beanName, Class<T> beanClass) {
        return context.getBean(beanName, beanClass);
    }

    /**
     * returns spring bean from IOC container based on input passed
     * 
     * @param <T>
     * @param beanClass
     * @param obj
     * @return Object
     */
    public static <T extends Object> T getBeanUsingParameter(Class<T> beanClass, Object... obj) {
        return context.getBean(beanClass, obj);
    }

    @Override
    public  void setApplicationContext(ApplicationContext context) {
        // store ApplicationContext reference to access required beans later on
    	setContext(context);
    }
    
    private static void setContext(ApplicationContext context2) {
    	context = context2;
	}

}

package Basic;

import java.util.Arrays;

public class MergeAndSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1= {5,1,6,99,8,7,5};
		int[] arr2= {9,8,7};
		int[] arr3= new int[arr1.length + arr2.length];
		int k=0;
		for(int i=0;i<arr1.length;i++) {
			arr3[k++]=arr1[i];
		}
		for(int i=0;i<arr2.length;i++) {
			arr3[k++]=arr2[i];
		}
		//Arrays.sort(arr3);
		//--->//Without sort method
		int s=0;
		int dummy=0;
		for(int i=0;i<arr3.length-1;i++) {
			s=i+1;
			while(s<arr3.length) {
			if(arr3[i]>arr3[s]) { 
				dummy=arr3[i];
				arr3[i]=arr3[s];
				arr3[s]=dummy;
			}
			s++;
			}
		}
		//--->///////////////////////////////
		for(int i:arr3) {
			System.out.print(i+",");
		}

	}

}

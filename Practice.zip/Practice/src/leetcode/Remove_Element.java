package leetcode;

public class Remove_Element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {3,2,2,3};
		int val =3;
		int count =0, k=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]!=val) {
				arr[k++]=arr[i];
				count++;
			}
		}
		System.out.println(count);
		
		

	}

}

package com.citiustech.fastplus.loader.entity;

import java.util.List;

public class FhirResourceData {

    private String resourceId;
    private String resourceName;
    private String jsonStr;
    private List<Search> searches;
    private List<ReferenceLink> references;
    private String flag;
    private String bundleJson;

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getJsonStr() {
        return jsonStr;
    }

    public void setJsonStr(String jsonStr) {
        this.jsonStr = jsonStr;
    }

    public List<Search> getSearches() {
        return searches;
    }

    public void setSearches(List<Search> searches) {
        this.searches = searches;
    }

    public List<ReferenceLink> getReferences() {
        return references;
    }

    public void setReferences(List<ReferenceLink> references) {
        this.references = references;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getBundleJson() {
        return bundleJson;
    }

    public void setBundleJson(String bundleJson) {
        this.bundleJson = bundleJson;
    }
}

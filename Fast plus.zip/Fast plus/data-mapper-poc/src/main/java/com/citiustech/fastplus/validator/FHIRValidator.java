package com.citiustech.fastplus.validator;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.exceptions.FHIRException;
import org.hl7.fhir.instance.model.api.IBaseOperationOutcome;
import org.hl7.fhir.r5.elementmodel.Manager;
import org.hl7.fhir.r5.model.CodeableConcept;
import org.hl7.fhir.r5.model.OperationOutcome;
import org.hl7.fhir.r5.model.OperationOutcome.OperationOutcomeIssueComponent;
import org.hl7.fhir.r5.utils.EOperationOutcome;
import org.hl7.fhir.validation.ValidationEngine;

public class FHIRValidator {
	
	// the validation engine
	private ValidationEngine validationEngine;
	// the core profile
	private String coreprofile = "hl7.fhir.r4.core#4.0.1";
	// the terminology server to be used
	private String terminologyServer;
	// the implementation guide to be used
	private String implGuide;
	//
	Pattern urlGrabberRegex = Pattern.compile("(?:http|https):\\/\\/[^ |'\"]*");
	//
	Pattern valueSetRegex = Pattern.compile("The value provided \\('.*'\\) is not in the value set");

	public FHIRValidator(final String implGuide,
			final String terminologyServer) throws  URISyntaxException, IOException  {
		this.implGuide = implGuide;
		this.terminologyServer = terminologyServer;
		initFHIRValidator();
	}

	private void initFHIRValidator() throws  URISyntaxException, IOException   {
		validationEngine = new ValidationEngine(coreprofile);
		// term server examples http://test.fhir.org/r4 , http://tx.fhir.org/r4

		if (!StringUtils.isEmpty(terminologyServer))
			validationEngine.setTerminologyServer(terminologyServer, null, null);
		else
			validationEngine.setTerminologyServer(null, null, null);

		String[] implGuideArr = implGuide.split("#");
		validationEngine.loadPackage(implGuideArr[0],implGuideArr[1]);
	}

	/**
	 * @param message
	 * @throws Exception
	 */
	/**
	 * @param message
	 * @throws EOperationOutcome 
	 * @throws IOException 
	 * @throws FHIRException 
	 * @throws Exception
	 */
	public IBaseOperationOutcome validate(final String message) throws IOException, EOperationOutcome  {
		//
		OperationOutcome oo = validationEngine
				.validate(Manager.FhirFormat.JSON,
						IOUtils.toInputStream(message, Charset.defaultCharset()),
						new ArrayList<>());

		ValidationResult validationResult = parseOperationStatus(oo);

		List<OperationOutcomeIssueComponent> issueComponents = validationResult.getErrors().stream()
				.map(err ->  new OperationOutcomeIssueComponent(err.getIssueSeverity(),err.getIssueType()).setDiagnostics(err.getErrorMsg()))
				.peek(err ->  {
					System.out.println(err.getDiagnostics());
					
				})
				.collect(Collectors.toList());

		OperationOutcome operationOutcome = new OperationOutcome().setIssue(issueComponents);

		if( !operationOutcome.getIssue().isEmpty()) {
			operationOutcome.setText(null);
//			throw new InvalidRequestException("Validation failed",operationOutcome);
		}
		return operationOutcome;

	}

	public ValidationResult parseOperationStatus(final OperationOutcome op) {
		List<CodeableConcept> warnings = new ArrayList<>();
		List<ErrorDetail> errors = new ArrayList<>();
		boolean result = true;
		// if we have issues , we iterate result and check
		if (op.hasIssue()) {
			// Handles Unresolvable URLs in the Fhir IG and moves such errors into warnings.
			Set<String> deadUrlList = new HashSet<>();
			handleUnResolvableUrls(op, deadUrlList);

			if (!deadUrlList.isEmpty()) {
				deadUrlList.forEach(msg -> System.out.println(msg));
			}
			// // Handles Dead URLs
			result = handleDeadUrls(op, warnings, errors, result, deadUrlList);
		}
		return new ValidationResult(result, warnings, errors);
	}

	public boolean handleDeadUrls(final OperationOutcome op, List<CodeableConcept> warnings, List<ErrorDetail> errors,
			boolean result, Set<String> deadUrlList) {
		boolean tempResult = result;
		for (OperationOutcome.OperationOutcomeIssueComponent issue : op.getIssue()) {
			if (issue.getSeverity() == OperationOutcome.IssueSeverity.ERROR || issue.getSeverity() == OperationOutcome.IssueSeverity.FATAL) {
				boolean checkForDeadUrls = false;
				String errorMsg = issue.getDetails().getText();
				String pathOfError = issue.getExpression().get(0).getValue();
				if(deadUrlList.stream().anyMatch(errorMsg::contains)) {
					checkForDeadUrls = true;
				}
				if (checkForDeadUrls) { // error msg has dead url reference
					warnings.add(issue.getDetails()); // add to warning
				} else if (valueSetRegex.matcher(errorMsg).find()) {  // regex for value set related validation
					// errors
					warnings.add(issue.getDetails()); // add to warning
				} else {
					ErrorDetail detail = new ErrorDetail(errorMsg + " at " + pathOfError, issue.getSeverity(), issue.getCode());
					errors.add(detail);
					tempResult = false;
				}
			}
			if (issue.getSeverity() == OperationOutcome.IssueSeverity.INFORMATION || issue.getSeverity() == OperationOutcome.IssueSeverity.WARNING) {
				warnings.add(issue.getDetails());
			}
		}
		return tempResult;
	}

	private void handleUnResolvableUrls(final OperationOutcome op, Set<String> deadUrlList) {
		for (OperationOutcome.OperationOutcomeIssueComponent issue : op.getIssue()) {
			if (issue.getSeverity() == OperationOutcome.IssueSeverity.ERROR || issue.getSeverity() == OperationOutcome.IssueSeverity.FATAL) {
				String errorMsg = issue.getDetails().getText();

				if (errorMsg.contains("resolve")) {
					Matcher outcome = urlGrabberRegex.matcher(errorMsg);
					if (outcome.find()) deadUrlList.add(outcome.group(0));
				}
			}
		}
	}

}

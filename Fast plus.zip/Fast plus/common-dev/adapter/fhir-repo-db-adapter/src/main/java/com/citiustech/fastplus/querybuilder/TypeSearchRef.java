package com.citiustech.fastplus.querybuilder;

import ca.uhn.fhir.model.api.IQueryParameterType;

/**
 * 
 * This is a class for TypeSearchRef which used to hold search type reference
 * values
 * 
 */

public class TypeSearchRef {
	
	/**
	 * This is a parameterType field used to hold parameter type value
	 */
    private IQueryParameterType parameterType;
    
    /**
	 * This is a paramName field used to hold parameter name value
	 */
    private String paramName;
    
    /**
	 * This is a resource field used to hold resource name value
	 */
    private String resource;

    /**
     * parameterized constructor to initialize object with required values
     * 
     * @param parameterType
     * @param paramName
     */
    public TypeSearchRef(IQueryParameterType parameterType, String paramName) {
        this.parameterType = parameterType;
        this.paramName = paramName;
    }

    /**
     * returns parameter type 
     */
    public IQueryParameterType getParameterType() {
        return parameterType;
    }

    /**
     * sets parameter type
     * 
     * @param parameterType
     */
    public void setParameterType(IQueryParameterType parameterType) {
        this.parameterType = parameterType;
    }

    /**
     * returns parameter name 
     */
    public String getParamName() {
        return paramName;
    }

    /**
     * sets parameter name
     * 
     * @param paramName
     */
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    /**
     * returns resource name 
     */
    public String getResource() {
        return resource;
    }

    /**
     * sets resource name
     * 
     * @param resource
     */
    public void setResource(String resource) {
        this.resource = resource;
    }
}

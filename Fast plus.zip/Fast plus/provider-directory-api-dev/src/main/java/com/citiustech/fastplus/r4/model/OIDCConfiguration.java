package com.citiustech.fastplus.r4.model;

import org.hl7.fhir.r4.model.DomainResource;
import org.hl7.fhir.r4.model.ResourceType;

import ca.uhn.fhir.model.api.annotation.ResourceDef;

@ResourceDef(name = ".well-known")
public class OIDCConfiguration extends DomainResource {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5412625980003226660L;

	@Override
	public DomainResource copy() {
		return null;
	}

	@Override
	public ResourceType getResourceType() {
		return null;
	}

}

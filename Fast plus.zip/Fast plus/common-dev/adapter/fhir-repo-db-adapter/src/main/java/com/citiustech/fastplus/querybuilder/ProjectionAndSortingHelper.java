package com.citiustech.fastplus.querybuilder;

import static com.citiustech.fastplus.util.AdapterUtil.getAliasedColumn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.healthmarketscience.sqlbuilder.AliasedObject;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.OrderObject.Dir;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

import ca.uhn.fhir.rest.api.SortOrderEnum;
import ca.uhn.fhir.rest.api.SortSpec;

@Component
public class ProjectionAndSortingHelper {

	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
	private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
	
	/**
	 * This is a customResourceUtil field used to hold CustomResourceUtil object
	 */
	private CustomResourceUtil customResourceUtil;
	
	/**
	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
	 */
	private FHIRErrorHandler fhirErrorHandler;
	
	@Autowired
	public ProjectionAndSortingHelper(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			CustomResourceUtil customResourceUtil, FHIRErrorHandler fhirErrorHandler) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.customResourceUtil = customResourceUtil;
		this.fhirErrorHandler = fhirErrorHandler;
	}
	
	public ProjectionAndSortingHelper() {
		
	}

	/**
	 * returns sort query if sorting required
	 * 
	 * @param resourceType
	 * @param sort
	 * @param queryBuilder
	 * @param mainOuterQuery
	 * @param listOfParam
	 * @param mainQueryAlias
	 * @return SelectQuery
	 */
	public SelectQuery buildSortQuery(String resourceType, SortSpec sort, FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
			SelectQuery mainOuterQuery, List<CustomSql> listOfParam, String mainQueryAlias) {
		SortSpec tempSort = sort;
		try {
			while (tempSort != null) {
				String paramName = tempSort.getParamName();
				SortOrderEnum sortOrder = tempSort.getOrder();
				Dir orderDirection = Dir.ASCENDING.toString().equals(" " + sortOrder.toString()) ? Dir.ASCENDING
						: Dir.DESCENDING;

				Optional<CustomSql> match = listOfParam.stream().filter(p -> p.toString().contains(paramName))
						.findAny();

				if (match.isPresent()) {
					mainOuterQuery.addCustomColumns(match.get());
					mainOuterQuery.addCustomOrdering(findColumnStr(match), orderDirection);
				} else {
					String targetAlias = resourceType + fhirRepositoryTableConfiguration.getRandomString();
					SelectQuery selectQuery = findSelectQuery(resourceType, paramName, targetAlias);

					queryBuilder.addJoin(mainOuterQuery, mainQueryAlias, selectQuery, targetAlias);
					mainOuterQuery.addCustomColumns(new CustomSql(getAliasedParam(paramName, targetAlias)));
					mainOuterQuery.addCustomOrdering(new CustomSql(getAliasedParam(paramName, targetAlias)),
							orderDirection);
				}
				tempSort = tempSort.getChain();
			}
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
		
		return mainOuterQuery;
	}
	
	private CustomSql findColumnStr(Optional<CustomSql> match) {
		String columnName = "";
		if (match.isPresent()) {
			columnName = match.get().toString();
		}
		if (columnName.contains(" AS "))
			columnName = columnName.substring(columnName.lastIndexOf(" AS ") + 4);
		return new CustomSql(columnName);
	}
	
	
	private SelectQuery findSelectQuery(String resourceType, String paramName, String targetAlias) {
		SelectQuery selectQuery = new SelectQuery();
		try {
		String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();
		selectQuery.addFromTable(new DbTable(null, tableName, targetAlias));

		List<CustomSql> columns = getProjectionColumn(targetAlias,
				ParamType.findByValue(customResourceUtil.getParamType(resourceType, paramName)), paramName);
		columns.stream().forEach(selectQuery::addCustomColumns);

		List<String> actualParamNames = fhirRepositoryTableConfiguration.getActualParamNames(resourceType, paramName);
		actualParamNames = Objects.nonNull(actualParamNames) && !actualParamNames.isEmpty() ?
                actualParamNames : Arrays.asList(paramName);

		List<Condition> orConditions = actualParamNames.stream()
				.map(aParam -> BinaryCondition.equalTo(
						fhirRepositoryTableConfiguration.getSearchAttributeColumn(targetAlias), aParam))
				.collect(Collectors.toList());

		selectQuery.addCondition(ComboCondition.or(orConditions.toArray(new Condition[0])));
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
		return selectQuery;
	}
	
	public List<CustomSql> getProjectionColumn(String resourceTypeAlias, ParamType paramType, String paramName) {
		List<CustomSql> customSqls = new ArrayList<>();
		customSqls.add(
				new CustomSql(getAliasedColumn(resourceTypeAlias, fhirRepositoryTableConfiguration.getIdColumn())));

		if (Objects.nonNull(paramType)) {
			List<CustomSql> projectionList = fhirRepositoryTableConfiguration.getProjectionColumn(paramType.getValue(),
					resourceTypeAlias);
			CustomSql customSql = null;
			switch (paramType) {
			case STRING:
				customSql = projectionList.get(0);
				break;
			case DATE:
				if ("_lastUpdated".equals(paramName))
					customSql = projectionList.get(2);
				else if ("end".equals(paramName))
					customSql = projectionList.get(1);
				else
					customSql = projectionList.get(0);
				break;
			case REFERENCE:
				customSql = projectionList.get(4);
				break;
			case TOKEN:
				customSql = projectionList.get(1);
				break;
			case URI:
				customSql=projectionList.get(0);
				break;
			case COMPOSITE:
				customSql = projectionList.get(0);
				break;
			}
			customSqls.add(new CustomSql(
					AliasedObject.toAliasedObject(customSql, getAliasedParam(paramName, resourceTypeAlias))));
		}
		return customSqls;
	}
	
	
	/**
	 * @param paramName
	 * @return
	 */
	public String getAliasedParam(String paramName,String aliasSufix) {
		return paramName.replace("-", "") + aliasSufix;
	}

	/**
	 * 
	 * @param selectQueryStructure
	 * @param resourceType
	 * @return
	 */
	public boolean isDistinctRequired(SelectQueryStructure selectQueryStructure, String resourceType) {
		boolean isDistinct = false;
		try {
			if (selectQueryStructure.isChainedParam()) {
				isDistinct = true;
			}

			List<String> distinctParameters = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType)
					.getDistinctParameters();
			if (distinctParameters.contains(selectQueryStructure.getParamName())) {
				isDistinct = true;
			}
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
		return isDistinct;
	}
}

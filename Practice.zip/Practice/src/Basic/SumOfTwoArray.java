package Basic;

import java.util.Scanner;

public class SumOfTwoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a1size = sc.nextInt();
		int[] arr1 =new int[a1size];
		for(int i=0;i<a1size;i++) {
			arr1[i]=sc.nextInt();
		}
		int a2size = sc.nextInt();
		int[] arr2 =new int[a2size];
		for(int i=0;i<a2size;i++) {
			arr2[i]=sc.nextInt();
		}
		sc.close();
		int carry=0;
		int[] sum= new int[a1size>a2size?a1size:a2size];
		int j=arr1.length-1;
		int k =arr2.length-1;
		for(int i=0;i<sum.length;i++) {
			
		}
		

	}

}

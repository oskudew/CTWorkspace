package com.citiustech.fastplus.config;

import java.io.IOException;
import java.io.InputStream;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;

/**
 * 
 * This is a class for TableConfiguration which holds configuration for defining
 * spring beans
 * 
 */

@Configuration
public class TableConfiguration {
	
	@Value("${fhirapi.table.config.filename:tableConfig.json}")
	private String tableConfigFileName;
	
	/**
	 * returns FhirRepositoryTableConfiguration by reading tableConfig.json file
	 * 
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
    @Bean("fhirRepositoryTableConfiguration")
    public FHIRRepositoryTableConfiguration getFHIRRepositoryTableConfiguration() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
        try(InputStream is = this.getClass().getClassLoader().getResourceAsStream(tableConfigFileName)) {
        	fhirRepositoryTableConfiguration = objectMapper.readValue(is, FHIRRepositoryTableConfiguration.class);
            fhirRepositoryTableConfiguration.duplicateTypeMap();
        } catch (IOException e) {
        	throw new IOException("Invalid configuration in tableConfig.json file", e);
		}
        return fhirRepositoryTableConfiguration;
    }

	/**
	 * returns Datasource object by reading fhirapi.datasource configuration
	 * 
	 */
    @Bean
    @ConfigurationProperties("fhirapi.datasource")
    public DataSource dataSource() {
        return  DataSourceBuilder.create()
                .type(HikariDataSource.class).build();
    }
    
    @Bean
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate() {
    	return new NamedParameterJdbcTemplate(dataSource());
    }
}

package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;

import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;

@ExtendWith(MockitoExtension.class)
class DeepNestedSqlBuilderMockTest {

	@InjectMocks
	private DeepNestedSqlBuilder deepNestedSqlBuilder ;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
	private  BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Mock
	private  ProjectionAndSortingHelper projectionAndSortingHelper;
	
	@Spy
	private FHIRErrorHandler fhirErrorHandler = new FHIRErrorHandler();
	
	private Integer searchLimit = TestConstants.searchLimit;
	
	private Integer multiplicationFactor = TestConstants.multiplicationFactor ;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
	}
	
	
	
	@DisplayName("Test case for query building with search parameter")
	@Test
	void test_BuildNestedQueriesForSearchParamsForaddressCity() {
		
		String resourceType =  ResourceType.Organization.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("Thailand").newInstance();
		
		searchParamMap.add(Organization.SP_ADDRESS_CITY,stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(searchLimit, multiplicationFactor));
		
		
		String randomAlphabeticString = "PKPR";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString);
		String resourceTypeAlias = resourceType + randomAlphabeticString;
		
		Condition condition = ComboCondition.or("(OrganizationPKPR.attribute = 'address-city') AND (OrganizationPKPR.value ILIKE 'Thailand%')");
				
		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
				eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Organization.SP_ADDRESS_CITY))).thenReturn(condition);
		
		List<CustomSql> customSqls = new ArrayList<CustomSql>();
		customSqls.add(new CustomSql("OrganizationPKPR.id"));
		customSqls.add(new CustomSql("OrganizationPKPR.value AS addresscityOrganizationPKPR"));
		
		lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias),
				 any(),eq(Organization.SP_ADDRESS_CITY)))
				.thenReturn(customSqls);
		
		lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class),eq(resourceType))).thenReturn(Boolean.TRUE);
		 
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT DISTINCT OrganizationPKPR.id FROM organizationsearch OrganizationPKPR WHERE ((OrganizationPKPR.attribute = 'address-city') AND (OrganizationPKPR.value ILIKE 'Thailand%')) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	@DisplayName("Test case for INVALID_PARAMETER_VALUE when search params are empty")
	@Test
	void test_BuildNestedQueriesForFhirException_InvalidParameterValue() {
		
		String resourceType =  ResourceType.Organization.name();
		
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringAndListParam();
		searchParamMap.add(Organization.SP_ADDRESS_CITY,stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(searchLimit, multiplicationFactor));
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));
		
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());
		
	}
	
	@DisplayName("Test case for QUERY_ERROR")
	@Test
	void test_BuildNestedQueriesForFhirException_QueryError() {
		
		String resourceType =  ResourceType.Organization.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("Thailand").newInstance();
		
		searchParamMap.add(Organization.SP_ADDRESS_CITY,stringAndListParam);
		
		searchParamMap.setLimit(Math.multiplyExact(searchLimit, multiplicationFactor));
		
		
		String randomAlphabeticString = "PKPR";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString);
		String resourceTypeAlias = resourceType + randomAlphabeticString;
		
		Condition condition = ComboCondition.or("(OrganizationPKPR.attribute = 'address-city') AND (OrganizationPKPR.value ILIKE 'Thailand%')");
				
		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
				eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Organization.SP_ADDRESS_CITY))).thenReturn(condition);
		
		
		 List<CustomSql> customSqls = new ArrayList<CustomSql>();
		 customSqls.add(new CustomSql("OrganizationPKPR.id"));
		 customSqls.add(new CustomSql("OrganizationPKPR.value AS addresscityOrganizationPKPR"));
		
		 lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias),
				 any(),eq(Organization.SP_ADDRESS_CITY)))
				.thenReturn(customSqls);
		
		 lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class),eq(resourceType))).thenThrow( new FHIRException(ExceptionCodes.QUERY_ERROR.getCode()));
		 
		FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));
		
		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());
	}
	
	
	@DisplayName("Test case for paginated query building with search parameter")
	@Test
	void test_BuildNestedPaginatedQueriesForSearchParamForaddressCity() {
		
		String resourceType =  ResourceType.Patient.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theLowerBound = new DateParam("gt1934-01-01");
		DateRangeParam birthDate = new DateRangeParam(theLowerBound,null);
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("J").setContains(Boolean.TRUE)).newInstance();
		
		searchParamMap.add(Patient.SP_BIRTHDATE, birthDate);
		searchParamMap.add(Patient.SP_NAME, stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit,TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "wWZi";
		String randomAlphabeticString2 = "RTrO";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		String resourceTypeAlias = resourceType + randomAlphabeticString1;
		String resourceTypeAlias2 = resourceType + randomAlphabeticString2;
		
		Condition condition = ComboCondition.or("(PatientwWZi.attribute = 'birthdate') AND (PatientwWZi.startdate > '1934-01-01 00:00:00')");
				
		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
				eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Patient.SP_BIRTHDATE))).thenReturn(condition);
		
		
		 List<CustomSql> customSqls = new ArrayList<CustomSql>();
		 customSqls.add(new CustomSql("PatientwWZi.id"));
		 customSqls.add(new CustomSql("PatientwWZi.startdate AS birthdatePatientwWZi"));
		
		 lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias),
				 any(),eq(Patient.SP_BIRTHDATE)))
				.thenReturn(customSqls);
		 lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class),eq(resourceType))).thenReturn(Boolean.FALSE);
		 
		 
		 Condition nameCondition = ComboCondition.or("((PatientRTrO.attribute = 'given') OR (PatientRTrO.attribute = 'family')) AND (PatientRTrO.value ILIKE '%J%')");
		 
		 lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
				 eq(resourceTypeAlias2),
				 any(IQueryParameterOr.class), eq(Patient.SP_NAME))).thenReturn(nameCondition);
		 
		 List<CustomSql> nameCustomSqls = new ArrayList<CustomSql>();
		 nameCustomSqls.add(new CustomSql("PatientRTrO.id"));
		 nameCustomSqls.add(new CustomSql("PatientRTrO.value AS namePatientRTrO"));
		 
		 lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias2),
				 any(),eq(Patient.SP_NAME)))
		 .thenReturn(nameCustomSqls);
		
		 
		
		String actualValue = deepNestedSqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT PatientwWZi.id,PatientwWZi.patient_id FROM patientsearch PatientwWZi WHERE (((PatientwWZi.attribute = 'birthdate') AND (PatientwWZi.startdate > '1934-01-01 00:00:00')) AND (EXISTS (SELECT 1 FROM patientsearch PatientRTrO"
				+ " WHERE ((((PatientRTrO.attribute = 'given') OR (PatientRTrO.attribute = 'family')) AND (PatientRTrO.value ILIKE '%J%')) AND (PatientwWZi.id = PatientRTrO.id))))) ORDER BY PatientwWZi.id LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	@DisplayName("Test case for INVALID_PARAMETER_VALUE when search params are empty")
	@Test
	void testBuildNestedPaginatedQueriesForSearchParamForFhirException_InvalidParameterValue() {
		
		String resourceType =  ResourceType.Patient.name();
		
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringAndListParam();
		searchParamMap.add(Patient.SP_NAME,stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(searchLimit, multiplicationFactor));
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));
		
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());
		
	}
	
	@DisplayName("Test case for QUERY_ERROR")
	@Test
	void test_BuildNestedPaginatedQueriesForSearchParamsForFhirException_QueryError() {
		
		String resourceType =  ResourceType.Patient.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theLowerBound = new DateParam("gt1934-01-01");
		DateRangeParam birthDate = new DateRangeParam(theLowerBound,null);
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("J").setContains(Boolean.TRUE)).newInstance();
		
		searchParamMap.add(Patient.SP_BIRTHDATE, birthDate);
		searchParamMap.add(Patient.SP_NAME, stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit,TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "wWZi";
		String randomAlphabeticString2 = "RTrO";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		String resourceTypeAlias = resourceType + randomAlphabeticString1;
		
		Condition condition = ComboCondition.or("(PatientwWZi.attribute = 'birthdate') AND (PatientwWZi.startdate > '1934-01-01 00:00:00')");
				
		lenient().when(baseTypeQueryFragmentBuilder.buildOrQuery(any(SelectQuery.class), any(FHIRRepositoryBaseSQLQueryBuilder.class), eq(resourceType),
				eq(resourceTypeAlias),
				any(IQueryParameterOr.class), eq(Patient.SP_BIRTHDATE))).thenReturn(condition);
		
		
		 List<CustomSql> customSqls = new ArrayList<CustomSql>();
		 customSqls.add(new CustomSql("PatientwWZi.id"));
		 customSqls.add(new CustomSql("PatientwWZi.startdate AS birthdatePatientwWZi"));
		
		 lenient().when(projectionAndSortingHelper.getProjectionColumn(eq(resourceTypeAlias),
				 any(),eq(Patient.SP_BIRTHDATE)))
				.thenReturn(customSqls);
		
		 lenient().when(projectionAndSortingHelper.isDistinctRequired(any(SelectQueryStructure.class),eq(resourceType))).thenThrow( new FHIRException(ExceptionCodes.QUERY_ERROR.getCode()));
		 
		FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap));
		
		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());
	}
}

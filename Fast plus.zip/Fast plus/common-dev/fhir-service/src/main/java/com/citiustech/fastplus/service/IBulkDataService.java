package com.citiustech.fastplus.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.StatusParam;

public interface IBulkDataService{

	String postExportRequest(Map<String,List<SearchParameterRequest>> resourceSearchParamMap, Date since,String encryptionKey);
	
	StatusParam statusRequest(String requestId);
	
	StatusParam deleteRequest(String requestId);
	
	List<String> memberMatchingRequest(String resourceType, SearchParameterRequest parameterMap);
	
	String getResourceJsons(String id, String resourceType);
}

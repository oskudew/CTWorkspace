package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.hl7.fhir.r4.model.Contract;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateParam.DateParamDateTimeHolder;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;

@ExtendWith(MockitoExtension.class)
class DateRangeParamQueryFragmentBuilderTest {
	
	@InjectMocks
	private static DateRangeParamQueryFragmentBuilder dateRangeParamQueryFragmentBuilder;
	
	@Mock
	private static CustomResourceUtil customResourceUtil;
    
    @Mock
    private static CommonQueryUtil commonQueryUtil;

    @Spy
	private static FHIRErrorHandler fhirErrorHandler;

    @Spy
    private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
    
    @BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
        dateRangeParamQueryFragmentBuilder = new DateRangeParamQueryFragmentBuilder(customResourceUtil,commonQueryUtil,
				fhirErrorHandler,fhirRepositoryTableConfiguration);
        
    }
    
    
    @DisplayName("Test case for _lastUpdated parameter less than date")
	@Test
	void test_frameQueryFragmentForLastUpdated() {
		
		String resourceType = ResourceType.Organization.name();
		String resourceTypeAlias = "OrganizationZnvX";
		String paramName = "_lastUpdated"; 
		String date = "1990-01-01";
		ParamPrefixEnum thePrefix = ParamPrefixEnum.LESSTHAN;
		
		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		queryBuilder.setParamType(ParamType.DATE);
		
		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(false);
		
		when(customResourceUtil.isCustomResource(resourceType)).thenReturn(true);
		
		Condition actualValue = dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(OrganizationZnvX.attribute = '_id') AND (OrganizationZnvX.lastupdated < '1990-01-01 00:00:00')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
		
	}
    
    @DisplayName("Test case for issued date(greater than) parameter (isLastUpdated)=false")
	@Test
	void test_frameQueryFragmentForIssuedDate() {
    	String resourceType = ResourceType.Contract.name();
		String resourceTypeAlias = "ContractjQOD";
		String paramName = Contract.SP_ISSUED; 
		String date = "2000-01-01";
   		ParamPrefixEnum thePrefix = ParamPrefixEnum.GREATERTHAN;
   		
   		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		queryBuilder.setParamType(ParamType.DATE);
		
		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(false);
		
		when(customResourceUtil.isCustomResource(resourceType)).thenReturn(false);
		
		Condition actualValue = dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		
		Condition expectedValue = ComboCondition.and("(ContractjQOD.attribute = 'issued') AND (ContractjQOD.startdate > '2000-01-01 00:00:00')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
    }
    
    @DisplayName("Test case for _lastUpdated parameter where exception occurs")
   	@Test
   	void test_frameQueryFragmentForException() {
       	String resourceType = ResourceType.Contract.name();
   		String resourceTypeAlias = "ContractjQOD";
   		String paramName = "_lastUpdated"; 
   		String date = "1999-07-09T14:21:08.615^00:00";
   		ParamPrefixEnum thePrefix = ParamPrefixEnum.EQUAL;
   		
   		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
   		
   		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                   fhirRepositoryTableConfiguration, resourceType);
   		
   		queryBuilder.setParamType(ParamType.DATE);
   		
   		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(true);
   		
   		FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName));
   		assertEquals(ExceptionCodes.INVALID_DATE_FORMAT.getCode(), exception.getMessage());
   		
       }
    
    @DisplayName("Test case for parameter period where ParamPrefixEnum.EQUAL")
   	@Test
   	void test_frameQueryFragmentForPeriodDateEqual() {
       	String resourceType = ResourceType.DocumentReference.name();
   		String resourceTypeAlias = "DocumentReferencefMMr";
   		String paramName = DocumentReference.SP_PERIOD; 
   		String date = "2005-03-08";
   		ParamPrefixEnum thePrefix = ParamPrefixEnum.EQUAL;
   		
   		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
   		
   		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                   fhirRepositoryTableConfiguration, resourceType);
   		
   		queryBuilder.setParamType(ParamType.DATE);
   		
   		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(false);
   		
   		when(customResourceUtil.isCustomResource(resourceType)).thenReturn(true);
   		
   		when(customResourceUtil.getCustomResource(resourceType)).thenReturn("org.hl7.fhir.r4.model.DocumentReference");
   		
   		Condition actualValue = dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
   		Condition expectedValue = ComboCondition.and("((DocumentReferencefMMr.attribute = 'period') AND (date_trunc('day',DocumentReferencefMMr.startdate) = '2005-03-08 00:00:00')) OR ((DocumentReferencefMMr.attribute = 'period') AND (date_trunc('day',DocumentReferencefMMr.enddate) = '2005-03-08 00:00:00'))");
   		
   		assertEquals(expectedValue.toString(),actualValue.toString());
   		
       }
    
    @DisplayName("Test case for parameter period where ParamPrefixEnum.LESSTHAN_OR_EQUALS")
   	@Test
   	void test_frameQueryFragmentForPeriodDateLessThanOrEquals() {
       	String resourceType = ResourceType.DocumentReference.name();
   		String resourceTypeAlias = "DocumentReferenceuMFw";
   		String paramName = DocumentReference.SP_PERIOD; 
   		String date = "2005-03-08";
   		ParamPrefixEnum thePrefix = ParamPrefixEnum.LESSTHAN_OR_EQUALS;
   		
   		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
   		
   		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                   fhirRepositoryTableConfiguration, resourceType);
   		
   		queryBuilder.setParamType(ParamType.DATE);
   		
   		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(false);
   		
   		when(customResourceUtil.isCustomResource(resourceType)).thenReturn(true);
   		
   		when(customResourceUtil.getCustomResource(resourceType)).thenReturn("org.hl7.fhir.r4.model.DocumentReference");
   		
   		Condition actualValue = dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
   		Condition expectedValue = ComboCondition.and("(DocumentReferenceuMFw.attribute = 'period') AND (DocumentReferenceuMFw.enddate <= '2005-03-08 00:00:00')");
   		
   		assertEquals(expectedValue.toString(),actualValue.toString());
   		
     }
    
    @DisplayName("Test case for parameter period where ParamPrefixEnum.LESSTHAN_OR_EQUALS")
   	@Test
   	void test_frameQueryFragmentForPeriodDateLessThan() {
       	String resourceType = ResourceType.DocumentReference.name();
   		String resourceTypeAlias = "DocumentReferenceuMFw";
   		String paramName = DocumentReference.SP_PERIOD; 
   		String date = "2005-03-08";
   		ParamPrefixEnum thePrefix = ParamPrefixEnum.LESSTHAN;
   		
   		DateParamDateTimeHolder theDate = new DateParamDateTimeHolder();
   		theDate.setValueAsString(date);
   		DateParam paramType = new DateParam(thePrefix,theDate);
   		
   		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                   fhirRepositoryTableConfiguration, resourceType);
   		
   		queryBuilder.setParamType(ParamType.DATE);
   		
   		when(commonQueryUtil.isInvalidDateTime(paramType.getValueAsString())).thenReturn(false);
   		
   		when(customResourceUtil.isCustomResource(resourceType)).thenReturn(true);
   		
   		when(customResourceUtil.getCustomResource(resourceType)).thenReturn("org.hl7.fhir.r4.model.DocumentReference");
   		
   		Condition actualValue = dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
   		Condition expectedValue = ComboCondition.and("(DocumentReferenceuMFw.attribute = 'period') AND (DocumentReferenceuMFw.enddate < '2005-03-08 00:00:00')");
   		
   		assertEquals(expectedValue.toString(),actualValue.toString());
   		
     }

}

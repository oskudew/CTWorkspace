package com.citiustech.fastplus.r4.resource.provider;

import java.util.Set;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Endpoint;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.r4.model.DavinciOrganization;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.IncludeParam;
import ca.uhn.fhir.rest.annotation.OptionalParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

/**
 * 
 * This class is the  Organization resource provider class
 * which will serves all supported read and search requests
 * for Organization resource
 *
 */
@Component
public class OrganizationResourceProvider implements IResourceProvider{

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(OrganizationResourceProvider.class.getName());
	
	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return DavinciOrganization.class;
	}

	/**
	 * This method will return Organization resource based on the provided id
	 * @param theId
	 * @return a single resource
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
        return service.getResourceById(theId.getIdPart(), ResourceType.Organization.name());
	}

	/**
	 * This method will return the bundle of resources based
	 * on the search parameters passed in the request
	 * @param theId
	 * @param adderss
	 * @param addressCity
	 * @param addressState
	 * @param addressPostalCode
	 * @param endpoint,chainParameters{Endpoint.SP_IDENTIFIER, 
	 * Endpoint.SP_CONNECTION_TYPE}
	 * @param name
	 * @param partof
	 * @param includes{"Organization:partof", "Organization:endpoint" }
	 * @param revIncludes{"Endpoint:organization", 
	 * "HealthcareService:organization", "InsurancePlan:administered-by", 
	 * "InsurancePlan:owned-by", "OrganizationAffiliation:primary-organization", 
	 * "PractitionerRole:organization", "PractitionerRole:network",
	 * "OrganizationAffiliation:participating-organization" }
	 * @return bundle of resources
	 */
	@Search()
	public IBundleProvider searchOrganization(
			@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = Organization.SP_ADDRESS) StringAndListParam adderss,
			@OptionalParam(name = Organization.SP_ADDRESS_CITY) StringAndListParam addressCity,
            @OptionalParam(name = Organization.SP_ADDRESS_STATE) StringAndListParam addressState,
            @OptionalParam(name = Organization.SP_ADDRESS_POSTALCODE) StringAndListParam addressPostalCode,
			@OptionalParam(name = Organization.SP_ENDPOINT, chainWhitelist = {"",Endpoint.SP_IDENTIFIER, Endpoint.SP_CONNECTION_TYPE}) 
			ReferenceAndListParam endpoint,
			@OptionalParam(name = Organization.SP_NAME) StringAndListParam name,
			@OptionalParam(name = Organization.SP_PARTOF) ReferenceAndListParam partof,
			@OptionalParam(name = Organization.SP_TYPE) TokenAndListParam type,
			@OptionalParam(name = DavinciOrganization.SP_COVERAGE_AREA) ReferenceAndListParam coverageArea,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@IncludeParam(allow = {"Organization:partof", "Organization:endpoint" }) Set<Include> includes,
			@IncludeParam(reverse = true, allow = {
					"Endpoint:organization", "HealthcareService:organization", "InsurancePlan:administered-by", "InsurancePlan:owned-by",
					"OrganizationAffiliation:primary-organization", "PractitionerRole:organization", "PractitionerRole:network",
					"OrganizationAffiliation:participating-organization" }) Set<Include> revIncludes
	) {

		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(IAnyResource.SP_RES_ID, theId);
		paramMap.add(Organization.SP_ADDRESS, adderss);
		paramMap.add(Organization.SP_ADDRESS_CITY,addressCity);
        paramMap.add(Organization.SP_ADDRESS_STATE,addressState);
        paramMap.add(Organization.SP_ADDRESS_POSTALCODE,addressPostalCode);
		paramMap.add(Organization.SP_ENDPOINT, endpoint);
		paramMap.add(Organization.SP_NAME, name);
		paramMap.add(Organization.SP_PARTOF, partof);
		paramMap.add(Organization.SP_TYPE, type);
		paramMap.add(DavinciOrganization.SP_COVERAGE_AREA, coverageArea);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		if (revIncludes != null && !revIncludes.isEmpty()) {
			paramMap.setRevIncludes(revIncludes);
		}
		if (includes != null && !includes.isEmpty()) {
			paramMap.setIncludes(includes);
		}
	
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
        return service.getResources(paramMap, ResourceType.Organization.name());
	}
}

package com.citiustech.fastplus.test.provider;

public class TestConstantsBulk {

	

	public static final String tableConfigString = "{\r\n" + 
			"	\"searchTableMap\": {\r\n" + 
			"		\"Location\": {\r\n" + 
			"			\"table\": \"fhirrepo.locationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			],\r\n" + 
			"			\"nestedsearchAttributes\": {\r\n" + 
			"				\"address\": [\r\n" + 
			"					\"address-line\",\r\n" + 
			"					\"address-city\",\r\n" + 
			"					\"address-state\",\r\n" + 
			"					\"address-postalcode\",\r\n" + 
			"					\"address-country\",\r\n" + 
			"					\"address-use\",\r\n" + 
			"					\"address-district\"\r\n" + 
			"				]\r\n" + 
			"			}\r\n" + 
			"		},\r\n" + 
			"		\"CarePlan\": {\r\n" + 
			"			\"table\": \"fhirrepo.careplansearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			],\r\n" + 
			"			\"periodSearchAttribute\": [\r\n" + 
			"				\"date\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"CareTeam\": {\r\n" + 
			"			\"table\": \"fhirrepo.careteamsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Patient\": {\r\n" + 
			"			\"table\": \"fhirrepo.patientsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			],\r\n" + 
			"			\"nestedsearchAttributes\": {\r\n" + 
			"				\"name\": [\r\n" + 
			"					\"given\",\r\n" + 
			"					\"family\"\r\n" + 
			"				]\r\n" + 
			"			}\r\n" + 
			"		},\r\n" + 
			"		\"Practitioner\": {\r\n" + 
			"			\"table\": \"fhirrepo.practitionersearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			],\r\n" + 
			"			\"nestedsearchAttributes\": {\r\n" + 
			"				\"name\": [\r\n" + 
			"					\"given\",\r\n" + 
			"					\"family\"\r\n" + 
			"				]\r\n" + 
			"			}\r\n" + 
			"		},\r\n" + 
			"		\"Immunization\": {\r\n" + 
			"			\"table\": \"fhirrepo.immunizationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Encounter\": {\r\n" + 
			"			\"table\": \"fhirrepo.encountersearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			],\r\n" + 
			"			\"periodSearchAttribute\": [\r\n" + 
			"				\"date\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"MedicationDispense\": {\r\n" + 
			"			\"table\": \"fhirrepo.medicationdispensesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"PractitionerRole\": {\r\n" + 
			"			\"table\": \"fhirrepo.practitionerrolesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Goal\": {\r\n" + 
			"			\"table\": \"fhirrepo.goalsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Medication\": {\r\n" + 
			"			\"table\": \"fhirrepo.medicationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"InsurancePlan\": {\r\n" + 
			"			\"table\": \"fhirrepo.insuranceplanSearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"OrganizationAffiliation\": {\r\n" + 
			"			\"table\": \"fhirrepo.organizationaffiliationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Organization\": {\r\n" + 
			"			\"table\": \"fhirrepo.organizationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			],\r\n" + 
			"			\"nestedsearchAttributes\": {\r\n" + 
			"				\"address\": [\r\n" + 
			"					\"address-line\",\r\n" + 
			"					\"address-city\",\r\n" + 
			"					\"address-state\",\r\n" + 
			"					\"address-postalcode\",\r\n" + 
			"					\"address-country\",\r\n" + 
			"					\"address-use\",\r\n" + 
			"					\"address-district\"\r\n" + 
			"				]\r\n" + 
			"			}\r\n" + 
			"		},\r\n" + 
			"		\"HealthcareService\": {\r\n" + 
			"			\"table\": \"fhirrepo.healthcareservicesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Provenance\": {\r\n" + 
			"			\"table\": \"fhirrepo.provenancesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Endpoint\": {\r\n" + 
			"			\"table\": \"fhirrepo.endpointsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"AllergyIntolerance\": {\r\n" + 
			"			\"table\": \"fhirrepo.allergyintolerancesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Condition\": {\r\n" + 
			"     		\"table\": \"fhirrepo.conditionSearch\",\r\n" + 
			"      		\"projections\": [\r\n" + 
			"        			\"id\",\"patient_id\"\r\n" + 
			"      		]\r\n" + 
			"    	},\r\n" + 
			"		\"Observation\": {\r\n" + 
			"			\"table\": \"fhirrepo.observationsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"DiagnosticReport\": {\r\n" + 
			"			\"table\": \"fhirrepo.diagnosticreportsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"List\": {\r\n" + 
			"			\"table\": \"fhirrepo.listsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Procedure\": {\r\n" + 
			"			\"table\": \"fhirrepo.proceduresearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			],\r\n" + 
			"			 \"periodSearchAttribute\": [\r\n" + 
			"				\"date\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"MedicationRequest\": {\r\n" + 
			"			\"table\": \"fhirrepo.medicationrequestsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Device\": {\r\n" + 
			"			\"table\": \"fhirrepo.devicesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"DocumentReference\": {\r\n" + 
			"			\"table\": \"fhirrepo.documentreferencesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			],\r\n" + 
			"			\"periodSearchAttribute\": [\r\n" + 
			"				\"period\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Coverage\": {\r\n" + 
			"			\"table\": \"fhirrepo.coveragesearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\",\"patient_id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"MedicationKnowledge\": {\r\n" + 
			"            \"table\": \"fhirrepo.medicationknowledgesearch\",\r\n" + 
			"            \"projections\": [\r\n" + 
			"                \"id\"\r\n" + 
			"            ]\r\n" + 
			"        },\r\n" + 
			"		\"ExplanationOfBenefit\": {\r\n" + 
			"            \"table\": \"fhirrepo.explanationofbenefitsearch\",\r\n" + 
			"            \"projections\": [\r\n" + 
			"                \"id\",\"patient_id\"\r\n" + 
			"            ],\r\n" + 
			"            \"periodSearchAttribute\": [\r\n" + 
			"				\"service-date\"\r\n" + 
			"			]\r\n" + 
			"        },\r\n" + 
			"        \"RelatedPerson\": {\r\n" + 
			"            \"table\": \"fhirrepo.relatedpersonsearch\",\r\n" + 
			"            \"projections\": [\r\n" + 
			"                \"id\",\"patient_id\"\r\n" + 
			"            ],\r\n" + 
			"            \"nestedsearchAttributes\": {\r\n" + 
			"				\"name\": [\r\n" + 
			"					\"given\",\r\n" + 
			"					\"family\"\r\n" + 
			"				],\r\n" + 
			"				\"address\": [  \r\n" + 
			"					\"address-line\",\r\n" + 
			"					\"address-city\",\r\n" + 
			"					\"address-state\",\r\n" + 
			"					\"address-postalcode\",\r\n" + 
			"					\"address-country\",\r\n" + 
			"					\"address-use\",\r\n" + 
			"					\"address-district\"\r\n" + 
			"				]\r\n" + 
			"			}\r\n" + 
			"        },\r\n" + 
			"        \"Contract\": {\r\n" + 
			"			\"table\": \"fhirrepo.contractsearch\",\r\n" + 
			"			\"projections\": [\r\n" + 
			"				\"id\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"Group\": {\r\n" + 
			"            \"table\": \"fhirrepo.groupsearch\",\r\n" + 
			"            \"projections\": [\r\n" + 
			"                \"id\"\r\n" + 
			"            ]\r\n" + 
			"        }\r\n" + 
			"	},\r\n" + 
			"	\"resourceLinkTable\": {\r\n" + 
			"		\"table\": [\r\n" + 
			"			\"fhirrepo.resourcelink\",\r\n" + 
			"			\"fhirrepo.resourcelink_provenance\"\r\n" + 
			"		],\r\n" + 
			"		\"projections\": [\r\n" + 
			"			\"srcid,trgtid,trgttype\"\r\n" + 
			"		],\r\n" + 
			"		\"typeColumnMap\": {\r\n" + 
			"			\"ReferenceParam\": [\r\n" + 
			"				\"trgttype\",\r\n" + 
			"				\"srctype\",\r\n" + 
			"				\"trgtid\",\r\n" + 
			"				\"srcid\",\r\n" + 
			"				\"attribute\"\r\n" + 
			"			]\r\n" + 
			"		},\r\n" + 
			"		\"nestedsearchAttributes\": {\r\n" + 
			"			\r\n" + 
			"		}\r\n" + 
			"	},\r\n" + 
			"	\"resourceInfoTable\": {\r\n" + 
			"		\"table\": [\r\n" + 
			"			\"resourceinfo\",\r\n" + 
			"			\"resourceinfo_provenance\"\r\n" + 
			"		],\r\n" + 
			"		\"projections\": [\r\n" + 
			"			\"id\",\r\n" + 
			"			\"resourcetext\"\r\n" + 
			"		],\r\n" + 
			"		\"nestedsearchAttributes\": {\r\n" + 
			"			\r\n" + 
			"		}\r\n" + 
			"	},\r\n" + 
			"	\"typeColumnMap\": {\r\n" + 
			"		\"token\": [\r\n" + 
			"			\"system\",\r\n" + 
			"			\"code\"\r\n" + 
			"		],\r\n" + 
			"		\"string\": [\r\n" + 
			"			\"value\"\r\n" + 
			"		],\r\n" + 
			"		\"date\": [\r\n" + 
			"			\"startdate\",\r\n" + 
			"			\"enddate\",\r\n" + 
			"			\"lastupdated\"\r\n" + 
			"		],\r\n" + 
			"		\"reference\": [\r\n" + 
			"			\"trgttype\",\r\n" + 
			"			\"srctype\",\r\n" + 
			"			\"trgtid\",\r\n" + 
			"			\"srcid\",\r\n" + 
			"			\"value\"\r\n" + 
			"		],\r\n" + 
			"		\"uri\": [\r\n" + 
			"			\"value\"\r\n" + 
			"		],\r\n" + 
			"		\"composite\": [\r\n" + 
			"			\"id\"\r\n" + 
			"		]\r\n" + 
			"	},\r\n" + 
			"	\"jsonColumn\": \"resourcetext\",\r\n" + 
			"	\"idColumn\": \"id\",\r\n" + 
			"	\"valueColumn\":\"value\",\r\n" + 
			"	\"searchAttributeColumn\": \"attribute\",\r\n" + 
			"	\"schema\": \"fhirrepo\",\r\n" + 
			"	\"pidColumn\":\"patient_id\",\r\n" + 
			"	\"resourceType\":\"resourcetype\",\r\n" + 
			"	\"lastUpdated\":\"lastupdated\"\r\n" + 
			"}";

	
}

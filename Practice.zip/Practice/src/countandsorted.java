import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class countandsorted {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc = new Scanner(System.in);
		List<String> l = Arrays.asList("dogs","cats","horses","bee","cats","dogs","cat","ant","bee");
		//System.out.println(l.stream().filter(i->i.equals("dogs")).count());
		Collections.sort(l);
		Map<String,Integer> map = new LinkedHashMap<String,Integer>();
		for(int i=0;i<l.size();i++) {
			if(!map.containsKey(l.get(i))) {
				int count=0;
				for(int j=i;j<l.size();j++) {
					if(l.get(i).equals(l.get(j))){
						count++;
					}
				}
				map.put(l.get(i),count);
				
			}
		
		}
		map.forEach((X,Y)->System.out.println(X+" "+Y));

	}

}

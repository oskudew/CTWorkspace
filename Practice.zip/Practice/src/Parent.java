//method1
public class Parent extends child {
	///in this parent is child and child is parent
	Parent(){
		System.out.println("Parent");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//child p =new Parent();
		//Parent q =new child();
		//child c= new child();
		Parent p1= new Parent();
	}

	
}

 class child {
	child(int i){
		System.out.println("child");
	}
	child(){
		System.out.println("child without constructor");
		
	}
	

	
}

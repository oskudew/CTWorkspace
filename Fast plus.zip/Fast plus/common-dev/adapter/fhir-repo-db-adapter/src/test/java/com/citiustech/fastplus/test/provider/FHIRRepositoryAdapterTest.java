package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.FHIRRepositoryAdapter;
import com.citiustech.fastplus.adapter.dao.FHIRRepositoryDAO;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;

@ExtendWith(MockitoExtension.class)
class FHIRRepositoryAdapterTest {
	
	@InjectMocks
	FHIRRepositoryAdapter fhirRepositoryAdapter;
	
	@Mock
	private FHIRRepositoryDAO fhirRepositoryDao;
	
	@Mock
	private DeepNestedSqlBuilder sqlBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
	
	@Spy
	private CommonQueryUtil commonQueryUtil;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,FHIRRepositoryTableConfiguration.class);
		 fhirRepositoryTableConfiguration.duplicateTypeMap();
		 
	}
	
	
	String resourceType = ResourceType.Organization.name();
	String value = "Thailand";
	String paramName = Organization.SP_ADDRESS_CITY;

	@DisplayName("Test case for getIdsForResource method")
	@Test
	void test_getIdsForResource() {
		
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue(value).newInstance();
		parameterMap.add(paramName,stringAndListParam);
		
		String condition = "SELECT DISTINCT OrganizationFePD.id FROM organizationsearch OrganizationFePD WHERE "
				+ "((OrganizationFePD.attribute = 'address-city') AND (OrganizationFePD.value ILIKE 'Thailand%')) LIMIT 500";
		
		when(sqlBuilder.buildNestedQueriesForSearchParams(resourceType, parameterMap)).thenReturn(condition);
		
		List<IdProjectionRow> projectionRows = new ArrayList<>();
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-coveragetest",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-ntwk-Net501",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org201",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org201_nw",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org202",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org203_nw",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org204_nw",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org205_nw",null));
		projectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org50011",null));
		
		when(fhirRepositoryDao
				.executeForIds(condition)).thenReturn(projectionRows);
		
		List<IdProjectionRow> actualValue = fhirRepositoryAdapter.getIdsForResource(resourceType, parameterMap);
		List<IdProjectionRow> expectedValue = projectionRows;
		
		assertEquals(expectedValue,actualValue);
		
	}
	
	@DisplayName("Test case for getResourceJsons method to test frameJsonRetrievalQuery(private) method")
	@Test
	void test_getResourceJsons() {
		String queryPrivateMethod = "SELECT id,resourcetext FROM fhirrepo.resourceinfo resourceinfo WHERE ((resourceinfo.resourcetype = 'Organization') AND "
				+ "(resourceinfo.id IN ('Kern-coveragetest') ))";
		
		List<Serializable> ids = new ArrayList<>();
		ids.add("Kern-coveragetest");
		
		List<String> result = new ArrayList<>();
		String resultValue	= "{\"id\": \"Kern-coveragetest\", \"meta\": {\"versionId\": \"1\", \"lastUpdated\": \"2020-12-01T09:44:45.268+00:00\"}, \"name\": \"BAYSIDE ENDOSCOPY,Garrettside\", \"type\": [{\"coding\": [{\"code\": \"atyprv\", \"system\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/OrgTypeCS\", \"display\": \"Atypical Provider\"}]}], \"alias\": [\"Alternate Location Name\"], \"active\": true, \"address\": [{\"city\": \"Thailand\", \"line\": [\"80288 Susan Isle New Jacobfort, IL 00729\", \"Garrettside\"], \"state\": \"State C\", \"district\": \"Thailand\", \"extension\": [{\"url\": \"http://hl7.org/fhir/StructureDefinition/geolocation\", \"extension\": [{\"url\": \"latitude\", \"valueDecimal\": -71.41177}, {\"url\": \"longitude\", \"valueDecimal\": 41.809006}]}], \"postalCode\": \"73848\"}], \"telecom\": [{\"rank\": 1, \"value\": \"-4796\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"mon\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"tue\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"wed\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"thu\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"fri\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sat\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sun\"}, {\"url\": \"allDay\", \"valueBoolean\": false}, {\"url\": \"availableStartTime\", \"valueTime\": \"08:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 2, \"value\": \"377-582-4948x803\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"wed\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"thu\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"fri\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sat\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"sun\"}, {\"url\": \"allDay\", \"valueBoolean\": false}, {\"url\": \"availableStartTime\", \"valueTime\": \"20:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 3, \"value\": \"369.518.7681x4340\", \"system\": \"phone\", \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/contactpoint-availabletime\", \"extension\": [{\"url\": \"daysOfWeek\", \"valueCode\": \"mon\"}, {\"url\": \"daysOfWeek\", \"valueCode\": \"tue\"}, {\"url\": \"allDay\", \"valueBoolean\": true}, {\"url\": \"availableStartTime\", \"valueTime\": \"20:29:47\"}, {\"url\": \"availableEndTime\", \"valueTime\": \"00:02:17\"}]}]}, {\"rank\": 1, \"value\": \"wilsondonna@yahoo.com\", \"system\": \"email\"}, {\"rank\": 2, \"value\": \"bryantnicholas@jones.com\", \"system\": \"email\"}], \"extension\": [{\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/location-reference\", \"valueReference\": {\"reference\": \"Location/QA-test-xyz\"}}], \"identifier\": [{\"type\": {\"coding\": [{\"code\": \"NPI\"}]}, \"value\": \"NPI22\", \"system\": \"http://hl7.org/fhir/sid/us-npi\"}, {\"type\": {\"coding\": [{\"code\": \"TAX\"}]}, \"value\": \"TIN2101\", \"system\": \"urn:oid:2.16.840.1.113883.4.4\"}, {\"type\": {\"coding\": [{\"code\": \"CLIA\"}]}, \"value\": \"CLIA1\", \"system\": \"urn:oid:2.16.840.1.113883.4.7\"}, {\"type\": {\"coding\": [{\"code\": \"Additionalids\"}]}, \"value\": \"ABC101\", \"system\": \"http://www.acme.com/identifiers/patient\"}, {\"type\": {\"coding\": [{\"code\": \"Additionalids\"}]}, \"value\": \"XYZ101\", \"system\": \"http://www.acme.com/identifiers/patient\"}], \"resourceType\": \"Organization\"}\"";
		result.add(resultValue);
		
		when(fhirRepositoryDao.executeForString(queryPrivateMethod,ids)).thenReturn(result);
		
		List<String> actualValue = fhirRepositoryAdapter.getResourceJsons(ids, resourceType);
		List<String> expectedValue = result;
		
		assertEquals(expectedValue,actualValue);
	}
	
	
	@DisplayName("Test case for getIncludedIds method to test frameIncludeQuery(private) method")
	@Test
	void test_getIncludedIds() {
		List<IdProjectionRow> listOfBaseIds = new ArrayList<>();
		listOfBaseIds.add(new IdProjectionRow(resourceType,"Orgtestchain",null));
		
		Set<Include> setOfIncludes = new HashSet<>();
		setOfIncludes.add(new Include("Organization:partof",false));
		
		String queryPrivateMethod = "SELECT resourcelink.trgtid,resourcelink.trgttype FROM fhirrepo.resourcelink resourcelink WHERE ((resourcelink.srctype = 'Organization') AND ((resourcelink.srcid IN ('Orgtestchain') ) AND (attribute IN ('partof') )))";
		
		Map<String, List<Serializable>> result = new HashMap<>();
		List<Serializable> resultValue = new ArrayList<>();
		resultValue.add("Orgref");
		result.put(resourceType, resultValue);
		
		when(fhirRepositoryDao.executeForMapData(queryPrivateMethod)).thenReturn(result);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
		
		Map<String, List<Serializable>> actualValue = fhirRepositoryAdapter.getIncludedIds(listOfBaseIds,setOfIncludes, resourceType);
		Map<String, List<Serializable>> expectedValue = result;
		
		assertEquals(expectedValue,actualValue);
		
	}	
	
	@DisplayName("Test case for getRevIncludedIds method to test frameRevIncludeQuery(private) method")
	@Test
	void test_getRevIncludedIds() {
		resourceType = ResourceType.Practitioner.name();
		
		List<IdProjectionRow> listOfBaseIds = new ArrayList<>();
		listOfBaseIds.add(new IdProjectionRow(resourceType,"Kern-pract-109",null));
		
		Set<Include> setOfRevIncludes = new HashSet<>();
		setOfRevIncludes.add(new Include("PractitionerRole:practitioner",false));
		
		String queryPrivateMethod = "SELECT resourcelink.srcid,resourcelink.srctype FROM fhirrepo.resourcelink resourcelink WHERE ((resourcelink.trgtid IN ('Kern-pract-109') ) AND (resourcelink.srctype IN ('PractitionerRole') ) AND (attribute IN ('practitioner') ))";
		
		Map<String, List<Serializable>> result = new HashMap<>();
		List<Serializable> resultValue = new ArrayList<>();
		resultValue.add("Kern-practrole-RoleId109");
		result.put(resourceType, resultValue);
		
		when(fhirRepositoryDao.executeForMapData(queryPrivateMethod)).thenReturn(result);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
		
		Map<String, List<Serializable>> actualValue = fhirRepositoryAdapter.getRevIncludedIds(listOfBaseIds,setOfRevIncludes, resourceType);
		Map<String, List<Serializable>> expectedValue = result;
		
		assertEquals(expectedValue,actualValue);
		
	}	
	
	@DisplayName("Test case for getPaginatedIdsForResource method")
	@Test
	void test_getPaginatedIdsForResource() {
		resourceType = ResourceType.ExplanationOfBenefit.name();
		String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		TokenAndListParam tokenAndListParam = new TokenFactory().setReferenceValue(value)
				.newInstance();
		parameterMap.add(IAnyResource.SP_RES_ID,tokenAndListParam);
		parameterMap.setPatientSearchParam("patient");
		
		String condition = "SELECT ExplanationOfBenefitUWdJ.id,ExplanationOfBenefitUWdJ.patient_id FROM explanationofbenefitsearch ExplanationOfBenefitUWdJ WHERE ((ExplanationOfBenefitUWdJ.attribute = '_id') AND (ExplanationOfBenefitUWdJ.code = '8d38f846-b98a-3010-565c-4f91be9ff3fc')) ORDER BY ExplanationOfBenefitUWdJ.id LIMIT 500";
		List<IdProjectionRow> projectionRows = new ArrayList<>();
		
		when(sqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, parameterMap)).thenReturn(condition);
		when(fhirRepositoryDao
					.executeForIds(condition)).thenReturn(projectionRows);
		  
		List<IdProjectionRow> actualValue = fhirRepositoryAdapter.getPaginatedIdsForResource(resourceType, parameterMap);
		List<IdProjectionRow> expectedValue = projectionRows;
			
		assertEquals(expectedValue,actualValue);
		
	}

}

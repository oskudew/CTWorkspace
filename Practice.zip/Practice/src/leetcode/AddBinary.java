package leetcode;

public class AddBinary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="11";
		String b="1";
		String c="";
		StringBuffer d=new StringBuffer();
		int size=Math.abs(a.length()-b.length());
		for(int i=0;i<size;i++) {
			c=c+0;
		}
		if(a.length()>b.length()) b=c+b;
		else a=c+b;
		System.out.println(a +" "+b);
		
		int carry=0;
		System.out.println(a.charAt(1)+"  "+b.charAt(1)+"  "+a.length() );
		for(int j=a.length()-1;j>=0;j--) {
		
			if(a.charAt(j)=='0'&& b.charAt(j)=='1') {
				if(carry==1) d.append(0);
				else {
					 d.append(1);
				}
			}
			else if(a.charAt(j)=='1'&& b.charAt(j)=='0') {
				System.out.println("Enter in 1,0");
				if(carry==1) d.append(0);
				else  d.append(1);
			
			}
			else if(a.charAt(j)=='1'&& b.charAt(j)=='1') {
				System.out.println("enter in else");
				if(carry==1) d.append(1);
				else  d.append(0);
				carry=1;
			}
			else {
				//if(a.charAt(j)=='0'&& b.charAt(j)=='0') {
				if(carry==1)  d.append(1);
				else {
					 d.append(0);
				}
				carry=0;
			}
		}
		if(carry==1) d.append(1);
		System.out.println(d.reverse());
	}

}

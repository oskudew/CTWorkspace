package com.citiustech.fastplus.util;

import ca.uhn.fhir.model.api.IQueryParameterAnd;
import ca.uhn.fhir.rest.param.*;
import com.citiustech.fastplus.SearchParameterRequest;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * 
 * This is a class for AdapterConsentUtil which provides utility methods for consent adapter
 * classes to frame a query
 * 
 */
@Component
public class AdapterConsentUtil {

    @Autowired
    CommonQueryUtil commonQueryUtil;

    /**
     * sets search parameters based on valid patients
     */
    public void setSearchParam(SearchParameterRequest searchParameterReq, List<String> validPatients) {

	if (Objects.nonNull(searchParameterReq.getParameterMap().get(searchParameterReq.getPatientSearchParam()))) {
	    removePatientParam(searchParameterReq, validPatients);
	} else {
	    if (searchParameterReq.getPatientSearchParam().equals(IAnyResource.SP_RES_ID)) {
		TokenOrListParam tokenOrListParam = new TokenOrListParam();
		for (String patientId : validPatients) {
		    tokenOrListParam.add(new TokenParam(patientId));
		}
		searchParameterReq.getParameterMap().put(searchParameterReq.getPatientSearchParam(),
			new TokenAndListParam().addAnd(tokenOrListParam));

	    } else {
		ReferenceOrListParam refOrListParam = new ReferenceOrListParam();
		for (String patientId : validPatients) {
		    refOrListParam.add(new ReferenceParam(patientId));
		}
		searchParameterReq.getParameterMap().put(searchParameterReq.getPatientSearchParam(),
			new ReferenceAndListParam().addAnd(refOrListParam));
	    }
	}

    }

    @SuppressWarnings("rawtypes")
    public void removePatientParam(SearchParameterRequest searchParameterReq, List<String> validPatients) {
	IQueryParameterAnd andQueryParam = searchParameterReq.getParameterMap()
		.get(searchParameterReq.getPatientSearchParam());
	removeFromReferenceOrTokenList(andQueryParam, validPatients);
	removeFromSearchReq(andQueryParam, searchParameterReq);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    private void removeFromReferenceOrTokenList(IQueryParameterAnd andQueryParam, List<String> validPatients) {
	andQueryParam.getValuesAsQueryTokens().forEach(list -> {
	    if (list instanceof ReferenceOrListParam) {
		removeFromReferenceList((ReferenceOrListParam) list, validPatients);
	    }
	    if (list instanceof TokenOrListParam) {
		removeFromTokenList((TokenOrListParam) list, validPatients);
	    }
	});
    }

    @SuppressWarnings("rawtypes")
    private void removeFromSearchReq(IQueryParameterAnd andQueryParam, SearchParameterRequest searchParameterReq) {
	if (!andQueryParam.getValuesAsQueryTokens().isEmpty() && andQueryParam.getValuesAsQueryTokens().size() == 1) {
	    if (andQueryParam instanceof ReferenceAndListParam && ((ReferenceAndListParam) andQueryParam)
		    .getValuesAsQueryTokens().get(0).getValuesAsQueryTokens().isEmpty()) {
		removeFromSearchReq(searchParameterReq);
	    }
	    if (andQueryParam instanceof TokenAndListParam && ((TokenAndListParam) andQueryParam)
		    .getValuesAsQueryTokens().get(0).getValuesAsQueryTokens().isEmpty()) {
		removeFromSearchReq(searchParameterReq);
	    }
	}
    }

    /**
     * removes entry from searchParameterReq map
     * 
     * @param searchParameterReq
     */
    private static void removeFromSearchReq(SearchParameterRequest searchParameterReq) {
	searchParameterReq.getParameterMap().remove(searchParameterReq.getPatientSearchParam());
    }

    /**
     * removes entry from token list if not belongs to valid patient
     * 
     * @param list
     * @param validPatients
     */
    private void removeFromTokenList(TokenOrListParam list, List<String> validPatients) {
	list.getValuesAsQueryTokens().removeIf(param -> !validPatients.contains(commonQueryUtil.findPrefixValue("Patient",param.getValue())));
    }

    /**
     * removes entry from reference list if not belongs to valid patient
     * 
     * @param list
     * @param validPatients
     */
    private void removeFromReferenceList(ReferenceOrListParam list, List<String> validPatients) {
	list.getValuesAsQueryTokens()
		.removeIf(param -> !validPatients.contains(commonQueryUtil.findPrefixValue("Patient",param.getIdPart())));
    }
}

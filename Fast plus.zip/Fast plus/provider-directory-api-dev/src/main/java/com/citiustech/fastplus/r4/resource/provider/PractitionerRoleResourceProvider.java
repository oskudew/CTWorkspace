package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.r4.model.DavinciPractitionerRole;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 
 * This class is the  PractitionerRole resource provider class
 * which will read and serves all supported search requests
 * for PractitionerRole resource
 *
 */
@Component
public class PractitionerRoleResourceProvider implements IResourceProvider{

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
	private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(PractitionerRoleResourceProvider.class.getName());

	 @Override
	public Class<? extends IBaseResource> getResourceType() {
		return  DavinciPractitionerRole.class;
	}

	/**
	 * This method will return PractitionerRole resource based on the provided id
	 * @param theId
	 * @return a single resource
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
		return service.getResourceById(theId.getIdPart(), ResourceType.PractitionerRole.name());
	}

	/**
	 * This method will return the bundle of resources based
	 * on the search parameters passed in the request
	 * @param id
	 * @param endpoint,chainParameters{Endpoint.SP_IDENTIFIER, 
	 * Endpoint.SP_CONNECTION_TYPE}
	 * @param location,chainParameters{Location.SP_IDENTIFIER, 
	 * Location.SP_TYPE, Location.SP_ADDRESS}
	 * @param networkReference,chainParameters{Organization.SP_IDENTIFIER, 
	 * Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}
	 * @param organization,chainParameters{Organization.SP_IDENTIFIER, 
	 * Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}
	 * @param healthcareService,chainParameters{HealthcareService.SP_IDENTIFIER, 
	 * HealthcareService.SP_SERVICE_CATEGORY}
	 * @param practitioner
	 * @param role
	 * @param speciality
	 * @param includes{"PractitionerRole:practitioner", 
	 * "PractitionerRole:organization", "PractitionerRole:location",
	 * "PractitionerRole:service", "PractitionerRole:network", 
	 * "PractitionerRole:endpoint"}
	 * @return bundle of resources
	 */
	@Search()
	public IBundleProvider searchPractitionerRole(
			@OptionalParam(name=IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name=PractitionerRole.SP_ENDPOINT, chainWhitelist = {"", Endpoint.SP_IDENTIFIER, Endpoint.SP_CONNECTION_TYPE}) ReferenceAndListParam endpoint,
			@OptionalParam(name=PractitionerRole.SP_LOCATION, chainWhitelist = {"", Location.SP_IDENTIFIER, Location.SP_TYPE, Location.SP_ADDRESS}) ReferenceAndListParam location,
			@OptionalParam(name=DavinciPractitionerRole.SP_NETWORK, chainWhitelist = {"", Organization.SP_IDENTIFIER, Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}) ReferenceAndListParam network,
			@OptionalParam(name=PractitionerRole.SP_ORGANIZATION, chainWhitelist = {"", Organization.SP_IDENTIFIER, Organization.SP_TYPE, Organization.SP_NAME, Organization.SP_ADDRESS}) ReferenceAndListParam organization,
			@OptionalParam(name=PractitionerRole.SP_SERVICE, chainWhitelist = {"", HealthcareService.SP_IDENTIFIER, HealthcareService.SP_SERVICE_CATEGORY}) ReferenceAndListParam healthcareService,
			@OptionalParam(name=PractitionerRole.SP_PRACTITIONER) ReferenceAndListParam practitioner,
			@OptionalParam(name=PractitionerRole.SP_ROLE) TokenAndListParam role,
			@OptionalParam(name=PractitionerRole.SP_SPECIALTY) TokenAndListParam speciality,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@IncludeParam(allow = {"PractitionerRole:practitioner", "PractitionerRole:organization", "PractitionerRole:location",
					"PractitionerRole:service", "PractitionerRole:network", "PractitionerRole:endpoint"}) Set<Include> includes
	) {

		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(IAnyResource.SP_RES_ID, theId);
		paramMap.add(PractitionerRole.SP_ENDPOINT, endpoint);
		paramMap.add(PractitionerRole.SP_LOCATION, location);
		paramMap.add(DavinciPractitionerRole.SP_NETWORK, network);
		paramMap.add(PractitionerRole.SP_ORGANIZATION, organization);
		paramMap.add(PractitionerRole.SP_PRACTITIONER, practitioner);
		paramMap.add(PractitionerRole.SP_ROLE, role);
		paramMap.add(PractitionerRole.SP_SERVICE, healthcareService);
		paramMap.add(PractitionerRole.SP_SPECIALTY, speciality);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		if (includes != null && !includes.isEmpty()) {
			paramMap.setIncludes(includes);
		}
		
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
		return service.getResources(paramMap,ResourceType.PractitionerRole.name());
	}
}

package com.citiustech.fastplus.identityprovider;

import java.util.Collection;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;

/**
 * 
 * It is an interface for IdentityProviderAccessTokenExtractor used to define
 * and extends from Converter,collection,IAccessTokenExtractor Its set the role
 *
 */

public interface IdentityProviderAccessTokenExtractor
		extends Converter<Jwt, Collection<GrantedAuthority>>, IAccessTokenExtractor {

	/**
	 * returns roles or permissions by extracting it from JWT token
	 * 
	 * @param jwt
	 * @return list of GrantedAuthorities
	 */
	Collection<GrantedAuthority> getGrantedAuthorities(Jwt jwt);

}

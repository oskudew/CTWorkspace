package com.citiustech.fastplus.identityprovider.okta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Scope;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.citiustech.fastplus.identityprovider.AuthorityPrefix;
import com.citiustech.fastplus.identityprovider.IdentityProviderAccessTokenExtractor;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;

/**
 * 
 * This is a class for OktaAccessTokenExtractor used to extract Okta specific
 * values from access token for identity management.
 *
 */

@Component(value = "okta")
@Scope(value = "prototype")
public class OktaAccessTokenExtractor implements IdentityProviderAccessTokenExtractor {

	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(OktaAccessTokenExtractor.class.getName());

	@Override
	public Collection<GrantedAuthority> convert(Jwt jwt) {
		return getGrantedAuthorities(jwt);
	}

	@Override
	public Collection<GrantedAuthority> getGrantedAuthorities(Jwt jwt) {

		Collection<GrantedAuthority> oktaRoles = new ArrayList<>();
		try {
			final List<String> groups = this.getRoles(jwt);
			final List<String> scopes = this.getScope(jwt);

			if (Objects.nonNull(groups))
				oktaRoles.addAll(groups.stream().map(role -> AuthorityPrefix.ROLE.toString() + role)
						.map(SimpleGrantedAuthority::new).collect(Collectors.toList()));

			if (Objects.nonNull(scopes))
				oktaRoles.addAll(scopes.stream().map(scope -> AuthorityPrefix.SCOPE.toString() + scope)
						.map(SimpleGrantedAuthority::new).collect(Collectors.toList()));

		} catch (Exception e) {
			oktaRoles = Collections.emptyList();
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Error while extracting grant authority from access token ", e);
		}
		return oktaRoles;
	}

	@Override
	public String getIssuedFor(Jwt jwt) {
		String issuedFor = "application";
		try {
			issuedFor = jwt.getClaimAsString(OktaConstants.CLIENT_NAME.toString());
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Error while extracting issued for from access token ", e);
		}

		return issuedFor;
	}

	@Override
	public String getPreferredUsername(Jwt jwt) {
		String preferredusername = "anonymous";
		try {
			preferredusername = jwt.getClaimAsString(OktaConstants.USERNAME.toString());
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Error while extracting preferred_username from access token :", e);
		}
		return preferredusername;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getRoles(Jwt jwt) {
		return (List<String>) jwt.getClaims().get(OktaConstants.ROLES.toString());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getScope(Jwt jwt) {
		Object authorities = jwt.getClaim(OktaConstants.SCOPE.toString());
		if (authorities instanceof String) {
			if (StringUtils.hasText((String) authorities)) {
				return Arrays.asList(((String) authorities).split(" "));
			} else {
				return Collections.emptyList();
			}
		} else if (authorities instanceof Collection) {
			return (List<String>) authorities;
		}

		return Collections.emptyList();
	}

	@Override
	public Map<String, Object> getUserAttributes(Jwt jwt) {
		// user attribute implementation will add here 
		return null;
	}

	@Override
	public Object getClaimByKey(String key, Jwt jwt) {
		// token claim implementation
		return null;
	}

}
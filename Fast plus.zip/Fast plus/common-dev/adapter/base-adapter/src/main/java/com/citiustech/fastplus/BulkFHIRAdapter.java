package com.citiustech.fastplus;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citiustech.fastplus.adapter.structure.StatusParam;

/**
 * 
 * This is an interface for Adapter for Bulk FHIR API defines methods to interact with dao classes
 * to perform operations related to a resource
 * 
 */	
public interface BulkFHIRAdapter{
	
	/**
	 * returns resource in a json format based on resource id and type
	 * 
	 * @param ids
	 * @param resourceType
	 * @return String
	 */
	String getResourceJsons(String id, String resourceType);
	
	/**
	 * Bulk Export request
	 * 
	 * @param resourceSearchParamMap
	 * @param since
	 * @param encryptionKey
	 * @return
	 */
	String postExportRequest(Map<String, List<SearchParameterRequest>> resourceSearchParamMap, Date since,String encryptionKey);
	
	/**
	 * Member matching request
	 * 
	 * @param resourceSearchParamMap
	 * @param since
	 * @return
	 */
	List<String> memberMatchingRequest(String resourceType, SearchParameterRequest parameterMap);
	
	/**
	 * Bulk status request
	 * 
	 * @param requestId
	 * @return StatusParam
	 */
	StatusParam statusRequest(String requestId);
	
	/**
	 * Bulk delete request
	 * 
	 * @param requestId
	 * @return StatusParam
	 */
	StatusParam deleteRequest(String requestId);
}

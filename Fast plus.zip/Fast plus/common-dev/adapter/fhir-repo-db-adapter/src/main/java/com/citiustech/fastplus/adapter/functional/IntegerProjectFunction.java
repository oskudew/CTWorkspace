package com.citiustech.fastplus.adapter.functional;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 
 * This is a class for IntegerProjectFunction which act as mapper to get Integer
 * object by extracting ResultSet
 * 
 */
public class IntegerProjectFunction implements RowMapper<Integer> {
    @Override
    public Integer mapRow(final ResultSet resultSet, final int index) throws SQLException {
        return resultSet.getInt(1);
    }
}

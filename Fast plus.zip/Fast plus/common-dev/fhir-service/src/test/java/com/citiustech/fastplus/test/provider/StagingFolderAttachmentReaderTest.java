package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.filereader.attachment.StagingFolderAttachmentReader;
import com.citiustech.fastplus.filereader.resource.DocumentReferenceReader;
import com.citiustech.fastplus.filereader.resource.IResourceReader;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.SearchServiceException;

@ExtendWith(MockitoExtension.class) 
class StagingFolderAttachmentReaderTest {

	@InjectMocks
	private  StagingFolderAttachmentReader stagingFolderAttachmentReader;

	@Mock
	private ApplicationContext applicationContext;

	@Mock
	private FileReaderUtils readerUtil;
	
	@Mock
	private IResourceReader reader;

	Set<String> attachments = new HashSet<>();

	
	@BeforeEach
	void setAttachments() {
		attachments.add("DiagnosticReport");
		attachments.add("DocumentReference");
		attachments.add("Contract");
		
		ReflectionTestUtils.setField(stagingFolderAttachmentReader, "attachments", attachments);
	}
	
	
	
	@DisplayName("Test case when attachments and resources are not null")
	@Test
	void test_readAttachmentsData() {

		String resourceType = ResourceType.DocumentReference.name();
		DocumentReference documentReference = mock(DocumentReference.class);
		DocumentReferenceReader documentReferenceReader = mock(DocumentReferenceReader.class);
		List<IBaseResource> resources = new ArrayList<>();
		resources.add(documentReference);
		reader = documentReferenceReader;

		when(applicationContext.getBean(resourceType + "Reader")).thenReturn((documentReferenceReader));
		stagingFolderAttachmentReader.readAttachmentsData(resources, resourceType);
		verify(reader,times(1)).readAttachment(resources);
		
	}
	
	@DisplayName("Test case when attachments and resources are empty")
	@Test
	void test_readAttachmentsData_WhenResourcesAreEmpty() {
		attachments = null;
		ReflectionTestUtils.setField(stagingFolderAttachmentReader, "attachments", attachments);
		String resourceType = ResourceType.DocumentReference.name();
		List<IBaseResource> resources = new ArrayList<>();

		stagingFolderAttachmentReader.readAttachmentsData(resources, resourceType);
		verify(reader,never()).readAttachment(resources);
		
	}
	
	@DisplayName("Test case when context.getbean() method throws error")
	@Test
	void test_readAttachmentsData_WhenReaderBeanIsAbsent() {
		String resourceType = ResourceType.DocumentReference.name();
		List<IBaseResource> resources = new ArrayList<>();
		DocumentReferenceReader documentReferenceReader = mock(DocumentReferenceReader.class);
		reader = documentReferenceReader;

		when(applicationContext.getBean(resourceType + "Reader")).
			thenThrow(new NoSuchBeanDefinitionException(resourceType));
		SearchServiceException exception = Assertions.assertThrows(SearchServiceException.class,() -> 
				stagingFolderAttachmentReader.readAttachmentsData(resources, resourceType));
		assertEquals(ExceptionCodes.INVALID_DATA.getCode(), exception.getMessage());

		
	}
	
	
	@DisplayName("Test case when read attachment method is called")
	@Test
	void test_readAttachmentsData_overridedMethod() {
		
		long totalAttachmentSize = 0;
		List<Attachment> attachments = new ArrayList<>();
		Attachment attachment = mock(Attachment.class);
		attachments.add(attachment);
		attachments.add(attachment);
		
		stagingFolderAttachmentReader.readAttachmentsData(attachments);
		verify(readerUtil,times(2)).setAttachmentdata(attachment,totalAttachmentSize);
		
	}
	
	@DisplayName("Test case when single resource is passed")
	@Test
	void test_readAttachmentData() {
		String resourceType = ResourceType.DocumentReference.name();
		IBaseResource documentReference = mock(DocumentReference.class);
		DocumentReferenceReader documentReferenceReader = mock(DocumentReferenceReader.class);
		reader = documentReferenceReader;
		
		when(applicationContext.getBean(resourceType + "Reader")).thenReturn((documentReferenceReader));
		stagingFolderAttachmentReader.readAttachmentsData(documentReference, resourceType);
		verify(reader,times(1)).readAttachment(any());
		
	}
	

}

package com.citiustech.fastplus.util.configuration.cache;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import redis.clients.jedis.JedisPoolConfig;

/**
 * 
 * This is a JedisConfiguration class used to hold redis configuration and
 * connection logic
 * 
 */

@Configuration
@PropertySource("application.properties")
public class JedisConfiguration {

	 /**
     * This is a redisHostName field used to hold redis host name 
     */
    @Value("${redis.hostname:}")
    private String redisHostName;

    /**
     * This is a redisPort field used to hold redis port number 
     */
    @Value("${redis.port: 6379}")
    private int redisPort;
    
    /**
     * This is a redisPassword field used to hold redis password 
     */
    @Value("${redis.password: }")
    private char[] redisPassword;

	/**
	 * This is a factory field used to hold JedisConnectionFactory object
	 */
    private JedisConnectionFactory factory;

	/**
	 * initializes the connection using Host Name and Port
	 */
    public void jedisConnectionFactory() {
    	
    	RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
        configuration.setHostName(redisHostName);
        configuration.setPort(redisPort);
        configuration.setPassword(redisPassword);
        Arrays.fill(redisPassword, '\0');
        factory = new JedisConnectionFactory(configuration);
        factory.getPoolConfig().setMaxTotal(50);
        factory.getPoolConfig().setMaxIdle(50);
    }

	/**
	 * returns RedisTemplate bean after initializing it
	 */
    @Bean
    public RedisTemplate<String, Object> redisTemplate() {
    
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        jedisConnectionFactory();
        redisTemplate.setConnectionFactory(factory);

        RedisSerializer<String> stringSerializer = new StringRedisSerializer();
        redisTemplate.setKeySerializer(stringSerializer);
        redisTemplate.setHashKeySerializer(stringSerializer);
        redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        redisTemplate.afterPropertiesSet();

        return redisTemplate;
    }

	/**
	 * returns RedisSerializer bean to store key and value pair in redis cache
	 */
    @Bean
    public  RedisSerializer<String> redisStringSerializer() {
    	return new StringRedisSerializer();
    }

}
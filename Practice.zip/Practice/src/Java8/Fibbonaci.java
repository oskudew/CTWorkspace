package Java8;

public class Fibbonaci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

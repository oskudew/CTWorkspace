package com.citiustech.fastplus.querybuilder;

import com.healthmarketscience.sqlbuilder.Condition;

import java.util.List;

/**
 * 
 * This is an interface for QueryBuilder defines methods to frame and build
 * queries
 * 
 */

public interface QueryBuilder {
	/**
	 * returns Condition by framing query based on list of conditions
	 * 
	 * @param conditions
	 * @return Condition
	 */
    Condition frameOrQueryAndReturn(List<Condition> conditions);

    /**
     * sets condition
     * 
     * @param condition
     */
    void addCondition(Condition condition);

    /**
     * returns query in string format
     * 
     * @return String
     */
    String build();
}

package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.MainOuterQueryObject;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.OrderObject.Dir;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

import ca.uhn.fhir.rest.api.SortOrderEnum;
import ca.uhn.fhir.rest.api.SortSpec;

@ExtendWith(MockitoExtension.class)
class ProjectionAndSortingHelperTest {

	@InjectMocks
	static ProjectionAndSortingHelper projectionAndSortingHelper;

	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
	private static CustomResourceUtil customResourceUtil;

	@Spy
	private static FHIRErrorHandler fhirErrorHandler;

	static String resourceType = ResourceType.Patient.name();
	String resourceTypeAlias = "PatientIAwJ";
	String targetAlias = "WeUo";
	String resourceTypeTragetAlias = "PatientWeUo";
	String tableName = "patientsearch";
	static FHIRRepositoryBaseSQLQueryBuilder queryBuilder;
	SelectQuery mainOuterQuery;
	List<CustomSql> listOfProjectionCol;
	SelectQuery mainOuterQueryExpected;

	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException {

		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,
				FHIRRepositoryTableConfiguration.class);
		fhirRepositoryTableConfiguration.duplicateTypeMap();
		queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(fhirRepositoryTableConfiguration, resourceType);
		projectionAndSortingHelper = new ProjectionAndSortingHelper(fhirRepositoryTableConfiguration,
				customResourceUtil, fhirErrorHandler);

	}

	@DisplayName("Test case for sort by birthdate ascending order")
	@Test 
	void test_buildSortQueryForAsc() throws NoSuchFieldException,ClassNotFoundException
	{ 
		String paramName = Patient.SP_BIRTHDATE;
		String paramType = "date";
  
		SortSpec sort = new SortSpec(Patient.SP_BIRTHDATE,SortOrderEnum.ASC);
		listOfProjectionCol = new ArrayList<>();
  
		Condition condition = ComboCondition.and("(PatientIAwJ.attribute = 'family') AND (PatientIAwJ.value ILIKE 'John%')");
  
		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition); selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
  
		List<CustomSql> columns = new ArrayList<>(); 
		columns.add(new CustomSql("PatientIAwJ.id")); 
		columns.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));
  
		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName,queryBuilder.isChainedParam());
		selectQueryStructure.getSelectQuery().setIsDistinct(true);
  
		List<CustomSql> projectionCols = selectQueryStructure.getProjection(); 
		mainOuterQuery = selectQueryStructure.getSelectQuery(); 
		projectionCols.stream().limit(1).forEach(selectQueryStructure.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObj = new MainOuterQueryObject(mainOuterQuery, resourceTypeAlias,listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();
  
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias); 
		when(customResourceUtil.getParamType(resourceType, paramName)).thenReturn(paramType); 
		
  
		SelectQuery actualValue = projectionAndSortingHelper.buildSortQuery(resourceType, sort, queryBuilder,mainOuterQuery, listOfProjectionCol, resourceTypeAlias);
  
		FHIRRepositoryBaseSQLQueryBuilder queryBuilderNew = new FHIRRepositoryBaseSQLQueryBuilder(fhirRepositoryTableConfiguration,resourceType);
  
		SelectQuery selectQueryNew = new SelectQuery(); 
		selectQueryNew.addCondition(condition);
		selectQueryNew.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
  
		List<CustomSql> columnsNew = new ArrayList<>(); 
		columnsNew.add(new CustomSql("PatientIAwJ.id")); 
		columnsNew.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));
  
		SelectQueryStructure selectQueryStructureNew = new SelectQueryStructure(resourceTypeAlias, selectQueryNew, columnsNew,paramName, queryBuilderNew.isChainedParam());
		selectQueryStructureNew.getSelectQuery().setIsDistinct(true);
  
		List<CustomSql> projectionColsExpect = selectQueryStructureNew.getProjection();
		mainOuterQueryExpected = selectQueryStructureNew.getSelectQuery();
		projectionColsExpect.stream().limit(1).forEach(selectQueryStructureNew.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObjNew = new MainOuterQueryObject(mainOuterQueryExpected,resourceTypeAlias,listOfProjectionCol); 
		mainOuterQueryExpected = mainOuterQueryObjNew.getMainOuterQuery();
  
		SelectQuery selectQueryExpected = new SelectQuery();
		selectQueryExpected.addFromTable(new DbTable(null, tableName,resourceTypeTragetAlias)); 
		List<CustomSql> columnsExpected = new ArrayList<>(); 
		columnsExpected.add(new CustomSql("PatientWeUo.id"));
		columnsExpected.add(new CustomSql("PatientWeUo.startdate AS birthdatePatientWeUo"));
		columnsExpected.stream().forEach(selectQueryExpected::addCustomColumns);
		List<Condition> orConditions = new ArrayList<>();
		orConditions.add(ComboCondition.and("PatientWeUo.attribute = 'birthdate'"));
		selectQueryExpected.addCondition(ComboCondition.or(orConditions.toArray(new Condition[0])));
		 
		Dir orderDirection =Dir.ASCENDING;
		queryBuilderNew.addJoin(mainOuterQueryExpected,resourceTypeAlias, selectQueryExpected, resourceTypeTragetAlias);
		mainOuterQueryExpected.addCustomColumns(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName, resourceTypeTragetAlias))); 
		mainOuterQueryExpected.addCustomOrdering(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName,resourceTypeTragetAlias)), orderDirection); 
		SelectQuery expectedValue = mainOuterQueryExpected;
		
		assertEquals(expectedValue.toString(),actualValue.toString());
  
  }
	

	@DisplayName("Test case for sort by birthdate descending order") 
	@Test 
	void test_buildSortQueryForDesc() throws NoSuchFieldException,ClassNotFoundException{ 
		String paramName = Patient.SP_BIRTHDATE;
		String paramType = "date"; 
		SortSpec sort = new SortSpec(Patient.SP_BIRTHDATE,SortOrderEnum.DESC);
  
		listOfProjectionCol = new ArrayList<>();
  
		Condition condition = ComboCondition.and("(PatientIAwJ.attribute = 'family') AND (PatientIAwJ.value ILIKE 'John%')");
  
		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition); selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
  
		List<CustomSql> columns = new ArrayList<>(); columns.add(new CustomSql("PatientIAwJ.id")); 
		columns.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));
  
		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName,queryBuilder.isChainedParam());
		selectQueryStructure.getSelectQuery().setIsDistinct(true);
  
		List<CustomSql> projectionCols = selectQueryStructure.getProjection(); 
		mainOuterQuery = selectQueryStructure.getSelectQuery(); 
		projectionCols.stream().limit(1).forEach(selectQueryStructure.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObj = new MainOuterQueryObject(mainOuterQuery, resourceTypeAlias,listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();
  
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias); 
		when(customResourceUtil.getParamType(resourceType,paramName)).thenReturn(paramType); 
  
		SelectQuery actualValue = projectionAndSortingHelper.buildSortQuery(resourceType, sort, queryBuilder, mainOuterQuery, listOfProjectionCol, resourceTypeAlias);
  
		FHIRRepositoryBaseSQLQueryBuilder queryBuilderNew = new FHIRRepositoryBaseSQLQueryBuilder(fhirRepositoryTableConfiguration,resourceType);
  
		SelectQuery selectQueryNew = new SelectQuery();
		selectQueryNew.addCondition(condition); 
		selectQueryNew.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
  
		List<CustomSql> columnsNew = new ArrayList<>(); 
		columnsNew.add(new CustomSql("PatientIAwJ.id")); 
		columnsNew.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));
  
		SelectQueryStructure selectQueryStructureNew = new SelectQueryStructure(resourceTypeAlias, selectQueryNew, columnsNew,paramName, queryBuilderNew.isChainedParam());
		selectQueryStructureNew.getSelectQuery().setIsDistinct(true);
  
		List<CustomSql> projectionColsExpect = selectQueryStructureNew.getProjection();
		mainOuterQueryExpected = selectQueryStructureNew.getSelectQuery();
		projectionColsExpect.stream().limit(1).forEach(selectQueryStructureNew.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObjNew = new MainOuterQueryObject(mainOuterQueryExpected,resourceTypeAlias,listOfProjectionCol);
		mainOuterQueryExpected = mainOuterQueryObjNew.getMainOuterQuery();
  
		SelectQuery selectQueryExpected = new SelectQuery();
		selectQueryExpected.addFromTable(new DbTable(null, tableName,resourceTypeTragetAlias));
		List<CustomSql> columnsExpected = new ArrayList<>(); 
		columnsExpected.add(new CustomSql("PatientWeUo.id"));
		columnsExpected.add(new CustomSql("PatientWeUo.startdate AS birthdatePatientWeUo"));
		columnsExpected.stream().forEach(selectQueryExpected::addCustomColumns);
		List<Condition> orConditions = new ArrayList<>();
		orConditions.add(ComboCondition.and("PatientWeUo.attribute = 'birthdate'"));
		selectQueryExpected.addCondition(ComboCondition.or(orConditions.toArray(new Condition[0])));
  
		Dir orderDirection = Dir.DESCENDING; queryBuilderNew.addJoin(mainOuterQueryExpected,resourceTypeAlias, selectQueryExpected, resourceTypeTragetAlias);
		mainOuterQueryExpected.addCustomColumns(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName,resourceTypeTragetAlias)));
		mainOuterQueryExpected.addCustomOrdering(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName,resourceTypeTragetAlias)), orderDirection); 
		SelectQuery expectedValue = mainOuterQueryExpected;
  
		assertEquals(expectedValue.toString(),actualValue.toString());
  
  }

	@DisplayName("Test case for sort by birthdate ascending order and sort chain")
	@Test
	void test_buildSortQueryForSortChainAsc() throws NoSuchFieldException,ClassNotFoundException{
		String paramName = Patient.SP_BIRTHDATE;
		String paramName2 = Patient.SP_NAME;
		String paramType = "date";
		String paramType2 = "string";
		SortSpec theChain = new SortSpec(Patient.SP_NAME, SortOrderEnum.ASC);
		SortSpec sort = new SortSpec(Patient.SP_BIRTHDATE, SortOrderEnum.ASC, theChain);

		listOfProjectionCol = new ArrayList<>();

		Condition condition = ComboCondition
				.and("(PatientIAwJ.attribute = 'family') AND (PatientIAwJ.value ILIKE 'John%')");

		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition);
		selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));

		List<CustomSql> columns = new ArrayList<>();
		columns.add(new CustomSql("PatientIAwJ.id"));
		columns.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));

		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName, queryBuilder.isChainedParam());
		selectQueryStructure.getSelectQuery().setIsDistinct(true);

		List<CustomSql> projectionCols = selectQueryStructure.getProjection();
		mainOuterQuery = selectQueryStructure.getSelectQuery();
		projectionCols.stream().limit(1).forEach(selectQueryStructure.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObj = new MainOuterQueryObject(mainOuterQuery, resourceTypeAlias,listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();

		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn("fJjn").thenReturn("pJXX");
		when(customResourceUtil.getParamType(resourceType, paramName)).thenReturn(paramType);
		when(customResourceUtil.getParamType(resourceType, paramName2)).thenReturn(paramType2);

		SelectQuery actualValue = projectionAndSortingHelper.buildSortQuery(resourceType, sort, queryBuilder, mainOuterQuery, listOfProjectionCol,resourceTypeAlias);

		FHIRRepositoryBaseSQLQueryBuilder queryBuilderNew = new FHIRRepositoryBaseSQLQueryBuilder(
				fhirRepositoryTableConfiguration, resourceType);

		SelectQuery selectQueryNew = new SelectQuery();
		selectQueryNew.addCondition(condition);
		selectQueryNew.addFromTable(new DbTable(null, tableName, resourceTypeAlias));

		List<CustomSql> columnsNew = new ArrayList<>();
		columnsNew.add(new CustomSql("PatientIAwJ.id"));
		columnsNew.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));

		SelectQueryStructure selectQueryStructureNew = new SelectQueryStructure(resourceTypeAlias, selectQueryNew,columnsNew, paramName, queryBuilderNew.isChainedParam());
		selectQueryStructureNew.getSelectQuery().setIsDistinct(true);

		List<CustomSql> projectionColsExpect = selectQueryStructureNew.getProjection();
		mainOuterQueryExpected = selectQueryStructureNew.getSelectQuery();
		projectionColsExpect.stream().limit(1).forEach(selectQueryStructureNew.getSelectQuery()::addCustomColumns);
		MainOuterQueryObject mainOuterQueryObjNew = new MainOuterQueryObject(mainOuterQueryExpected, resourceTypeAlias,listOfProjectionCol);
		mainOuterQueryExpected = mainOuterQueryObjNew.getMainOuterQuery();

		SelectQuery selectQueryExpected = new SelectQuery();
		selectQueryExpected.addFromTable(new DbTable(null, tableName, "PatientfJjn"));
		List<CustomSql> columnsExpected = new ArrayList<>();
		columnsExpected.add(new CustomSql("PatientfJjn.id"));
		columnsExpected.add(new CustomSql("PatientfJjn.startdate AS birthdatePatientfJjn"));
		columnsExpected.stream().forEach(selectQueryExpected::addCustomColumns);
		List<Condition> orConditions = new ArrayList<>();
		orConditions.add(ComboCondition.and("PatientfJjn.attribute = 'birthdate'"));
		selectQueryExpected.addCondition(ComboCondition.or(orConditions.toArray(new Condition[0])));

		Dir orderDirection = Dir.ASCENDING;
		queryBuilderNew.addJoin(mainOuterQueryExpected, resourceTypeAlias, selectQueryExpected, "PatientfJjn");
		mainOuterQueryExpected.addCustomColumns(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName, "PatientfJjn")));
		mainOuterQueryExpected.addCustomOrdering(
				new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName, "PatientfJjn")), orderDirection);

		SelectQuery selectQueryExpected2 = new SelectQuery();
		selectQueryExpected2.addFromTable(new DbTable(null, tableName, "PatientpJXX"));
		List<CustomSql> columnsExpected2 = new ArrayList<>();
		columnsExpected2.add(new CustomSql("PatientpJXX.id"));
		columnsExpected2.add(new CustomSql("PatientpJXX.value AS namePatientpJXX"));
		columnsExpected2.stream().forEach(selectQueryExpected2::addCustomColumns);
		List<Condition> orConditions2 = new ArrayList<>();
		orConditions2.add(ComboCondition.and("PatientpJXX.attribute = 'given'"));
		orConditions2.add(ComboCondition.and("PatientpJXX.attribute = 'family'"));
		selectQueryExpected2.addCondition(ComboCondition.or(orConditions2.toArray(new Condition[0])));

		queryBuilderNew.addJoin(mainOuterQueryExpected, "PatientIAwJ", selectQueryExpected2, "PatientpJXX");

		Dir orderDirection2 = Dir.ASCENDING;
		mainOuterQueryExpected.addCustomColumns(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName2, "PatientpJXX")));
		mainOuterQueryExpected.addCustomOrdering(new CustomSql(projectionAndSortingHelper.getAliasedParam(paramName2, "PatientpJXX")), orderDirection2);

		SelectQuery expectedValue = mainOuterQueryExpected;

		assertEquals(expectedValue.toString(),actualValue.toString());

	}
	
	@DisplayName("Test case for buildSortQuery method for FHIRException")
	@Test
	void test_buildSortQueryForException() {
		SortSpec sort = new SortSpec(Patient.SP_BIRTHDATE,SortOrderEnum.DESC);
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class, () ->projectionAndSortingHelper.buildSortQuery(resourceType, sort, 
												queryBuilder,mainOuterQuery, listOfProjectionCol, resourceTypeAlias));
		
		assertEquals(ExceptionCodes.QUERY_ERROR.getCode(),exception.getMessage());
		
	}

	@DisplayName("Test case for getProjectionColumn method for birthdate paramName")
	@Test
	void test_getProjectionColumnForDate() {
		String paramName = Patient.SP_BIRTHDATE;
		ParamType paramType = ParamType.DATE;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("PatientIAwJ.id"));
		expectedValue.add(new CustomSql("PatientIAwJ.startdate AS birthdatePatientIAwJ"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias, paramType,paramName);

		assertEquals(expectedValue.toString(),actualValue.toString());

	}

	@DisplayName("Test case for getProjectionColumn method for _lastUpdated Date paramName")
	@Test
	void test_getProjectionColumnForLastUpdatedDate() {
		String paramName = "_lastUpdated";
		ParamType paramType = ParamType.DATE;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("PatientIAwJ.id"));
		expectedValue.add(new CustomSql("PatientIAwJ.lastupdated AS _lastUpdatedPatientIAwJ"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias, paramType,paramName);

		assertEquals(expectedValue.toString(),actualValue.toString());
	}

	@DisplayName("Test case for getProjectionColumn method for endDate paramName")
	@Test
	void test_getProjectionColumnForEndDate() {
		String paramName = "end";
		ParamType paramType = ParamType.DATE;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("PatientIAwJ.id"));
		expectedValue.add(new CustomSql("PatientIAwJ.enddate AS endPatientIAwJ"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias, paramType,paramName);

		assertEquals(expectedValue.toString(),actualValue.toString());

	}

	@DisplayName("Test case for getProjectionColumn method for partof(reference) paramName")
	@Test
	void test_getProjectionColumnForReferenceParam() {
		String resourceAlias = "LocationDJYL";
		String paramName = Location.SP_PARTOF;
		ParamType paramType = ParamType.REFERENCE;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("LocationDJYL.id"));
		expectedValue.add(new CustomSql("LocationDJYL.value AS partofLocationDJYL"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceAlias, paramType,paramName);

		assertEquals(expectedValue.toString(),actualValue.toString());

	}

	@DisplayName("Test case for getProjectionColumn method for id(token) paramName")
	@Test
	void test_getProjectionColumnForToken() {
		String paramName = IAnyResource.SP_RES_ID;
		ParamType paramType = ParamType.TOKEN;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("PatientIAwJ.id"));
		expectedValue.add(new CustomSql("PatientIAwJ.code AS _idPatientIAwJ"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias, paramType,paramName);

		assertEquals(expectedValue.toString(),actualValue.toString());

	}

	@DisplayName("Test case for getProjectionColumn method for String(family) paramName")
	@Test
	void test_getProjectionColumnForStringParam() {
		String paramName = Patient.SP_FAMILY;
		ParamType paramType = ParamType.STRING;
		List<CustomSql> expectedValue = new ArrayList<>();
		expectedValue.add(new CustomSql("PatientIAwJ.id"));
		expectedValue.add(new CustomSql("PatientIAwJ.value AS familyPatientIAwJ"));
		List<CustomSql> actualValue = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias, paramType,paramName);
		assertEquals(expectedValue.toString(),actualValue.toString());

	}

	@DisplayName("Test case for isDistinctRequired method")
	@Test
	void test_isDistinctRequired() {
		String paramName = Patient.SP_BIRTHDATE;

		Condition condition = ComboCondition.and(
				"(PatientxzHI.attribute = 'birthdate') AND (date_trunc('day',PatientxzHI.startdate) = '2014-07-21 00:00:00')");

		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition);
		selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));

		List<CustomSql> columns = new ArrayList<>();
		columns.add(new CustomSql("PatientIAwJ.id"));
		columns.add(new CustomSql("PatientIAwJ.startdate AS birthdatePatientIAwJ"));

		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName, queryBuilder.isChainedParam());

		boolean actualValue = projectionAndSortingHelper.isDistinctRequired(selectQueryStructure, resourceType);
		boolean expectedValue = false;

		assertEquals(expectedValue,actualValue);

	}
	
	@DisplayName("Test case for isDistinctRequired method for Distinct Parameters")
	@Test
	void test_isDistinctRequiredForDistinctParameters() {
		String paramName = Patient.SP_NAME;
		Condition condition = ComboCondition.and(
				"((PatientIAwJ.attribute = 'given') OR (PatientIAwJ.attribute = 'family')) AND (PatientIAwJ.value ILIKE 'John Colon%')");
		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition);
		selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));

		List<CustomSql> columns = new ArrayList<>();
		columns.add(new CustomSql("PatientIAwJ.id"));
		columns.add(new CustomSql("PatientIAwJ.value AS namePatientIAwJ"));
		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName, queryBuilder.isChainedParam());

		boolean actualValue = projectionAndSortingHelper.isDistinctRequired(selectQueryStructure, resourceType);
		boolean expectedValue = true;

		assertEquals(expectedValue,actualValue);

	}
	
	@DisplayName("Test case for isDistinctRequired method for Chained Param")
	@Test
	void test_isDistinctRequiredForChainedParam() {
		String paramName = Patient.SP_BIRTHDATE;
		Condition condition = ComboCondition.and(
				"(PatientxzHI.attribute = 'birthdate') AND (date_trunc('day',PatientxzHI.startdate) = '2014-07-21 00:00:00')");

		SelectQuery selectQuery = new SelectQuery();
		selectQuery.addCondition(condition);
		selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));

		List<CustomSql> columns = new ArrayList<>();
		columns.add(new CustomSql("PatientIAwJ.id"));
		columns.add(new CustomSql("PatientIAwJ.startdate AS birthdatePatientIAwJ"));

		queryBuilder.setChainedParam(true);

		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName, queryBuilder.isChainedParam());

		boolean actualValue = projectionAndSortingHelper.isDistinctRequired(selectQueryStructure, resourceType);
		boolean expectedValue = true;

		assertEquals(expectedValue,actualValue);

	}
	
	@DisplayName("Test case for isDistinctRequired method for Exception")
	@Test
	void test_isDistinctRequiredForException() {
		String paramName = Patient.SP_BIRTHDATE;

		SelectQuery selectQuery = new SelectQuery();

		List<CustomSql> columns = new ArrayList<>();
		
		SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery, columns, paramName, queryBuilder.isChainedParam());
		 
		 when(fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType)).thenThrow(new NullPointerException());
		 
		 FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> projectionAndSortingHelper.isDistinctRequired(selectQueryStructure, resourceType));
		 assertEquals(ExceptionCodes.QUERY_ERROR.getCode(),exception.getMessage());
	}
	

}

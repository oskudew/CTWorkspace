package com.java.conference;

import com.java.conference.Service.SpeakerService;
import com.java.conference.Service.SpeakerServiceInter;

import org.springframework.context.ApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	SpeakerServiceInter sp = new SpeakerService();
    	System.out.println(sp.findAll().get(0).getName());
    }
}

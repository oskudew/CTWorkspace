package com.citiustech.fastplus.adapter.structure;

import java.time.ZonedDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class StatusParam {
	
	
	private String requestId;
	private String requestUrl;
	private String status;
	private String cancelFlag;
	private int progressPercent;
	private ZonedDateTime expirationTime;
	private String response;
	private String dataKey;
}
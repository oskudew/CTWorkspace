package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;

import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.StringParam;

@ExtendWith(MockitoExtension.class)
class StringParamQueryFragmentBuilderTest {
	
	@InjectMocks
	static StringParamQueryFragmentBuilder stringParamQueryFragmentBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
    private static CommonQueryUtil commonQueryUtil;
	
	String resourceTypeAlias = "OrganizationDDRC";
	String resourceType = ResourceType.Organization.name();
	String paramName = Organization.SP_ADDRESS_CITY; 
	String value;
	
	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,FHIRRepositoryTableConfiguration.class);
		fhirRepositoryTableConfiguration.duplicateTypeMap();
		stringParamQueryFragmentBuilder = new StringParamQueryFragmentBuilder(
                 fhirRepositoryTableConfiguration,commonQueryUtil);
		
	}
	
	FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
            fhirRepositoryTableConfiguration, resourceType);
	
	
	@DisplayName("Test case for frameQueryFragment method with contains false and exct false")
	@Test
	void test_frameQueryFragment() { 
		
		value = "Thailand";
		StringParam param = new StringParam(value);
		
		queryBuilder.setParamType(ParamType.STRING);
		
		doNothing().when(commonQueryUtil).validateParamValue(param.getValue(), true);

		Condition actualValue = stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, param, paramName);
		Condition expectedValue = ComboCondition.and("(OrganizationDDRC.attribute = 'address-city') AND (OrganizationDDRC.value ILIKE 'Thailand%')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for frameQueryFragment method with contains true")
	@Test
	void test_frameQueryFragmentWithContains() {
		
		value = "Thailand";
		StringParam param = new StringParam(value);
		param.setContains(true);
		
		queryBuilder.setParamType(ParamType.STRING);
		
		doNothing().when(commonQueryUtil).validateParamValue(param.getValue(), true);
		
		Condition actualValue = stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, param, paramName);
		Condition expectedValue = ComboCondition.and("(OrganizationDDRC.attribute = 'address-city') AND (OrganizationDDRC.value ILIKE '%Thailand%')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
	}
	
	@DisplayName("Test case for frameQueryFragment method with exact true")
	@Test
	void test_frameQueryFragmentWithExact() {
		
		value = "Thailand";
		StringParam paramType = new StringParam(value);
		paramType.setExact(true);
		
		queryBuilder.setParamType(ParamType.STRING);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getValue(), true);
		
		Condition actualValue = stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(OrganizationDDRC.attribute = 'address-city') AND (OrganizationDDRC.value = 'Thailand')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
	}
	
	@DisplayName("Test case for frameQueryFragment method for Exception")
	@Test
	void test_frameQueryFragmentForException() { 
		
		value = "";
		StringParam param = new StringParam(value);
		
		queryBuilder.setParamType(ParamType.STRING);
		
		doThrow(new FHIRException("FPE-3003")).when(commonQueryUtil).validateParamValue(param.getValue(),true);

		FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, param, paramName));
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());
	}
	
}

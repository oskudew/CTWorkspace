package basic;

import java.util.Scanner;

public class InverseNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//54321
		//12435
		
		//54321
		//13245
		
		//613254
		//621435
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int count =1;
		int sum=0;
		
		while(a!=0) {
			int p =a%10;
			sum=sum+count*(int)Math.pow(10, p-1);
			count++;
			a=a/10;
		}
		System.out.println(sum);
		
		

	}

}

import java.util.Scanner;

public class Fibbonacci_Recursion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Please enter no of series:");
		int num=sc.nextInt();
		for(int i=0;i<num;i++) {
			System.out.print(fibbo(i)+" ");
		}
		int position = sc.nextInt();
		System.out.println(" Yo-"+fibbo(position-1));
		
		
	}
	
	public static int fibbo(int n) {
		if(n==0) return 0;
		if(n==1|| n==2) return 1;
		return fibbo(n-1)+fibbo(n-2);
	}

}

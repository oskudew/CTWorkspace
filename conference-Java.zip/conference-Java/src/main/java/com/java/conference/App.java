package com.java.conference;

import com.java.conference.Repository.SpeakerRepository;
import com.java.conference.Service.SpeakerService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	//SpeakerServiceInter sp = new SpeakerService();

        ApplicationContext app = new AnnotationConfigApplicationContext(AppConfig.class);
        SpeakerService service =app.getBean("speakerService",SpeakerService.class);
        SpeakerRepository sr = app.getBean("speakerRepository",SpeakerRepository.class);
        System.out.println(sr);
        System.out.println(service.findAll().get(0).getName());


    }
}

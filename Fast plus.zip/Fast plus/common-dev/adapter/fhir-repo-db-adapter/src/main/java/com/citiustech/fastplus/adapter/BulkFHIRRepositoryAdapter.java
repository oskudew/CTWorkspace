package com.citiustech.fastplus.adapter;

import java.math.BigInteger;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.citiustech.fastplus.BulkFHIRAdapter;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.dao.FHIRRepositoryDAO;
import com.citiustech.fastplus.adapter.structure.StatusParam;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.querybuilder.BulkExportSQLBuilder;
import com.citiustech.fastplus.util.BulkExportData;
import com.citiustech.fastplus.util.BulkFHIREnums.StatusCode;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;


@Component
public class BulkFHIRRepositoryAdapter implements BulkFHIRAdapter {
	
	/**
	 * This is a flag used to compare or update the cancelflag column values in database
	 */
	private static final String CANCEL_FLAG_YES = "Y";
	
	/**
	 * This is a sqlBuilder field used to hold DeepNestedSqlBuilder object
	 */
	@Autowired
	private BulkExportSQLBuilder bulkExportSqlBuilder;
	
	/**
	 * This is a fhirRepositoryDao field used to hold fhirRepositoryDao object
	 */
	@Autowired
	private FHIRRepositoryDAO fhirRepositoryDao;
	
	@Autowired
	private HttpServletRequest servletRequest;

	/**
	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
	 */
	@Autowired
    private FHIRErrorHandler fhirErrorHandler;
	
	@Value("${server.baseUrl:}")
	private String serverBaseUrl;
	
	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGING = LoggerFactory.getLogger(BulkFHIRRepositoryAdapter.class.getName());
	
	/**
	 * Export operation detail service
	 * 
	 */
	@Override
	@Transactional
	public String postExportRequest(Map<String,List<SearchParameterRequest>> resourceSearchParamMap, Date since,String encryptionKey) {
		UUID uuid=UUID.randomUUID(); 
		try {	
			List<BulkExportData> resourceQueries = resourceSearchParamMap
					.entrySet().stream()
					.flatMap(e -> e.getValue().stream()
							.map(f -> new BulkExportData(e.getKey(),
									bulkExportSqlBuilder.buildNestedQueriesForSearchParams(e.getKey(), f),
									f.getExecutionSequence())))
					.collect(Collectors.toList());
			

			StringBuilder requestUrl = new StringBuilder();
			requestUrl.append(serverBaseUrl);
			requestUrl.append(servletRequest.getRequestURI().replace(servletRequest.getContextPath(), ""));
			
			if (Objects.nonNull(servletRequest.getQueryString())) {
				requestUrl.append("?").append(servletRequest.getQueryString());
			}
			
			LOGGING.logInfo(LoggingMarkers.APPLICATION.getValue(), ">>>>>>>> reqUrl after replacement  "+ requestUrl.toString());

			insertBulkQueries(since, uuid, resourceQueries, requestUrl.toString(), encryptionKey);
		}catch(Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
		
		return uuid.toString();
	}

	
	/**
	 * combined all database operations in single method 
	 * 
	 * @param since
	 * @param uuid
	 * @param resourceQueries
	 * @param requestUrl
	 */

	private void insertBulkQueries(Date since, UUID uuid, List<BulkExportData> resourceQueries, String requestUrl, String encryptionKey) {
		BigInteger id = fhirRepositoryDao.insertBulkExportHdrEntry(requestUrl, uuid.toString(),since, encryptionKey);	
		fhirRepositoryDao.batchInsert(resourceQueries, id);
		fhirRepositoryDao.updateBulkHdrStatus(uuid.toString(), StatusCode.REGISTERED.toString());
	}

	
	@Override
	public StatusParam statusRequest(String requestId) {
		return fhirRepositoryDao.getBulkDataStatus(requestId);
	}

	@Override
	public StatusParam deleteRequest(String requestId) {
		StatusParam statusParam = fhirRepositoryDao.getBulkDataStatus(requestId);
		
		if ((StatusCode.REGISTERED.toString().equalsIgnoreCase(statusParam.getStatus())
				|| StatusCode.PAUSED.toString().equalsIgnoreCase(statusParam.getStatus())
				|| StatusCode.INPROGRESS.toString().equalsIgnoreCase(statusParam.getStatus()))
				&& (!CANCEL_FLAG_YES.equalsIgnoreCase(statusParam.getCancelFlag()))) {
			// update flag as Y
			fhirRepositoryDao.deleteBulkDataStatus(requestId, CANCEL_FLAG_YES);
		}
		
		return statusParam;
	}

	@Override
	public List<String> memberMatchingRequest(String resourceType, SearchParameterRequest parameterMap) {
		return fhirRepositoryDao.executeForString(
				 bulkExportSqlBuilder.buildNestedQueriesToGetResponseJson
					(resourceType, parameterMap),Collections.emptyList());
	}

	@Override
	public String getResourceJsons(String id, String resourceType) {
		
		return fhirRepositoryDao.executeForString(
				bulkExportSqlBuilder.frameJsonRetrievalQuery(resourceType,id),Collections.emptyList()).get(0);
	}

}

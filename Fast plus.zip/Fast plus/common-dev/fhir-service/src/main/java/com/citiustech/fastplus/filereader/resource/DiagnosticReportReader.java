package com.citiustech.fastplus.filereader.resource;

import java.util.List;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.DiagnosticReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.filereader.FileReaderUtils;
/**
 * 
 * This is a class for DiagnosticReport Resource used as implementation for IResourceReader
 * to read resource attachment data from shared location.
 *
 */
@Component(value = "DiagnosticReportReader")
public class DiagnosticReportReader implements IResourceReader {
	
	@Autowired
	FileReaderUtils readerUtil;

	@Override
	public void readAttachment(List<IBaseResource> resources) {
		List<DiagnosticReport> reports = resources.stream().filter(rs -> rs instanceof DiagnosticReport)
				.map(rs -> (DiagnosticReport) rs).collect(Collectors.toList());
		readDiagnosticReportAttachment(reports);
	}

	/**
	 * iterate over Contract resources and set the attachment data using URL.
	 * 
	 * @param resources
	 */
	private void readDiagnosticReportAttachment(List<DiagnosticReport> resources) {

		long totalAttachmentSize = 0;
		for (DiagnosticReport df : resources) {
			for (Attachment attachment : df.getPresentedForm()) {
				totalAttachmentSize = readerUtil.setAttachmentdata(attachment, totalAttachmentSize);
			}
		}
	}

}

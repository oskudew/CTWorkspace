package basic;

import java.util.Scanner;

public class PrimeNo_orNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		System.out.println(check(a));
	}
	public static String check(int a) {
		
		int flag =0;
		if(a==0 || a==1|| a==2) { 
			return(a +" is a prime number");
			}
		else {
		for(int i=2;i<a/2;i++) {
		if(a%i==0) {
			flag++;
		}
	}
		if(flag!=0) return a +" is not a prime number";
		else return (a +" is a prime number");
	}
	}
}

package com.citiustech.fastplus.service;

import com.citiustech.fastplus.mapper.PatientMapper;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.fastplus.mapper.PatientResourceMapper;
import com.jayway.jsonpath.Configuration;

import ca.uhn.fhir.context.FhirContext;

@Service
public class DemoMapperService {
	
	@Autowired
	private FhirContext fhirContext;

	@Autowired
	private PatientResourceMapper patientResourceMapper;

	@Autowired
	private PatientMapper patientMapper;
	
	
   public String convertToFHIRBundle(String inputJson) throws Exception{
		Object jsonDocument = Configuration.defaultConfiguration().jsonProvider().parse(inputJson);
       
//		PatientResourceMapper mapper = new PatientResourceMapper();
		
		Bundle bundle =
				patientResourceMapper.map(jsonDocument);
		
		  String resourceString = fhirContext.newJsonParser().encodeResourceToString(bundle);
		  
		
		  System.out.println("Converted Fhir json is : ");
		  System.out.println(resourceString);
		  return resourceString;
	}

	public String convertToFHIRPatient(String inputJson) throws Exception{
		Object jsonDocument = Configuration.defaultConfiguration().jsonProvider().parse(inputJson);

		Patient patient =
				patientMapper.mapForPatient(jsonDocument);
		
		patientResourceMapper.validateEachResource(patient);
		String resourceString = fhirContext.newJsonParser().encodeResourceToString(patient);


		System.out.println("Converted Fhir json is : ");
		System.out.println(resourceString);
		return resourceString;
	}


}

package com.citiustech.fastplus.querybuilder;


import static com.citiustech.fastplus.util.AdapterUtil.getAliasedColumn;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.util.MainOuterQueryObject;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.custom.postgresql.PgLimitClause;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

import ca.uhn.fhir.model.api.IQueryParameterAnd;
import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.rest.api.SortSpec;

/**
 * 
 * This is a class for DeepNestedSqlBuilder which used to build deep nested sql
 * query
 * 
 */

@Component("sqlBuilder")
public class DeepNestedSqlBuilder {

	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
	@Autowired
	protected FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	/**
	 * This is a baseTypeQueryFragmentBuilder field used to hold
	 * BaseTypeQueryFragmentBuilder object
	 */
	@Autowired
	private BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	/**
	 * This is a sortingAndProjectionHelper field used to hold
	 * ProjectionAndSortingHelper object
	 */
	@Autowired
	protected ProjectionAndSortingHelper projectionAndSortingHelper;

	/**
	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
	 */
	@Autowired
	protected FHIRErrorHandler fhirErrorHandler;
	
	
	private static final Logging LOGGER = LoggerFactory.getLogger(DeepNestedSqlBuilder.class.getName());
	
	/**
     * returns nested query by for different conditions as given as search parameters
     * all combinations as requested in search criteria are taken into consideration here
     * 
     * @param resourceType
     * @param selectQueryStructures
     * @param limit
     * @return String
     */
	private String buildNestedQueryFromSubQueries(String resourceType,
												  List<SelectQueryStructure> selectQueryStructures, Integer limit, SortSpec sort, 
												  FHIRRepositoryBaseSQLQueryBuilder queryBuilder) {
		SelectQuery mainOuterQuery = null;
		List<CustomSql> listOfProjectionCol = new ArrayList<>();
		String query;
		
		String mainQueryAlias = null;

		MainOuterQueryObject mainOuterQueryObj = buildMainOuterQuery(resourceType, mainOuterQuery, mainQueryAlias, selectQueryStructures, queryBuilder, listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();
		listOfProjectionCol = mainOuterQueryObj.getListOfProjectionCol();
		mainQueryAlias = mainOuterQueryObj.getMainQueryAlias();

		if (sort != null) {
			mainOuterQuery = projectionAndSortingHelper.buildSortQuery(resourceType, sort, queryBuilder, mainOuterQuery, listOfProjectionCol, mainQueryAlias);
		}
		if(Objects.nonNull(limit))
			mainOuterQuery.addCustomization(new PgLimitClause(limit));

		query = mainOuterQuery.toString();
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Nested query built "+query);

		return query;
	}
	
	/**
	 * This method is used to build the main outer query for the requested search criteria
	 * 
	 * @param resourceType
	 * @param mainOuterQuery
	 * @param mainQueryAlias
	 * @param selectQueryStructures
	 * @param queryBuilder
	 * @param listOfProjectionCol
	 * @return
	 */
	protected MainOuterQueryObject buildMainOuterQuery(String resourceType, SelectQuery mainOuterQuery, 
			String mainQueryAlias, List<SelectQueryStructure> selectQueryStructures,
			FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
			List<CustomSql> listOfProjectionCol) {
		SelectQuery tempMainOuterQuery = mainOuterQuery;
		String tempQueryAlias = mainQueryAlias;
		
		int index = 0;
		for (SelectQueryStructure selectQueryStructure : selectQueryStructures) {
			String queryAlias = selectQueryStructure.getAlias();
			if (index == 0) {
				if (projectionAndSortingHelper.isDistinctRequired(selectQueryStructure,resourceType)) {
					selectQueryStructure.getSelectQuery().setIsDistinct(true);
				}
				List<CustomSql> projectionCols = selectQueryStructure.getProjection();
				tempMainOuterQuery = selectQueryStructure.getSelectQuery();
				tempQueryAlias = queryAlias;
				projectionCols.stream().limit(1)
				.forEach(selectQueryStructure.getSelectQuery()::addCustomColumns);
			} else {
				selectQueryStructure.getSelectQuery().addCustomColumns(new CustomSql(1));
				queryBuilder.addExist(tempMainOuterQuery, tempQueryAlias, selectQueryStructure.getSelectQuery(), queryAlias);
			}
			
			++index;
		}
		return new MainOuterQueryObject(tempMainOuterQuery, tempQueryAlias,listOfProjectionCol);
		
		
	}

    /**
     * returns queries for each parameter type and nested sub queries for requested criteria
     * 
     * @param resourceType
     * @param searchParamMap
     * @return String
     */
    public String buildNestedQueriesForSearchParams(String resourceType, SearchParameterRequest searchParamMap) {
        FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
        try {
        	if(Objects.nonNull(searchParamMap) && !searchParamMap.isEmpty()) {
        		List<SelectQueryStructure> selectQueryStructures = getSelectQueryStructures(resourceType,
						searchParamMap, queryBuilder);
        		
				return buildNestedQueryFromSubQueries(resourceType, selectQueryStructures, searchParamMap.getLimit(),
						searchParamMap.getSort(), queryBuilder);
        	}else {
        		return buildQueryWithoutParameters(queryBuilder, resourceType);
        	}
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"FHIRException thrown while building nested queries ");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Exception thrown while building nested queries ");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}

    /**
     * This method is used to create list SelectQueryStructure for each search type
     * as requested in the search criteria
     * 
     * @param resourceType
     * @param searchParamMap
     * @param queryBuilder
     * @return list of SelectQuery structures
     */
	protected List<SelectQueryStructure> getSelectQueryStructures(String resourceType,
			SearchParameterRequest searchParamMap, FHIRRepositoryBaseSQLQueryBuilder queryBuilder) {
		
		
		return searchParamMap.entrySet()
							 .stream()
							 .flatMap(t -> getSelectStructures(t.getValue(),queryBuilder,t.getKey(),resourceType)
							 .stream())
							 .collect(Collectors.toList());
		
		 
					  	
	}

	@SuppressWarnings({"unchecked","rawtypes"})
	private List<SelectQueryStructure> getSelectStructures(IQueryParameterAnd value,
			FHIRRepositoryBaseSQLQueryBuilder queryBuilder,String paramName,String resourceType) {
		
		List<IQueryParameterOr> orValues = (List<IQueryParameterOr>)value.getValuesAsQueryTokens()
													.stream()
													.distinct()
													.collect(Collectors.toList());

		queryBuilder.setChainedParam(false);
		queryBuilder.setJoinQuery(false);
		return buildAndSubQuery(queryBuilder, resourceType, orValues, paramName);
		
	}
	
	/**
	 * returns list of select query structure queries for list of OR query parameters provided
	 * 
	 * @param queryBuilder
	 * @param resourceType
	 * @param orValues
	 * @param paramName
	 * @return List of SelectQueryStructure
	 */
	@SuppressWarnings("rawtypes")
    private List<SelectQueryStructure> buildAndSubQuery(FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
                                                       String resourceType,
                                                       List<IQueryParameterOr> orValues,
                                                       String paramName) {
        List<SelectQueryStructure> selectQueryStructures = new ArrayList<>();
        
        if(orValues.isEmpty()) {
        	throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_PARAMETER_VALUE);
        }

		for (IQueryParameterOr parameterOr : orValues) {
			String resourceTypeAlias = resourceType + fhirRepositoryTableConfiguration.getRandomString();
			SelectQuery selectQuery = new SelectQuery();
			String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();
			selectQuery.addCondition(
					baseTypeQueryFragmentBuilder.buildOrQuery(selectQuery, queryBuilder, resourceType,
							resourceTypeAlias,
							parameterOr, paramName));

			List<CustomSql> columns = projectionAndSortingHelper.getProjectionColumn(resourceTypeAlias,
					queryBuilder.isChainedParam() ? null : queryBuilder.getParamType(),paramName);

			if (!queryBuilder.isJoinQuery()) {
				selectQuery.addFromTable(new DbTable(null, tableName, resourceTypeAlias));
			}
			SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceTypeAlias, selectQuery,
					columns, paramName, queryBuilder.isChainedParam());

			selectQueryStructures.add(selectQueryStructure);
		}
			return selectQueryStructures;

	}
    
    /**
     * This method is used to build a query when no search parameter is provided in search query
     * 
     * @param queryBuilder
     * @param resourceType
     * @return Query string
     */
    protected String buildQueryWithoutParameters(FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
                                                       String resourceType) {
    	
    	SelectQuery selectQuery = new SelectQuery();
		String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();
		
		selectQuery.addFromTable(new DbTable(null, tableName, resourceType));
		selectQuery.addCustomColumns(new CustomSql(getAliasedColumn(resourceType, fhirRepositoryTableConfiguration.getIdColumn())));
		selectQuery.setIsDistinct(true);
		
    	SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceType, selectQuery,
    			null, null, queryBuilder.isChainedParam());
    	
    	return selectQueryStructure.getSelectQuery().toString();
    }
    
    /**
     * returns queries for each parameter type and nested sub queries for requested criteria
     * 
     * @param resourceType
     * @param searchParamReq
     * @return String
     */
    public String buildNestedPaginatedQueriesForSearchParams(String resourceType, SearchParameterRequest searchParamReq) {

        
        FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
        try {
        	
        	if(Objects.nonNull(searchParamReq) && !searchParamReq.isEmpty()) {
        		List<SelectQueryStructure> selectQueryStructures = getSelectQueryStructures(resourceType,
						searchParamReq, queryBuilder);
        		
        		return buildNestedPaginatedQueryFromSubQueries(resourceType, selectQueryStructures, searchParamReq.getLimit(),
        				 searchParamReq.getSort(),
    					searchParamReq.getId()!=null?searchParamReq.getId(): null, queryBuilder);
        	}else {
        		return buildQueryWithoutParameters(queryBuilder, resourceType);
        	}

		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"FHIRException thrown while building nested paginated queries ");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Exception thrown while building nested paginated queries ");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}


	private String buildNestedPaginatedQueryFromSubQueries(String resourceType,
			List<SelectQueryStructure> selectQueryStructures, Integer limit,
			 SortSpec sort, String id,
			FHIRRepositoryBaseSQLQueryBuilder queryBuilder) {
		SelectQuery mainOuterQuery = null;
		List<CustomSql> listOfProjectionCol = new ArrayList<>();
		String query = null;
		
		String mainQueryAlias = null;

		MainOuterQueryObject mainOuterQueryObj = buildMainOuterQuery(resourceType, mainOuterQuery, mainQueryAlias, selectQueryStructures, queryBuilder, listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();
		listOfProjectionCol = mainOuterQueryObj.getListOfProjectionCol();
		mainQueryAlias = mainOuterQueryObj.getMainQueryAlias();

		boolean addOrderBy = false;
		if(fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getProjections().size() >1) {
			if (mainOuterQuery!=null)mainOuterQuery.addCustomColumns(new CustomSql(getAliasedColumn(mainQueryAlias,
					fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getProjections().get(1))));
			addOrderBy = true;
		}
		
		if(sort != null)
			mainOuterQuery = projectionAndSortingHelper.buildSortQuery(resourceType, sort, queryBuilder, mainOuterQuery, listOfProjectionCol, mainQueryAlias);

		if(addOrderBy && mainOuterQuery!=null)
			mainOuterQuery.addCustomOrderings(new CustomSql(getAliasedColumn(mainQueryAlias,
				fhirRepositoryTableConfiguration.getIdColumn())));
		
		if(Objects.nonNull(id) && mainOuterQuery!=null)
			mainOuterQuery.addCondition(BinaryCondition.greaterThan(
				new CustomSql(getAliasedColumn(mainQueryAlias,
						fhirRepositoryTableConfiguration.getIdColumn())),
						id));


		if(Objects.nonNull(limit) && mainOuterQuery!=null)
			mainOuterQuery.addCustomization(new PgLimitClause(limit));

		return mainOuterQuery!= null ? mainOuterQuery.toString() : query;
	}
}

package com.citiustech.fastplus.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.fastplus.BulkFHIRAdapter;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.StatusParam;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.service.IBulkDataService;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.citiustech.fastplus.util.exception.SearchServiceException;

@Service
public class BulkDataService implements IBulkDataService {

	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(BulkDataService.class.getName());
    
	/**
	 * Bulk fhir implementation of adapter
	 */
	@Autowired
	private BulkFHIRAdapter bulkfhirRepositoryAdapter;

	/**
	 * Export operation service
	 * 
	 */
	@Override
	public String postExportRequest(Map<String, List<SearchParameterRequest>> resourceSearchParamMap, Date since,String encryptionKey) {
		try {
				return bulkfhirRepositoryAdapter.postExportRequest(resourceSearchParamMap, since,encryptionKey);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error in post export operation : " + e.getMessage());
			throw new SearchServiceException(e.getMessage(), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingMarkers.APPLICATION.getValue(),ExceptionCodes.DB_CONNECTION_ERROR.getCode());
			throw new SearchServiceException(ExceptionCodes.DB_CONNECTION_ERROR.getCode(), e);
		} 
	}

	/**
	 * Check export status by requestId
	 */
	@Override
	public StatusParam statusRequest(String requestId) {
		try {
			return bulkfhirRepositoryAdapter.statusRequest(requestId);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "error in status operation ");
			throw new SearchServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Stop/Cancel export by requestId
	 */
	@Override
	public StatusParam deleteRequest(String requestId) {
		try {
			return bulkfhirRepositoryAdapter.deleteRequest(requestId);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "error in delete operation ");
			throw new SearchServiceException(e.getMessage(), e);
		}
	}

	/**
	 *Get List of JSON Data ResourceType and search params
	 */
	@Override
	public List<String> memberMatchingRequest(String resourceType, SearchParameterRequest parameterMap) {
		try {
			return bulkfhirRepositoryAdapter.memberMatchingRequest(resourceType, parameterMap);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error in member matching operation ");
			throw new SearchServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Get JSON Data by Id and ResourceType
	 */
	@Override
	public String getResourceJsons(String id, String resourceType) {
		try {
			return bulkfhirRepositoryAdapter.getResourceJsons(id, resourceType);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"error in get JSON response ");
			throw new SearchServiceException(e.getMessage(), e);
		}
	}
}

package com.citiustech.fastplus.adapter.dao;

import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.adapter.structure.StatusParam;
import com.citiustech.fastplus.util.BulkExportData;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 
 * This is an interface for FHIRRepositoryDAO defines methods to interact with
 * repository to perform operations related to a resource
 * 
 */	

public interface FHIRRepositoryDAO {

	/**
	 * returns list of ids based on input query
	 * @param query
	 * @return List<IdProjectionRow> list of ids
	 */
	List<IdProjectionRow> executeForIds(String query);

	/**
	 * returns the json based on input query
	 * @param query
	 * @param list 
	 * @return List<String> list of jsons
	 */
	List<String> executeForString(String query, List<Serializable> list);

	/**
	 * used this in case of include and revinclude
	 * @param query
	 * @return Map<String, List<Serializable>>
	 */
	Map<String, List<Serializable>> executeForMapData(String query);
	
	/**
	 * returns the integer based on input query
	 * 
	 * @param query
	 * @return int
	 */
	Integer executeForInt(String query);

	
	/**
	 * method for inserting header entry
	 * 
	 * @param requestUrl
	 * @param uuid
	 * @param since
	 * @return id for persisted entry in header
	 */
	BigInteger insertBulkExportHdrEntry(String requestUrl, String uuid, Date since,String encryptionKey);
	
	/**
	 * Insert bulk queries created for different resources
	 * 
	 * @param resourceQueries
	 * @param refId
	 * @return ids of inserted data
	 */
	public int[] batchInsert(List<BulkExportData> resourceQueries, BigInteger refId);
	
	/**
	 *  returns true if record updated
	 * 
	 * @param requestId
	 * @param statusCode
	 * @return integer
	 */
	int updateBulkHdrStatus(String requestId, String statusCode);
	
	/**
	 * get the status details of the request
	 * 
	 * @param requestId
	 * @return StatusParam
	 */
	StatusParam getBulkDataStatus(String requestId);
	
	
	/**
	 * delete the status details of the request
	 * 
	 * @param requestId
	 * @param cancelFlag
	 * @return integer
	 */
	int deleteBulkDataStatus(String requestId, String cancelFlag);
}

package com.citiustech.fastplus.util;

import java.util.HashMap;
import java.util.Map;

import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;

public enum ParamType {

	STRING("string", StringAndListParam.class),

	TOKEN("token", TokenAndListParam.class),

	DATE("date", DateRangeParam.class),

	REFERENCE("reference",ReferenceAndListParam.class),
	
	URI("uri", null),
	
	COMPOSITE("composite", null);
	
	private final String myValue;
	
	private final Class<?> clazz;
	
	private static final Map<String, ParamType> VALUE_TO_ENUM;
	
	private ParamType(String myValue, Class<?> clazz) {
		this.myValue = myValue;
		this.clazz = clazz;
	}
	
	static {
		Map<String, ParamType> valueToEnum = new HashMap<>();
		for (ParamType next : values()) {
			valueToEnum.put(next.getValue(), next);
		}
		VALUE_TO_ENUM = valueToEnum;
	}

	public String getValue() {
		return myValue;
	}
	
	/**
	 * @return the clazz
	 */
	public Class<?> getClazz() {
		return clazz;
	}



	public static ParamType findByValue(String val) {
		ParamType t = VALUE_TO_ENUM.get(val);
		if(t == null) {
			throw new IllegalStateException(String.format("Unsupported type %s.", val));
		}
		return t;
	}
}

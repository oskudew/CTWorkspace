package com.citiustech.fastplus.mapper;

import com.citiustech.fastplus.mapper.AbstractResourceMapper;
import com.jayway.jsonpath.JsonPath;
import org.hl7.fhir.r4.model.*;
import org.springframework.context.annotation.Configuration;

import java.util.*;

@Configuration
public class PatientMapper extends AbstractResourceMapper {
    @Override
    public Bundle map(Object document) {

        Patient patient = new Patient();

        patient.setId(extractString(document, "$.resource_id"));
        patient.setMeta(extractMeta(document));

        patient.setIdentifier(extractIdentifier(document, "identifier"));
        patient.setName(getName(extractValue(document, "$.name")));
        patient.setGender(Enumerations.AdministrativeGender.fromCode(extractString(document, "$.gender.code")));
        patient.setContact(getContact(extractValue(document, "$.contact")));

        patient.setGeneralPractitioner(getGeneralPractitioner(extractValue(document, "$.generalpractitioner")));
        patient.setTelecom(getTelecom(extractValue(document,"$.telecom")));
        patient.setBirthDate(extractDate(document, "$.birthdate"));
        patient.setAddress(getAddress(extractValue(document, "$.address")));
        patient.addCommunication().setLanguage(getCodeableCode(extractValue(document, "$.communication.language")));
        patient.setMaritalStatus(getCodeableCode(extractValue(document, "$.maritalstatus")));
        patient.setExtension(extractExtensions(extractValue(document, "$.extension")));
        patient.setLink(extractLinkComponent(document, "$.link"));

        if(checkIfValuePresent(document, "$.deceased.codedateTime"))
            patient.setDeceased( extractDateTimeType(document,"$.deceased.codedateTime"));
        if(checkIfValuePresent(document, "$.active"))
            patient.setActive(extractBoolean(document, "$.active"));
        if(checkIfValuePresent(document, "$.deceased.codeBoolean"))
            patient.setDeceased(new BooleanType(extractBoolean(document, "$.deceased.codeBoolean")));
        if(checkIfValuePresent(document, "$.multiplebirth"))
            patient.setMultipleBirth(new BooleanType(extractBoolean(document, "$.multiplebirth")));

        return createBundle(patient);
    }

    public Patient mapForPatient(Object document){
        Patient patient = new Patient();

        patient.setId(extractString(document, "$.resource_id"));
        patient.setMeta(extractMeta(document));

        patient.setIdentifier(extractIdentifier(document, "identifier"));
        patient.setName(getName(extractValue(document, "$.name")));
        patient.setGender(Enumerations.AdministrativeGender.fromCode(extractString(document, "$.gender.code")));
        patient.setContact(getContact(extractValue(document, "$.contact")));

        patient.setGeneralPractitioner(getGeneralPractitioner(extractValue(document, "$.generalpractitioner")));
        patient.setTelecom(getTelecom(extractValue(document,"$.telecom")));
        patient.setBirthDate(extractDate(document, "$.birthdate"));
        patient.setAddress(getAddress(extractValue(document, "$.address")));
        patient.addCommunication().setLanguage(getCodeableCode(extractValue(document, "$.communication.language")));
        patient.setMaritalStatus(getCodeableCode(extractValue(document, "$.maritalstatus")));
        patient.setExtension(extractExtensions(extractValue(document, "$.extension")));
        patient.setLink(extractLinkComponent(document, "$.link"));

        if(checkIfValuePresent(document, "$.deceased.codedateTime"))
            patient.setDeceased( extractDateTimeType(document,"$.deceased.codedateTime"));
        if(checkIfValuePresent(document, "$.active"))
            patient.setActive(extractBoolean(document, "$.active"));
        if(checkIfValuePresent(document, "$.deceased.codeBoolean"))
            patient.setDeceased(new BooleanType(extractBoolean(document, "$.deceased.codeBoolean")));
        if(checkIfValuePresent(document, "$.multiplebirth"))
            patient.setMultipleBirth(new BooleanType(extractBoolean(document, "$.multiplebirth")));

        return patient;


    }

    public List<Patient.PatientLinkComponent> extractLinkComponent(Object document, String jsonPath){
        List<Patient.PatientLinkComponent> list = new ArrayList<Patient.PatientLinkComponent>();
        int length = length(document, jsonPath+".length()");
        for(int i=0; i< length; i++) {
            Patient.PatientLinkComponent obj = new Patient.PatientLinkComponent();
            obj.setOther(extractReference(document, jsonPath+"[" + i + "].other.reference"));
            obj.setType(Patient.LinkType.fromCode(extractString(document, jsonPath+"[" + i + "].type")));
            list.add(obj);
        }
        return list;
    }


    public List<Address> getAddress(Object addDoc) {
        List<Address> addresses = new ArrayList<>();
        int length = length(addDoc, "$.length()");
        for (int index = 0; index < length; index++) {
            Address address = new Address()
                    .setUse(Address.AddressUse.fromCode(extractString(addDoc, "$.[" + index + "].use")))
                    .setCity(extractString(addDoc, "$.[" + index + "].city"))
                    .setState(extractString(addDoc, "$.[" + index + "].state"))
                    .setCountry(extractString(addDoc, "$.[" + index + "].country"))
                    .setDistrict(extractString(addDoc, "$.[" + index + "].district"))
                    .setPostalCode(extractString(addDoc, "$.[" + index + "].postalcode"))
                    .setPeriod(extractPeriod(addDoc, "$.[" + index + "].period.start", "$.[" + index + "].period.end"));
            int lineLength = length(addDoc, "$.[" + index + "].line.length()");
            for (int i = 0; i < lineLength; i++) {
                address.addLine(extractString(addDoc, "$.[" + index + "].line.[" + i + "]"));
            }

            addresses.add(address);
        }
        return addresses;
    }

    private List<Reference> getGeneralPractitioner(Object pracDoc) {

        List<Reference> refs = new ArrayList<>();
        refs.add(extractReference(pracDoc, "$.reference"));
        return refs;
    }

    private List<Patient.ContactComponent> getContact(Object conDoc) {
        List<Patient.ContactComponent> components = new ArrayList<>();
        int length = length(conDoc, "$.length()");

        for (int index = 0; index < length; index++) {
            Patient.ContactComponent contact = new Patient.ContactComponent();
            contact.setName(new HumanName()
                    .addGiven(extractString(conDoc, "$.[" + index + "].name.given"))
                    .setFamily(extractString(conDoc, "$.[" + index + "].name.family")));

            contact.addRelationship(getCodeableCode(extractValue(conDoc, "$.[" + index + "].relationship")));
            contact.setTelecom(getTelecom(extractValue(conDoc, "$.[" + index + "].telecom")));
            contact.setGender(Enumerations.AdministrativeGender.fromCode(extractString(conDoc, "$.[" + index + "].gender")));
            contact.setPeriod(extractPeriod(conDoc, "$.[" + index + "].period.start", "$.[" + index + "].period.end"));
            contact.setAddress(new Address().setText(extractString(conDoc, "$.[" + index + "].address.text")));
            components.add(contact);
        }
        return components;
    }

    public List<ContactPoint> getTelecom(Object telDoc) {
        List<ContactPoint> contacts = new ArrayList<>();
        int length = length(telDoc, "$.length()");

        for (int index = 0; index < length; index++) {
            ContactPoint cp = new ContactPoint()
                    .setSystem(ContactPoint.ContactPointSystem.fromCode(extractString(telDoc, "$.[" + index + "].system")))
                    .setUse(ContactPoint.ContactPointUse.fromCode(extractString(telDoc, "$.[" + index + "].use")))
                    .setValue(extractString(telDoc, "$.[" + index + "].value"));

            contacts.add(cp);
        }
        return contacts;
    }

    public List<HumanName> getName(Object nameDoc) {

        List<HumanName> names = new ArrayList<>();
        HumanName name = new HumanName();
        name.setFamily(extractString(nameDoc, "$.family"));
        name.addPrefix(extractString(nameDoc, "$.prefix"));

        int length = length(nameDoc, "$.given.length()");
        for (int index = 0; index < length; index++) {
            name.addGiven(extractString(nameDoc, "$.given[" + index + "]"));
        }
        names.add(name);

        return names;
    }

    private CodeableConcept getCodeableCode(Object codeDoc) {

        CodeableConcept code = null;
        if (codeDoc != null) {
            code = new CodeableConcept();
            code.addCoding(new Coding().setCode(extractString(codeDoc, "$.coding.code"))
                    .setDisplay(extractString(codeDoc, "$.coding.display"))
                    .setSystem(extractString(codeDoc, "$.coding.system")));

            code.setText(extractString(codeDoc, "$.text"));
        }

        return code;
    }

}

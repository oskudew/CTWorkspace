package recurssive;

import java.util.Arrays;
import java.util.Scanner;

public class DifferenceOfTwoArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int[] arr= new int[a];
		
		for(int i =0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		
		
		int b = sc.nextInt();
		
		int[] arr1= new int[b];
		
		for(int i =0;i<b;i++) {
			arr1[i]=sc.nextInt();
		}
		
	////////////////////////	
		int[] arr2 = new int[b+a-b];
		
		if(a!=b) {
			int c = a-b;
			arr2[0]=0;
			int k=0;
			for(int i =0;i<c;i++) {
				k++;
				arr2[i]=0;
			}
			for(int i=0;i<b;i++) {
				arr2[k++]=arr1[i];
			}
			System.out.println(Arrays.toString(arr2));
		}
		else {
			arr2=arr1;
			System.out.println(Arrays.toString(arr2));
			
		}
		///////////////////////
		int[] result = new int[a];
		int c=0;
		for(int i =a-1;i>=0;i--) {
			
			result[i]=arr[i]-arr2[i]+c;
			System.out.println("arr[i] "+arr[i]+" arr2[i] "+arr2[i]+" "+result[i] + "before if");
			if(result[i]<0) {
				result[i]=result[i]+10;
				System.out.println(result[i] + "after if");
				c=-1;
			}
			else {
				//result[i]=result[i]+c;
				c=0;
			}
			
		}
		
		int count =0;
		
		for(int i=0;i<a;i++) {
			if(result[i]!=0) {
				break;
			}
			else {
				count ++;
			}
		}
		
		int len =a-count;
		int [] result1= new int[len];
		int pc=0;
		for(int i = count;i<a;i++) {
			result1[pc++] = result[i];
		}
		
		System.out.println(Arrays.toString(result1));
		
	
		

	}

}

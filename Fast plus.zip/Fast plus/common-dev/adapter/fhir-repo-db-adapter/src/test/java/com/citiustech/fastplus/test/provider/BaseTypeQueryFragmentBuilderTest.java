package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.SelectQuery;

import ca.uhn.fhir.model.api.IQueryParameterOr;
import ca.uhn.fhir.model.api.IQueryParameterType;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateParam.DateParamDateTimeHolder;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringOrListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

@ExtendWith(MockitoExtension.class)
class BaseTypeQueryFragmentBuilderTest {
	
	@InjectMocks
	private static BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
	
	@Mock
	private static TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;
	
	@Spy
	static private FHIRErrorHandler fhirErrorHandler;
	
	@Spy
	private TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;
	
	static private CustomResourceUtil customResourceUtil;
	
	
	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
    	baseTypeQueryFragmentBuilder = new BaseTypeQueryFragmentBuilder(fhirRepositoryTableConfiguration, stringParamQueryFragmentBuilder,
                tokenParamQueryFragmentBuilder, referenceParamQueryFragmentBuilder, dateRangeParamQueryFragmentBuilder);
        
	}
	

	@DisplayName("Test case for buildOrQuery method")
	@Test
	void test_buildOrQuery() {
		String resourceTypeAlias = "OrganizationUNwk";
		String resourceType = ResourceType.Organization.name();
		String paramName = Organization.SP_ADDRESS_CITY; 
		String value = "Thailand";
		SelectQuery selectQuery = new SelectQuery();
		Map<String, IQueryParameterOr> parameterMap = new HashedMap<>();
		StringParam paramType = new StringParam();
		StringOrListParam stringOrListParam = new StringOrListParam();
		paramType.setValue(value);
		stringOrListParam.addOr(paramType);
		parameterMap.put(paramName,stringOrListParam);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		Condition condition = ComboCondition.and("((OrganizationUNwk.attribute = 'address-city') AND (OrganizationUNwk.value ILIKE 'Thailand%'))");

		when(stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
				(StringParam) paramType, paramName)).thenReturn(condition);
		
		Condition actualValue = baseTypeQueryFragmentBuilder.buildOrQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, parameterMap.get(paramName), paramName);
	    Condition expectedValue = ComboCondition.and("((OrganizationUNwk.attribute = 'address-city') AND (OrganizationUNwk.value ILIKE 'Thailand%'))");
	    
	    assertEquals(expectedValue.toString(),actualValue.toString());
	    
	}

	@DisplayName("Test case for build query method for string param")
	@Test
	void test_buildQueryForStringParam() {
		String resourceTypeAlias = "OrganizationUNwk";
		String resourceType = ResourceType.Organization.name();
		String paramName = Organization.SP_ADDRESS_CITY; 
		String value = "Thailand";
		SelectQuery selectQuery = new SelectQuery();

		StringParam paramType = new StringParam();
		paramType.setValue(value);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		Condition condition = ComboCondition.and("((OrganizationUNwk.attribute = 'address-city') AND (OrganizationUNwk.value ILIKE 'Thailand%'))");
		
		when(stringParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
					(StringParam) paramType, paramName)).thenReturn(condition);
		
		Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("((OrganizationUNwk.attribute = 'address-city') AND (OrganizationUNwk.value ILIKE 'Thailand%'))");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for build query method for token param")
	@Test
	void test_buildQueryForTokenParam() {
		String resourceTypeAlias = "OrganizationUNwk";
		String resourceType= ResourceType.Organization.name();
		String paramName = Organization.SP_TYPE;
		String value = "tax";
		SelectQuery selectQuery = new SelectQuery();
		
		TokenParam paramType = new TokenParam();
		paramType.setValue(value);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		Condition condition = ComboCondition.and("((OrganizationmNdQ.attribute = 'type') AND (OrganizationmNdQ.code = 'tax'))");
		
		when(tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
				(TokenParam) paramType, paramName)).thenReturn(condition);
	
	    Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
	    Condition expectedValue = ComboCondition.and("((OrganizationmNdQ.attribute = 'type') AND (OrganizationmNdQ.code = 'tax'))");
	
	    assertEquals(expectedValue.toString(),actualValue.toString());
	    
	}
	
	@DisplayName("Test case for build query method for reference param where chain is null")
	@Test
	void test_buildQueryForReferenceParamAndChainNull() {
		String resourceTypeAlias = "LocationXwyu";
		String resourceType= ResourceType.Location.name();
		String paramName = Location.SP_PARTOF; 
		String value = "QA-Loc-12ref";
		SelectQuery selectQuery = new SelectQuery();
		
		ReferenceParam paramType = new ReferenceParam(value);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		Condition condition = ComboCondition.and("((LocationXwyu.attribute = 'partof') AND (LocationXwyu.value = 'QA-Loc-12ref'))");
		
		when(referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType,
				resourceTypeAlias, (ReferenceParam) paramType, paramName)).thenReturn(condition);
		
	
	    Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
	    Condition expectedValue = ComboCondition.and("((LocationXwyu.attribute = 'partof') AND (LocationXwyu.value = 'QA-Loc-12ref'))");
	
	    assertEquals(expectedValue.toString(),actualValue.toString());
	    
	}
	
	@DisplayName("Test case for build query method for reference param where chain is not null")
	@Test
	void test_buildQueryForReferenceParamAndChainNotNull() {
		String resourceTypeAlias = "Locationobzz";
		String resourceType = ResourceType.Location.name();
		String paramName =  Location.SP_PARTOF; 
		SelectQuery selectQuery = new SelectQuery();
		
		String chain = Location.SP_TYPE;
		String value = "tax";
		ReferenceParam paramType = new ReferenceParam(chain,value);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
	            fhirRepositoryTableConfiguration, resourceType);
		queryBuilder.setChainedParam(true);
		
		Map<String, String> customResourceMap = new HashMap<>();
		customResourceMap.put("InsurancePlan", "com.citiustech.fastplus.r4.model.DavinciInsurancePlan");
		customResourceMap.put("PractitionerRole", "com.citiustech.fastplus.r4.model.DavinciPractitionerRole");
		customResourceMap.put("Organization", "com.citiustech.fastplus.r4.model.DavinciOrganization");
	    
	    customResourceUtil = new CustomResourceUtil(customResourceMap);
	    baseTypeQueryFragmentBuilder.setCustomResourceUtil(customResourceUtil);
		
		Condition condition = ComboCondition.and("(Location.attribute = 'type') AND (Location.code = 'TAX')");
		
		TokenParam parameterType = new TokenParam(value);
		
		when(tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder,resourceType, resourceType,
				(TokenParam) parameterType,chain)).thenReturn(condition);
		
		Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(Locationobzz.attribute = 'partof') AND ((Location.attribute = 'type') AND (Location.code = 'TAX'))");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for build query method for date param")
	@Test
	void test_buildQueryForDateParam() {
		String resourceTypeAlias = "Organizationolzu";
		String resourceType = ResourceType.Organization.name(); 
		String paramName = "_lastUpdated";
		SelectQuery selectQuery = new SelectQuery();
		
		String lower = "1947-01-16T05:49:13.568+00:00";
		DateParam paramType = new DateParam("eq1947-01-16T05:49:13.568+00:00");
		DateParamDateTimeHolder lowerHolder = new DateParamDateTimeHolder();
		lowerHolder.setValueAsString(lower);
		paramType.setValue(lowerHolder);
		paramType.setPrefix(ParamPrefixEnum.EQUAL);
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
		
		Condition condition = ComboCondition.and("(date_trunc('second',Organizationolzu.lastupdated) = '1947-01-15 21:49:13')");
		
		when(dateRangeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType,
				resourceTypeAlias, paramType, paramName)).thenReturn(condition);
		
		Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(date_trunc('second',Organizationolzu.lastupdated) = '1947-01-15 21:49:13')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	
	@DisplayName("Test case for build query method for parameterType null")
	@Test
	void test_buildQueryForParamTypeNull() {
		String resourceTypeAlias = "OrganizationUNwk";
		String resourceType = ResourceType.Organization.name();
		String paramName = Organization.SP_ADDRESS_CITY; 
		SelectQuery selectQuery = new SelectQuery();

		IQueryParameterType paramType = null;
		
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
                fhirRepositoryTableConfiguration, resourceType);
	
		Condition actualValue = baseTypeQueryFragmentBuilder.buildQuery(selectQuery, queryBuilder, resourceType, resourceTypeAlias,paramType, paramName);
		Condition expectedValue = Condition.EMPTY;
		
		assertEquals(expectedValue,actualValue);
	}

}

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class triplet {
//	
//	void method1(int a, float b) {
//	}
//	void method1(float a, int b) {
//	}
	
	//In given array find if there is a triplet in array whose sum is equal to the given value.
		//If there is such a triplet present in array, then print all the possible triplet 
		//Input: array = {12, 3, 4, 1, 6, 9}, sum = 24; 
		//Output: 12, 3, 9
	
	public static int[] solution(int[]arr, int target) {
		LinkedHashSet set = new LinkedHashSet();
		for(int i=0; i<arr.length;i++) { 
			for(int j=i+1; j<arr.length;j++) {
				int com = target- arr[i]-arr[j];
				if(set.contains(com)) {
					return new int[] {arr[i],com,arr[j]};
				}
				set.add(arr[j]);
			}
			set.add(arr[i]);
			
		}
		return null;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		triplet t = new triplet();
//		t.method1(12, 12);
		int[] arr= new int[] {12,9,4,1,6,3};
		int[] sol=solution(arr, 8);
		
		for(int sols:sol) {
			System.out.println(sols);
		}

	}

}


public class Primeno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=5;
		int flag=0;
		if(i==1 || i==0) {
			System.out.println("not a prime");
		}
		else {
		for(int j=2;j<=i/2;j++) {
			System.out.println("hi");
			if(i%j==0) {
				flag++;
				System.out.println("non prime");
				break;
			}
		}
		if(flag==0) {
			System.out.println("Prime no");
		}
		}

	}

}

package com.citiustech.fastplus.util.sanitize;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document.OutputSettings;
import org.jsoup.safety.Safelist;
import org.springframework.stereotype.Component;

/**
 * This is a JsonTransformation class used for sanitizing invalid html tags 
 * for post and put operations
 */
@Component
public class HTMLSanitizer {

    
    /**
     * Method used for sanitizing invalid html tags
     * 
     * @param inputJson
     * @return
     */
    public String sanitize(String inputJson){
    	OutputSettings outputSettings = new OutputSettings();
		outputSettings.prettyPrint(false);
		Safelist safelist = Safelist.none();
		String safeResourceJson = Jsoup.clean(inputJson, "",safelist,outputSettings);
		return safeResourceJson;
    }
   
}
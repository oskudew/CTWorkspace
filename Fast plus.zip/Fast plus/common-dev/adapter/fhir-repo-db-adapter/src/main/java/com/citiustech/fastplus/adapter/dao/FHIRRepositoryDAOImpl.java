package com.citiustech.fastplus.adapter.dao;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.citiustech.fastplus.adapter.functional.IdProjectionFunction;
import com.citiustech.fastplus.adapter.functional.JsonProjectionFunction;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.adapter.structure.JsonProjectionRow;
import com.citiustech.fastplus.adapter.structure.ResourceLinkData;
import com.citiustech.fastplus.adapter.structure.StatusParam;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.util.BulkExportData;
import com.citiustech.fastplus.util.BulkFHIREnums.StatusCode;
import com.citiustech.fastplus.util.MaskSqlQuery;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;

/**
 * 
 * This is a class for FHIRRepositoryDAOImpl which act as an implementation for
 * FHIRRepositoryDAO interface and provides logic to execute queries
 * 
 */

@Repository
public class FHIRRepositoryDAOImpl implements FHIRRepositoryDAO {

	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGING = LoggerFactory.getLogger(FHIRRepositoryDAOImpl.class.getName());
	
	private static final String QUERY_KEYWORD = "Query : ";

	/**
	 * This is a jdbcTemplate field used to hold jdbcTemplate object to execute
	 * queries
	 */
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object to
	 * handle errors
	 */
	@Autowired
	private FHIRErrorHandler fhirErrorHandler;

	@Autowired
	MaskSqlQuery maskSqlQuery;
	
	KeyHolder keyHolder = new GeneratedKeyHolder();

	@Override
	public List<IdProjectionRow> executeForIds(String query) {
		try {
			LOGGING.logDebug(LoggingMarkers.APPLICATION.getValue(), QUERY_KEYWORD + maskSqlQuery.maskSelectQuery(query));
			return jdbcTemplate.query(query, new IdProjectionFunction());
		} catch (BadSqlGrammarException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}

	@Override
	public List<String> executeForString(String query, List<Serializable> ids) {
		try {
			LOGGING.logDebug(LoggingMarkers.APPLICATION.getValue(), QUERY_KEYWORD + maskSqlQuery.maskSelectQuery(query));
			List<JsonProjectionRow> list = jdbcTemplate.query(query, new JsonProjectionFunction());
			Collections.sort(list, Comparator.comparing(item -> ids.indexOf(item.getSourceId())));

			return list.stream().map(JsonProjectionRow::getResourceJson).collect(Collectors.toList());
		} catch (BadSqlGrammarException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}

	@Override
	public Map<String, List<Serializable>> executeForMapData(String query) {
		List<ResourceLinkData> resourceList = Collections.emptyList();
		try {
			LOGGING.logDebug(LoggingMarkers.APPLICATION.getValue(), QUERY_KEYWORD + maskSqlQuery.maskSelectQuery(query));
			resourceList = jdbcTemplate.query(query,
					(resultSet, i) -> new ResourceLinkData(resultSet.getString(1), resultSet.getString(2)));
			
			 
			return resourceList.stream()
					.collect(Collectors.groupingBy(ResourceLinkData::getTargetType,
							Collectors.mapping(ResourceLinkData::getTargetId, Collectors.toList())));
		} catch (BadSqlGrammarException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR,e);
		}
	}
	
	@Override
	public Integer executeForInt(String query) {
		try {
			LOGGING.logDebug(LoggingMarkers.APPLICATION.getValue(), QUERY_KEYWORD + query);
			return jdbcTemplate.queryForObject(query, Integer.class);
		} catch (Exception e) {
			LOGGING.logError("Method : executeForIds :: Error occurred : ", LoggingMarkers.APPLICATION.getValue(), e);
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}
	
	
	@Override
	public BigInteger insertBulkExportHdrEntry(String requestUrl, String uuid, Date since,String encryptionKey) {
		try {
				jdbcTemplate.update(
			    new PreparedStatementCreator() {
			        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
			            PreparedStatement ps =
			                connection.prepareStatement(QueryConstants.INSERT_FHIRREPO_HDR_DATA_QUERY, new String[] {"id"});
			            ps.setString(1, requestUrl);
			            ps.setString(2, uuid);
			            ps.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
			            ps.setString(4, StatusCode.PENDING.toString());
			            ps.setTimestamp(5, Objects.nonNull(since)?new Timestamp(since.toInstant().toEpochMilli()):null);
			            ps.setString(6, encryptionKey);
			            return ps;
			        }
			    },
			    keyHolder);
		}catch(Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR,e);
		}
		Number data = keyHolder.getKey();
		if(data == null ) {
			throw new FHIRException(ExceptionCodes.QUERY_ERROR.toString());
		}else {
			return BigInteger.valueOf(data.longValue());
		}
		
	}
	
	@Override
	 public int[] batchInsert(List<BulkExportData> resourceQueries, BigInteger refId) {
		 
			try {
			 return this.jdbcTemplate.batchUpdate(
					 QueryConstants.INSERT_RESOURCELVL_FHIRREPO_DATA_QUERY,
		               
		                new BatchPreparedStatementSetter() {
		                    public void setValues(PreparedStatement ps, int i) 
		                        throws SQLException {
		                    	
		                    	ps.setLong(1, refId.longValue());
		                        ps.setString(2, resourceQueries.get(i).getResourceType());
		                        ps.setString(3, resourceQueries.get(i).getExportQuery());
		                        ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
		                        ps.setString(5, StatusCode.PENDING.toString());
		                        ps.setInt(6, resourceQueries.get(i).getExecutionSequence());
		                        
		                    }
		                    public int getBatchSize() {
		                        return resourceQueries.size();
		                    }
		                });
			}catch(Exception e) {
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR,e);
			}
	    }
	
	@Override
	public int updateBulkHdrStatus(String requestId, String statusCode) {
		
		try {
				return jdbcTemplate.update(QueryConstants.UPDATE_BULK_HDR_STATUS_UPDATE_QUERY, statusCode, requestId);
		}catch(Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR,e);
		}
	}

	@Override
	public StatusParam getBulkDataStatus(String requestId) {
		try {
			LOGGING.logDebug(LoggingMarkers.APPLICATION.getValue(), QUERY_KEYWORD + QueryConstants.GET_BULK_HDR_STATUS_QUERY);
			return jdbcTemplate.queryForObject(QueryConstants.GET_BULK_HDR_STATUS_QUERY, new Object[] { requestId },
					(rs, rowNum) -> new StatusParam(
							rs.getString("requestid"),
							rs.getString("requesturl"),
							rs.getString("status"),
							rs.getString("cancelflag"), 
							rs.getInt("progresspercent"),
							rs.getTimestamp("expirationtime") == null ? null : rs.getTimestamp("expirationtime").toLocalDateTime().atZone(ZoneId.systemDefault()),
							rs.getString("response"),
							rs.getString("datakey")
							));
		} catch (EmptyResultDataAccessException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_REQUEST, e);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}	
	}

	@Override
	public int deleteBulkDataStatus(String requestId, String cancelFlag) {
		try {
			return jdbcTemplate.update(QueryConstants.DELETE_BULK_HDR_STATUS_QUERY, cancelFlag, requestId);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}
}

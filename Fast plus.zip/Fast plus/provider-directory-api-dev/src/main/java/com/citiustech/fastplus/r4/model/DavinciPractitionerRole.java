package com.citiustech.fastplus.r4.model;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.PractitionerRole;

/**
 * This class will provide extra search parameter 
 * support based on the Davinci profile.
 */
@ResourceDef(name="PractitionerRole", profile="http://hl7.org/fhir/StructureDefinition/PractitionerRole")
public class DavinciPractitionerRole extends PractitionerRole{

	private static final long serialVersionUID = 1L;
	
	/**
	 * This is a search parameter constant for network-reference
	 * which specifies practitioner is a member of the specified 
	 * health insurance provider network
	 */
	 @SearchParamDefinition(name="network", path="PractitionerRole.extension.where(url='http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/network-reference')", 
			 description="practitioner is a member of the specified health insurance provider network", type="reference", target={Organization.class } )
	  public static final String SP_NETWORK = "network";
}

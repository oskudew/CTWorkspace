package leetcode;

public class hamming_distance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		int a = hammingDistance(2,4);
		System.out.println(a);

	}
	 public static int hammingDistance(int x, int y) {
	      int unique= x^y;
	      System.out.println("unique : "+unique);
	      int count=0;
	      while(unique!=0)
	      {  
	          count++;
	          unique=unique&(unique-1);
	          System.out.println("unique in while-->"+ unique);
	      }
	      return count;
	      
	    }

}

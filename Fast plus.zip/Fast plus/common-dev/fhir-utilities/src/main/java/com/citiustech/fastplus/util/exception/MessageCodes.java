package com.citiustech.fastplus.util.exception;

/**
 * 
 * This is an enum MessageCodes used to define constant codes for different
 * message scenarios
 *
 */

public enum MessageCodes {

	/**
	 * constant for Cancelled Request
	 */
	CANCELLED_REQUEST("FPE-4001"),
	
	/**
	 * constant for Not Started
	 */
	NOT_STARTED("FPE-4002"),

	/**
	 * constant for In-Progress
	 */
	INPROGRESS("FPE-4003"),

	/**
	 * constant for Expired Request
	 */
	EXPIRED_REQUEST("FPE-4004"),

	/**
	 * constant for Request Cancelled
	 */
	REQUEST_CANCELLED("FPE-4005"),
	
	/**
	 * constant for Completed Request
	 */
	COMPLETED_REQUEST("FPE-4006"),
	
	/**
	 * constant for Failed Request
	 */
	FAILED_REQUEST("FPE-4007"),
	
	/**
	 * constant for Failed Request
	 */
	INVALID_STATUS("FPE-4008"),
	
	/**
	 * constant for user accessing unauthorized status and delete operations 
	 */
	UNAUTHORIZED_USER("FPE-4009");
	
	/**
	 * This is a code field used to hold code value
	 */
	private String code;

	/**
	 * parameterized constructor
	 * 
	 * @param code
	 */
	MessageCodes(String code) {
		this.code = code;
	}

	/**
	 * returns code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * returns string representation for this class
	 */
	@Override
	public String toString() {
		return this.code;
	}
}

package com.citiustech.fastplus.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citiustech.fastplus.Adapter;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.filereader.attachment.IAttachmentReader;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.service.ISearchService;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.citiustech.fastplus.util.exception.SearchServiceException;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.model.api.ResourceMetadataKeyEnum;
import ca.uhn.fhir.model.valueset.BundleEntrySearchModeEnum;
import ca.uhn.fhir.parser.DataFormatException;
import ca.uhn.fhir.parser.IParser;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;

/**
 * This is a class for SearchService used as implementation for ISearchService
 * to perform search operation for a resource
 */
@Service
public class SearchService implements ISearchService {
	/**
	 * /** This is a fhirRepositoryAdapter field used to hold fhirRepositoryAdapter
	 * object
	 */
	@Autowired
	protected Adapter fhirRepositoryAdapter;

	/**
	 * This is a resourcesForTransformation field used to hold
	 * resourcesForTransformation
	 */
	@Value("${transform.resources:}")
	private String resourcesForTransformation;

	/**
	 * This is a profileName field used to hold name of profile
	 */
	@Value("${profile.name:}")
	private String profileName;

	/**
	 * This is a searchLimit field used to hold limit for search
	 */
	@Value("${search.limit: 500}")
	private Integer searchLimit;

	/**
	 * This is a fhirRepositoryAdapter field used to hold search multiplication
	 * factor
	 */
	@Value("${search.multiplication.factor: 1}")
	private Integer multiplicationFactor;
	
	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object
	 */
	@Autowired
	protected FHIRErrorHandler fhirErrorHandler;

	@Autowired
	private FhirContext fhirContext;

	@Autowired
	IAttachmentReader attachmentReader;

	/**
	 * This is a commonQueryUtil field used to hold CommonQueryUtil object
	 */
	@Autowired
	private CommonQueryUtil commonQueryUtil;
	
	/**
	 * Get List of resourceIds By resourceType and search params
	 */
	@Override
	public List<IdProjectionRow> findResourceIds(String resourceType, SearchParameterRequest searchParameterMap) {
		try {
			if (searchParameterMap.isEmpty()) {
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.PARAMETER_MISSING);
			}

			searchParameterMap.setLimit(searchLimit);
			return fhirRepositoryAdapter.getIdsForResource(resourceType, searchParameterMap);
		} catch (FHIRException e) {
			if (e.getMessage().contains(ExceptionCodes.PARAMETER_MISSING.toString())
					|| e.getMessage().contains(ExceptionCodes.INVALID_PARAMETER_VALUE.toString())
					|| e.getMessage().contains(ExceptionCodes.INVALID_DATE_FORMAT.toString())) {
				throw new InvalidRequestException(e.getMessage());
			}
			throw new SearchServiceException(e.getMessage(), e);
		}
	}

	/**
	 *Get resource JSON  by resource id and resourceType
	 */
	@Override
	public IBaseResource getResource(String resourceId, String resourceType) {
	    try {
		String resourceIdWithPrefix = commonQueryUtil.findPrefixValue(resourceType, resourceId.trim());
		List<String> jsons = fhirRepositoryAdapter.getResourceJsons(Arrays.asList(resourceIdWithPrefix),
			resourceType);
		if (null != jsons && !jsons.isEmpty()) {
		    Map<String, List<String>> mapOfJson = new HashMap<>();
		    mapOfJson.put(resourceType, jsons);
		    IBaseResource resource = processJson(mapOfJson, null).get(0);
		    attachmentReader.readAttachmentsData(resource, resourceType);
		    return resource;
		} else {
		    return null;
		}
	    } catch (FHIRException e) {
		throw new SearchServiceException(e.getMessage(), e);
	    }
	}

	/**
	 *Get List of resources JSON  by searchResult 
	 */
	@Override
	public List<IBaseResource> getResourcesByIds(SearchResult searchResult) {
		List<IdProjectionRow> listOfResourceIds = searchResult.getListOfResourceIds();
		Set<Include> includeSet = Collections.emptySet();
		Set<Include> setOfRevIncludes = Collections.emptySet();
		Set<Include> setOfRevIncludesProvenance = Collections.emptySet();

		if (Objects.nonNull(searchResult.getSetOfIncludes()))
			includeSet = searchResult.getSetOfIncludes().stream().map(Include::new).collect(Collectors.toSet());

		if (Objects.nonNull(searchResult.getSetOfRevIncludes())) {
			setOfRevIncludes = searchResult.getSetOfRevIncludes().stream()
					.filter(str -> !str.contains(ResourceType.Provenance.name())).map(Include::new)
					.collect(Collectors.toSet());
			setOfRevIncludesProvenance = searchResult.getSetOfRevIncludes().stream()
					.filter(str -> str.contains(ResourceType.Provenance.name())).map(Include::new)
					.collect(Collectors.toSet());
		}

		String resourceType = listOfResourceIds.get(0).getResourceType();
		Map<String, List<Serializable>> resourceIdsMap = new HashMap<>();
		Map<String, List<Serializable>> includedIdsMap = new HashMap<>();

		resourceIdsMap.put(resourceType,
				listOfResourceIds.stream().map(IdProjectionRow::getSourceId).collect(Collectors.toList()));

		if (!includeSet.isEmpty()) {
			includedIdsMap.putAll(fhirRepositoryAdapter.getIncludedIds(listOfResourceIds, includeSet, resourceType));
		}

		if (!setOfRevIncludes.isEmpty()) {
			includedIdsMap
					.putAll(fhirRepositoryAdapter.getRevIncludedIds(listOfResourceIds, setOfRevIncludes, resourceType));
		}

		if (!setOfRevIncludesProvenance.isEmpty()) {
			includedIdsMap.putAll(fhirRepositoryAdapter.getRevIncludedIds(listOfResourceIds, setOfRevIncludesProvenance,
					ResourceType.Provenance.name()));
		}

		Map<String, List<String>> jsons = fhirRepositoryAdapter.getResourceJsons(resourceIdsMap);
		Map<String, List<String>> includedJsons = fhirRepositoryAdapter.getResourceJsons(includedIdsMap);

		List<IBaseResource> iBaseResourceList = new ArrayList<>();
		iBaseResourceList.addAll(processJson(jsons, BundleEntrySearchModeEnum.MATCH.getCode()));
		iBaseResourceList.addAll(processJson(includedJsons, BundleEntrySearchModeEnum.INCLUDE.getCode()));
		attachmentReader.readAttachmentsData(iBaseResourceList, resourceType);
		return iBaseResourceList;
	}

	/**
	 * returns list of resources by processing input jsons
	 *
	 * @param jsons
	 * @param mode
	 * @return resource list
	 * @throws SearchServiceException
	 */
	@SuppressWarnings("unchecked")
	private List<IBaseResource> processJson(Map<String, List<String>> jsons, String mode) {
		return (jsons.entrySet().stream().flatMap(entry -> entry.getValue().stream().map(inputJson -> {
			try {
				IParser parser = fhirContext.newJsonParser();

				IBaseResource resource = parser.parseResource(
						(Class<IBaseResource>) Class.forName(AdapterUtil.getResourcePkg(entry.getKey()) + "."
								+ (entry.getKey().equals("List") ? entry.getKey().concat("Resource") : entry.getKey())),
						inputJson);

				if (null != mode)
					ResourceMetadataKeyEnum.ENTRY_SEARCH_MODE.put((IAnyResource) resource, mode);
				return resource;
			} catch (DataFormatException | FHIRException | ClassNotFoundException e) {
				throw new SearchServiceException(ExceptionCodes.PARSING_ERROR.toString(), e);
			}
		})).collect(Collectors.toList()));
	}

	/**
	 * Get List of resourceIds By resourceType and search params
	 */
	@Override
	public List<IdProjectionRow> getPaginatedIdsForResource(String resourceType,
			SearchParameterRequest searchParameterReq) {
		try {
			if (searchParameterReq.isEmpty()) {
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.PARAMETER_MISSING);
			}

			return fhirRepositoryAdapter.getPaginatedIdsForResource(resourceType, searchParameterReq);
		} catch (FHIRException e) {
			if (e.getMessage().contains(ExceptionCodes.PARAMETER_MISSING.toString())
					|| e.getMessage().contains(ExceptionCodes.INVALID_PARAMETER_VALUE.toString())
					|| e.getMessage().contains(ExceptionCodes.INVALID_DATE_FORMAT.toString())) {
				throw new InvalidRequestException(e.getMessage());
			}
			throw new SearchServiceException(e.getMessage(), e);
		}
	}
	
}

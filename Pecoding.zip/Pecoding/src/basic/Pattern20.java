package basic;

import java.util.Scanner;

public class Pattern20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int a=(n/2)+1;
		int b=(n/2)+1;
		
		for(int i =1;i<=n;i++) {
			for(int j=1;j<=n;j++) {
				if(i<=n/2) {
					if(j==1  || j== n) {
						System.out.print("*\t");
					}
					else {
						System.out.print("\t");
					}
				}
				
				else {
					if(j==1|| j==n ) {
						System.out.print("*\t");
						
					}
					else if(j==a || j==b) {
						System.out.print("*\t");
						
						
						
					}
					else {
						System.out.print("\t");
					}
					
				
				}
				
				
			}
			if(i>n/2) {
				a++;
				b--;	
			}
			
			
			System.out.println();
		}
		

	}

}

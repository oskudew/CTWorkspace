package com.citiustech.fastplus.util;

public class BulkFHIREnums {
	
	public enum StatusCode{
		
		PENDING("Pending"),
		REGISTERED("Registered"),
		INPROGRESS("In-Progress"),
		PAUSED("Paused"),
		COMPLETED("Completed"),
		FAILED("Failed"),
		CANCELLED("Cancelled"),
		EXPIRED("Expired");
		
		private String status;
		
		private StatusCode(String status) {
			this.status = status;
		}
		
		@Override
		public String toString() {
			return this.status;
		}

	}

}

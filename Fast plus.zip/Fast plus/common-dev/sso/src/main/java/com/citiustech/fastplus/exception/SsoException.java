package com.citiustech.fastplus.exception;

/**
 * This is a class for SsoException used to define custom exception to handle
 * SSO related exceptions
 * 
 */
public class SsoException extends RuntimeException {
	/**
	 * This is a serialVersionUID field used to assign serial version id to this
	 * class
	 */
	private static final long serialVersionUID = 4915321869422617501L;
	
	/**
	 * No arguments constructor
	 */
	public SsoException() {
		super();
	}
  
	/**
	 * Parameterized constructor
	 * 
	 * @param errorMessage
	 */
	public SsoException(String errorMessage) {
		super(errorMessage);
	}

	/**
	 * Parameterized constructor
	 * 
	 * @param message
	 * @param throwable
	 */
	public SsoException(String message, Throwable throwable) {
		super(message, throwable);
	}

	/**
	 * Parameterized constructor
	 * 
	 * @param throwable
	 */
	public SsoException(Throwable throwable) {
		super(throwable);
	}
}

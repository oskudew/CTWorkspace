package com.citiustech.fastplus.util;

import org.springframework.stereotype.Component;

@Component
public class MaskSqlQuery {

	public String maskSelectQuery(String query) {

		String[] list = query.split("'");
		StringBuilder maskQuery = new StringBuilder("");
		for (int i = 0; i < list.length; i++) {
			if (i % 2 == 0)
				maskQuery.append(i != (list.length - 1) ? list[i] + "???" : list[i]) ;
		}

		return maskQuery.toString();
	}
}

package Java8;

import java.util.Arrays;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="le@#vel";
		char[] arr=str1.toCharArray();
		System.out.println(str1.chars().fi); 
		String str= "This#string%contains^special*charac09ters&.";   
		str = str.replaceAll("[^a-zA-Z]", "");  
		System.out.println(str);  

	}

}

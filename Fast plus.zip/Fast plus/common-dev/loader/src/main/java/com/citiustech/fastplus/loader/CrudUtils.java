package com.citiustech.fastplus.loader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Service;

import com.citiustech.fastplus.loader.entity.FhirResourceData;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;

@Service
public class CrudUtils {

	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging logger = LoggerFactory.getLogger(CrudUtils.class.getName());

	/**
	 * This is a loader field used to perform mapping operations
	 */
	@Autowired
	private FHIRDataLoader loader;

	/**
	 * This is a crudDao field used to perform CRUD operations
	 */
	@Autowired
	private CrudDAO crudDao;
	
	@Autowired
	private ResourceConfigLoader resourceConfigLoader;

	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object
	 */
	@Autowired
	private FHIRErrorHandler fhirErrorHandler;

	/**
	 * @param resourceJson
	 * @param resourceType
	 * @param crudFlag
	 */
	public void saveAndUpdate(String resourceJson, String resourceType, String crudFlag) {
		final String insertOperation = "I";
		final String updateOperation = "U";
		
		try {
			logger.logDebug(LoggingMarkers.APPLICATION.getValue(), "Json parsing started");
			FhirResourceData fhirResourceData = loader.parse(resourceType, resourceJson,
					resourceConfigLoader.getResourceConfig().get(resourceType + ".json"));
			logger.logDebug(LoggingMarkers.APPLICATION.getValue(), "Json parsing ended");
			logger.logDebug(LoggingMarkers.APPLICATION.getValue(), CrudUtils.class.getName() + " :: crudOperation :"
					+ crudFlag + " resourceType=" + resourceType + " " + "resourceJson =" + resourceJson);
			switch (crudFlag) {
			case insertOperation:
				logger.logInfo(LoggingMarkers.APPLICATION.getValue(), "Performing Insert Operations ...");
				crudDao.insert(fhirResourceData);
				break;
			case updateOperation:
				logger.logInfo(LoggingMarkers.APPLICATION.getValue(), "Performing Update Operations ...");
				crudDao.update(fhirResourceData);
				break;
			default:
				logger.logInfo(LoggingMarkers.APPLICATION.getValue(), "No Operation ...");
			}
		}  catch (FHIRException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.NO_RECORDS, e);
		} catch (BadSqlGrammarException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}
	
	/**for delete operation
	 * @param resourceType
	 * @param id
	 */
	public void delete(String resourceType, String id) {
		logger.logInfo(LoggingMarkers.APPLICATION.getValue(), "Performing Delete Operations ...");
		try {
			crudDao.delete(resourceType, id);
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.DB_CONNECTION_ERROR, e);
		}
	}


}

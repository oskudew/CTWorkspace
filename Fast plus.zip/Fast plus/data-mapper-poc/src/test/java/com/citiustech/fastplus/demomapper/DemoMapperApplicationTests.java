package com.citiustech.fastplus.demomapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMapperApplicationTests {

	@Test
	void contextLoads() {
	}

}

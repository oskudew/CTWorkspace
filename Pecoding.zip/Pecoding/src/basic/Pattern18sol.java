package basic;

import java.util.Scanner;

public class Pattern18sol {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		int st=n;
		int sp=1;
		
		for(int i=1;i<=n;i++){
			
			for(int k=1;k<=sp;k++) {
				System.out.print("\t");
			}
		
			for(int k=1;k<=st;k++) {
				if(i>1 && i<=n/2 && k>1 && k<st) {
					System.out.print("\t");
				}
				else {
				System.out.print("*\t");
				}
			}
			
		    if(i<=n/2) {
		    	st=st-2;
		    	sp++;
		    }
		    else {
		    	
		    	st=st+2;
		    	sp--;
		    	
		    }
		    System.out.println();
		}

	}

}

package com.citiustech.fastplus.querybuilder;

import com.citiustech.fastplus.config.CommonTableConfiguration;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.ParamType;
import com.healthmarketscience.sqlbuilder.*;
import com.healthmarketscience.sqlbuilder.ComboCondition.Op;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSchema;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbSpec;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

import java.util.List;

/**
 * 
 * This is a class for FHIRRepositoryBaseSQLQueryBuilder which used to build
 * base sql query for fhir repository
 * 
 */

public class FHIRRepositoryBaseSQLQueryBuilder implements QueryBuilder {

	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
    private final FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;
    
	/**
	 * This is a currentSearchTable field used to hold CommonTableConfiguration
	 * object
	 */
    private final CommonTableConfiguration currentSearchTable;
    
	/**
	 * This is a resource field used to hold resource information
	 */
    private final String resource;
    
    /**
	 * This is a comboCondition field used to hold OR condition
	 */
    private final ComboCondition comboCondition = new ComboCondition(Op.OR);
    
    /**
	 * This is a selectQuery field used to hold select query object
	 */
    private final SelectQuery selectQuery = new SelectQuery();
    
    /**
	 * This is a schema field used to hold database schema name
	 */
    private final DbSchema schema;
    
	/**
	 * This is a isJoinQuery field used to hold boolean value true if it is a join
	 * query else false
	 */
    private boolean isJoinQuery;
    
    private boolean isChainedParam;
    
    private ParamType paramType;

    /**
     * parameterized constructor to initialize object with required values
     * 
     * @param tableConfiguration
     * @param resource
     */
    public FHIRRepositoryBaseSQLQueryBuilder(
            FHIRRepositoryTableConfiguration tableConfiguration,
            String resource) {
        this.fhirRepositoryTableConfiguration = tableConfiguration;
        this.currentSearchTable = fhirRepositoryTableConfiguration.getSearchTableMap()
                .get(resource);
        this.resource = resource;

        DbSpec spec = new DbSpec();
        this.schema = spec.addSchema(tableConfiguration.getSchema());
    }

    /**
     * sets from table name
     * 
     * @param tableName
     * @param alias
     */
    public void setFromTable(String tableName, String alias) {
        if (!isJoinQuery) {
            selectQuery.addFromTable(new DbTable(schema, tableName, alias));
        }
    }

    @Override
    public void addCondition(Condition condition) {
        comboCondition.addCondition(condition);
    }
    
    /**
     * sets join tables information
     * 
     * @param selectQuery
     * @param targetResource
     * @param targetAlias
     * @param sourceResource
     * @param sourceAlias
     */
	public void addJoinMap(SelectQuery selectQuery, String targetResource, String targetAlias, String sourceResource,
			String sourceAlias) {
		isJoinQuery = true;
		selectQuery.addJoin(SelectQuery.JoinType.INNER,
				new DbTable(schema, fhirRepositoryTableConfiguration.getSearchTableMap().get(sourceResource).getTable(),
						sourceAlias),
				new DbTable(schema, fhirRepositoryTableConfiguration.getSearchTableMap().get(targetResource).getTable(),
						targetAlias),
				BinaryCondition.equalTo(
						new CustomSql(AdapterUtil.getAliasedColumn(sourceAlias,
								fhirRepositoryTableConfiguration.getValueColumn())),
						new CustomSql(AdapterUtil.getAliasedColumn(targetAlias,
								fhirRepositoryTableConfiguration.getIdColumn()))));
	}
	
	public void addJoin(SelectQuery sourceSelectQuery, String sourceAlias, SelectQuery targetSelectQuery, String targetAlias) {
		sourceSelectQuery.addCustomJoin(SelectQuery.JoinType.INNER, 
				null,
				AliasedObject.toAliasedObject(new CustomSql("(" + targetSelectQuery.toString() + ")"), targetAlias) ,
				BinaryCondition.equalTo(
						new CustomSql(AdapterUtil.getAliasedColumn(sourceAlias,
								fhirRepositoryTableConfiguration.getIdColumn())),
						new CustomSql(AdapterUtil.getAliasedColumn(targetAlias,
								fhirRepositoryTableConfiguration.getIdColumn())))	
				);
	}
	
	public void addExist(SelectQuery sourceSelectQuery, String sourceAlias, SelectQuery targetSelectQuery,
			String targetAlias) {

		targetSelectQuery.addCondition(BinaryCondition.equalTo(
				new CustomSql(
						AdapterUtil.getAliasedColumn(sourceAlias, fhirRepositoryTableConfiguration.getIdColumn())),
				new CustomSql(
						AdapterUtil.getAliasedColumn(targetAlias, fhirRepositoryTableConfiguration.getIdColumn()))));

		sourceSelectQuery.addCondition(UnaryCondition.exists(targetSelectQuery));
	}
    
    @Override
    public Condition frameOrQueryAndReturn(List<Condition> conditions) {
        return ComboCondition.or(conditions.toArray(new Condition[0]));
    }

	@Override
	public String build() {
		return selectQuery.addCondition(comboCondition).validate().toString();
	}

    /**
     * sets columns to be fetched from table
     * 
     * @param projections
     */
    public void setProjections(CustomSql... projections) {
        selectQuery.addCustomColumns(projections);
    }

    /**
     * returns resource name 
     */
    public String getResource() {
        return resource;
    }

    /**
     * returns current search table configuration 
     */
    public CommonTableConfiguration getCurrentSearchTable() {
        return currentSearchTable;
    }

    /**
     * returns isJoinQuery flag 
     */
    public boolean isJoinQuery() {
        return isJoinQuery;
    }

	/**
	 * sets boolean value to isJoinQuery
	 * 
	 * @param joinQuery
	 */
    public void setJoinQuery(boolean joinQuery) {
        isJoinQuery = joinQuery;
    }

	/**
	 * @return the isChainedParam
	 */
	public boolean isChainedParam() {
		return isChainedParam;
	}

	/**
	 * @param isChainedParam the isChainedParam to set
	 */
	public void setChainedParam(boolean isChainedParam) {
		this.isChainedParam = isChainedParam;
	}

	/**
	 * @return the paramType
	 */
	public ParamType getParamType() {
		return paramType;
	}

	/**
	 * @param paramType the paramType to set
	 */
	public void setParamType(ParamType paramType) {
		this.paramType = paramType;
	}
	
	  /**
     * sets from table name
     * 
     * @param tableName
     * @param alias
     */
    public void setFromTable(String tableName, String alias,String schemaName) {
    	DbSpec spec = new DbSpec();
        DbSchema tempSchema = spec.addSchema(schemaName);
        if (!isJoinQuery) {
            selectQuery.addFromTable(new DbTable(tempSchema, tableName, alias));
        }
    }

}

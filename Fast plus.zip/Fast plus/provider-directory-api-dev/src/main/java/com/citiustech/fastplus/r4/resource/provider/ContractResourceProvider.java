package com.citiustech.fastplus.r4.resource.provider;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Contract;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.OptionalParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

/** 
 * 
 * This class is the Contract resource provider class
 * which will serves all supported
 * read and search parameter requests for Contract resource
 * 
 */
@Component
public class ContractResourceProvider implements IResourceProvider{

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(ContractResourceProvider.class.getName());
	
	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return Contract.class;
	}

	/**
	 * This method will return Contract resource based on the provided id
	 * @param theId
	 * @return a single resource
	 * 
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {

		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Read operation for id " + theId.getIdPart());
		return service.getResourceById(theId.getIdPart(), ResourceType.Contract.name());
	}

	/**
	 * This method will return the bundle of 
	 * resources based on the search 
	 * parameters passed in the request
	 * @param theId
	 * @param identifier
	 * @param authority
	 * @param domain
	 * @param issuedDate
	 * @param lastUpdated
	 * @param signerParty
	 * @param status
	 * @param subject
	 * @param uri
	 * @return bundle of resources
	 */
	@Search()
	public IBundleProvider getContract(
			@OptionalParam(name = Contract.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = Contract.SP_IDENTIFIER) TokenAndListParam identifier,
			@OptionalParam(name = Contract.SP_AUTHORITY) ReferenceAndListParam authority,
			@OptionalParam(name = Contract.SP_DOMAIN) ReferenceAndListParam domain,
			@OptionalParam(name = Contract.SP_ISSUED) DateRangeParam issuedDate,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@OptionalParam(name = Contract.SP_SIGNER) ReferenceAndListParam signerParty,
			@OptionalParam(name = Contract.SP_STATUS) TokenAndListParam status,
			@OptionalParam(name = Contract.SP_SUBJECT) ReferenceAndListParam subject
			
	) {
		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(Contract.SP_RES_ID, theId);
		paramMap.add(Contract.SP_IDENTIFIER, identifier);
		paramMap.add(Contract.SP_AUTHORITY, authority);
		paramMap.add(Contract.SP_DOMAIN, domain);
		paramMap.add(Contract.SP_ISSUED, issuedDate);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		paramMap.add(Contract.SP_SIGNER, signerParty);
		paramMap.add(Contract.SP_STATUS, status);
		paramMap.add(Contract.SP_SUBJECT, subject);
		
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
        return service.getResources(paramMap, ResourceType.Contract.name());          
	}
}


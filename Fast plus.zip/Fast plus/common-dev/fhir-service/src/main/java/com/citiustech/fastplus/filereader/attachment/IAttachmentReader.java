package com.citiustech.fastplus.filereader.attachment;

import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;

/**
 * 
 * This is an interface for AttachmentReader defines methods to perform
 * operation for file read.
 * 
 */
public interface IAttachmentReader {

	/**
	 * use to set attachment data.
	 * 
	 * @param resources
	 * @param resourceType
	 */
	void readAttachmentsData(List<IBaseResource> resources, String resourceType);

	/**
	 * use to set attachment data.
	 * 
	 * @param attachments
	 */
	void readAttachmentsData(List<Attachment> attachments);

	void readAttachmentsData(IBaseResource resource, String resourceType);

}

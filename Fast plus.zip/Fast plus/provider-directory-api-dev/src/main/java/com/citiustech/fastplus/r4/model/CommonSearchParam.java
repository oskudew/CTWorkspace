package com.citiustech.fastplus.r4.model;

import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;


public class CommonSearchParam {
	
	/**
     * Search parameter constant for <b>_lastUpdated</b>     
     * 
     * */
	@SearchParamDefinition(name="_lastUpdated", path="", description="Defines the date when Resource was created or updated, whichever comes last", type="date"  )
    public static final String SP_LAST_UPDATED = "_lastUpdated";
	
	private CommonSearchParam() {}
}

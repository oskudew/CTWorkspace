import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class prac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="4,8,12,1,8,2,4,4";
		String[] s1 =s.split(",");
		int[] arr=new int[s1.length]; 
		for(int i=0;i<s1.length;i++) {
			arr[i]= Integer.parseInt(s1[i]);
		}
		Arrays.sort(arr);
		int count=0;
		
//		
//		 HashSet<Integer> set= new HashSet<Integer>();
//		
//		 ///////////////////
//		for(int i=0;i<arr.length;i++) {
//			if(set.add(arr[i])) {
//			for(int j=0;j<arr.length;j++) {
//				 
//				if(arr[i]==arr[j]) {
//					count++;
//				}
//				
//			}
//			System.out.println(arr[i]+"-"+ count);
//			count=0;
//			}
//		}
//		System.out.println("/////////without using collection");//////////////////////////////
//		
		
			 int count1 = 1;
		        for (int i = 0; i < arr.length; i++) {
		            if (i!=arr.length-1 && arr[i] == arr[i + 1])
		                count1++;
		            else {
		                System.out.println(arr[i] + "--" + count1);
		                count1=1;
		            }
		        }
		
	}

}

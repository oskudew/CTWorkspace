package com.citiustech.fastplus.validator;

import org.hl7.fhir.r5.model.OperationOutcome.IssueSeverity;
import org.hl7.fhir.r5.model.OperationOutcome.IssueType;

public class ErrorDetail {
	
	private String errorMsg;
	private IssueSeverity issueSeverity; 
	private IssueType issueType;
	
	/**
	 * @param errorMsg
	 * @param issueSeverity
	 * @param issueType
	 */
	public ErrorDetail(String errorMsg, IssueSeverity issueSeverity, IssueType issueType) {
		super();
		this.errorMsg = errorMsg;
		this.issueSeverity = issueSeverity;
		this.issueType = issueType;
	}
	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}
	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	/**
	 * @return the issueSeverity
	 */
	public IssueSeverity getIssueSeverity() {
		return issueSeverity;
	}
	/**
	 * @param issueSeverity the issueSeverity to set
	 */
	public void setIssueSeverity(IssueSeverity issueSeverity) {
		this.issueSeverity = issueSeverity;
	}
	/**
	 * @return the issueType
	 */
	public IssueType getIssueType() {
		return issueType;
	}
	/**
	 * @param issueType the issueType to set
	 */
	public void setIssueType(IssueType issueType) {
		this.issueType = issueType;
	} 
	
	

}

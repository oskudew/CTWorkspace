package leetcode;

public class PlusOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] digits= {9,9,9,9,9,9,9,9,9,7,9,9,9,9};
		//int[] digits= {7,2,8,5,0,9,1,2,9,5,3,6,6,7,3,2,8,4,3,7,9,5,7,7,4,7,4,9,4,7,0,1,1,1,7,4,0,0,6};
//		String s="";
//		for(int i=0;i<digits.length;i++) {
//			s=s+digits[i];
//		}
//		
//	        System.out.println("yo  "+s);
//	        long a= Long.parseLong(s);
//	        a=a+1;
//	        s=""+a;
//	        System.out.println(s);
//	        int[] arr=new int[s.length()];
//	        for(int i=0;i<s.length();i++){
//	            arr[i]=s.charAt(i)-48;
//	            System.out.print(arr[i]+",");
//	        }
	     	int len=digits.length-1;
	     	int k=digits[0];
	     	int carry=0;
	     	
	     	while(len>=0) {
	    	  if(digits[len]<9) {
	    		  digits[len]=digits[len]+1;
	    		  carry=0;
	    		  break;
	    	  }
	    	  else {
	    		  digits[len]=0;
	    		  carry=1;
	    		  len=len-1;
	    		  
	    	  }
	     	}
	    	  if(k==9 && carry==1) {
		     		int[] arr=new int[digits.length+1];
		     		arr[0]=1;
		     		int p=1;
		     		 for(int i=0;i<digits.length;i++) {
			    		  arr[p++]=digits[i];
			    	  }
		     		for(int i=0;i<arr.length;i++)
		    	     	System.out.print(arr[i]+",");
			    	  
		     	}
	    	  for(int i=0;i<digits.length;i++) {
	    		  System.out.print(digits[i]+"-");
	    	  }
	      

	}

}

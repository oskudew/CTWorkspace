package com.citiustech.fastplus.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.model.api.annotation.Child;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 
 * This is a class for CustomResourceUtil which provides utility methods for
 * performing validations for custom resource
 * 
 */

@Component
@PropertySource("classpath:application.properties")
public class CustomResourceUtil {

	/**
	 * This is a customResourceMap field used to hold custome resources
	 */
	@Value("#{${custom.resource.map: {}}}")
	private Map<String, String> customResourceMap;

	
	private static Map<String, String> getSpecialAttributes() {
		Map<String, String> specialAttributes = new HashMap<>();
		specialAttributes.put("_id", "RES_ID");
		 return specialAttributes;
	}
	
	/**
	 * returns boolean value true if it is a custome resource alse false
	 * 
	 * @param resource
	 * @return boolean
	 */
	public CustomResourceUtil(Map<String, String> customResourceMap) {
		super();
		this.customResourceMap = customResourceMap;
	}
	
	public CustomResourceUtil() {
		
	}
	
	public boolean isCustomResource(String resource) {
		if (customResourceMap == null)
			return false;
		return customResourceMap.containsKey(resource);
	}

	

	/**
	 * returns custom resource from map using input
	 * 
	 * @param key
	 * @return String
	 */
	public String getCustomResource(String key) {
		return customResourceMap.get(key);
	}
	
	
	/**
	 * @param resourceType
	 * @param paramName
	 * @throws NoSuchFieldException
	 * @throws ClassNotFoundException
	 */
	public String getParamType(String resourceType, String paramName)
			throws NoSuchFieldException, ClassNotFoundException {
		return getSearchParamDefinition(resourceType, paramName).type();
	}
	
	/**
	 * @param resourceType
	 * @param paramName
	 * @throws NoSuchFieldException
	 * @throws ClassNotFoundException
	 */
	public SearchParamDefinition getSearchParamDefinition(String resourceType, String paramName)
			throws NoSuchFieldException, ClassNotFoundException {
		String searchparamPrefix = "SP_";
		String paramNameRef = paramName;
		paramNameRef = paramNameRef.replace('-', '_');
		
		Field field = Class.forName(getResourceClass(resourceType))
					.getField(searchparamPrefix + getParamName(paramNameRef).toUpperCase(Locale.getDefault()));
		
		return field.getDeclaredAnnotation(SearchParamDefinition.class);
	}
	
	private String getParamName(String paramName) {
		
		if(getSpecialAttributes().keySet().contains(paramName)) {
			return getSpecialAttributes().get(paramName);
		}
		return paramName;
			
	}

	/**
	 * @param resourceType
	 * @return
	 */
	private String getResourceClass(String resourceType) {
		String resourceClass = AdapterUtil.getResourcePkg(resourceType) + "."+ (resourceType.equals("List")? resourceType.concat("Resource"): resourceType);
		if (isCustomResource(resourceType)) {
			resourceClass = getCustomResource(resourceType);
		}
		return resourceClass;
	}

	public Child getChildDefinition(String resourceType, String paramName) throws NoSuchFieldException, ClassNotFoundException {

		SearchParamDefinition definition = getSearchParamDefinition(resourceType, paramName);
		Field field = Class.forName(AdapterUtil.getResourcePkg(resourceType) + "."+ resourceType).getDeclaredField(definition.path().split("\\.")[1]);
		
		return field.getDeclaredAnnotation(Child.class);
	}
	
	public List<String> getReferenceTargetList(String resourceType,  String paramName) throws NoSuchFieldException, ClassNotFoundException {
	    SearchParamDefinition searchParamDefinition = getSearchParamDefinition(resourceType, paramName);
	    
	    
	    return Arrays.asList(searchParamDefinition.target()).stream().map(Class::getSimpleName).collect(Collectors.toList());
	}
	
}

package com.citiustech.fastplus;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IBaseConformance;
import org.hl7.fhir.r4.model.CapabilityStatement;
import org.hl7.fhir.r4.model.CapabilityStatement.CapabilityStatementRestComponent;
import org.hl7.fhir.r4.model.CapabilityStatement.CapabilityStatementRestSecurityComponent;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.UriType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.server.RestfulServerConfiguration;
import ca.uhn.fhir.rest.server.method.BaseMethodBinding;
import ca.uhn.fhir.rest.server.method.ReadMethodBinding;
import ca.uhn.fhir.rest.server.method.SearchMethodBinding;
import ca.uhn.fhir.rest.server.servlet.ServletRequestDetails;

@Component
@Interceptor
public class CapabilityStatementCustomizer {
	
	/**
	 * This is a publisher field used to represent publisher name for Capability
	 * Statement
	 */
	@Value("${fhir.publisher}")
	private String publisher;

	/**
	 * This is a softwareName field used to represent software name for Capability
	 * Statement
	 */
	@Value("${fhir.software.name}")
	private String softwareName;

	/**
	 * This is a description field used to represent description for Capability
	 * Statement
	 */
	@Value("${fhir.instance.description}")
	private String description;
	
	@Value("${iam-baseurl}")
	private String iamBaseUrl;
	
	/**
	 * This is a supportedProfiles field used to represent supported profiles to be
	 * added in Capability Statement
	 */
	@Autowired
	SupportedProfiles supportedProfiles;
	
	
	@Hook(Pointcut.SERVER_CAPABILITY_STATEMENT_GENERATED)
	public void customize(IBaseConformance theCapabilityStatement,
			RequestDetails theRequestDetails, ServletRequestDetails servletRequestDetails) {

		CapabilityStatement cs = (CapabilityStatement) theCapabilityStatement;

		// Customize the CapabilityStatement as desired
		cs.setName(softwareName);
		cs.getImplementation().setDescription(description);
		cs.setPublisher(publisher);
		cs.getSoftware().setName(softwareName);
		
		
		injectSupportedSubprofiles(cs);
		insertRestSecurity(cs);
		injectIncludesAndRevIncludes(cs, theRequestDetails, servletRequestDetails.getServer().createConfiguration());
	}
	
	/**
	 * adds include and revInclude parameters in the CapabilityStatement
	 * 
	 * @param statement
	 * @param theRequestDetails
	 */
	private void injectIncludesAndRevIncludes(CapabilityStatement statement, 
			RequestDetails theRequestDetails,RestfulServerConfiguration configuration) {

		Map<String, List<BaseMethodBinding<?>>> resourceToMethods = configuration.collectMethodBindings();
		
		statement.getRest().forEach(rest -> rest.getResource().forEach(fhirResource -> {
			fhirResource.setSearchInclude(null);
			fhirResource.setSearchRevInclude(null);
			List<BaseMethodBinding<?>> methodBindings = resourceToMethods.get(fhirResource.getType());
			methodBindings.forEach(nextMethodBinding -> {
				if (nextMethodBinding instanceof SearchMethodBinding || 
					nextMethodBinding instanceof ReadMethodBinding) {
					
					List<StringType> revInclude = nextMethodBinding.getRevIncludes().stream()
							.map(str -> new StringType(str)).collect(Collectors.toList());
					List<StringType> include = nextMethodBinding.getIncludes().stream()
							.map(str -> new StringType(str)).collect(Collectors.toList());

					if(!CollectionUtils.isEmpty(revInclude)) {
						fhirResource.setSearchRevInclude(revInclude);
					}	
					if(!CollectionUtils.isEmpty(include)) {
						fhirResource.setSearchInclude(include);
					}
				}
			});
		}));
		
	}
	
	/**
	 * adds supported profiles in Capability Statement
	 * 
	 * @param statement
	 */
	  private void injectSupportedSubprofiles(final CapabilityStatement statement) {
	        statement.getRest().get(0).getResource().forEach(
	                resource -> resource.addSupportedProfile(supportedProfiles.getSupportedProfile().get(resource.getType()))
	        );
	    }
	

	private void insertRestSecurity(CapabilityStatement statement) {

		CapabilityStatementRestComponent rest = statement.getRest().get(0);
		CapabilityStatementRestSecurityComponent restSecurity = new CapabilityStatementRestSecurityComponent();

		CodeableConcept security = new CodeableConcept(
				new Coding("http://hl7.org/fhir/restful-security-service", "SMART-on-FHIR", "SMART-on-FHIR"));
		security.setText("See http://docs.smarthealthit.org/");

		restSecurity.addService(security);
		restSecurity.setDescription(
				"This is the Capability Statement to declare that the server supports SMART-on-FHIR. See the SMART-on-FHIR docs for the extension that would go with such a server");

		List<Extension> oauthExtensions = Arrays.asList(
			new Extension("token", new UriType(iamBaseUrl.concat("/token"))),
				new Extension("authorize", new UriType(iamBaseUrl.concat("/auth"))));
		
		Extension securityExtension = new Extension(
				"http://fhir-registry.smarthealthit.org/StructureDefinition/oauth-uris");
		securityExtension.setExtension(oauthExtensions);

		restSecurity.addExtension(securityExtension);
		rest.setSecurity(restSecurity);
	}
}

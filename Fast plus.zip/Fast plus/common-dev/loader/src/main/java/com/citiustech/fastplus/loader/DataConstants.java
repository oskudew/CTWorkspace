package com.citiustech.fastplus.loader;

public class DataConstants {
	
	private DataConstants() {
		
	}

	public static final String PROVIDERID = "$.extension[0].valueString";
	
	public static final String PATIENTID = "$.extension[3].extension[*].valueReference.reference";
	
	public static final String STARTDATE = "$.extension[2].valueInstant";
	
	public static final String ENDDATE = "$.end";
	
	public static final String RESOURCES = "$.criteria";
	
	public static final String STATUS = "$.status";
	
	public static final String CHANNEL_TYPE = "$.channel.type";
	
	public static final String CHANNEL_ENDPOINT = "$.channel.endpoint";
	
	public static final String CHANNEL_HEADER = "$.channel.header";
	
	public static final String SUBSCRIPTION_NAME = "$.extension[1].valueString";
	
	public static final String CRITERIA = "$.extension[4].extension[*].valueReference.reference";
}

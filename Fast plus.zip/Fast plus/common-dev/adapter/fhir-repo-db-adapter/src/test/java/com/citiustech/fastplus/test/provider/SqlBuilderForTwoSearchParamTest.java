package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.hl7.fhir.r4.model.InsurancePlan;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.ReferenceParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.UriParamQueryFragmentBuilder;
import com.citiustech.fastplus.test.factory.ReferenceFactory;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

@ExtendWith(MockitoExtension.class)
class SqlBuilderForTwoSearchParamTest {

	@InjectMocks
	private DeepNestedSqlBuilder deepNestedSqlBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Spy
	private static BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Spy
	private static ProjectionAndSortingHelper projectionAndSortingHelper;
	
	@Spy
	private static FHIRErrorHandler fhirErrorHandler;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;
		CustomResourceUtil customResourceUtil;
		TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;
		
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
        fhirErrorHandler = new FHIRErrorHandler();
        
        Map<String, String> customResourceMap = new HashMap<>();
        customResourceMap.put("FormularyDrug", "com.citiustech.fastplus.r4.model.DavinciFormularyDrug");
        customResourceMap.put("DocumentReference", "com.citiustech.fastplus.r4.model.USCoreDocumentReference");
        customResourceMap.put("ExplanationOfBenefit", "com.citiustech.fastplus.r4.model.USCoreExplanationOfBenefit");
        
		customResourceUtil = new CustomResourceUtil(customResourceMap);
		CommonQueryUtil commonQueryUtil = new CommonQueryUtil(fhirErrorHandler,customResourceUtil);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
        stringParamQueryFragmentBuilder =  new StringParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        tokenParamQueryFragmentBuilder = new TokenParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil,
        		fhirErrorHandler);
        referenceParamQueryFragmentBuilder = new ReferenceParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        dateRangeParamQueryFragmentBuilder = new DateRangeParamQueryFragmentBuilder(customResourceUtil, commonQueryUtil, fhirErrorHandler,
        		fhirRepositoryTableConfiguration);
        uriParamQueryFragmentBuilder = new UriParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        
        baseTypeQueryFragmentBuilder = new BaseTypeQueryFragmentBuilder(fhirRepositoryTableConfiguration,
        		stringParamQueryFragmentBuilder, tokenParamQueryFragmentBuilder, referenceParamQueryFragmentBuilder,
        		dateRangeParamQueryFragmentBuilder);
        
        baseTypeQueryFragmentBuilder.setCustomResourceUtil(customResourceUtil);
        baseTypeQueryFragmentBuilder.setFhirErrorHandler(fhirErrorHandler);
        baseTypeQueryFragmentBuilder.setUriParamQueryFragmentBuilder(uriParamQueryFragmentBuilder);
        
        projectionAndSortingHelper = new ProjectionAndSortingHelper(fhirRepositoryTableConfiguration, customResourceUtil,
        		fhirErrorHandler);
	}
	
	
	@DisplayName("Test case for String and Token search parameter with or condition")
	@Test
	void test_BuildNestedQueriesForStringeAndTokenParam() {
		
		String resourceType =  ResourceType.InsurancePlan.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("Planname:103")
				.addStringParam(new StringParam("Planname:104")).newInstance();
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.addTokenParam(new TokenParam("http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/InsuranceProductTypeCS", "mediadvhmo"))
				.newInstance();
		
		searchParamMap.add(InsurancePlan.SP_NAME, stringAndListParam);
		searchParamMap.add(InsurancePlan.SP_TYPE, tokenAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "wuxk";
		String randomAlphabeticString2 = "vxMq";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT InsurancePlanwuxk.id FROM insuranceplanSearch InsurancePlanwuxk WHERE ((((InsurancePlanwuxk.attribute = 'name') AND (InsurancePlanwuxk.value ILIKE 'Planname:103%')) OR ((InsurancePlanwuxk.attribute = 'name') AND (InsurancePlanwuxk.value ILIKE 'Planname:104%'))) " + 
				"AND (EXISTS (SELECT 1 FROM insuranceplanSearch InsurancePlanvxMq WHERE ((((InsurancePlanvxMq.attribute = 'type') AND (InsurancePlanvxMq.system = 'http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/InsuranceProductTypeCS')) AND (InsurancePlanvxMq.code = 'mediadvhmo')) AND (InsurancePlanwuxk.id = InsurancePlanvxMq.id))))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	@DisplayName("Test case for String and Reference search parameter with string contains modifier")
	@Test
	void test_BuildNestedQueriesForStringAndReferenceParam() {
		
		String resourceType =  ResourceType.Organization.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("Kern-endpt-6").newInstance();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("Mexico").setContains(Boolean.TRUE)).newInstance();
		
		searchParamMap.add(Organization.SP_ENDPOINT, referenceAndListParam);
		searchParamMap.add(Organization.SP_NAME, stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "yMpN";
		String randomAlphabeticString2 = "hJrJ";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT OrganizationyMpN.id FROM organizationsearch OrganizationyMpN WHERE (((OrganizationyMpN.attribute = 'endpoint') " + 
				"AND (OrganizationyMpN.value = 'Kern-endpt-6')) AND (EXISTS (SELECT 1 FROM organizationsearch OrganizationhJrJ WHERE (((OrganizationhJrJ.attribute = 'name') " + 
				"AND (OrganizationhJrJ.value ILIKE '%Mexico%')) AND (OrganizationyMpN.id = OrganizationhJrJ.id))))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	@DisplayName("Test case for Reference and Token search parameter with chaining")
	@Test
	void test_BuildNestedQueriesForReferenceAndTokenParam() {
		
		String resourceType =  ResourceType.PractitionerRole.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();

		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.addReferenceParam( new ReferenceParam("name:contains","ACME")).newInstance();
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.addTokenParam( new TokenParam("http://nucc.org/provider-taxonomy", "363LA2200X")).newInstance();
		
		searchParamMap.add(PractitionerRole.SP_ORGANIZATION, referenceAndListParam);
		searchParamMap.add(PractitionerRole.SP_SPECIALTY, tokenAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit,TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "scPu";
		String randomAlphabeticString2 = "lUOE";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT DISTINCT PractitionerRolescPu.id FROM fhirrepo.practitionerrolesearch PractitionerRolescPu INNER JOIN fhirrepo.organizationsearch Organization ON (PractitionerRolescPu.value = Organization.id) "
				+ "WHERE (((PractitionerRolescPu.attribute = 'organization') AND ((Organization.attribute = 'name') AND (Organization.value ILIKE '%ACME%'))) "
				+ "AND (EXISTS (SELECT 1 FROM practitionerrolesearch PractitionerRolelUOE WHERE ((((PractitionerRolelUOE.attribute = 'specialty') "
				+ "AND (PractitionerRolelUOE.system = 'http://nucc.org/provider-taxonomy')) AND (PractitionerRolelUOE.code = '363LA2200X')) AND (PractitionerRolescPu.id = PractitionerRolelUOE.id))))) LIMIT 500" ; 
		
		assertEquals(expectedValue, actualValue);
	}
	
	
	// test for patient resources 
	@DisplayName("Test case for String and Date search parameter with date modifier")
	@Test
	void test_BuildNestedQueriesForStringAndDateParam() {
		
		String resourceType =  ResourceType.Patient.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theLowerBound = new DateParam("gt1934-01-01");
		DateRangeParam birthDate = new DateRangeParam(theLowerBound,null);
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("J").setContains(Boolean.TRUE)).newInstance();
		
		searchParamMap.add(Patient.SP_BIRTHDATE, birthDate);
		searchParamMap.add(Patient.SP_NAME, stringAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit,TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "Yozr";
		String randomAlphabeticString2 = "FTfF";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		
		String actualValue = deepNestedSqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT PatientYozr.id,PatientYozr.patient_id FROM patientsearch PatientYozr WHERE (((PatientYozr.attribute = 'birthdate') AND (PatientYozr.startdate > '1934-01-01 00:00:00')) AND "
				+ "(EXISTS (SELECT 1 FROM patientsearch PatientFTfF WHERE ((((PatientFTfF.attribute = 'given') OR (PatientFTfF.attribute = 'family')) AND (PatientFTfF.value ILIKE '%J%')) AND (PatientYozr.id = PatientFTfF.id))))) ORDER BY PatientYozr.id LIMIT 500"; 
		
		assertEquals(expectedValue, actualValue);
		
	}	
	 
	@DisplayName("Test case for Token and Date search parameter with date modifier")
	@Test
	void test_BuildNestedQueriesForTokenAndDateParam() {
		
		String resourceType =  ResourceType.Observation.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theUpperBound = new DateParam("lt2020-12-13");
		DateRangeParam date = new DateRangeParam(null,theUpperBound);
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.setReferenceValue("laboratory").newInstance();
		
		searchParamMap.add(Observation.SP_DATE, date);
		searchParamMap.add(Observation.SP_CATEGORY, tokenAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "uXlD";
		String randomAlphabeticString2 = "uBwS";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2);
		
		String actualValue = deepNestedSqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT ObservationuXlD.id,ObservationuXlD.patient_id FROM observationsearch ObservationuXlD WHERE (((ObservationuXlD.attribute = 'date') AND (ObservationuXlD.startdate < '2020-12-13 00:00:00')) "
				+ "AND (EXISTS (SELECT 1 FROM observationsearch ObservationuBwS WHERE (((ObservationuBwS.attribute = 'category') AND (ObservationuBwS.code = 'laboratory')) AND (ObservationuXlD.id = ObservationuBwS.id))))) ORDER BY ObservationuXlD.id LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
		
	}
	
	@DisplayName("Test case for Reference and Date search parameter with date modifier")
	@Test
	void test_BuildNestedQueriesForReferenceAndDateParam() {
		
		String resourceType =  ResourceType.Procedure.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theUpperBound = new DateParam("le2012-02-14");
		DateParam theLowerBound = new DateParam("gt2005-03-01");
		DateRangeParam date = new DateRangeParam(theLowerBound,theUpperBound);
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("Kern-pat-7b7709ff-a107-49ea-8211-56771b65cd19").newInstance();
		
		searchParamMap.add(Procedure.SP_DATE, date);
		searchParamMap.add(Procedure.SP_PATIENT, referenceAndListParam);
		if (Objects.nonNull(referenceAndListParam)) {
			searchParamMap.setPatientIds(AdapterUtil.getParamList(referenceAndListParam));
		}
		searchParamMap.setPatientSearchParam(Procedure.SP_PATIENT);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "bsCv";
		String randomAlphabeticString2 = "uGue";
		String randomAlphabeticString3= "cRiZ";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,randomAlphabeticString2,randomAlphabeticString3);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT DISTINCT ProcedurebsCv.id FROM proceduresearch ProcedurebsCv WHERE (((ProcedurebsCv.attribute = 'date') AND (ProcedurebsCv.startdate > '2005-03-01 00:00:00')) AND "
				+ "(EXISTS (SELECT 1 FROM proceduresearch ProcedureuGue WHERE (((ProcedureuGue.attribute = 'date') AND (ProcedureuGue.enddate <= '2012-02-14 00:00:00')) AND (ProcedurebsCv.id = ProcedureuGue.id)))) AND "
				+ "(EXISTS (SELECT 1 FROM proceduresearch ProcedurecRiZ WHERE (((ProcedurecRiZ.attribute = 'patient') AND (ProcedurecRiZ.value = 'Kern-pat-7b7709ff-a107-49ea-8211-56771b65cd19')) AND (ProcedurebsCv.id = ProcedurecRiZ.id))))) LIMIT 500"; 
		
		assertEquals(expectedValue, actualValue);
		
	}
	    
}

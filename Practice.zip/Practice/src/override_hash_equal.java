
import java.util.HashSet;
import java.util.Set;
 
public class override_hash_equal {
    // Program to demonstrate the need for overriding `equals` and `hashCode`
    // method in Java
    public static void main(String[] args)
    {
        Employee e1 = new Employee("null", 80000);
        Employee e2 = new Employee("null", 80000);
        Employee e3 = new Employee("Johnn",80000);
 
        Set<Employee> employees = new HashSet<>();
 
       employees.add(e1);
        employees.add(e2);
        employees.add(e3);
        System.out.println(e1.hashCode()+" "+ e2.hashCode()+" "+e3.hashCode());
        System.out.println(e1.equals(e2));
 
        System.out.println(employees);
    }
}



class Employee
{
    private String name;
    private int salary;
 
    public Employee(String name, int salary)
    {
        this.name = name;
        this.salary = salary;
    }
 
    @Override
    public String toString() {
        return "{" + name + ", " + salary + "}";
    }
 
//    @Override
//    public boolean equals(Object o)
//    {
//        if (this == o) {
//            return true;
//        }
//        if (o == null || getClass() != o.getClass()) {
//            return false;
//        }
// 
//        Employee employee = (Employee) o;
// 
//        if (salary != employee.salary) {
//            return false;
//        }
// 
//        if (name != null ? !name.equals(employee.name) : employee.name != null) {
//            return false;
//        }
// 
//        return true;
//    }
// 
//    @Override
//    public int hashCode()
//    {
//        int result = name != null ? name.hashCode() : 0;
//        result = 31 * result + salary;
//        return result;
//    }
    
    @Override
    public boolean equals(Object o) {
    	if(this==o) {
    		return true;
    	}
    	if(o== null ||( getClass() !=o.getClass() )) {
    		return false;
    	}
    	Employee employee=(Employee)o;
    	if(name!=employee.name ) {
    		return false;
    	}
    	if(salary!=employee.salary)
    	return false;
    	
    	return true;
    }
    
    @Override
    public int hashCode() {
    	int result =name!=null ? name.hashCode():0;
    	
    	//int hash =name.hashCode();
    	result = result*31 +salary;
    	return result;
    }
    
    
}


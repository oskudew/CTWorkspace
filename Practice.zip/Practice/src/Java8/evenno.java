package Java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class evenno {
	
	public static evenno singleton=null;
	
	private evenno() {
		
	}
	
	public evenno meth() {
		if(this==singleton) {
			return singleton;
		}
		else {return singleton=new evenno();
		     
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,2,3,4,5,6,7};
		int sum=9;
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]+arr[j]==sum) {
					System.out.println(arr[i]+"-"+arr[j]);
				}
			}
		}
		
//		List<Integer> l = new ArrayList<Integer>();
//		for(int i=0;i< arr.length;i++) {
//			l.add(arr[i]);
//		}
		
		//System.out.println(l.stream().filter(i->i%2==0).collect(Collectors.toList()));
		
		

	}

}

package com.citiustech.fastplus.adapter.functional;

import com.citiustech.fastplus.adapter.structure.JsonProjectionRow;
import org.springframework.jdbc.core.RowMapper;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JsonProjectionFunction implements RowMapper<JsonProjectionRow> {

    @Override
    public JsonProjectionRow mapRow(ResultSet resultSet, int index) throws SQLException {
        return new JsonProjectionRow((Serializable)resultSet.getObject(1),
                 resultSet.getString(2));
    }
}

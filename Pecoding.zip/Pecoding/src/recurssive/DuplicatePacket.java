package recurssive;

import java.util.Scanner;
import java.util.Stack;

public class DuplicatePacket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		
		System.out.println(check(s));
		
		
		

	}
	
	public static boolean check(String s) {
		
		Stack<Character> stack= new Stack<Character>();
		
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)!=')') {
				stack.push(s.charAt(i));
			}
			else{
				int k=0;
				while(stack.peek()!='(') {
					stack.pop();
					k++;
				}
				if(s.charAt(i)=='(') {
					stack.pop();
				}
				if(k==0) {
					return true;
				}
			}
		
		}
		
		return false;
		
		
	}

}

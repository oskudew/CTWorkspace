package recurssive;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class LargestAreaHistogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
				Scanner sc = new Scanner(System.in);
				int a = sc.nextInt();
				int[] arr= new int[a];
				
				for(int i =0;i<arr.length;i++) {
					arr[i]=sc.nextInt();
				}
				
				int[] ld = new int[a];
				int[] rd= new int[a];
				
				Stack<Integer> s1= new Stack<>();
				Stack<Integer> s2 = new Stack<>();
				
				rd[0]=-1;
				ld[a-1]=a;
				for(int i=a-2;i>=0;i--) {
					while(s1.size()>0 && arr[i]<=arr[s1.peek()]) {
						s1.pop();
					}
					if(s1.size()>0) {
						ld[i]=s1.peek();
					}
					else {
						ld[i]=a;
					}
					s1.push(i);
				}
				for(int i=1;i<a;i++) {
					while(s2.size()>0 && arr[i]<=arr[s2.peek()]) {
						s2.pop();
					}
					if(s2.size()>0) {
						rd[i]=s2.peek();
					}
					else {
						rd[i]=-1;
					}
					s2.push(i);
				}
				System.out.println(Arrays.toString(ld));
				System.out.println(Arrays.toString(rd));
				int max=0;
				for(int i=0;i<a;i++) {
					int temp = ld[i]-(rd[i])-1;
					System.out.println("temp->"+i +" "+temp);
					int area=arr[i]*temp;
					if(area>max) {
						max=area;
					}
				}
				
			System.out.println(max);	
				

	}

}

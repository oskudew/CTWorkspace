package secondlvlcascade;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import map.Question;



public class secCascade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		
		Session s1= sf.openSession();
		Question q1 =(Question)s1.get(Question.class, 101);
		System.out.println(q1.getQuestion_id() + ": "+ q1.getQuestion());
		s1.close();
		
		Session s2 = sf.openSession();
		Question q2 =(Question)s2.get(Question.class, 101);
		System.out.println(q2.getQuestion_id() + ": "+ q2.getQuestion());
		s2.close();
		
		sf.close();
		

	}

}

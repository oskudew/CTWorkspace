package leetcode;

import java.util.ArrayList;

public class largestSumAfterKNegations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] strs= {"flower","flow","ight"};
		 int min=200;
	        for(int i=0; i<strs.length;i++){
	            if(min>strs[i].length()){
	                min=strs[i].length();
	            }
	        }
	        ///min=4
	        boolean flag=false;
	        char c;
	        int i=0;
	        for(i=0;i<min;i++){
	            c=strs[0].charAt(i);
	            for(int j=1;j< strs.length;j++){
	                if(c!=strs[j].charAt(i)){
	                    flag=true;
	                    break;
	            }     
	            
	        }
	             if(flag){
	                    break;
	                }
	        }
	        System.out.println(strs[0].substring(0,i));
	    

	}

}

package com.citiustech.fastplus.model.trace;

import java.time.ZonedDateTime;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * This is a class for TraceEvent used to hold entries for trace event
 * 
 */

@Getter
@Setter
@ToString
public class TraceEvent {

    
    /**
	 * This is a timestamp field used to hold current time stamp value
	 */
    private ZonedDateTime timestamp;
    
    /**
	 * This is a remoteAddress field used to hold address of remote
	 */
    private String remoteAddress;
    
    /**
	 * This is a application field used to hold application information
	 */
    private String application;
    
    /**
	 * This is a httpMethod field used to hold type of httpMethod
	 */
    private String httpMethod;
    
    /**
	 * This is a httpStatus field used to hold httpStatus information
	 */
    private String httpStatus;
    
    /**
	 * This is a responseTime field used to hold time taken for response
	 */
    private Integer responseTime;
    
    /**
	 * This is a responseSize field used to hold size of response
	 */
    private Integer responseSize;

}

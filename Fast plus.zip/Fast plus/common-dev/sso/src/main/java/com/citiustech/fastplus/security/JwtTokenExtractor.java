package com.citiustech.fastplus.security;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.exception.SsoException;
import com.citiustech.fastplus.identityprovider.IdentityProviderAccessTokenExtractor;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;

/**
 * 
 * This is a class for JwtTokenExtractor provides methods to process and extract
 * required information from JWT token
 *
 */

@Component
public class JwtTokenExtractor {

	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(JwtTokenExtractor.class.getName());

	/**
	 * This is a applicationContext field used to hold IOC container
	 */
	@Autowired
	ApplicationContext applicationContext;

	/**
	 * returns tokenExtractor through IdentityProviderAccess interface if there no
	 * bean for tokenExtractor then its returns no bean found for tokenExtractor
	 * otherwise it will give a bean found for token extractor
	 * 
	 * @return IdentityProviderAccessTokenExtractor
	 * @throws SsoException
	 */
	private IdentityProviderAccessTokenExtractor getExtractor() {
		IdentityProviderAccessTokenExtractor extractor = null;
		if (null != applicationContext && applicationContext.containsBean("tokenExtractor")) {
			extractor = (IdentityProviderAccessTokenExtractor) applicationContext.getBean("tokenExtractor");
		} else {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"No Bean found for qualifier token extractor.");
			throw new SsoException("No Bean found for qualifier token extractor.");
		}
		return extractor;
	}

	/**
	 * returns authentication token from authentication
	 * 
	 * @return JwtAuthenticationToken
	 * @throws SsoException
	 */
	private JwtAuthenticationToken getAuthentication() {
		JwtAuthenticationToken jwtAuthenticationToken = null;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (null != authentication) {
			jwtAuthenticationToken = (JwtAuthenticationToken) authentication;
		} else {
			throw new SsoException("Request not authenticated, hence no authentication available.");
		}
		return jwtAuthenticationToken;
	}

	/**
	 * returns a authentication JWT token
	 * 
	 * @return Jwt
	 */
	private Jwt getJwtToken() {
		return getAuthentication().getToken();
	}

	/**
	 * returns preferred user name by extracting it from JWT token
	 * 
	 * @return String
	 * @throws SsoException
	 */
	public String getUserName() {
		return getExtractor().getPreferredUsername(getJwtToken());
	}

	/**
	 * returns set of user roles
	 * 
	 * @return set of string
	 * @throws SsoException
	 */
	public Set<String> getUserRoles() {
		return new HashSet<>(getExtractor().getRoles(getJwtToken()));
	}

	/**
	 * returns issued for information
	 * 
	 * @return String
	 * @throws SsoException
	 */
	public String getIssuedFor() {
		return getExtractor().getIssuedFor(getJwtToken());
	}

	public Map<String, Object> getUserAttributes() {

		Map<String, Object> attributesMap = getExtractor().getUserAttributes(getJwtToken());
		if (Objects.isNull(attributesMap)) {
			throw new SsoException("No user attributes present");
		}

		return attributesMap;
	}

	public Object getUserAttribute(String attributeKey) {
		return getUserAttributes().get(attributeKey);
	}
	
	public Object getClaimByKey(String key) {
		return getExtractor().getClaimByKey(key, getJwtToken());
	}

}

package com.citiustech.fastplus.mapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hl7.fhir.exceptions.FHIRException;
import org.hl7.fhir.r4.model.Address;
import org.hl7.fhir.r4.model.BooleanType;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.ContactPoint;
import org.hl7.fhir.r4.model.Enumerations;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.UriType;
import org.hl7.fhir.r5.utils.EOperationOutcome;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.service.PrefixMapping;
import com.citiustech.fastplus.validator.FHIRValidator;

import ca.uhn.fhir.context.FhirContext;
@Component
public class PatientResourceMapper extends AbstractResourceMapper {

	
	@Autowired
	@Qualifier("USCoreValidator")
	private FHIRValidator fhirValidator; 
	
	@Autowired
	private FhirContext fhirContext;
	
	public static final String FHIR_DEFAULT_BASE_URL = "https://example.com/base/";
	
	@Override
    public Bundle map(Object document) {

		List<Resource> resources = new ArrayList<>();
		String[] practitionerPaths = {"WoundExpertDocument.WoundCarePhysician","WoundExpertDocument.ReferringPhysician",
				"WoundExpertDocument.PrimaryCarePhysician",
				"WoundExpertDocument.SupervisingPhysician","WoundExpertDocument.ThirdProvider"};
        Patient patient = new Patient();

        patient.setId( PrefixMapping.PATIENT.getPrefix()+ extractString(document, "$.WoundExpertDocument.PatientNumber"));
        patient.setMeta(extractMeta(document));

        patient.setName(getName(document));
        patient.setGender(Enumerations.AdministrativeGender.fromCode(extractGender(document, "$.WoundExpertDocument.Gender")));
        String [] addressPath = {"WoundExpertDocument.Address","WoundExpertDocument.SecondaryAddress"};
        patient.setAddress(getAddress(document,addressPath));
        String [] phoneNumberPath = {"WoundExpertDocument.PhoneNumber","WoundExpertDocument.SecondaryPhoneNumber"};
        patient.setTelecom(getTelecom(document,phoneNumberPath));
        patient.setContact(getContact(document));
        patient.setGeneralPractitioner(getGeneralPractitioner(document,practitionerPaths));
        patient.setBirthDate(extractDate(document, "$.DateOfBirth"));
        patient.setExtension(getRaceExtension(document));
        if(checkIfValuePresent(document, "$.WoundExpertDocument.IsDeceased"))
            patient.setDeceased(new BooleanType(extractBoolean(document, "$.WoundExpertDocument.IsDeceased")));

        resources.add(patient);
        //RelatedPerson

        List<ContactPoint> contacts = new ArrayList<>();
        Object conDoc = extractValue(document, "$.WoundExpertDocument.AuthorizedRepresentatives");
        contacts = getTelecom(conDoc,"AuthorizedRepresentative.PhoneNumber");

        RelatedPerson relatedPerson = new RelatedPerson();
        relatedPerson.setId( PrefixMapping.RELATEDPERSON.getPrefix() +extractString(document, "$.WoundExpertDocument.PatientNumber"));
        relatedPerson.setAddress(getAddress(conDoc,"AuthorizedRepresentative.Address"));
        relatedPerson.setTelecom(contacts);
        List<HumanName> humanNames = new ArrayList<>();
        humanNames.add(new HumanName()
                .addGiven(extractString(conDoc, "$.AuthorizedRepresentative.FirstName"))
                .setFamily(extractString(conDoc, "$.AuthorizedRepresentative.LastName")));
        relatedPerson.setName(humanNames);
        relatedPerson.setPatient(new Reference(ResourceType.Patient.name()+"/"+patient.getId()));
        
        
        CodeableConcept codeableConcept = new CodeableConcept();
        codeableConcept.setText(extractString(conDoc, "$.AuthorizedRepresentative.Relationship"));
        relatedPerson.addRelationship(codeableConcept);
        resources.add(relatedPerson);

        //Practitioner

        List<Practitioner> practitioners = new ArrayList<>();
        practitioners = getAllPractitioner(document,practitionerPaths);
        resources.addAll(practitioners);
        
        List<PractitionerRole> practitionerRoles  = new ArrayList<>();
        practitionerRoles = getPractitionerRoles(document,practitionerPaths);
        resources.addAll(practitionerRoles);

        return createBundle(resources);
    }

   /* public Patient mapForPatient(Object document) {
        *//*String[] practitionerPaths = {"generalpractitioner"};
        Patient patient = new Patient();

        patient.setId(extractString(document, "$.patientid"));
        System.out.println("Oshankkd------>");
        patient.setMeta(extractMeta(document));

        patient.setName(getName(document));
        patient.setGender(Enumerations.AdministrativeGender.fromCode(extractGender(document, "$.gender")));
        String [] addressPath = {"address"};
        patient.setAddress(getAddress(document,addressPath));
        String [] phoneNumberPath = {"telecom"};
        patient.setTelecom(getTelecom(document,phoneNumberPath));
        patient.setContact(getContact(document));
        patient.setGeneralPractitioner(getGeneralPractitioner(document,practitionerPaths));
        patient.setBirthDate(extractDate(document, "$.DateOfBirth"));
        patient.setExtension(getRaceExtension(document));
       //if(checkIfValuePresent(document, "$.WoundExpertDocument.IsDeceased"))
           // patient.setDeceased(getDeceased());

        return patient;*//*
    }*/

    private List<Practitioner> getAllPractitioner(Object document, String[] practitionerPaths) {
        List<Practitioner> practitioners = new ArrayList<>();

        for (String path:practitionerPaths) {
            Object conDoc = extractValue(document, "$."+path);
            
            String practid =  extractString(conDoc, "$.ID");
            if(!StringUtils.isNotBlank(practid)){
            	continue;
            }
            Practitioner practitioner = new Practitioner();
            List<HumanName> practitionerHumanNames = new ArrayList<>();
            practitionerHumanNames.add(new HumanName()
                    .addGiven(extractString(conDoc, "$.FirstName"))
                    .setFamily(extractString(conDoc, "$.LastName")));
            practitioner.setName(practitionerHumanNames);
            practitioner.setId(PrefixMapping.PRACTITIONER.getPrefix() +practid);

            practitioners.add(practitioner);
        }
        return  practitioners;

    }

	private List<PractitionerRole> getPractitionerRoles(Object document, String[] practitionerPaths) {
    	List<PractitionerRole> practitionerRoles = new ArrayList<>();
    	
    	for (String path:practitionerPaths) {
    		if(path.contains("PrimaryCarePhysician")) {
    			PractitionerRole practitionerRole = new PractitionerRole();
    			List<CodeableConcept> codeableConcepts = new ArrayList<>();
    			CodeableConcept codeableConcept = new CodeableConcept();
    			Coding coding = new Coding("http://snomed.info/sct", "446050000", "PCP - Primary care physician");
    			codeableConcept.setCoding(Arrays.asList(coding));
    			codeableConcepts.add(codeableConcept);
    			practitionerRole.setCode(codeableConcepts);
    			String [] practPath = {path};
    			practitionerRole.setPractitioner(getGeneralPractitioner(document,
    					practPath).get(0));
    			practitionerRoles.add(practitionerRole);
    		}else {
    			continue;
    		}
    		
    	
    	}
    	return  practitionerRoles;
    	
    }

    private List<Extension> getRaceExtension(Object document) {
        List<Extension> extensionsParent = new ArrayList<Extension>();
        List<Extension> extensions = new ArrayList<Extension>();

        String[] raceLists = new String[]{"$.WoundExpertDocument.raceList.string",
                "$.WoundExpertDocument.SecondaryRaceList.string"};
        String[] raceCodes = new String[]{"$.WoundExpertDocument.RaceCdcCodes.string",
                "$.WoundExpertDocument.SecondaryRaceCdcCodes.string"};
        Extension extensionRace = new Extension();
        extensionRace.setUrl("http://hl7.org/fhir/us/core/StructureDefinition/us-core-race");
        extensionRace.setExtension(extensions);
        extensionsParent.add(extensionRace);
        Extension extensionText = new Extension();
        extensionText.setUrl("text");
        extensionText.setValue(new StringType(extractString(document, raceLists[0])));
        extensions.add(extensionText);
        
        for(int i=0; i<=raceLists.length-1;i++){
            Extension extension = new Extension();
            extension.setUrl("ombCategory");
            Coding coding = new Coding();
            coding.setDisplay(extractString(document, raceLists[i]));
            coding.setCode(extractString(document, raceCodes[i]));
            extension.setValue(coding);
            extensions.add(extension);
        }
        return extensionsParent;
    }

    private String extractGender(Object document, String jsonPath) {
        String genderString = extractString(document,jsonPath);
        if (genderString != null && !"".equals(genderString)) {
            if ("M".equals(genderString)) {
                return "male";
            } else if ("F".equals(genderString)) {
                return "female";
            } else if ("O".equals(genderString)) {
                return "other";
            } else if ("U".equals(genderString)) {
                return "unknown";
            } else {
                throw new FHIRException("Unknown AdministrativeGender code '" + genderString + "'");
            }
        } else {
            return null;
        }

    }

    public List<Patient.PatientLinkComponent> extractLinkComponent(Object document, String jsonPath){
        List<Patient.PatientLinkComponent> list = new ArrayList<Patient.PatientLinkComponent>();
        int length = length(document, jsonPath+".length()");
        for(int i=0; i< length; i++) {
            Patient.PatientLinkComponent obj = new Patient.PatientLinkComponent();
            obj.setOther(extractReference(document, jsonPath+"[" + i + "].other.reference"));
            obj.setType(Patient.LinkType.fromCode(extractString(document, jsonPath+"[" + i + "].type")));
            list.add(obj);
        }
        return list;
    }


    public List<Address> getAddress(Object document,String ... jsonPaths) {
//        String [] addressPath = {"WoundExpertDocument.Address","WoundExpertDocument.SecondaryAddress"};
        String [] addressPath = jsonPaths;

        List<Address> addresses = new ArrayList<>();
        for (String currentAddress: addressPath) {
            Object addDoc = extractValue(document, "$."+currentAddress);

            Address address = new Address()
                    .addLine(extractString(addDoc, "$.AddressLine1"))
                    .addLine(extractString(addDoc, "$.AddressLine2"))
                    .setCity(extractString(addDoc, "$.City"))
                    .setState(extractString(addDoc, "$.State"))
                    .setCountry(extractString(addDoc, "$.Country"))
                    .setDistrict(extractString(addDoc, "$.County"))
                    .setPostalCode(extractString(addDoc, "$.ZipCode"));

            addresses.add(address);
        }
        return addresses;
    }

    private List<Reference> getGeneralPractitioner(Object document, String[] practitionerPaths) {
        List<Reference> refs = new ArrayList<>();

        for (String path:practitionerPaths) {
            Object conDoc = extractValue(document, "$."+path);
            
            String practid = extractString(conDoc, "$.ID");
            if(!StringUtils.isNotBlank(practid)){
            	continue;
            }       
            refs.add(new Reference(ResourceType.Practitioner.name()+"/"+
            PrefixMapping.PRACTITIONER.getPrefix()+practid));
        }
        return refs;
    }

    private List<Patient.ContactComponent> getContact(Object document) {
        List<Patient.ContactComponent> components = new ArrayList<>();
//        Object conDoc = extractValue(document, "$.WoundExpertDocument.AuthorizedRepresentatives");
//        Patient.ContactComponent contact = new Patient.ContactComponent();
//        contact.setName(new HumanName()
//                .addGiven(extractString(conDoc, "$.AuthorizedRepresentative.FirstName"))
//                .setFamily(extractString(conDoc, "$.AuthorizedRepresentative.LastName")));
//        CodeableConcept codeableConcept = new CodeableConcept();
//        codeableConcept.setText(extractString(conDoc, "$.AuthorizedRepresentative.Relationship"));
//        contact.addRelationship(codeableConcept);
//
//        List<ContactPoint> contacts = new ArrayList<>();
//        contacts = getTelecom(conDoc,"AuthorizedRepresentative.PhoneNumber");
//        contact.setTelecom(contacts);
//
//        List<Address> addresses = getAddress(conDoc,"AuthorizedRepresentative.Address");
//
//        contact.setAddress(addresses.get(0));
//        components.add(contact);

        Patient.ContactComponent emcontact = new Patient.ContactComponent();
        emcontact.setName(new HumanName()
                .addGiven(extractString(document, "$.WoundExpertDocument.EmergencyContact.FirstName"))
                .setFamily(extractString(document, "$.WoundExpertDocument.EmergencyContact.LastName")));
        CodeableConcept emCodeableConcept = new CodeableConcept();
        emCodeableConcept.setText(extractString(document, "$.WoundExpertDocument.EmergencyContactRelationship"));
        emcontact.addRelationship(emCodeableConcept);

        List<ContactPoint> emContacts = new ArrayList<>();
        emContacts = getTelecom(document,"WoundExpertDocument.EmergencyContact");
        emcontact.setTelecom(emContacts);

        List<Address> emAddresses = getAddress(document,"WoundExpertDocument.EmergencyContactAddress");

        emcontact.setAddress(emAddresses.get(0));
        components.add(emcontact);

        return components;
    }

    public List<ContactPoint> getTelecom(Object document, String ... phoneNumberPaths) {

        String [] phoneNumberPath = phoneNumberPaths;

        List<ContactPoint> contacts = new ArrayList<>();

        for (String currentPhoneNumber: phoneNumberPath) {
            Object telDoc = extractValue(document, "$."+currentPhoneNumber);
            ContactPoint cp = new ContactPoint()
                    .setSystem(ContactPoint.ContactPointSystem.PHONE)
                    .setUse(getContactPointUser(telDoc, "$.Type"))
                    .setValue(extractValue(telDoc, "$.Number").toString());

            contacts.add(cp);
        }
        return contacts;
    }

    public List<HumanName> getName(Object document) {
        String firstName = extractString(document, "$.WoundExpertDocument.FirstName");
        String lastName = extractString(document, "$.WoundExpertDocument.LastName");
        String middleName = extractString(document, "$.WoundExpertDocument.MiddleNameFull");


        List<HumanName> names = new ArrayList<>();
        HumanName name = new HumanName();
        name.setFamily(lastName);
        name.addGiven(firstName);
        name.addGiven(middleName);
        names.add(name);

        return names;
    }


    private ContactPoint.ContactPointUse getContactPointUser(Object telDoc, String jsonPath){
        String cpValue = extractString(telDoc, jsonPath);
        if("Home".equalsIgnoreCase(cpValue)){
            return ContactPoint.ContactPointUse.HOME;
        }else if("Cell".equalsIgnoreCase(cpValue)) {
            return ContactPoint.ContactPointUse.MOBILE;
        }
        return  null;
    }

    public Bundle createBundle( List<Resource> resources) {
        //
        Bundle.BundleEntryRequestComponent bundleEntryRequest = new Bundle.BundleEntryRequestComponent();
//        bundleEntryRequest.setMethod(Bundle.HTTPVerb.POST);
//        bundleEntryRequest.setUrl("http://localhost:8888/mapper");
        //

        Bundle bundle = new Bundle();
        bundle.setType(Bundle.BundleType.SEARCHSET);

        for (Resource resource:resources) {
        	validateEachResource(resource);
            Bundle.BundleEntryComponent entryComponent = new Bundle.BundleEntryComponent();
            entryComponent.setResource(resource);
            entryComponent.setFullUrlElement(new UriType(FHIR_DEFAULT_BASE_URL + resource.getId()));
            entryComponent.setRequest(bundleEntryRequest);
            bundle.addEntry(entryComponent);

        }

        //
        return bundle;
    }

    
    void validateEachResource(Resource resource)  {
    	 String resourceString = fhirContext.newJsonParser().encodeResourceToString(resource);
    	try {
    		fhirValidator.validate(resourceString);
    	} catch (IOException | EOperationOutcome e) {
//    		throw new Exception("RESOURCE_VALIDATION_FAILED"+e);
    		System.out.println("Excpetion while validating the resource: "+ e);
    	}
    }
}

package com.citiustech.fastplus.util.exception;

/**
 * 
 * This is a FHIRException class used as custom exception for exception handling 
 * 
 */

public class FHIRException extends RuntimeException {
	
	/**
	 * This is a serialVersionUID field used to assign serial version uid to this
	 * class
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * No arguments constructor
	 */
	public FHIRException() {
		super();
	}

	/**
	 * Parameterized constructor
	 * 
	 * @param errorMessage
	 */
	public FHIRException(String errorMessage) {
		super(errorMessage);
	}
	
	/**
	 * Parameterized constructor
	 * 
	 * @param message
	 * @param throwable
	 */
	public FHIRException(String message, Throwable throwable) {
        super(message, throwable);
    }

	/**
	 * Parameterized constructor
	 * 
	 * @param throwable
	 */
    public FHIRException(Throwable throwable) {
        super(throwable);
    }
}

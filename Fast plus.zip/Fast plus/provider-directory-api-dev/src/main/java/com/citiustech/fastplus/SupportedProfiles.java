package com.citiustech.fastplus;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.Map;

/**
 * 
 * This is the configuration class to read
 * the supported profiles from the property file.
 *
 */
@Configuration
@PropertySource("classpath:supportedprofiles.properties")
@ConfigurationProperties(prefix = "fhir")
public class SupportedProfiles {

	/**
	 * The field supportedProfiles will have the
	 * values of profile and its URL both in String format
	 */
	private Map<String, String> supportedProfile;

	public Map<String, String> getSupportedProfile() {
		return supportedProfile;
	}

	public void setSupportedProfile(Map<String, String> supportedProfile) {
		this.supportedProfile = supportedProfile;
	}

}

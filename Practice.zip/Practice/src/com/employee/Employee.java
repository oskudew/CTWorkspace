package com.employee;

public class Employee {
	
	private int id;
	private String name;
	private String deptName;
	
	
	public Employee(int id, String name, String deptName) {
		super();
		this.id = id;
		this.name = name;
		this.deptName = deptName;
	}
	
	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	/*
	 * public Employee(int id, String name) { super(); this.id = id; this.name =
	 * name; }
	 */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int hashCode() {
		
		int result = (name!=null)?name.hashCode():0;
		result=result*32+id;
		
		return result;
	}
	
	@Override
	public boolean equals(Object o) {
		if(this==o)
		return true;
		
		if(o==null|| getClass()!=this.getClass()) return false;
		
		Employee emp =(Employee)o;
		if(emp.id!=this.id) return false;
			if( !emp.name.equals(this.name)) return false;
		
		
		return true;
		
	}

}

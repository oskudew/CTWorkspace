package com.citiustech.fastplus.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="resource_info")
public class ResourceInfo {

	@Id
	@Column
	private Integer id;
	
	@Column
	private String resourceText;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getResourceText() {
		return resourceText;
	}

	public void setResourceText(String resourceText) {
		this.resourceText = resourceText;
	}
	
	

	public ResourceInfo() {
		super();
	}

	public ResourceInfo(Integer id, String resourceText) {
		super();
		this.id = id;
		this.resourceText = resourceText;
	}
	
	
	
	
}

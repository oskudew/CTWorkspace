import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Dice {

	
	public String result(String str) {
		
		
		str = str.replace("|"," ");
		String[] arr = str.split(" "); 
		int[] a = new int[arr.length];
		for(int i=0;i<arr.length;i++) {
			a[i]=Integer.parseInt(arr[i]);
		}
		String append=check(a);
		int value=a[0]+a[1];
		if(a[0] + a[1] ==7 || a[0] + a[1]==11) return "natural" + append;
		
		else if(value==2 || value ==3 || value ==12) return "craps" + append;
		else {
		for(int i=2;i<arr.length-1;i++) { 
			
			int sum =a[i]+ a[++i];
				//return (sum ==7 ? "seven out" + append : sum == value ? "markpoint"+ append:""+append);
			if(sum==7) {
				return "seven out" + append;
			}
			if(sum==value) return "markpoint" +append;
			}
		}
		return ""+ append; 
	}


	public String check(int[] arr) {

		List<Integer> l = new ArrayList<Integer>();
		int[] in1 = { 4, 5, 6, 8, 9, 10 };
		List l1 = Arrays.asList(in1);

		for (int i = 0, k = 0; i < arr.length - 1; i++) {
			l.add(arr[i] + arr[++i]);
			//System.out.println(l.get(k++));
		}
		if (l.contains(4) && l.contains(5) && l.contains(6) && l.contains(8) && l.contains(9) && l.contains(10)) {
			//System.out.println("aryu");
			return "covered";
		}

		return " ";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dice d = new Dice();
		System.out.println(d.result("6|4|2|2|2|3|3|3|4|4"));
		//int[] arr = { 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 1, 3 };
	//	System.out.println(d.check(arr));

	}

}

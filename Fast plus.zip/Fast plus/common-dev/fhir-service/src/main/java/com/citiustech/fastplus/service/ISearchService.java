package com.citiustech.fastplus.service;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.util.exception.SearchServiceException;
import org.hl7.fhir.instance.model.api.IBaseResource;

import java.util.List;

/**
 * 
 * This is an interface for SearchService defines methods to perform operation
 * on a resource
 * 
 */
public interface ISearchService {

	/**
	 * returns list of resource ids based of resource type and search parameters
	 * 
	 * @param resourceType
	 * @param searchParameterMap
	 * @return list
	 * @throws SearchServiceException
	 */
    List<IdProjectionRow> findResourceIds(String resourceType, SearchParameterRequest searchParameterMap);

    /**
     * 
     * 
     * @param resourceId
     * @param resourceType
     * @return resource
     * @throws SearchServiceException
     */
    IBaseResource getResource(String resourceId, String resourceType);

    /**
     * returns resources based on list of input identifiers
     * 
     * @param listOfResourceIds
     * @return list of resources
     * @throws SearchServiceException
     */
    List<IBaseResource> getResourcesByIds(SearchResult listOfResourceIds);
    /**
     * returns resource ids for a resource based on resource type, search
	 * parameters and offset
	 * 
     * @param resourceType
     * @param searchParameterReq
     * @return list
     */
	List<IdProjectionRow> getPaginatedIdsForResource(String resourceType, SearchParameterRequest searchParameterReq);

}

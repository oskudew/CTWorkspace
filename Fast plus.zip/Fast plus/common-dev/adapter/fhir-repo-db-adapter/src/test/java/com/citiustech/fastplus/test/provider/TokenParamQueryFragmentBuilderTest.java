package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.TokenParam;

@ExtendWith(MockitoExtension.class)
class TokenParamQueryFragmentBuilderTest {
	
	@InjectMocks
	static TokenParamQueryFragmentBuilder tokenParamQueryFragmentBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
	private static CommonQueryUtil commonQueryUtil;
	    
	@Spy
	private static FHIRErrorHandler fhirErrorHandler;
	
	String resourceTypeAlias = "OrganizationtooL";
	String resourceType = ResourceType.Organization.name();
	String paramName = Organization.SP_TYPE;
	String system = "http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/OrgTypeCS";
	String value = "ntwk";
	
	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,FHIRRepositoryTableConfiguration.class);
		fhirRepositoryTableConfiguration.duplicateTypeMap();
		tokenParamQueryFragmentBuilder = new TokenParamQueryFragmentBuilder(
                 fhirRepositoryTableConfiguration,commonQueryUtil,fhirErrorHandler);
		 
	}

	FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
            fhirRepositoryTableConfiguration, resourceType);
	
	@DisplayName("Test case for token param on frameQueryFragment where system and value are true")
	@Test
	void test_frameQueryFragment() {
		
		TokenParam paramType = new TokenParam(system,value);
		
		queryBuilder.setParamType(ParamType.TOKEN);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getSystem(), false);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getValue(), false);
		
		Condition actualValue = tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("((OrganizationtooL.attribute = 'type') AND (OrganizationtooL.system = 'http://hl7.org/fhir/us/davinci-pdex-plan-net/CodeSystem/OrgTypeCS')) AND (OrganizationtooL.code = 'ntwk')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	
	@DisplayName("Test case for token param on frameQueryFragment for id param")
	@Test
	void test_frameQueryFragmentForIdParam() {
		String paramName = IAnyResource.SP_RES_ID;
		String value = "Kern-coveragetest";
		TokenParam paramType = new TokenParam(value);
		queryBuilder.setParamType(ParamType.TOKEN);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getSystem(), false);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getValue(), false);
		
		when(commonQueryUtil.findPrefixValue(resourceType, paramType.getValue())).thenReturn(value);
		
		Condition actualValue = tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(OrganizationtooL.attribute = '_id') AND (OrganizationtooL.code = 'Kern-coveragetest')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for token param on frameQueryFragment where system and value are empty and FHIRException occurs")
	@Test
	void test_frameQueryFragmentForException() {
		TokenParam paramType = new TokenParam();
		queryBuilder.setParamType(ParamType.TOKEN);
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> tokenParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName));
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());
		
	}
	
}

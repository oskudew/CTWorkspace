package com.citiustech.fastplus.r4.resource.provider;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.ListResource;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.OptionalParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

/**
 * 
 * This is a class for CoveragePlan resource provider used to serve all
 * supported read and search parameter requests for CoveragePlan resource
 * 
 */

@Component
public class CoveragePlanResourceProvider implements IResourceProvider {

	/**
	 * This is a service instance field used to call methods from service layer
	 */
	private static final Logging logger = LoggerFactory.getLogger(CoveragePlanResourceProvider.class.getName());

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;

	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return ListResource.class;
	}

	/**
	 * returns CoveragePlan resource based on the provider id
	 * 
	 * @param pId
	 * @return single CoveragePlan resource
	 * @throws Exception
	 */
	@Read
	public IBaseResource getResourceById(@IdParam IdType pId) {
		logger.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Read operation for id " + pId.getIdPart());
		return service.getResourceById(pId.getIdPart(), ResourceType.List.name());
	}

	/**
	 * returns the bundle of resources based on the search parameters passed in the
	 * request
	 * 
	 * @param id
	 * @return bundle resource of CoveragePlan resources
	 * @throws Exception
	 */
	@Search
	public IBundleProvider getResourcesByParam(@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam id,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdatedDate) {
		
		SearchParameterRequest searchMap = new SearchParameterRequest();
		searchMap.add(IAnyResource.SP_RES_ID, id);
		searchMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdatedDate);

		logger.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Search operation for parameters " + searchMap.toString());
		return service.getResources(searchMap, ResourceType.List.name());
	}

}

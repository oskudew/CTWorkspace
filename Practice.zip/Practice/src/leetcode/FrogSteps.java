package leetcode;

import java.util.Arrays;

public class FrogSteps {
	public static int solution(int [] blocks) {
		int size=blocks.length;
		int[] left = new int[size];
		int[] right= new int[size];
		
		int i=1;
		left[0]=0;
		while(i<size) {//3--.0,0,0,1,
			if(blocks[i]>=blocks[i-1]) {
				left[i]=left[i-1]+1; 
			}
			else left[i]=0;
			i++;
		}
		right[size-1]=0;
		int j=size-2;//2
		while(j>=0) {//0,
			if(blocks[j]>=blocks[j+1]) {
				right[j]=right[j+1]+1;
			}
			else right[j]=0;
			j--;
		}
		
		int max=0;
		System.out.println(Arrays.toString(left));
		System.out.println(Arrays.toString(right));
		
		for(int k=0;k<size;k++) {
			max=Math.max(max, left[k]+right[k]+1);
		}
		return max;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		int[] a = {2,4,4,5,2,2,3,4,5,6,7,8};
		System.out.println(solution(a));

	}

}

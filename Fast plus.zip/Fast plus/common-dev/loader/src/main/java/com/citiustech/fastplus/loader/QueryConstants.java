package com.citiustech.fastplus.loader;

public final class QueryConstants {
	
	private QueryConstants() {

	}

	public static final String INSERTINTO = "insert into ";
	public static final String DELETEFROM = "delete from ";
	
	public static final String PROVENANCE = "provenance";
	
	public static final String RESOURCEINFO = "resourceinfo";
	public static final String RESOURCEINFO_PROVENANCE = "resourceinfo_provenance";
	
	public static final String RESOURCELINK = "resourcelink";
	public static final String RESOURCELINK_PROVENANCE = "resourcelink_provenance";

	public static final String SUBSCRIPTION_INFO_TABLE = "subscriptioninfo";
	public static final String SUBSCRIPTION_LINK_TABLE = "subscriptionlink";
	public static final String SUBSCRIPTION_DETAILS_TABLE = "subscription_details";
	public static final String SUBSCRIBED_PATIENT_TABLE = "subscribed_patient";
	public static final String SUBSCRIPTION_RESOURCE_TABLE = "subscribed_resource";
	public static final String SUBSCRIBED_CHANNEL_TABLE = "subscribed_channel";
	public static final String SUBSCRIPTION_RESOURCE_NAME = "Subscription";
	
	
	public static final String RESOURCE_TABLE_QUERY = new StringBuilder("(id, lastUpdated) values (?,current_timestamp)").toString();
	
	public static final String RESOURCEINFO_TABLE_QUERY = new StringBuilder
			("(id, resourcetype, resourcetext, createdtime, updatedtime) values (?,?,to_json(?::JSON),current_timestamp, current_timestamp)").toString();
	
	public static final String RESOURCELINK_TABLE_QUERY = new StringBuilder
			("(srcid, srctype, trgtid, trgttype, attribute,lastupdated) values (?,?,?,?,?,current_timestamp)").toString();
	
	public static final String SEARCH_TABLE_QUERY = new StringBuilder
	("search(id,datatype,system,code,value,unit,startdate,enddate,attribute, patient_id, trgttype ,lastupdated) values(?,?,?,?,?,?,cast(? as timestamp ),cast(? as timestamp ),?,?,?,cast(? as timestamp ))").toString();
	
	public static final String GET_SUBSCRIPTION_COUNT = new StringBuilder
			("SELECT COUNT(*) from subscription_details where subscriptionid=?").toString();
	
	public static final String SUBSCRIPTION_DETAILS_INSERT_QUERY = new StringBuilder(INSERTINTO).append(SUBSCRIPTION_DETAILS_TABLE)
			.append("(subscription_name, subscriptionid, valid_from, valid_to, status,providerid,updated_date) values") 
					.append("(:subscriptionName,:id,cast(:validFrom as timestamp ),cast(:validTo as timestamp ),:status,:providerId,current_timestamp)").toString();
	
	public static final String SUBSCRIPTION_CHANNEL_INSERT_QUERY = new StringBuilder(INSERTINTO).append(SUBSCRIBED_CHANNEL_TABLE)
			.append("(subscriptionid, channel_type, channel_endpoint, channel_key,updated_date) values") 
			.append("(:id,:channelType,:channelendpoint,:channelHeader,current_timestamp)").toString();
	
	public static final String SUBSCRIPTION_PATIENT_INSERT_QUERY = new StringBuilder(INSERTINTO).append(SUBSCRIBED_PATIENT_TABLE)
			.append("(subscriptionid, patientid,updated_date) values") 
			.append("(?,?,current_timestamp)").toString();
	
	public static final String SUBSCRIPTION_RESOURCE_INSERT_QUERY = new StringBuilder(INSERTINTO).append(SUBSCRIPTION_RESOURCE_TABLE)
			.append("(subscriptionid, resource_name,updated_date) values") 
			.append("(?,?,current_timestamp)").toString();
	

}

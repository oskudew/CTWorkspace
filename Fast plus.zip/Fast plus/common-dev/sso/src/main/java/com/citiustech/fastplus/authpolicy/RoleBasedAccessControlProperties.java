package com.citiustech.fastplus.authpolicy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpMethod;
import org.springframework.web.cors.CorsConfiguration;

import com.citiustech.fastplus.identityprovider.AuthorityPrefix;

/**
 * This is a class for RoleBasedAccessControlProperties used to set the
 * properties to all security constraints,patterns,identityProvider and jwkUri
 * 
 */

@Configuration
@PropertySource(value = "classpath:appsecurity.properties")
@ConfigurationProperties(prefix = "app.security", ignoreUnknownFields = false)
public class RoleBasedAccessControlProperties {

	/**
	 * This is a enabled field used to hold boolean value
	 */
	private boolean enabled;

	/**
	 * This is a identityProvider field used to hold identity provider value
	 */
	private String identityProvider;

	/**
	 * This is a publicPatterns field used to hold list of public patterns
	 */
	private List<String> publicPatterns = new ArrayList<>();

	/**
	 * This is a jwksUri field used to hold key store uri
	 */
	private String jwksUri;

	/**
	 * This is a securityConstraints field used to hold constraints
	 */
	private List<SecurityConstraint> securityConstraints = new ArrayList<>();

	/**
	 * returns list of public patterns
	 */

	private String authPolicy="role";
	
	private Cors cors = new Cors();

	public Cors getCors() {
		return cors;
	}

	public void setCors(Cors cors) {
		this.cors = cors;
	}

	public List<String> getPublicPatterns() {
		return publicPatterns;
	}

	/**
	 * sets list of public patterns
	 * 
	 * @param publicPatterns
	 */
	public void setPublicPatterns(List<String> publicPatterns) {
		this.publicPatterns = publicPatterns;
	}

	/**
	 * returns list of security constraints
	 */
	public List<SecurityConstraint> getSecurityConstraints() {
		return securityConstraints;
	}

	/**
	 * sets security constraints
	 * 
	 * @param securityConstraints
	 */
	public void setSecurityConstraints(List<SecurityConstraint> securityConstraints) {
		this.securityConstraints = securityConstraints;
	}

	/**
	 * No arguments constructor
	 */
	public RoleBasedAccessControlProperties() {
		super();
	}

	/**
	 * returns the jwkUri
	 */
	public String getJwksUri() {
		return jwksUri;
	}

	/**
	 * sets jwksuri value
	 * 
	 * @param jwksUri
	 */
	public void setJwksUri(String jwksUri) {
		this.jwksUri = jwksUri;
	}

	/**
	 * returns the IdentityProvider
	 */
	public String getIdentityProvider() {
		return identityProvider;
	}

	/**
	 * sets identity provider
	 * 
	 * @param identityProvider
	 */
	public void setIdentityProvider(String identityProvider) {
		this.identityProvider = identityProvider;
	}

	/**
	 * returns enabled field
	 */
	public boolean isEnabled() {
		return enabled;
	}

	/**
	 * sets value to enable field
	 * 
	 * @param enabled
	 */
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * This is an inner class SecurityConstraint to hold declaring the authRoles and
	 * url patterns for security constraint
	 *
	 */
	@ConfigurationProperties()
	public static class SecurityConstraint {

		/**
		 * This is a patterns field used to hold list of url patterns to protect
		 */
		private List<String> patterns = new ArrayList<>();

		/**
		 * This is a authRoles field used to hold list of authentication roles
		 */
		private List<String> authRoles = new ArrayList<>();

		private List<String> scopes = new ArrayList<>();
		private HttpMethod method;

		/**
		 * returns patterns list
		 */
		public List<String> getPatterns() {
			return patterns;
		}

		/**
		 * sets patters list
		 * 
		 * @param patterns
		 */
		public void setPatterns(List<String> patterns) {
			this.patterns = patterns;
		}

		/**
		 * returns the authentication roles
		 */
		public List<String> getAuthRoles() {
			return authRoles;
		}

		/**
		 * sets list of authRoles
		 * 
		 * @param authRoles
		 */
		public void setAuthRoles(List<String> authRoles) {
			List<String> tempRoles = authRoles;
			if (Objects.nonNull(tempRoles)) {
				tempRoles = tempRoles.stream().map(AuthorityPrefix.ROLE.toString()::concat)
						.collect(Collectors.toList());
			}
			this.authRoles = tempRoles;
		}

		public List<String> getScopes() {
			return scopes;
		}

		public void setScopes(List<String> scopes) {
			List<String> tempScopes = scopes;
			if (Objects.nonNull(tempScopes)) {
				tempScopes = tempScopes.stream().map(AuthorityPrefix.SCOPE.toString()::concat).collect(Collectors.toList());
			}
			this.scopes = tempScopes;
		}

		public HttpMethod getMethod() {
			return method;
		}

		public void setMethod(HttpMethod method) {
			this.method = method;
		}

	}

	@ConfigurationProperties()
	public class Cors {

		private List<String> allowedOrigins = Arrays.asList("*");
		private List<String> allowedMethods = Arrays.asList("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS");
		private List<String> allowedHeaders = Arrays.asList("*");
		private List<String> exposedHeaders;
		private Boolean allowCredentials;
		private Long maxAge = Long.valueOf(3600);

		public List<String> getAllowedOrigins() {
			return allowedOrigins;
		}

		public void setAllowedOrigins(List<String> allowedOrigins) {
			this.allowedOrigins = allowedOrigins;
		}

		public List<String> getAllowedMethods() {
			return allowedMethods;
		}

		public void setAllowedMethods(List<String> allowedMethods) {
			this.allowedMethods = allowedMethods;
		}

		public List<String> getAllowedHeaders() {
			return allowedHeaders;
		}

		public void setAllowedHeaders(List<String> allowedHeaders) {
			this.allowedHeaders = allowedHeaders;
		}

		public List<String> getExposedHeaders() {
			return exposedHeaders;
		}

		public void setExposedHeaders(List<String> exposedHeaders) {
			this.exposedHeaders = exposedHeaders;
		}

		public Boolean getAllowCredentials() {
			return allowCredentials;
		}

		public void setAllowCredentials(Boolean allowCredentials) {
			this.allowCredentials = allowCredentials;
		}

		public Long getMaxAge() {
			return maxAge;
		}

		public void setMaxAge(Long maxAge) {
			this.maxAge = maxAge;
		}
	}

	public CorsConfiguration getCorsConfiguration() {

		CorsConfiguration corsConfiguration = new CorsConfiguration();
		corsConfiguration.setAllowedOrigins(cors.getAllowedOrigins());
		corsConfiguration.setAllowedMethods(cors.getAllowedMethods());
		corsConfiguration.setAllowedHeaders(cors.getAllowedHeaders());
		corsConfiguration.setExposedHeaders(cors.getExposedHeaders());
		corsConfiguration.setAllowCredentials(cors.getAllowCredentials());
		corsConfiguration.setMaxAge(cors.getMaxAge());

		return corsConfiguration;
	}

	public String getAuthPolicy() {
		return authPolicy;
	}

	public void setAuthPolicy(String authPolicy) {
		this.authPolicy = authPolicy;
	}

}

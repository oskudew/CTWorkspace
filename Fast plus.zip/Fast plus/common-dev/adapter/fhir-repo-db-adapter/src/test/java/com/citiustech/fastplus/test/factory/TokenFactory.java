package com.citiustech.fastplus.test.factory;

import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenOrListParam;
import ca.uhn.fhir.rest.param.TokenParam;

public class TokenFactory {

	
	TokenAndListParam  tokenAndListParam = new TokenAndListParam();
	
	TokenOrListParam tokenOrListParam ;
	
	TokenParam tokenParam ;
	
	
	public TokenFactory() {
	
		tokenOrListParam = new TokenOrListParam();
		tokenAndListParam.addAnd(tokenOrListParam);
	}
	
	
	
	public TokenAndListParam newInstance(){
		return tokenAndListParam;
	}
	
	public TokenFactory setReferenceValue(String theValue) {
		tokenParam = new TokenParam(theValue);
		tokenOrListParam.add(tokenParam);
		return this;
	}
	
	public TokenFactory addTokenParam(TokenParam tokenParam) {
		tokenOrListParam.add(tokenParam);
		return this;
	}
	
}

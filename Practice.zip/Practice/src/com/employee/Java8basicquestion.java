package com.employee;

import java.sql.Date;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Java8basicquestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Java 8 Program to Print ten random numbers using forEach?
		 Random r = new Random();
		 r.ints().limit(10).forEach(System.out::println);
		 
		 //Java 8 program to iterate a Stream using the forEach method?
		 List<Integer> l1 = Arrays.asList(9,3,5,7,1,34,4436,45);
		 l1.stream().forEach(System.out::println);
		 
		 //Java 8 program to find the Minimum number of a Stream?
		System.out.println( l1.stream().min(Integer::compare).get());
		
		List<String> l2 = Arrays.asList("shekhar","Abhishek","tarun","ABHISHEK","tarun","shekhar","sakshi","sd","sdc");
		System.out.println(l2.stream().min((i1,i2)->i1.compareTo(i2)).get());
		
		//Java 8 program to find the Maximum number of a Stream?
		
		System.out.println("max integer : "+ l1.stream().max(Comparator.comparing(Integer::valueOf)).get());
		System.out.println("max integer : "+ l1.stream().max(Integer::compare).get());
		
		//string
		System.out.println("max String :"+ l2.stream().max(Comparator.comparing(String::valueOf)).get());
		
		//Java 8 program to Count Strings whose length is greater than 3 in List?
		
		System.out.println("Count whose string is greater than 3: "+ l2.stream().filter(i->i.length()>3).count());
		
		//Java 8 program to Print Strings whose length is greater than 3 in List.
		l2.stream().filter(i->i.length()>3).forEach(System.out::println);
		
		//Java 8 program to multiply 3 to all element in list and print the list?
		l1.stream().map(i->i*3).collect(Collectors.toList()).forEach(System.out::println);
		
		//Java 8 program to perform concatenation on two Streams?
		Stream<String> s1=Stream.of("Oshank");
		Stream<String> s2=Stream.of("Dewangan");
		Stream concate = Stream.concat(s1, s2);
		concate.forEach(System.out::print);
		
		//Java 8 program to remove the duplicate elements from the list?
		
		l2.stream().map(i->i.toLowerCase()).distinct().forEach(System.out::println);
		
		//Print current date and time in Java 8 Date and Time API?
		System.out.println("Date: "+ java.time.LocalDate.now());
		System.out.println("Time: "+ java.time.LocalTime.now());
		System.out.println("DateTime: "+ java.time.LocalDateTime.now());
		
		//Java 8 program to sort the given list?
		l2.stream().sorted().forEach(System.out::println);
		
		//Write a Java 8 program to get the sum of all numbers present in a list?
		System.out.println(l1.stream().mapToInt(Integer::intValue).sum());
		
		//Java 8 program to perfrom cube on list elements and filter numbers greater than 50.
		l1.stream().map(i->i*i*i).filter(i->i>50).forEach(System.out::println);
		
		//------------------------------------------------------------------------------------------------------------
		//How to check if list is empty in Java 8 using Optional, if not null iterate through the list and print the object?
		
		List<String> l3=Arrays.asList("Narendra","Shyam",null,"Krrish",null,"Rahul");
		Optional<List<String>> op=Optional.ofNullable(l3);
		op.orElseGet(Collections::emptyList).
		stream().filter(Objects::nonNull).
		//filter(x->x!=null)
		//map(notes->l::getTagName).
		forEach(System.out::println);
		
		//How to sort Collection in Java 8
		
		//direct sort
		//l1.sort((i1,i2)->i1-i2);
		
		//sort by stream
		l1.stream().sorted().forEach(System.out::println);
		
		l1.stream().forEach(System.out::println);
		
		
		//-----------------------------------------------------------------------
		//What is the best way to convert a primitive Array to a List in Java 8?
		//using Arrays.stream() sequential stream with boxed
		//List<Integer> numsLst = Arrays.stream(nums).boxed().collect(Collectors.toList());

		//OR
		//By using IntStream.boxed(), convert each element of the stream to an Integer ().
		//List<Integer> numsLst = IntStream.of(nums).boxed().collect(Collectors.toList());
		
		
		//-------------------------------------------
		//How to count each element/word from the String ArrayList in Java8?
		
		List<String> names = Arrays.asList("AA", "BB", "AA", "CC");
		Map<String,Long> namesCount = names
		                          .stream()
		                          .collect(
		                           Collectors.groupingBy(
		                             Function.identity()
		                           , Collectors.counting()
		                           ));
		System.out.println(namesCount);
		

		//----------------------------------------------------------------------
		//How to find only duplicate elements with its count from the String ArrayList in Java8?
		
		List<String> names1 = Arrays.asList("AA", "BB", "AA", "CC");
		Map<String,Long> namesCount1 = names1
		                             .stream()
						             .filter(x->Collections.frequency(names1, x)>1)
						             .collect(Collectors.groupingBy
						             (Function.identity(), Collectors.counting()));
		System.out.println(namesCount1);
		
		
	}

}

package com.citiustech.fastplus.querybuilder.types;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.custom.postgresql.PgBinaryCondition;

import ca.uhn.fhir.rest.param.ReferenceParam;

/**
 * 
 * This is a class for ReferenceParamQueryFragmentBuilder which used to build
 * query fragments for reference parameters
 * 
 */

@Component
public class ReferenceParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<ReferenceParam> {

    /**
     * This is a fhirRepositoryTableConfiguration field used to hold
     * FHIRRepositoryTableConfiguration object
     */
    private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	/**
     * This is a commonQueryUtil field used to hold CommonQueryUtil object
     */
    private CommonQueryUtil commonQueryUtil;
    
    @Autowired
    public ReferenceParamQueryFragmentBuilder(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			CommonQueryUtil commonQueryUtil) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.commonQueryUtil = commonQueryUtil;
	}

    public ReferenceParamQueryFragmentBuilder() {
    	
    }
    
    /**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
	@Override
	public Condition frameQueryFragment(QueryBuilder queryBuilder, String resourceType, String alias,
			ReferenceParam paramType, String paramName) {
	    commonQueryUtil.validateParamValue(paramType.getIdPart(), true);
	    commonQueryUtil.validateParamValue(paramType.getResourceType(), false);

	    if (StringUtils.isBlank(paramType.getIdPart())) {
		return Condition.EMPTY;
	    }

	    Condition condition = BinaryCondition
		    .equalTo(fhirRepositoryTableConfiguration.getSearchAttributeColumn(alias), paramName);
	    if (paramType.hasResourceType()) {
		condition = createCondition(condition, resourceType, alias, paramType.getResourceType(), 0);

		String value = commonQueryUtil.findPrefixValue(paramType.getResourceType(), paramType.getIdPart());
		condition = createCondition(condition, resourceType, alias, value, 4);
	    } else {
		List<String> targetList = commonQueryUtil.getTargetReferenceList(resourceType, paramName);
		if (targetList.size() == 1) {
		    String value = commonQueryUtil.findPrefixValue(targetList.get(0), paramType.getIdPart());
		    condition = createCondition(condition, resourceType, alias, value, 4);
		} else {
		    String value = commonQueryUtil.findPrefixValue(paramType.getIdPart());
		    condition = ComboCondition.and(condition,
			    PgBinaryCondition.iLike(fhirRepositoryTableConfiguration
				    .getSearchColumn(ParamType.REFERENCE.getValue(), resourceType, alias).get(4),
				    value));
		}
	    }
	    return condition;
	}

	/**
	 * returns condition by processing input parameters
	 * 
	 * @param condition
	 * @param resourceType
	 * @param resourceTypeAlias
	 * @param paramValue
	 * @param index
	 * @return Condition
	 */
	private Condition createCondition(Condition condition, String resourceType, String resourceTypeAlias,
		String paramValue, int index) {
	    return ComboCondition.and(condition,
		    BinaryCondition.equalTo(fhirRepositoryTableConfiguration
			    .getSearchColumn(ParamType.REFERENCE.getValue(), resourceType, resourceTypeAlias)
			    .get(index), paramValue));
	}
    }

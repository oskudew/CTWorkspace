package Basic;

public abstract class Emp {
 public abstract void pan(); 
// {
//	 System.out.println("Java");
// }
 
}

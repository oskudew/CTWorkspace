package com.citiustech.fastplus.adapter.structure;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 
 * This is a class for SearchParameterRequest defines fields to hold resource
 * identifiers, type and last updated date
 * 
 */

@Getter
@Setter
@ToString
public class IdProjectionRow implements Serializable {
	/**
	 * This is a serialVersionUID field used to assign serial version uid to class
	 */
    private static final long serialVersionUID = -8782442416497358349L;
    
    /**
	 * This is a resourceType field used to hold type of resource
	 */
    private String resourceType;
    
    /**
	 * This is a sourceId field used to hold identifier of source resource
	 */
    private Serializable sourceId;
    
    /**
	 * This is a patientId field used to hold patient identifier
	 */
    private Serializable patientId;
    
    /**
     * No arguments constructor
     */
    public IdProjectionRow() {
        //nothing to add
    }

	/**
	 * Arguments constructor to initialize fields with required values
	 * 
	 * @param resourceType
	 * @param sourceId
	 * @param patientId
	 */
    public IdProjectionRow(String resourceType, Serializable sourceId, Serializable patientId) {
        this.resourceType = resourceType;
        this.sourceId = sourceId;
        this.patientId = patientId;
    }
}
package com.citiustech.fastplus.logging;

/**
*
* A LoggerFactory class for creating custom logging object,
* this object will be used in the API/Class from where it has been invoked
*/

public final class LoggerFactory {

	/**
     * @param className name of the class
     * @return Logging object with classname value
     */
   private LoggerFactory() {
   }
   
    public static Logging getLogger(final String className) {
        return new Logging(className);
    }
}

package com.citiustech.fastplus.adapter.structure;

import java.io.Serializable;

/**
 * This is a class for ResourceLinkData used to hold target resource information
 */
public class ResourceLinkData implements Serializable {

    /**
     * This is a serialVersionUID field used to assign serial version uid to class
     */
    private static final long serialVersionUID = 1L;

    /**
     * This is a targetType field used to hold type of target
     */
    private final String targetType;

    /**
     * This is a targetId field used to hold id of target
     */
    private final String targetId;

    /**
     * arguments constructor
     *
     * @param targetId
     * @param targetType
     */
    public ResourceLinkData(String targetId, String targetType) {
        this.targetId = targetId;
        this.targetType = targetType;
    }

    /**
     * returns target type
     */
    public String getTargetType() {
        return targetType;
    }

    /**
     * returns target id
     */
    public String getTargetId() {
        return targetId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(100);
        builder.append("ResourceLinkData [targetType=")
                .append(targetType)
                .append(", targetId=")
                .append(targetId)
                .append(']');
        return builder.toString();
    }

}

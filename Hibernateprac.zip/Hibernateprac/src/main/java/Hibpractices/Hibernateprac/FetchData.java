package Hibpractices.Hibernateprac;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class FetchData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		
		//Employee emp= (Employee)s.load(Employee.class,101);
		//for invalid id then it gives AN objectnotfoundException
		Employee emp= (Employee)s.load(Employee.class,1001);
		//System.out.println(emp.getName());
//		Employee emp1= (Employee)s.get(Employee.class,1011);
	System.out.println(emp);
		//invalid id gives a null instead of exception when using get

	}

}

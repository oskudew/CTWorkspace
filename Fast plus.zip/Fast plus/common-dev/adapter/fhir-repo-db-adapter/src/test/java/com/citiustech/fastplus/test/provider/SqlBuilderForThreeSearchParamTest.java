package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.ReferenceParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.UriParamQueryFragmentBuilder;
import com.citiustech.fastplus.test.factory.ReferenceFactory;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

@ExtendWith(MockitoExtension.class)
class SqlBuilderForThreeSearchParamTest {

	@InjectMocks
	private DeepNestedSqlBuilder deepNestedSqlBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Spy
	private static BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Spy
	private static ProjectionAndSortingHelper projectionAndSortingHelper;
	
	@Spy
	private static FHIRErrorHandler fhirErrorHandler;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;
		CustomResourceUtil customResourceUtil;
		TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;
		
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
        fhirErrorHandler = new FHIRErrorHandler();
        
        Map<String, String> customResourceMap = new HashMap<>();
        customResourceMap.put("FormularyDrug", "com.citiustech.fastplus.r4.model.DavinciFormularyDrug");
        customResourceMap.put("DocumentReference", "com.citiustech.fastplus.r4.model.USCoreDocumentReference");
        customResourceMap.put("ExplanationOfBenefit", "com.citiustech.fastplus.r4.model.USCoreExplanationOfBenefit");
        
		customResourceUtil = new CustomResourceUtil(customResourceMap);
		CommonQueryUtil commonQueryUtil = new CommonQueryUtil(fhirErrorHandler,customResourceUtil);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
        stringParamQueryFragmentBuilder =  new StringParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        tokenParamQueryFragmentBuilder = new TokenParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil,
        		fhirErrorHandler);
        referenceParamQueryFragmentBuilder = new ReferenceParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        dateRangeParamQueryFragmentBuilder = new DateRangeParamQueryFragmentBuilder(customResourceUtil, commonQueryUtil, fhirErrorHandler,
        		fhirRepositoryTableConfiguration);
        uriParamQueryFragmentBuilder = new UriParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        
        baseTypeQueryFragmentBuilder = new BaseTypeQueryFragmentBuilder(fhirRepositoryTableConfiguration,
        		stringParamQueryFragmentBuilder, tokenParamQueryFragmentBuilder, referenceParamQueryFragmentBuilder,
        		dateRangeParamQueryFragmentBuilder);
        
        baseTypeQueryFragmentBuilder.setCustomResourceUtil(customResourceUtil);
        baseTypeQueryFragmentBuilder.setFhirErrorHandler(fhirErrorHandler);
        baseTypeQueryFragmentBuilder.setUriParamQueryFragmentBuilder(uriParamQueryFragmentBuilder);
        
        projectionAndSortingHelper = new ProjectionAndSortingHelper(fhirRepositoryTableConfiguration, customResourceUtil,
        		fhirErrorHandler);
	}
	
	@DisplayName("Test case for String,Token and Reference search parameter")
	@Test
	void test_BuildNestedQueriesForStringAndTokenAndReferenceParam() {
		
		String resourceType =  ResourceType.Organization.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("Orgaforpartof").newInstance();
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.addTokenParam(new TokenParam("http://hl7.org/fhir/R4/valueset-organization-type.html", "")).newInstance();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("Mexico").newInstance();
		
		searchParamMap.add(Organization.SP_NAME, stringAndListParam);
		searchParamMap.add(Organization.SP_PARTOF, referenceAndListParam);
		searchParamMap.add(Organization.SP_TYPE, tokenAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		
		String randomAlphabeticString1 = "VEWl";
		String randomAlphabeticString2 = "XWFn";
		String randomAlphabeticString3 = "axSJ";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,
				randomAlphabeticString2,randomAlphabeticString3);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT OrganizationVEWl.id FROM organizationsearch OrganizationVEWl WHERE (((OrganizationVEWl.attribute = 'name') AND (OrganizationVEWl.value ILIKE 'Mexico%')) "
				+"AND (EXISTS (SELECT 1 FROM organizationsearch OrganizationXWFn WHERE (((OrganizationXWFn.attribute = 'partof') AND (OrganizationXWFn.value = 'Orgaforpartof')) AND (OrganizationVEWl.id = OrganizationXWFn.id)))) "
				+"AND (EXISTS (SELECT 1 FROM organizationsearch OrganizationaxSJ WHERE (((OrganizationaxSJ.attribute = 'type') AND (OrganizationaxSJ.system = 'http://hl7.org/fhir/R4/valueset-organization-type.html')) AND (OrganizationVEWl.id = OrganizationaxSJ.id))))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	@DisplayName("Test case for String,Token and Date search parameter with date modifier")
	@Test
	void test_BuildNestedQueriesForStringAndTokenAndDateParam() {
		
		String resourceType =  ResourceType.PractitionerRole.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.addReferenceParam(new ReferenceParam("name:exact","ACME CT Premium Preferred Provider Network")).newInstance();
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.addTokenParam(new TokenParam("http://nucc.org/provider-taxonomy", "363LA2200X")).newInstance();
		
		DateParam theLowerBound = new DateParam("ge2020-07-07");
		DateRangeParam lastupdatedDate = new DateRangeParam(theLowerBound,null);
		
		searchParamMap.add(PractitionerRole.SP_ORGANIZATION, referenceAndListParam);
		searchParamMap.add(PractitionerRole.SP_SPECIALTY, tokenAndListParam);
		searchParamMap.add(TestConstants.SP_LAST_UPDATED, lastupdatedDate);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "MtEO";
		String randomAlphabeticString2 = "gKbt";
		String randomAlphabeticString3 = "hLSI";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,
				randomAlphabeticString2,randomAlphabeticString3);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT DISTINCT PractitionerRoleMtEO.id FROM fhirrepo.practitionerrolesearch PractitionerRoleMtEO INNER JOIN fhirrepo.organizationsearch Organization ON (PractitionerRoleMtEO.value = Organization.id) WHERE (((PractitionerRoleMtEO.attribute = 'organization') AND ((Organization.attribute = 'name') AND (Organization.value = 'ACME CT Premium Preferred Provider Network'))) " + 
				"AND (EXISTS (SELECT 1 FROM practitionerrolesearch PractitionerRolegKbt WHERE ((((PractitionerRolegKbt.attribute = 'specialty') AND (PractitionerRolegKbt.system = 'http://nucc.org/provider-taxonomy')) AND (PractitionerRolegKbt.code = '363LA2200X')) AND (PractitionerRoleMtEO.id = PractitionerRolegKbt.id)))) " + 
				"AND (EXISTS (SELECT 1 FROM practitionerrolesearch PractitionerRolehLSI WHERE (((PractitionerRolehLSI.attribute = '_id') AND (PractitionerRolehLSI.lastupdated >= '2020-07-07 00:00:00')) AND (PractitionerRoleMtEO.id = PractitionerRolehLSI.id))))) LIMIT 500" ;
		
		assertEquals(expectedValue, actualValue);
	}
	
	
	// test for patient resources 
	@DisplayName("Test case for String,Reference and Date search parameter with date modifier")
	@Test
	void test_BuildNestedQueriesForStringAndReferenceAndDateParam() {
		
		String resourceType =  ResourceType.Location.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam theLowerBound = new DateParam("eq2018-01-01");
		DateRangeParam lastupdatedDate = new DateRangeParam(theLowerBound,null);
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("1234").newInstance();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.setStringValue("73848").newInstance();
		
		searchParamMap.add(Location.SP_ORGANIZATION, referenceAndListParam);
		searchParamMap.add(Location.SP_ADDRESS_POSTALCODE, stringAndListParam);
		searchParamMap.add(TestConstants.SP_LAST_UPDATED, lastupdatedDate);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "prrY";
		String randomAlphabeticString2 = "ikkD";
		String randomAlphabeticString3 = "lgIy";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,
				randomAlphabeticString2,randomAlphabeticString3);
		
		String actualValue = deepNestedSqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT LocationprrY.id FROM locationsearch LocationprrY WHERE (((LocationprrY.attribute = 'organization') AND (LocationprrY.value = '1234')) " + 
				"AND (EXISTS (SELECT 1 FROM locationsearch LocationikkD WHERE (((LocationikkD.attribute = 'address-postalcode') AND (LocationikkD.value ILIKE '73848%')) AND (LocationprrY.id = LocationikkD.id)))) " + 
				"AND (EXISTS (SELECT 1 FROM locationsearch LocationlgIy WHERE (((LocationlgIy.attribute = '_id') AND (date_trunc('day',LocationlgIy.lastupdated) = '2018-01-01 00:00:00')) AND (LocationprrY.id = LocationlgIy.id))))) LIMIT 500";  
		
		assertEquals(expectedValue, actualValue);
		
	}	
	 
	@DisplayName("Test case for Token,Reference and Date search parameter")
	@Test
	void test_BuildNestedQueriesForTokenAndReferenceAndDateParam() {
		
		String resourceType =  ResourceType.Encounter.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		DateParam dateparam = new DateParam("1986-12-25");
		DateRangeParam date = new DateRangeParam(dateparam);
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.setReferenceValue("finished").newInstance();
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("7b7709ff-a107-49ea-8211-56771b65cd19").newInstance();
		
		searchParamMap.add(Encounter.SP_STATUS, tokenAndListParam);
		searchParamMap.add(TestConstants.SP_LAST_UPDATED, date);
		searchParamMap.add(Encounter.SP_PATIENT, referenceAndListParam);
		if (Objects.nonNull(referenceAndListParam)) {
			searchParamMap.setPatientIds(AdapterUtil.getParamList(referenceAndListParam));
		}
		searchParamMap.setPatientSearchParam(Encounter.SP_PATIENT);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		
		String randomAlphabeticString1 = "RRIV";
		String randomAlphabeticString2 = "OhRh";
		String randomAlphabeticString3 = "RNiN";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,
				randomAlphabeticString2,randomAlphabeticString3);
		
		
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT EncounterRRIV.id FROM encountersearch EncounterRRIV WHERE (((EncounterRRIV.attribute = 'status') AND (EncounterRRIV.code = 'finished')) AND (EXISTS (SELECT 1 FROM encountersearch EncounterOhRh WHERE (((EncounterOhRh.attribute = '_id') " + 
				"AND (date_trunc('day',EncounterOhRh.lastupdated) = '1986-12-25 00:00:00')) AND (EncounterRRIV.id = EncounterOhRh.id)))) " + 
				"AND (EXISTS (SELECT 1 FROM encountersearch EncounterRNiN WHERE (((EncounterRNiN.attribute = 'patient') AND (EncounterRNiN.value = '7b7709ff-a107-49ea-8211-56771b65cd19')) AND (EncounterRRIV.id = EncounterRNiN.id))))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
		
	}
	    
}

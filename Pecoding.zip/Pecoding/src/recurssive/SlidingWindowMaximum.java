package recurssive;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class SlidingWindowMaximum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		////Incoreect we have to watch it again
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int[] arr= new int[a];
		int[] arr1 = new int[a];
		/
		for(int i =0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		int k=sc.nextInt();
		
		Stack<Integer> s1 = new Stack<>();
		s1.push(arr.length-1);
		arr1[arr.length-1]=arr.length;
		
				
		for(int i=arr.length-2;i>=0;i--) {
			while(s1.size()> 0 && arr[i]>=arr[s1.peek()] ) {
				s1.pop();
			}
			if(s1.size()>0) {
				arr1[i]=s1.peek();
			}
			else {
				arr1[i]=arr.length;
			}
			s1.push(i);
		}
		System.out.println(Arrays.toString(arr1));
		
		int j=0;
		for(int i=0;i<a-k;i++) {
			if(j<i) {
				j=i;
			}
			while(arr1[j]<i+k) {
				j=arr1[j];
			}
			System.out.println(arr[j]);
		}
		
		
	}

}

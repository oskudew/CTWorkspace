package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.io.IOException;
import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.CompositeParamQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import ca.uhn.fhir.rest.param.CompositeParam;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;
import ca.uhn.fhir.rest.param.DateParam.DateParamDateTimeHolder;

@ExtendWith(MockitoExtension.class)
class CompositeParamQueryFragmentBuilderTest {
	 
	 
	@InjectMocks
	static CompositeParamQueryFragmentBuilder compositeParamQueryFragmentBuilder;
	 
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
    private static CommonQueryUtil commonQueryUtil;
	
	@Mock
	private static TypeQueryFragmentBuilder<StringParam> stringParamBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<TokenParam> tokenParamBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<ReferenceParam> referenceParamBuilder;
	
	@Mock
	private static TypeQueryFragmentBuilder<DateParam> dateRangeParamBuilder;
	
	@Spy
	static private FHIRErrorHandler fhirErrorHandler;
	
	@Spy
	private TypeQueryFragmentBuilder<UriParam> uriParamBuilder;
	
	String resourceTypeAlias = "Patientsbag";
	String targetAlias = "sbag";
	String resourceType = ResourceType.Patient.name();
    String value;
	

	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,FHIRRepositoryTableConfiguration.class);
		 fhirRepositoryTableConfiguration.duplicateTypeMap();
	}
	
    FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
            fhirRepositoryTableConfiguration, resourceType);
	
	
	
	
     @DisplayName("Test case for frameQueryFragment")
	 @Test 
	 void test_frameQueryFragment() {
	  
	     String value1 = "EN"; 
		 String value2 = "FR"; 
	     StringParam v0 = new StringParam(value1);
		 StringParam v1 = new StringParam(value2);
		 String paramName1=	Patient.SP_LANGUAGE;
		 String paramName2=	Patient.SP_LANGUAGE;
			
		 String paramName=paramName1 +"-"+ paramName2;
		 CompositeParam<StringParam, StringParam> paramType = new CompositeParam<>(v0, v1);
		 
		 when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias); 
				
		 Condition condition1 = ComboCondition.and("((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'EN%'))");	
		 when(stringParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (StringParam) v0, paramName1)).thenReturn(condition1);
		 
		 Condition condition2 = ComboCondition.and("((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'FR%'))");	
		 when(stringParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (StringParam) v1, paramName2)).thenReturn(condition2);
				
		  Condition actualValue = compositeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder,
		  resourceType, resourceTypeAlias, paramType, paramName); 
		  
		  Condition expectedValue = ComboCondition.
		  and("(((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'EN%'))) AND (EXISTS (SELECT 1 FROM patientsearch Patientsbag WHERE ((Patientsbag.id = Patientsbag.id) AND (((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'FR%'))))))"
		  );
		  
		  assertEquals(expectedValue.toString(),actualValue.toString());
	  
	  }
	  

     @DisplayName("Test case for frameQueryFragment with date param")
	 @Test 
	 void test_frameQueryFragmentWithDateParam() {
	  
	     String date1 = "1990-01-01";
	     ParamPrefixEnum thePrefix1 = ParamPrefixEnum.LESSTHAN;
	     DateParamDateTimeHolder theDate1 = new DateParamDateTimeHolder();
		 theDate1.setValueAsString(date1);
		 DateParam dateParamtype1 = new DateParam(thePrefix1,theDate1);
		
		 String date2 = "1970-01-01";
	     ParamPrefixEnum thePrefix2 = ParamPrefixEnum.GREATERTHAN;
	     DateParamDateTimeHolder theDate2 = new DateParamDateTimeHolder();
		 theDate2.setValueAsString(date2);
		 DateParam dateParamtype2 = new DateParam(thePrefix2,theDate2);
		 
	     String paramName1=	Patient.SP_BIRTHDATE;
		 String paramName2=	Patient.SP_BIRTHDATE;
			
		 String paramName=paramName1 +"-"+ paramName2;
		 CompositeParam<DateParam, DateParam> paramType = new CompositeParam<>(dateParamtype1, dateParamtype2);
		 
		 when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias); 
				
		 Condition condition1 = ComboCondition.and("((Patientsbag.attribute = 'birthdate') AND (Patientsbag.value > '1970-01-01 00:00:00'))");	
		 when(dateRangeParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (DateParam) dateParamtype2, paramName1)).thenReturn(condition1);
		 
		 Condition condition2 = ComboCondition.and("((Patientsbag.attribute = 'birthdate') AND (Patientsbag.value < '1990-01-01 00:00:00'))");	
		 when(dateRangeParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (DateParam) dateParamtype1, paramName2)).thenReturn(condition2);
				
		  Condition actualValue = compositeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder,
		  resourceType, resourceTypeAlias, paramType, paramName); 
		  
		  Condition expectedValue = ComboCondition.
		  and("(((Patientsbag.attribute = 'birthdate') AND (Patientsbag.value < '1990-01-01 00:00:00'))) AND (EXISTS (SELECT 1 FROM patientsearch Patientsbag WHERE ((Patientsbag.id = Patientsbag.id) AND (((Patientsbag.attribute = 'birthdate') AND (Patientsbag.value > '1970-01-01 00:00:00'))))))"
		  );
		  
		  assertEquals(expectedValue.toString(),actualValue.toString());
	  
	  }
	  

     
     @DisplayName("Test case for frameQueryFragment for token")
	 @Test 
	 void test_frameQueryFragmentWithTokenParam() {
    	 

	     String value1 = "Kern-pat-90001";
	     String value2 = "FR"; 
		 TokenParam v0 = new TokenParam(value1);
		 StringParam v1 = new StringParam(value2);
		 
		 String paramName1=	IAnyResource.SP_RES_ID;;
		 String paramName2=	Patient.SP_LANGUAGE;
			
		 String paramName=paramName1 +"-"+ paramName2;
		 CompositeParam<TokenParam, StringParam> paramType = new CompositeParam<>(v0, v1);
		 
		 when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias); 
				
		 Condition condition1 = ComboCondition.and("((Patientsbag.attribute = '_id') AND (Patientsbag.code = 'Kern-pat-90001')");	
		 when(tokenParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (TokenParam) v0, paramName1)).thenReturn(condition1);
		 
		 Condition condition2 = ComboCondition.and("((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'FR%'))");	
		 when(stringParamBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias,
		 (StringParam) v1, paramName2)).thenReturn(condition2);
				
		  Condition actualValue = compositeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder,
		  resourceType, resourceTypeAlias, paramType, paramName); 
		  
		  Condition expectedValue = ComboCondition.
		  and("(((Patientsbag.attribute = '_id') AND (Patientsbag.code = 'Kern-pat-90001')) AND (EXISTS (SELECT 1 FROM patientsearch Patientsbag WHERE ((Patientsbag.id = Patientsbag.id) AND (((Patientsbag.attribute = 'language') AND (Patientsbag.value ILIKE 'FR%'))))))"
		  );
		  
		  assertEquals(expectedValue.toString(),actualValue.toString());
	  
	  }

    @DisplayName("Test case for frameQueryFragment for reference param")
	@Test 
	void test_frameQueryFragmentForReferenceParam() {
	  
	    String resource2 = ResourceType.DocumentReference.name();
	    String resourceAlias2 = "DocumentReferencevzcV";
	    String targetAlias2 = "vzcV";
	    
	 	String paramName1 = DocumentReference.SP_PATIENT;
	 	String paramName2 = DocumentReference.SP_TYPE;
	 	
	 	String value1 = "7b7709ff-a107-49ea-8211-56771b65cd19"; 
	    String value2="History and physical note";
	    
	    ReferenceParam v0 = new ReferenceParam(value1);
	    ReferenceParam v1 = new ReferenceParam(value2);
	
		String paramName=paramName1 +"-"+ paramName2;
		CompositeParam<ReferenceParam, ReferenceParam> paramType = new CompositeParam<>(v0, v1);
		
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(targetAlias2); 
	
		Condition condition1 = ComboCondition.and("(DocumentReferencevzcV.attribute = 'patient') AND (DocumentReferencevzcV.value = '7b7709ff-a107-49ea-8211-56771b65cd19')");	
		when(referenceParamBuilder.frameQueryFragment(queryBuilder, resource2, resourceAlias2,
		(ReferenceParam) v0, paramName1)).thenReturn(condition1);
		 
		Condition condition2 = ComboCondition.and("(DocumentReferencevzcV.attribute = 'type') AND (DocumentReferencevzcV.value = 'History and physical note'))");	
		when(referenceParamBuilder.frameQueryFragment(queryBuilder, resource2, resourceAlias2,
		(ReferenceParam) v1, paramName2)).thenReturn(condition2);
				
		Condition actualValue = compositeParamQueryFragmentBuilder.frameQueryFragment(queryBuilder,
				  resource2, resourceAlias2, paramType, paramName); 
		  
		Condition expectedValue = ComboCondition.
		  and("((DocumentReferencevzcV.attribute = 'patient') AND (DocumentReferencevzcV.value = '7b7709ff-a107-49ea-8211-56771b65cd19')) AND (EXISTS (SELECT 1 FROM documentreferencesearch DocumentReferencevzcV WHERE ((DocumentReferencevzcV.id = DocumentReferencevzcV.id) AND ((DocumentReferencevzcV.attribute = 'type') AND (DocumentReferencevzcV.value = 'History and physical note'))))))"
		  );
		  
		assertEquals(expectedValue.toString(),actualValue.toString());
	  
	  }

}

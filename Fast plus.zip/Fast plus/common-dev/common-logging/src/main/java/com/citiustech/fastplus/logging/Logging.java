package com.citiustech.fastplus.logging;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.MarkerManager;


/**
 * Logging class for creating a logger object and
 * calling required methods by providing necessary input params
 */
public class Logging {
    private Logger logger;

    /**
     * It is a constructor which creates a logger object with the classname provided as an input
     *
     * @param className	name of the class
     * @return logging object
     */
    public Logging(final String className) {
        logger = LogManager.getLogger(className);
    }

    /**
     * Prints the logger message of Info level
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     */
    public void logInfo(String loggingMarkers, String msg) {
        logger.info(MarkerManager.getMarker(loggingMarkers), msg);
    }

    /**
     * Prints the logger message of Debug level
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     */
    public void logDebug(String loggingMarkers, String msg) {
        logger.debug(MarkerManager.getMarker(loggingMarkers), msg);
    }

    /**
     * Prints the logger message of Error level
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     */
    public void logError(String loggingMarkers, String msg) {
        logger.error(MarkerManager.getMarker(loggingMarkers), msg);
    }

    /**
     * Prints the logger message of Warning level
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     */
    public void logWarning(String loggingMarkers, String msg) {
        logger.warn(MarkerManager.getMarker(loggingMarkers), msg);
    }

    /**
     * Prints the logger message of Trace level
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     */
    public void logTrace(String loggingMarkers, String msg) {
        logger.trace(MarkerManager.getMarker(loggingMarkers), msg);
    }

    /**
     * Prints the logger message of Info level with throwable exception message
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     * @param throwable         error message of throwable type
     */
    public void logInfo(String loggingMarkers, String msg, Throwable throwable) {
        logger.info(MarkerManager.getMarker(loggingMarkers), msg, throwable);
    }

    /**
     * Prints the logger message of Debug level with throwable exception message
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     * @param throwable         error message of throwable type
     */
    public void logDebug(String loggingMarkers, String msg, Throwable throwable) {
        logger.debug(MarkerManager.getMarker(loggingMarkers), msg, throwable);
    }

    /**
     * Prints the logger message of Error level with throwable exception message
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     * @param throwable         error message of throwable type
     */
    public void logError(String loggingMarkers, String msg, Throwable throwable) {
        logger.error(MarkerManager.getMarker(loggingMarkers), msg, throwable);
    }

    /**
     * Prints the logger message of Warning level with throwable exception message
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     * @param throwable         error message of throwable type
     */
    public void logWarning(String loggingMarkers, String msg, Throwable throwable) {
        logger.warn(MarkerManager.getMarker(loggingMarkers), msg, throwable);
    }

    /**
     * Prints the logger message of Trace level with throwable exception message
     *
     * @param loggingMarkers    marker string to bifurcate different logs
     * @param msg	            actual message which needs to be printed
     * @param throwable         error message of throwable type
     */
    public void logTrace(String loggingMarkers, String msg, Throwable throwable) {
        logger.trace(MarkerManager.getMarker(loggingMarkers), msg, throwable);
    }

	
}

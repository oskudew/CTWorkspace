package com.java.conference.Service;

import java.util.List;

import com.java.conference.Repository.HibernateSpeakerRepositoryImpl;
import com.java.conference.Repository.SpeakerRepository;
import com.java.conference.model.Speaker;

public class SpeakerService implements SpeakerServiceInter {
	
	SpeakerRepository repo = new HibernateSpeakerRepositoryImpl();
	
	public void setRepo(SpeakerRepository repo) {
		this.repo = repo;
	}
	
	public List<Speaker> findAll(){
		return repo.findAll();
	}
	
	
}

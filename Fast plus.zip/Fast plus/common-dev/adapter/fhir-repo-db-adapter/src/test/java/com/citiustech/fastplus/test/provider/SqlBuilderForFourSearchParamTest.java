package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.BaseTypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.ProjectionAndSortingHelper;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.DateRangeParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.ReferenceParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.StringParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.TokenParamQueryFragmentBuilder;
import com.citiustech.fastplus.querybuilder.types.UriParamQueryFragmentBuilder;
import com.citiustech.fastplus.test.factory.ReferenceFactory;
import com.citiustech.fastplus.test.factory.StringFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.AdapterUtil;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.param.UriParam;

@ExtendWith(MockitoExtension.class)
class SqlBuilderForFourSearchParamTest {

	@InjectMocks
	private DeepNestedSqlBuilder deepNestedSqlBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Spy
	private static BaseTypeQueryFragmentBuilder baseTypeQueryFragmentBuilder;
	
	@Spy
	private static ProjectionAndSortingHelper projectionAndSortingHelper;
	
	@Spy
	private static FHIRErrorHandler fhirErrorHandler;
	
	@BeforeAll
	static void createFhirRepositoryTableConfiguration() throws IOException {
		TypeQueryFragmentBuilder<StringParam> stringParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<TokenParam> tokenParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<DateParam> dateRangeParamQueryFragmentBuilder;
		CustomResourceUtil customResourceUtil;
		TypeQueryFragmentBuilder<UriParam> uriParamQueryFragmentBuilder;
		TypeQueryFragmentBuilder<ReferenceParam> referenceParamQueryFragmentBuilder;
		
		ObjectMapper objectMapper = new ObjectMapper();
    	fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString, FHIRRepositoryTableConfiguration.class);
        fhirRepositoryTableConfiguration.duplicateTypeMap();
        fhirErrorHandler = new FHIRErrorHandler();
        
        Map<String, String> customResourceMap = new HashMap<>();
        customResourceMap.put("FormularyDrug", "com.citiustech.fastplus.r4.model.DavinciFormularyDrug");
        customResourceMap.put("DocumentReference", "com.citiustech.fastplus.r4.model.USCoreDocumentReference");
        customResourceMap.put("ExplanationOfBenefit", "com.citiustech.fastplus.r4.model.USCoreExplanationOfBenefit");
        
		customResourceUtil = new CustomResourceUtil(customResourceMap);
		CommonQueryUtil commonQueryUtil = new CommonQueryUtil(fhirErrorHandler,customResourceUtil);
		commonQueryUtil.setInvalidSpecialCharacters("'=");
        stringParamQueryFragmentBuilder =  new StringParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        tokenParamQueryFragmentBuilder = new TokenParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil,
        		fhirErrorHandler);
        referenceParamQueryFragmentBuilder = new ReferenceParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        dateRangeParamQueryFragmentBuilder = new DateRangeParamQueryFragmentBuilder(customResourceUtil, commonQueryUtil, fhirErrorHandler,
        		fhirRepositoryTableConfiguration);
        uriParamQueryFragmentBuilder = new UriParamQueryFragmentBuilder(fhirRepositoryTableConfiguration, commonQueryUtil);
        
        baseTypeQueryFragmentBuilder = new BaseTypeQueryFragmentBuilder(fhirRepositoryTableConfiguration,
        		stringParamQueryFragmentBuilder, tokenParamQueryFragmentBuilder, referenceParamQueryFragmentBuilder,
        		dateRangeParamQueryFragmentBuilder);
        
        baseTypeQueryFragmentBuilder.setCustomResourceUtil(customResourceUtil);
        baseTypeQueryFragmentBuilder.setFhirErrorHandler(fhirErrorHandler);
        baseTypeQueryFragmentBuilder.setUriParamQueryFragmentBuilder(uriParamQueryFragmentBuilder);
        
        projectionAndSortingHelper = new ProjectionAndSortingHelper(fhirRepositoryTableConfiguration, customResourceUtil,
        		fhirErrorHandler);
	}
	
	@DisplayName("Test case for String,Token,Reference and Date search parameter with or condition in token")
	@Test
	void test_BuildNestedQueriesForStringAndTokenAndReferenceAndDateParam() {
		
		String resourceType =  ResourceType.RelatedPerson.name();
		SearchParameterRequest searchParamMap = new SearchParameterRequest();
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue("7b7709ff-a107-49ea-8211-56771b65cd19").newInstance();
		
		TokenAndListParam tokenAndListParam = new TokenFactory().setReferenceValue("other")
				.addTokenParam(new TokenParam("male")).newInstance();
		
		StringAndListParam stringAndListParam = new StringFactory()
				.addStringParam(new StringParam("A").setContains(Boolean.TRUE)).newInstance();
		
		DateParam theLowerBound = new DateParam("ge2018-02-28");
		DateRangeParam lastupdatedDate = new DateRangeParam(theLowerBound,null);
		
		searchParamMap.add(RelatedPerson.SP_GENDER, tokenAndListParam);
		searchParamMap.add(TestConstants.SP_LAST_UPDATED, lastupdatedDate);
		searchParamMap.add("family", stringAndListParam);
		searchParamMap.add(RelatedPerson.SP_PATIENT, referenceAndListParam);
		searchParamMap.setLimit(Math.multiplyExact(TestConstants.searchLimit, TestConstants.multiplicationFactor));
		if (Objects.nonNull(referenceAndListParam)) {
			searchParamMap.setPatientIds(AdapterUtil.getParamList(referenceAndListParam));
		}
		searchParamMap.setPatientSearchParam(RelatedPerson.SP_PATIENT);
		
		String randomAlphabeticString1 = "ugYh";
		String randomAlphabeticString2 = "STug";
		String randomAlphabeticString3 = "lDkp";
		String randomAlphabeticString4 = "ZynM";
		when(fhirRepositoryTableConfiguration.getRandomString()).thenReturn(randomAlphabeticString1,
				randomAlphabeticString2,randomAlphabeticString3,randomAlphabeticString4);
		
		String actualValue = deepNestedSqlBuilder.buildNestedQueriesForSearchParams(resourceType, searchParamMap);
		
		String expectedValue = "SELECT RelatedPersonugYh.id FROM relatedpersonsearch RelatedPersonugYh WHERE ((((RelatedPersonugYh.attribute = 'gender') AND (RelatedPersonugYh.code = 'other')) OR ((RelatedPersonugYh.attribute = 'gender') AND (RelatedPersonugYh.code = 'male'))) " + 
				"AND (EXISTS (SELECT 1 FROM relatedpersonsearch RelatedPersonSTug WHERE (((RelatedPersonSTug.attribute = '_id') AND (RelatedPersonSTug.lastupdated >= '2018-02-28 00:00:00')) AND (RelatedPersonugYh.id = RelatedPersonSTug.id)))) " + 
				"AND (EXISTS (SELECT 1 FROM relatedpersonsearch RelatedPersonlDkp WHERE (((RelatedPersonlDkp.attribute = 'family') AND (RelatedPersonlDkp.value ILIKE '%A%')) AND (RelatedPersonugYh.id = RelatedPersonlDkp.id)))) " + 
				"AND (EXISTS (SELECT 1 FROM relatedpersonsearch RelatedPersonZynM WHERE (((RelatedPersonZynM.attribute = 'patient') AND (RelatedPersonZynM.value = '7b7709ff-a107-49ea-8211-56771b65cd19')) AND (RelatedPersonugYh.id = RelatedPersonZynM.id))))) LIMIT 500";
		
		assertEquals(expectedValue, actualValue);
	}
	
	    
}

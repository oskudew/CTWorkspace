package com.citiustech.fastplus.mapper;

import org.hl7.fhir.r4.model.Bundle;

public interface ResourceMapper {
    public Bundle map(final Object document);

//    public String validate(final ValidationEngine validator,
//                           final boolean disableValidation,
//                           final String resourceString) throws Exception;

    public void setDatePattern(final String datePattern);
}

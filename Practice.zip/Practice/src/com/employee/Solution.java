package com.employee;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> l= Arrays.asList( new Employee(1,"sachin","IT"),
				 new Employee(2,"Dravid","IT"),
				 new Employee(3,"Dhoni","Security"),
				 new Employee(4,null,"Security"));
		
		for(int i =0;i<l.size();i++) {
			Optional<String> op= Optional.ofNullable(l.get(i).getName());
			//System.out.println(op.(l.remove(i)));
		}
		
		Map<String,Long> map =l.stream().collect(Collectors.groupingBy(Employee::getDeptName,
								TreeMap::new, Collectors.counting()));
		
		map.forEach((x,y)->System.out.println(x+" : "+y));
		
//		List number = Arrays.asList(2,3,4,5);
//		int even =(int) number.stream().filter(x->x%2==0).reduce(0,(ans,i)-> ans+i);
//
//		System.out.println(even);

	}

}

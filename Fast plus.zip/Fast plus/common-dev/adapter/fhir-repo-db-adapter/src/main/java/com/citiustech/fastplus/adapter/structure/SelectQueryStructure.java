package com.citiustech.fastplus.adapter.structure;

import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString

/**
 * 
 * This is a class for SelectQueryStructure which holds data to form query
 * 
 */
public class SelectQueryStructure {
	
	/**
	 * This is a alias field used to hold alias used in query 
	 */
    private String alias;
    
    /**
	 * This is a selectQuery field used to hold select query
	 */
    private SelectQuery selectQuery;

    /**
	 * This is a projection field used to hold columns to be selected
	 */
    private List<CustomSql> projection;

    /**
	 * This is a paramName field used to hold parameter name to be selected
	 */
    private String paramName;
    
    /**
	 * This is a isChainedParam field used to hold is this chained parameter or not
	 */
    private boolean isChainedParam;

    /**
	 * @param alias
	 * @param selectQuery
	 * @param projection
	 * @param paramName
	 * @param isChainedParam
	 */
    public SelectQueryStructure(String alias, SelectQuery selectQuery, List<CustomSql> projection, String paramName, boolean isChainedParam) {
        this.alias = alias;
        this.selectQuery = selectQuery;
        this.projection = projection;
        this.paramName = paramName;
        this.isChainedParam = isChainedParam;
    }

}

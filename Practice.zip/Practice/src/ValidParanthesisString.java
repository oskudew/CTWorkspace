import java.util.Stack;

public class ValidParanthesisString {

	public static boolean valid(String parens) {

		
		Stack<Character> stack = new Stack<Character>();
		char[] ch = parens.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == ')' && !stack.isEmpty() && stack.peek()=='(')
				stack.pop();
			else if (ch[i] == '}' && !stack.isEmpty() && stack.peek()=='{')
				stack.pop();
			else if (ch[i] == ']' && !stack.isEmpty() && stack.peek()=='[')
				stack.pop();
			else stack.push(ch[i]);
		}
		return stack.isEmpty();
		 
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(valid("{[(])}"));

	}

}

package basic;

import java.util.Scanner;

public class Pattern15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int sp =n/2;
		int sr=1;
		int val=1;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=sp;j++) {
				System.out.print("\t");
			}
			int cval=val;
			for(int j=1;j<=sr;j++) {
				System.out.print(cval+"\t");
				if(j<=sr/2) {
					cval++;
				}
				
				else {
					cval--;
				}
				
			}
			
			if(i<=n/2) {
				sp--;
				sr=sr+2;
				val++;
			}
			else {
				
				sp++;
				sr=sr-2;
				val--;
			}
			
			System.out.println();
		}
		

	}

}

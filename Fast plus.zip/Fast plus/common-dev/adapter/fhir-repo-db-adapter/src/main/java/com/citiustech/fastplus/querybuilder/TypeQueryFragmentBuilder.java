package com.citiustech.fastplus.querybuilder;

import ca.uhn.fhir.model.api.IQueryParameterType;
import com.healthmarketscience.sqlbuilder.Condition;
import org.springframework.stereotype.Component;

/**
 * 
 * This is an interface for TypeQueryFragmentBuilder defines methods to frame
 * query fragments
 * 
 */

@Component
public interface TypeQueryFragmentBuilder<V extends IQueryParameterType> {

	/**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
    Condition frameQueryFragment(QueryBuilder queryBuilder, String resurceType, String alias, V paramType, String paramName);

}

package com.citiustech.fastplus.adapter.functional;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 
 * This is a class for StringProjectionFunction which act as mapper to get
 * String object by extracting ResultSet
 * 
 */
public class StringProjectionFunction implements RowMapper<String> {
    @Override
    public String mapRow(final ResultSet resultSet, final int index) throws SQLException {
        return resultSet.getString(1);
    }
}

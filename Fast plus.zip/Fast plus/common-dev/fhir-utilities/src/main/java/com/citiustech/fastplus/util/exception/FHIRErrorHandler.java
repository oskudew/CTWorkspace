package com.citiustech.fastplus.util.exception;

import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import org.springframework.stereotype.Component;

/**
 * 
 * This is a FHIRErrorHandler class used to handle exception/errors
 *
 */
@Component
public class FHIRErrorHandler {
	
	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(FHIRErrorHandler.class.getName());
	
	/**
	 * handles the errors and exceptions
	 * 
	 * @param fhirErrCode
	 */
	public FHIRException handleErrorCode(ExceptionCodes fhirErrCode) {
		return logAndThrowError(fhirErrCode);
	}
	
	/**
	 * logs and throws the exception using input error code
	 * 
	 * @param fhirErrCode
	 */
	private FHIRException logAndThrowError(ExceptionCodes fhirErrCode) {
		LOGGER.logError(LoggingMarkers.APPLICATION.getValue(),fhirErrCode.getCode());
		return new FHIRException(fhirErrCode.getCode());
	}
	
	/**
	 * handles the errors and exceptions
	 * 
	 * @param fhirErrCode
	 * @param ex
	 */
	public FHIRException handleErrorCode(ExceptionCodes fhirErrCode, Exception ex) {
		return logAndThrowError(fhirErrCode, ex);
	}

	/**
	 * logs and throws the exception using input parameters
	 * 
	 * @param fhirErrCode
	 * @param ex
	 */
	private FHIRException logAndThrowError(ExceptionCodes fhirErrCode, Exception ex) {
		LOGGER.logError(LoggingMarkers.APPLICATION.getValue(), fhirErrCode.getCode(), ex);
		
		return new FHIRException(fhirErrCode.getCode());
	}
	
	/**
	 * handles the errors and exceptions
	 * 
	 * @param fhirErrCode
	 * @param msg
	 * @param ex
	 */
	public FHIRException handleErrorCode(ExceptionCodes fhirErrCode, String msg, Exception ex) {
		return logAndThrowError(fhirErrCode, msg, ex);
	}
	
	/**
	 * logs and throws the exception using input parameters
	 * 
	 * @param fhirErrCode
	 * @param msg
	 * @param ex
	 */
	private FHIRException logAndThrowError(ExceptionCodes fhirErrCode, String msg, Exception ex) {
		String logMsg = fhirErrCode.getCode() + ": " + msg;
		LOGGER.logError(LoggingMarkers.APPLICATION.getValue(), logMsg, ex);
		
		return new FHIRException(fhirErrCode.getCode());
	}
}

package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.r4.model.DavinciInsurancePlan;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.InsurancePlan;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 
 * This class is the InsurancePlan resource provider class
 * which will serves all supported read and search requests
 * for InsurancePlan resource
 *
 */
@Component
public class InsurancePlanResourceProvider implements IResourceProvider {

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
    @Autowired
    private ProviderDirectoryService service;
    
    /**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(InsurancePlanResourceProvider.class.getName());

    @Override
    public Class<? extends IBaseResource> getResourceType() {
        return DavinciInsurancePlan.class;
    }

    /**
     * This method will return InsurancePlan resource based on the provided id
     * @param theId
     * @return a single resource
     */
    @Read()
    public IBaseResource getResourceById(@IdParam IdType theId) {
        LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
        return service.getResourceById(theId.getIdPart(), ResourceType.InsurancePlan.name());
    }

    /**
     * This method will return the bundle of resources
     * based on the search parameters passed in the request
     * @param id
     * @param administeredBy,chainParameters{Organization.SP_IDENTIFIER,
     * Organization.SP_NAME}
     * @param coverageArea,chainParameters{Location.SP_IDENTIFIER}
     * @param name
     * @param ownedBy,chainParameters{Organization.SP_IDENTIFIER,
     * Organization.SP_NAME}
     * @param network,chainParameters{Organization.SP_IDENTIFIER, 
     * Organization.SP_NAME}
     * @param type
     * @param planType
     * @param includes{"InsurancePlan:administered-by", 
     * "InsurancePlan:owned-by", "InsurancePlan:coverage-area"}
     * @return bundle of resources
     */
    @Search()
    public IBundleProvider getInsurancePlan(
            @OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
            @OptionalParam(name = InsurancePlan.SP_ADMINISTERED_BY, chainWhitelist = {"", Organization.SP_IDENTIFIER, Organization.SP_NAME}) ReferenceAndListParam administeredBy,
            @OptionalParam(name = DavinciInsurancePlan.SP_COVERAGE_AREA, chainWhitelist = {"", Location.SP_IDENTIFIER}) ReferenceAndListParam coverageArea,
            @OptionalParam(name = InsurancePlan.SP_NAME) StringAndListParam name,
            @OptionalParam(name = InsurancePlan.SP_OWNED_BY, chainWhitelist = {"", Organization.SP_IDENTIFIER, Organization.SP_NAME}) ReferenceAndListParam ownedBy,
            @OptionalParam(name = DavinciInsurancePlan.SP_NETWORK, chainWhitelist = {"", Organization.SP_IDENTIFIER, Organization.SP_NAME}) ReferenceAndListParam network,
            @OptionalParam(name = InsurancePlan.SP_TYPE) TokenAndListParam type,
            @OptionalParam(name = DavinciInsurancePlan.SP_PLAN_TYPE) TokenAndListParam planType,
            @OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
            @IncludeParam(allow = {"InsurancePlan:administered-by", "InsurancePlan:owned-by", "InsurancePlan:coverage-area"}) Set<Include> includes

    ) {

    	SearchParameterRequest paramMap = new SearchParameterRequest();
        paramMap.add(IAnyResource.SP_RES_ID, theId);
        paramMap.add(InsurancePlan.SP_ADMINISTERED_BY, administeredBy);
        paramMap.add(DavinciInsurancePlan.SP_COVERAGE_AREA, coverageArea);
        paramMap.add(InsurancePlan.SP_NAME, name);
        paramMap.add(InsurancePlan.SP_OWNED_BY, ownedBy);
        paramMap.add(DavinciInsurancePlan.SP_NETWORK, network);
        paramMap.add(InsurancePlan.SP_TYPE, type);
        paramMap.add(DavinciInsurancePlan.SP_PLAN_TYPE, planType);
        paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
        if (includes != null && !includes.isEmpty()) {
        	paramMap.setIncludes(includes);
        }
        LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Search operation for parameters " + paramMap.toString());
        return service.getResources(paramMap, ResourceType.InsurancePlan.name());
    }
}
package com.citiustech.fastplus.model;

import com.citiustech.fastplus.adapter.structure.IdProjectionRow;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

/**
 * 
 * This is a class for SearchResult used to hold the set of resource ids,
 * includes and reverse includes
 * 
 */

public class SearchResult implements Serializable {

	/**
	 * This is a serialVersionUID field used to assign serial version uid to class
	 */
	private static final long serialVersionUID = 3681795677717741005L;
	
	/**
	 * This is a listOfResourceIds field used to hold resource ids
	 */
	private List<IdProjectionRow> listOfResourceIds;
	
	/**
	 * This is a setOfIncludes field used to hold included records
	 */
    private Set<String> setOfIncludes;
    
	/**
	 * This is a setOfRevIncludes field used to hold reverse included records
	 */
    private Set<String> setOfRevIncludes;

    /**
     * arguments constructor
     *  
     * @param listOfResourceIds
     * @param setOfIncludes
     * @param setOfRevIncludes
     */
    public SearchResult(List<IdProjectionRow> listOfResourceIds, Set<String> setOfIncludes,
                        Set<String> setOfRevIncludes) {
        super();
        this.listOfResourceIds = listOfResourceIds;
        this.setOfIncludes = setOfIncludes;
        this.setOfRevIncludes = setOfRevIncludes;
    }

    /**
     * No argument constructor
     */
    public SearchResult() {
        super();
    }

    /**
     * returns list of resource ids
     * 
     * @return resourceids
     */
    public List<IdProjectionRow> getListOfResourceIds() {
        return listOfResourceIds;
    }

    /**
     * returns set of includes for a resource
     * 
     * @return includes
     */
    public Set<String> getSetOfIncludes() {
        return setOfIncludes;
    }

    /**
     * returns set of reverse includes for a reasource
     * 
     * @return revIncludes
     */
    public Set<String> getSetOfRevIncludes() {
        return setOfRevIncludes;
    }

}

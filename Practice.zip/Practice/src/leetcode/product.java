package leetcode;

import java.util.ArrayList;

class ProductOfNumbers {
    static ArrayList<Integer> l=new ArrayList<Integer>();
 public ProductOfNumbers() {
 //IntStream stream = l.stream();
     //ArrayList<Integer> l=new ArrayList<Integer>();
  
 }
 public void add(int num) {
     ProductOfNumbers.l.add(num);
     
     
 }
 
 public int getProduct(int k) {
     int pro=1;
     int z=1;
     ProductOfNumbers.l.stream().forEach((X)->System.out.println("oo->"+X));
     System.out.println("size-->"+ (ProductOfNumbers.l.size()-1));
     for(int i=ProductOfNumbers.l.size()-1;i>=ProductOfNumbers.l.size()-k;i--){
         System.out.println(ProductOfNumbers.l.get(i));
         z=ProductOfNumbers.l.get(i);
         pro=pro*z;
     }
     return pro;
 }
}

/**
* Your ProductOfNumbers object will be instantiated and called as such:
* ProductOfNumbers obj = new ProductOfNumbers();
* obj.add(num);
* int param_2 = obj.getProduct(k);
*/

public class product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductOfNumbers p = new ProductOfNumbers();
		p.add(3);
		p.add(3);
		p.add(3);
		p.add(3);
		p.add(3);
		System.out.println(p.getProduct(2));

	}

}

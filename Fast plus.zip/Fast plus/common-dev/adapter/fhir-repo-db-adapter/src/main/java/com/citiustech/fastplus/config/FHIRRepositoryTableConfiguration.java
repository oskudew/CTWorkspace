package com.citiustech.fastplus.config;


import ca.uhn.fhir.model.api.TemporalPrecisionEnum;
import ca.uhn.fhir.rest.param.ParamPrefixEnum;

import com.citiustech.fastplus.util.AdapterUtil;
import com.healthmarketscience.sqlbuilder.CustomSql;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.RandomStringUtils;

/**
 * 
 * This is a class for FHIRRepositoryTableConfiguration which holds table
 * configuration for fhir repository
 * 
 */

@Getter
@Setter
public class FHIRRepositoryTableConfiguration {
	
	/**
	 * This is a searchTableMap field used to hold search param and table
	 * configuration in the form of map
	 */
    private Map<String, CommonTableConfiguration> searchTableMap = new HashMap<>();
    
	/**
	 * This is a resourceLinkTable field used to hold common table configuration for
	 * resourcelinktable
	 */
    private ResInfoLinkTableConfiguration resourceLinkTable;
    
    /**
	 * This is a resourceInfoTable field used to hold common table configuration for
	 * resourceinfotable
	 */
    private ResInfoLinkTableConfiguration resourceInfoTable;
    
    /**
	 * This is a typeColumnMap field used to hold type of column 
	 */
    private Map<String, List<String>> typeColumnMap = new HashMap<>();
    
    /**
	 * This is a jsonColumn field used to hold json column information 
	 */
    private String jsonColumn;
    
    /**
	 * This is a idColumn field used to hold id column information 
	 */
    private String idColumn;
    
    /**
	 * This is a valueColumn field used to hold value column information 
	 */
    private String valueColumn;
    
    /**
	 * This is a dbschema field used to hold database schema information 
	 */
    private String dbschema;
    
    /**
	 * This is a searchAttributeColumn field used to hold search attribute column information 
	 */
    private String searchAttributeColumn;
    
    /**
	 * This is a schema field used to hold schema information 
	 */
    private String schema;
    
    /**
	 * This is a pidColumn field used to hold patient id column information 
	 */
    private String pidColumn;
    
    /**
	 * This is a lastUpdated field used to hold last updated date time for a record 
	 */
    private String lastUpdated;
    
    /**
	 * This is a resourceType field used to hold resource Type
	 */
    private String resourceType;

    /**
     * No arguments constructor
     */
    public FHIRRepositoryTableConfiguration() {
    }

	/**
	 * parameterized constructor to initialize object with required values
	 * 
	 * @param searchTableMap
	 * @param resourceLinkTable
	 * @param resourceInfoTable
	 */
    public FHIRRepositoryTableConfiguration(Map<String, CommonTableConfiguration> searchTableMap,
    										ResInfoLinkTableConfiguration resourceLinkTable,
    										ResInfoLinkTableConfiguration resourceInfoTable) {

        this.searchTableMap = searchTableMap;
        this.resourceLinkTable = resourceLinkTable;
        this.resourceInfoTable = resourceInfoTable;
    }

    public void duplicateTypeMap() {
        searchTableMap.values().stream().forEach(s ->
                s.setTypeColumnMap(typeColumnMap));
        resourceLinkTable.setTypeColumnMap(typeColumnMap);
    }

    /**
     * returns list of columns to be search for input type and resource
     * 
     * @param type
     * @param resource
     * @return list of CustomSql
     */
    public List<CustomSql> getSearchColumn(String type, String resource) {
        return this.searchTableMap.get(resource).getTypeColumnMap().get(type)
                .stream()
                .map(c -> new CustomSql(AdapterUtil.getAliasedColumn(resource, c)))
                .collect(Collectors.toList());
    }
    
    /**
     * returns list of columns to be search for data 
     * 
     * @param type
     * @param resource
     * @param precision
     * @param alias
     * @param prefix
     * @return list of CustomSql
     */
    public List<CustomSql> getSearchColumnForDate(String type, String resource, TemporalPrecisionEnum precision,
			String alias, ParamPrefixEnum prefix) {
		return this.searchTableMap.get(resource).getTypeColumnMap().get(type).stream().map(column -> {
			if (ParamPrefixEnum.LESSTHAN.equals(prefix) || ParamPrefixEnum.LESSTHAN_OR_EQUALS.equals(prefix)
					|| ParamPrefixEnum.GREATERTHAN.equals(prefix)
					|| ParamPrefixEnum.GREATERTHAN_OR_EQUALS.equals(prefix)) {
				return new CustomSql(alias + "." + column);
			} else {
				return new CustomSql(AdapterUtil.getCastedColumn(alias, column, precision));
			}
		}).collect(Collectors.toList());
	}

    /**
     * returns list of columns to be search for input type, resource and alias
     * 
     * @param type
     * @param resource
     * @param alias
     * @return list of CustomSql
     */
    public List<CustomSql> getSearchColumn(String type, String resource, String alias) {
        return this.searchTableMap.get(resource).getTypeColumnMap().get(type)
                .stream()
                .map(c -> new CustomSql(AdapterUtil.getAliasedColumn(alias, c)))
                .collect(Collectors.toList());
    }
    
    public List<CustomSql> getProjectionColumn(String type, String alias) {
        return this.getTypeColumnMap().get(type)
                .stream()
                .map(c -> new CustomSql(AdapterUtil.getAliasedColumn(alias, c)))
                .collect(Collectors.toList());
    }

    /**
     * returns column information with alias for a type
     * 
     * @param tableConfiguration
     * @param paramName
     * @return CustomSql
     */
    public CustomSql getColumn(CommonTableConfiguration tableConfiguration, String paramName) {
        return tableConfiguration.getColumnWithAliasForType(paramName).get(0);
    }

    /**
     * returns actual 
     * 
     * @param resource
     * @param paramName
     * @return list of param names
     */
    public List<String> getActualParamNames(String resource, String paramName) {
        Map<String, List<String>> nestedsearchAttributes = this.searchTableMap.get(resource).getNestedsearchAttributes();
        return (Objects.isNull(nestedsearchAttributes) || nestedsearchAttributes.isEmpty()) ? new ArrayList<>():
                this.searchTableMap.get(resource).getNestedsearchAttributes().get(paramName)
               ;
    }

   
    /**
     * returns search attribute column by input resource
     * 
     * @param resource
     * @return CustomSql
     */
    public CustomSql getSearchAttributeColumn(String alias) {
        return new CustomSql(AdapterUtil.getAliasedColumn(alias, this.searchAttributeColumn));
    }

    
    /**
     * returns search attribute column 
     */
    public String getSearchAttributeColumn() {
        return searchAttributeColumn;
    }

	/**
	 * sets search attribute column name
	 * 
	 * @param searchAttributeColumn
	 */
    public void setSearchAttributeColumn(String searchAttributeColumn) {
        this.searchAttributeColumn = searchAttributeColumn;
    }

	public String getRandomString() {
		
		return RandomStringUtils.randomAlphabetic(4);
	}

}

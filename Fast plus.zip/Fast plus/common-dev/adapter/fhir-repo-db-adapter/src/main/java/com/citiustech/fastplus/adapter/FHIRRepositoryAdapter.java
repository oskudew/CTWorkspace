package com.citiustech.fastplus.adapter;

import static com.citiustech.fastplus.util.AdapterUtil.getAliasedColumn;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.hl7.fhir.r4.model.Enumerations.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.Adapter;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.dao.FHIRRepositoryDAO;
import com.citiustech.fastplus.adapter.dao.QueryConstants;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.config.ResInfoLinkTableConfiguration;
import com.citiustech.fastplus.querybuilder.DeepNestedSqlBuilder;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.InCondition;
import com.healthmarketscience.sqlbuilder.UnaryCondition;

import ca.uhn.fhir.model.api.Include;

/**
 * 
 * This is a class for FHIRRepositoryAdapter which act as a implementation for Adapter interface and provides concrete logic 
 *  
 * defines methods to interact with dao classes
 * to perform operations related to a resource
 * 
 */	

@Component
public class FHIRRepositoryAdapter implements Adapter {

	
	/**
	 * This is a REFERENCE_PARAM field used to hold string ReferenceParam
	 */
	private static final String REFERENCE_PARAM = "reference";
	
	/**
	 * This is a fhirRepositoryDao field used to hold fhirRepositoryDao object
	 */
	@Autowired
	private FHIRRepositoryDAO fhirRepositoryDao;

	/**
	 * This is a tableConfig field used to hold FHIRRepositoryTableConfiguration object
	 */
	@Autowired
	private FHIRRepositoryTableConfiguration tableConfig;

	/**
	 * This is a sqlBuilder field used to hold DeepNestedSqlBuilder object
	 */
	@Autowired
	private DeepNestedSqlBuilder sqlBuilder;
	
	/**
	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
	 */
	@Autowired
    private FHIRErrorHandler fhirErrorHandler;
	
	/**
	 * This is a commonQueryUtil field used to hold CommonQueryUtil object
	 */
    @Autowired
    private CommonQueryUtil commonQueryUtil;

	@Override
	public List<String> getResourceJsons(List<Serializable> ids, String resourceType) {
			return fhirRepositoryDao.executeForString(
					frameJsonRetrievalQuery(ids, tableConfig, resourceType),ids);
	}

	@Override
	public Map<String, List<String>> getResourceJsons(Map<String, List<Serializable>> resourceIdsMap)
			{
		return resourceIdsMap
				.entrySet()
				.stream()
				.collect(
						Collectors.toMap(
								Map.Entry::getKey,
								e -> fhirRepositoryDao.executeForString(
										frameJsonRetrievalQuery(
												e.getValue(),
												tableConfig,
												e.getKey()),e.getValue())));

	}

	@Override
	public List<IdProjectionRow> getIdsForResource(String resourceType, SearchParameterRequest parameterMap)
	{
		List<IdProjectionRow> projectionRows = fhirRepositoryDao
				.executeForIds(sqlBuilder.buildNestedQueriesForSearchParams(resourceType, parameterMap));
		return projectionRows.stream().map(id -> {
			id.setResourceType(resourceType);
			return id;
		}).collect(Collectors.toList());
	}

	@Override
	public Map<String, List<Serializable>> getIncludedIds(List<IdProjectionRow> listOfBaseIds,
			Set<Include> setOfIncludes, String resourceType) {
		return fhirRepositoryDao.executeForMapData(frameIncludeQuery(listOfBaseIds, setOfIncludes, resourceType));
	}

	/**
	 * returns a include query by building it in string format using input
	 * parameters
	 * 
	 * @param listOfBaseIds
	 * @param setOfIncludes
	 * @param resourceType
	 * @return include query
	 */
	private String frameIncludeQuery(List<IdProjectionRow> listOfBaseIds, Set<Include> setOfIncludes, String resourceType) {
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
				tableConfig, resourceType);
		try {
			setOfIncludes.stream().forEach(include -> commonQueryUtil.validateParamValue(include.getValue(), true));
			ComboCondition condition = null;
			ResInfoLinkTableConfiguration configuration = tableConfig.getResourceLinkTable();
			String table = configuration.getTable().get(0);
			queryBuilder.setFromTable(table, table);

			queryBuilder.setProjections(new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(2)),
					new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(0)));

			if (setOfIncludes.stream().anyMatch(include -> include.getValue().equals("*"))) {
				condition = ComboCondition.and(new InCondition(new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(3)), listOfBaseIds.stream().map(
						IdProjectionRow::getSourceId).collect(Collectors.toList())),
						UnaryCondition.isNotNull(new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(0))));
				
			}else {
				condition = ComboCondition.and(new InCondition(new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(3)), listOfBaseIds.stream().map(
						IdProjectionRow::getSourceId).collect(Collectors.toList())),
						new InCondition(new CustomSql(tableConfig.getSearchAttributeColumn()), setOfIncludes.stream().map(Include::getParamName)
								.collect(Collectors.toList())));
			}
			Condition srctypeCondition = BinaryCondition.equalTo(new CustomSql(configuration.getColumnForType(table, REFERENCE_PARAM).get(1)), resourceType);
			queryBuilder.addCondition(ComboCondition.and(srctypeCondition, condition));
			return queryBuilder.build();
		} catch (FHIRException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);	
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}


	@Override
	public Map<String, List<Serializable>> getRevIncludedIds(List<IdProjectionRow> listOfBaseIds, Set<Include> setOfRevIncludes, String resourceType){
		return fhirRepositoryDao.executeForMapData(frameRevIncludeQuery(listOfBaseIds ,setOfRevIncludes,resourceType));
	}

	/**
	 * returns a reverse include query by building it in string format using input
	 * parameters
	 * 
	 * @param listOfBaseIds
	 * @param setOfRevIncludes
	 * @param resourceType
	 * @return reverse include query
	 */
	private String frameRevIncludeQuery(List<IdProjectionRow> listOfBaseIds,Set<Include> setOfRevIncludes,  String resourceType) {
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
				tableConfig, resourceType);
		ResInfoLinkTableConfiguration configuration = tableConfig.getResourceLinkTable();
		
		try {
			setOfRevIncludes.stream().forEach(include -> commonQueryUtil.validateParamValue(include.getValue(), true));
			String tableAlias;
			String table = tableAlias = configuration.getTable().get(0);
			if(ResourceType.PROVENANCE.toString().equalsIgnoreCase(resourceType))
				table = configuration.getTable().get(1);
			
			queryBuilder.setFromTable(table,tableAlias);

			queryBuilder.setProjections(new CustomSql(configuration.getColumnForType(tableAlias,REFERENCE_PARAM).get(3)),
					new CustomSql(configuration.getColumnForType(tableAlias,REFERENCE_PARAM).get(1))
					);

			ComboCondition condition= ComboCondition.and(new InCondition(new CustomSql(configuration.getColumnForType(tableAlias,REFERENCE_PARAM).get(2)), listOfBaseIds.stream().map(
					IdProjectionRow::getSourceId
					).collect(Collectors.toList()))
					,
					new InCondition(new CustomSql(configuration.getColumnForType(tableAlias,REFERENCE_PARAM).get(1)), setOfRevIncludes.stream().map(
							Include::getParamType
							).collect(Collectors.toList()))
					,
					new InCondition(new CustomSql(tableConfig.getSearchAttributeColumn()), setOfRevIncludes.stream().map(
							Include::getParamName
							).collect(Collectors.toList())));

			queryBuilder.addCondition(condition);
			return queryBuilder.build();
		} catch (FHIRException e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);	
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}

	/**
	 * returns a json retrieval query in string format by building it using input
	 * parameters
	 * 
	 * @param ids
	 * @param tableConfig
	 * @param resourceType
	 * @return query
	 */
	private String frameJsonRetrievalQuery(List<Serializable> ids, FHIRRepositoryTableConfiguration tableConfig,
			String resourceType) {
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
				tableConfig, resourceType);
		try {
			String tableAlias;
			String table = tableAlias = tableConfig.getResourceInfoTable().getTable().get(0);
			if(ResourceType.PROVENANCE.toString().equalsIgnoreCase(resourceType)) {
				table = tableConfig.getResourceInfoTable().getTable().get(1);
				queryBuilder.setFromTable(table,tableAlias);
			}else if(ResourceType.SUBSCRIPTION.toString().equalsIgnoreCase(resourceType)){
				table = tableConfig.getResourceInfoTable().getTable().get(2);
				queryBuilder.setFromTable(table,tableAlias,QueryConstants.SUBSCRIPTIONS_SCHEMA);
			}else {
				queryBuilder.setFromTable(table,tableAlias);
				
			}
			
			queryBuilder.setProjections(
					new CustomSql(tableConfig.getIdColumn()),
					new CustomSql(tableConfig.getJsonColumn()));
			
			Condition inCondition = new InCondition(new CustomSql(getAliasedColumn(
					tableAlias, tableConfig.getIdColumn())), ids);
			Condition resourceTypeCondition = BinaryCondition.equalTo(new CustomSql(
					getAliasedColumn(tableAlias, tableConfig.getResourceType())),
					resourceType);		
			queryBuilder.addCondition(ComboCondition.and(resourceTypeCondition, inCondition));
			
			return queryBuilder.build();
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}

	
	
	@Override
	public List<IdProjectionRow> getPaginatedIdsForResource(String resourceType, SearchParameterRequest searchParameterReq) {
		List<IdProjectionRow> projectionRows = fhirRepositoryDao
				.executeForIds(sqlBuilder.buildNestedPaginatedQueriesForSearchParams(resourceType, searchParameterReq));
		return projectionRows.stream().map(id -> {
			id.setResourceType(resourceType);
			return id;
		}).collect(Collectors.toList());
	}
}
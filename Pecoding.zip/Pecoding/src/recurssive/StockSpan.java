package recurssive;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class StockSpan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int[] arr= new int[a];
		int[] arr1= new int[a];
		
		for(int i =0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		
		Stack<Integer> s1= new Stack<>();
		Stack<Integer> s2= new Stack<>();
		s2.push(1);
		s1.push(arr[0]);
		arr1[0]=1;
		for(int i=1;i<a;i++) {
			int sum =1;
			while(!s1.isEmpty() && s1.peek()<=arr[i]){
				s1.pop();
				sum =sum+s2.peek();
				s2.pop();
			}
			s1.push(arr[i]);
			s2.push(sum);
			arr1[i]=sum;
			
		}
		System.out.println(Arrays.toString(arr1));
		
		System.out.println(Arrays.toString(optimise(arr)));

	}
	public static int[] optimise(int[] arr) {
		Stack<Integer> st= new Stack<>();
		int[] span = new int[arr.length];
		st.push(0);
		span[0]=1;
		for(int i =1;i<arr.length;i++) {
			while(st.size()>0 && arr[i]>arr[st.peek()]) {
				st.pop();
			}
			if(st.size()==0) {
				span[i]=i+1;
				
			}
			else {
				span[i]=i-st.peek();
				
			}
			st.push(i);
		}
		return span;
		
	}

}

package com.citiustech.fastplus.querybuilder.types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.UriParam;

/**
*
* This is a class for UriParamQueryFragmentBuilder which used to build
* query fragments for uri search parameters
*
*/
@Component
public class UriParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<UriParam> {

	/**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
	private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	/**
   	 * This is a commonQueryUtil field used to hold CommonQueryUtil object
   	 */
	private CommonQueryUtil commonQueryUtil;
	
	
	@Autowired
	public UriParamQueryFragmentBuilder(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			CommonQueryUtil commonQueryUtil) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.commonQueryUtil = commonQueryUtil;
	}

	public UriParamQueryFragmentBuilder() {
		
	}

	/**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
	@Override
	public Condition frameQueryFragment(QueryBuilder queryBuilder, String resourceType, String alias,
			UriParam paramType, String paramName) {
	    commonQueryUtil.validateParamValue(paramType.getValue(), true);

	    Condition condition = BinaryCondition
		    .equalTo(fhirRepositoryTableConfiguration.getSearchAttributeColumn(alias), paramName);

		/**
		 * String qualifier = paramType.getQueryParameterQualifier(); 
		 * For exact we are getting qualifier value as null which is default 
		 * implementation of FHIR so we are not providing extra support for exact 
		 * as the behavior is similar to normal implementation
		 */
		condition = ComboCondition.and(condition, BinaryCondition.equalTo(
				fhirRepositoryTableConfiguration.getSearchColumn(ParamType.URI.getValue(), resourceType, alias).get(0),
				paramType.getValue()));
		return condition;
	}

}

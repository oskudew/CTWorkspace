package com.java.conference.Service;

import java.util.List;

import com.java.conference.Repository.SpeakerRepository;
import com.java.conference.model.Speaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service("speakerService")
@Scope(value= BeanDefinition.SCOPE_SINGLETON)
public class SpeakerServiceImpl implements SpeakerService {

	@Autowired
	private SpeakerRepository repo;

	public SpeakerServiceImpl(){
		System.out.println("no args constructor call");
	}

	//@Autowired
	public SpeakerServiceImpl(SpeakerRepository repo){
		System.out.println("SpeakerService arg");
		this.repo= repo;
	}
	//SpeakerRepository repo = new HibernateSpeakerRepositoryImpl();

	//@Autowired
	public void setRepo(SpeakerRepository repo) {
		System.out.println("calling setter Injection");
		this.repo = repo;
	}
	
	public List<Speaker> findAll(){
		return repo.findAll();
	}
	
	
}

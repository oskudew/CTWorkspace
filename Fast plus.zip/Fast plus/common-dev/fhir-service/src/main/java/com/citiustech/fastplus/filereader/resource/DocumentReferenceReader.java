package com.citiustech.fastplus.filereader.resource;

import java.util.List;
import java.util.stream.Collectors;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.DocumentReference.DocumentReferenceContentComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.filereader.FileReaderUtils;
/**
 * 
 * This is a class for DocumentReference Resource used as implementation for IResourceReader
 * to read resource attachment data from shared location.
 *
 */
@Component(value = "DocumentReferenceReader")
public class DocumentReferenceReader implements IResourceReader {

	@Autowired
	FileReaderUtils readerUtil;

	@Override
	public void readAttachment(List<IBaseResource> resources) {
		List<DocumentReference> docrefs = resources.stream().filter(rs -> rs instanceof DocumentReference)
				.map(rs -> (DocumentReference) rs).collect(Collectors.toList());
		readDocumentReferanceAttachment(docrefs);
	}

	/**
	 * iterate over Contract resources and set the attachment data using URL.
	 * 
	 * @param resources
	 */
	private void readDocumentReferanceAttachment(List<DocumentReference> resources) {

		long totalAttachmentSize = 0;
		for (DocumentReference df : resources) {
			for (DocumentReferenceContentComponent content : df.getContent()) {
				totalAttachmentSize = readerUtil.setAttachmentdata(content.getAttachment(), totalAttachmentSize);
			}
		}
	}

}

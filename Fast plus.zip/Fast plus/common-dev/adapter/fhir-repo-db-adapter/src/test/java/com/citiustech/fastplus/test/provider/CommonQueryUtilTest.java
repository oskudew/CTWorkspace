package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.CustomResourceUtil;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.citiustech.fastplus.util.exception.FHIRException;

import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;


@ExtendWith(MockitoExtension.class)
class CommonQueryUtilTest {

	  @InjectMocks
	  private static CommonQueryUtil commonQueryUtil;
	
	  @Spy
	  private FHIRErrorHandler fhirErrorHandler;
	
	  @Mock
	  private CustomResourceUtil customResourceUtil;
	
	  @DisplayName("Test case to validate param value")
	  @Test 
	  void test_validateParamValue() {
		  String param="";	  
		  boolean isRequired = true; 
		  
		  FHIRException exception = assertThrows(FHIRException.class,() -> 
		  commonQueryUtil.validateParamValue(param,isRequired));
		  assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(),exception.getMessage());
	  
	  }
	
	  @DisplayName("Test case to validate param value when invalid special char")
	  @Test 
	  void test_validateParamValueInvalidSpecialChar() {
		  String param="ABC%6";	  
		  boolean isRequired = false; 
		  commonQueryUtil.setInvalidSpecialCharacters("%");
		  
		  FHIRException exception = assertThrows(FHIRException.class,() -> 
		  commonQueryUtil.validateParamValue(param,isRequired));
		  assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(),exception.getMessage());
	  
	  }
	  
	
	  @DisplayName("Test case for Valid date and time")
	  @Test 
	  void test_isInvalidDateTimeWithValidFormat() {
		  
		  boolean isinvalid = false; 
		  boolean testresult =commonQueryUtil.isInvalidDateTime("19-11-1987 23:55:21");
		  
		  assertEquals(isinvalid,testresult);
	  
	  }
	
	
	  @DisplayName("Test case for inValid date and time")
	  @Test 
	  void test_isInvalidDateTimeWithInvalidFormat() {
		  
		  boolean isinvalid = true; 
		  boolean testresult =commonQueryUtil.isInvalidDateTime("09134-1@1-199276 %12:0044:0097654");
		  
		  assertEquals(isinvalid,testresult);
	  
	  }
	
	  @DisplayName("Test case to find prefix value for blank clientprefix")
	  @Test 
	  void test_findPrefixValue() {
	  
		  String resourceType = "Patient"; 
		  String idValue = "Kern-pat-90001";
		  commonQueryUtil.setClientPrefix("");
		  
		  String prefix = commonQueryUtil.findPrefixValue(resourceType,idValue);
		  assertEquals(idValue,prefix); 
	  
	  }

	  @DisplayName("Test case to find prefix value when clientprefix not blank and Idvalue start with clientprefix")
	  @Test 
	  void test_findPrefixValueForClientprefixNotBlank() {
		  
		  String resourceType = "Patient"; 
		  String idValue = "Kern-pat-90001";
		  
		  commonQueryUtil.setClientPrefix("Kern");
		  
		  String prefix = commonQueryUtil.findPrefixValue(resourceType,idValue);
		  
		  assertEquals(idValue,prefix); 
	  
	  }
	 
	
	  @DisplayName("Test case to find prefix value for not blank clientprefix and Idvalue not start with clientprefix")
	  @Test
	  void test_findPrefixValueForClientprefixNotBlankIdvalNotStartWithPrefix() {
			
		  String resourceType = "Patient";
		  String idValue = "Tern-pat-90001";
		  String idValReturned = "Kern-pat-Tern-pat-90001";
				
		  commonQueryUtil.setClientPrefix("Kern");
		  String prefix = commonQueryUtil.findPrefixValue(resourceType,idValue);
			
		  assertEquals(idValReturned,prefix);
	  
	 }
	
	  @DisplayName("Test case for find prefix value for blank clientprefix method with one parameter")
	  @Test 
	  void test_findPrefixValueWithOneParam() {
	  
		  String idValue = "Kern-90001";
		  String prefix = commonQueryUtil.findPrefixValue(idValue);
		  assertEquals(idValue,prefix); 
	  
	  }

	  @DisplayName("Test case for find prefix value for not blank clientprefix method with one parameter")
	  @Test 
	  void test_findPrefixValueWithOneParamClientprefixNotBlank() {
	  
		  String idValue = "Kern-90001";
		  commonQueryUtil.setClientPrefix("Kern");
		  String prefix = commonQueryUtil.findPrefixValue(idValue);
		  assertEquals(idValue,prefix); 
	  
	  }
	  
	  @DisplayName("Test case for find prefix value for not blank clientprefix and Idvalue not start with clientprefix method with one parameter")
	  @Test 
	  void test_findPrefixValueWithOneParamClientprefixNotBlankIdValNotStartWithPrefix() {
	  
		  String idValue = "Tern-90001";
		  String idValReturned = "Kern-%%-Tern-90001";
		  commonQueryUtil.setClientPrefix("Kern");
		  String prefix = commonQueryUtil.findPrefixValue(idValue);
		  assertEquals(idValReturned,prefix); 
	  
	  }
	  
	  
	  @DisplayName("Test case for getTargetReferenceList")
	  @Test
	  void test_getTargetReferenceList() throws NoSuchFieldException, ClassNotFoundException {
		  
		  String resourceType = ResourceType.Patient.name();
		  String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		  String paramName = "Age";
		  TokenAndListParam param = new TokenAndListParam();
		  param.addAnd(new TokenParam(value));
				
	      List<String> projectionRows = new ArrayList<>();
	
		  when(customResourceUtil.getReferenceTargetList(resourceType, paramName)).thenReturn(projectionRows);
	
		  List<String> actualValue = commonQueryUtil.getTargetReferenceList(resourceType, paramName);
		  List<String> expectedValue = projectionRows;
	
		  assertEquals(expectedValue.toString(), actualValue.toString());

		}
	    
	    
	  @DisplayName("Test case for getTargetReferenceList with exception")
	  @Test
	  void test_getTargetReferenceListException() throws NoSuchFieldException, ClassNotFoundException {
		  
		  String resourceType = ResourceType.Patient.name();
		  String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		  String paramName = "Age";
		  TokenAndListParam param = new TokenAndListParam();
		  param.addAnd(new TokenParam(value));
				
		  when(customResourceUtil.getReferenceTargetList(resourceType, paramName)).thenThrow( new FHIRException(ExceptionCodes.QUERY_ERROR.getCode()));
		  FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> commonQueryUtil.getTargetReferenceList(resourceType, paramName));
				
		  assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());
		
	  }
	    

	  @DisplayName("Test case for getTargetReferenceList with Classnotfound exception")
	  @Test
	  void test_getTargetReferenceListExceptionClassNotFound() throws NoSuchFieldException, ClassNotFoundException {
		  
		  String resourceType = ResourceType.Patient.name();
		  String value = "8d38f846-b98a-3010-565c-4f91be9ff3fc";
		  String paramName = "Age";
		  TokenAndListParam param = new TokenAndListParam();
		  param.addAnd(new TokenParam(value));
				
		  when(customResourceUtil.getReferenceTargetList(resourceType, paramName)).thenThrow( new ClassNotFoundException());
		  FHIRException exception = Assertions.assertThrows(FHIRException.class,() -> commonQueryUtil.getTargetReferenceList(resourceType, paramName));
				
		  assertEquals(ExceptionCodes.QUERY_ERROR.getCode(), exception.getMessage());
		
	  }

}

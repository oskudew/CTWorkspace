package Java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc = new Scanner(System.in);
		Integer[] arr= {1,2,3,6,3,2,4,5};
		//String[] arr1= {"ab","dsdsaad","bcsdd","","kps"};
		String arr2 = "Abcdefdg";
		reverseArray(arr2);
		reverseArray(arr);
		
	}
	public static void reverseArray(Integer[] arr) {
	 List<Integer> ltr= Arrays.asList(arr);
	 //Collections.reverse(ltr);
	 System.out.println(ltr.stream().mapToInt(x->x).summaryStatistics());
	 System.out.println(ltr.stream().max(Comparator.naturalOrder()));
	 System.out.println(ltr.stream().mapToInt(x->x).average());
	 System.out.println(ltr.stream().mapToInt(x->x).sum());
	}
	
	public static void reverseArray(String arr2) {
		System.out.println(Stream.of(arr2).map(i->new StringBuffer(i).reverse()).collect(Collectors.joining()));
	}
	
	

}

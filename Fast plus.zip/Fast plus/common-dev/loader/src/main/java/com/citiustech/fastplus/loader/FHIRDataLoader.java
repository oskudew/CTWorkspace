package com.citiustech.fastplus.loader;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.citiustech.fastplus.loader.entity.FhirResourceData;
import com.citiustech.fastplus.loader.entity.ReferenceLink;
import com.citiustech.fastplus.loader.entity.Search;
import com.citiustech.fastplus.loader.entity.ValueHolder;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;

import net.minidev.json.JSONArray;

@Service
public class FHIRDataLoader {

    private static final Logger logger = LoggerFactory.getLogger(FHIRDataLoader.class);
    private static final String VALUECONST = "Value";
    private static final String STARTVALUE = "StartValue";
    private static final String VALUEQUANTITY = "valueQuantity";
    private static final String URNUUID = "urn:uuid:";

    /**
     * @param resourceType
     * @param json
     * @param config
     * @return
     */
    public FhirResourceData parse(final String resourceType, final String json, final String config) {
        FhirResourceData fhirResourceData = new FhirResourceData();
        logger.info("Processing {} records ..." , resourceType);
        Object jsonDocument = Configuration.defaultConfiguration().jsonProvider().parse(json);
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(config);
        int length = JsonPath.read(document, "$.length()");
        List<Search> searches = new ArrayList<>();
        List<ReferenceLink> references = new ArrayList<>();
        String id = null;
        String patientId = null;
        patientId = extractPatientId(document,jsonDocument, "$.[0].patientidPath");
        String lastUpdated = extractStringValue(jsonDocument, "$.meta.lastUpdated");

        for (int index = 0; index < length; index++) {
            String attribute = extractValue(document, "$.[" + index + "].attribute").toString();
            String searchType = extractValue(document, "$.[" + index + "].searchType").toString();
            String jsonpath = extractValue(document, "$.[" + index + "].jsonpath").toString();
            String jsonType = extractValue(document, "$.[" + index + "].jsonType").toString();
            String idPath = extractValue(document, "$.[" + index + "].idPath").toString();

            Object object = null;
            id = (String) extractValue(jsonDocument, idPath);
            object = extractValue(jsonDocument, jsonpath);
            if (object != null && (!object.toString().isEmpty())) {
            	List<ValueHolder> values = new ArrayList<>();
                switch (jsonType) {
                    case "code":
                        values = extractCodeValue(jsonDocument, jsonpath, "Code");
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "string":
                    case "id":
                    case "url":
                    	values = extractCodeValue(jsonDocument, jsonpath, VALUECONST);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "date":
                    	values = extractCodeValue(jsonDocument, jsonpath, STARTVALUE);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "identifier":
                    	values = extractIdentifier(jsonDocument, values, jsonpath);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "referenceSearchId":
                    	values = extractReferenceSearchId(jsonDocument,values, jsonpath);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "period":
                    	values = extractPeriod(jsonDocument, values, jsonpath);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "CodeableConcept":
                    case "CodeableConceptValue":
                    case VALUEQUANTITY:
                    	values = extractCodeableConcept(jsonDocument,values, jsonpath, jsonType);
                        searches.addAll(populateSearch(values, attribute, searchType, id, patientId, lastUpdated));
                        break;
                    case "reference":
                        extractReference(resourceType, jsonDocument, references, id, attribute, jsonpath);
                        break;
                    default:
                        logger.debug("No such jsonType supported...");
                        break;
                }
            } else {
                logger.info("No value for attribute in json... Skipping :- {}", attribute);
            }
        }
        fhirResourceData.setResourceId(id);
        fhirResourceData.setResourceName(resourceType);
        fhirResourceData.setJsonStr(json);
        fhirResourceData.setReferences(references);
        fhirResourceData.setSearches(searches);
        return fhirResourceData;
    }

    private List<ValueHolder> extractReferenceSearchId(Object jsonDocument,List<ValueHolder> values, String jsonpath) {
        final Object refObject = extractValue(jsonDocument, jsonpath);
        if (refObject instanceof JSONArray) {
            JSONArray refObjects = (JSONArray) refObject;
            for (Object obj : refObjects) {
                if (obj instanceof String) {
                    String value = (String) obj;
                    if (value.length() > 0) {
                        splitTargetReference(values, value);
                    }
                }
            }
        } else if (refObject instanceof String) {
            String tgtReference = (String) refObject;
            if (tgtReference.length() > 0) {
                splitTargetReference(values, tgtReference);
            }
        }
        return values;
    }

    private void splitTargetReference(List<ValueHolder> values, String tgtReference) {
        ValueHolder valueHolder=new ValueHolder();
        final String[] tgt = tgtReference.split("/");
        if (tgt.length == 2) {
            valueHolder.setValue(tgt[1]);
            valueHolder.setTrgtType(tgt[0]);
        } else if (tgt.length == 1) {
            final String lId = tgt[0];
            if (lId.startsWith(URNUUID)) {
                valueHolder.setValue(tgt[0].substring(9));
            } else {
                valueHolder.setValue(tgt[0]);
            }
        }
        values.add(valueHolder);
    }

    private void extractReference(String resourceType, Object jsonDocument, List<ReferenceLink> references, String id, String attribute, String jsonpath) {
        final Object refObject = extractValue(jsonDocument, jsonpath);
        if (refObject instanceof JSONArray) {
            JSONArray refObjects = (JSONArray) refObject;
            for (Object obj : refObjects) {

                if (obj instanceof String) {
                    String value = (String) obj;
                    if (value.length() > 0) {
                        splitReferenceSearch(resourceType, references, id, attribute, value);
                    }
                }
            }
        } else if (refObject instanceof String) {
            String tgtReference = (String) refObject;
            if (tgtReference.length() > 0) {
                splitReferenceSearch(resourceType, references, id, attribute, tgtReference);
            }
        }
    }

    private void splitReferenceSearch(String resourceType, List<ReferenceLink> references, String id, String attribute, String tgtReference) {
        final String[] tgt = tgtReference.split("/");
        ReferenceLink rlink = new ReferenceLink();
        rlink.setSrcId(id);
        rlink.setSrcType(resourceType);
        if (tgt.length == 2) {
            rlink.setTgtId(tgt[1]);
            rlink.setTgtType(tgt[0]);
        } else if (tgt.length == 1) {
            final String lId = tgt[0];
            if (lId.startsWith(URNUUID))
                rlink.setTgtId(tgt[0].substring(9));
            else
                rlink.setTgtId(tgt[0]);
        }
        rlink.setAttribute(attribute);
        references.add(rlink);
    }

    private List<ValueHolder> extractCodeableConcept(Object jsonDocument,List<ValueHolder> values, String jsonpath, String jsonType) {
        String valueType = VALUECONST;
        if (jsonType.equals("CodeableConcept")) {
            valueType = "display";
        }

        Object refObject = extractValue(jsonDocument, jsonpath);
        if (refObject instanceof JSONArray && !((JSONArray) refObject).isEmpty()) {
            JSONArray refObjects = (JSONArray) refObject;
            for (int sIndex = 0; sIndex < refObjects.size(); sIndex++) {
                ValueHolder valueHolder = new ValueHolder();
                valueHolder.setSystem(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault("system", "")));
                valueHolder.setCode(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault("code", "")));
                valueHolder.setValue(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault(valueType, "")));
                if (jsonType.equals(VALUEQUANTITY)) {
                    valueHolder.setUnit(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault("unit", "")));
                }
                values.add(valueHolder);
            }
        } else if (refObject instanceof LinkedHashMap) {
            ValueHolder valueHolder = new ValueHolder();
            valueHolder.setSystem(String.valueOf(((LinkedHashMap) refObject).getOrDefault("system", "")));
            valueHolder.setCode(String.valueOf(((LinkedHashMap) refObject).getOrDefault("code", "")));
            valueHolder.setValue(String.valueOf(((LinkedHashMap) refObject).getOrDefault(valueType, "")));
            if (jsonType.equals(VALUEQUANTITY)) {
                valueHolder.setUnit(String.valueOf(((LinkedHashMap) refObject).getOrDefault("unit", "")));
            }
            values.add(valueHolder);
        }
        return values;
    }

    private List<ValueHolder> extractPeriod(Object jsonDocument, List<ValueHolder> values, String jsonpath) {
        Object refObject = extractValue(jsonDocument, jsonpath);
        if (refObject instanceof JSONArray && !((JSONArray) refObject).isEmpty()) {
            JSONArray refObjects = (JSONArray) refObject;
            for (int sIndex = 0; sIndex < refObjects.size(); sIndex++) {
                ValueHolder valueHolder = new ValueHolder();
                valueHolder.setStartvalue(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault("start", "")));
                valueHolder.setEndvalue(String.valueOf(((LinkedHashMap) ((JSONArray) refObject).get(sIndex)).getOrDefault("end", "")));
                values.add(valueHolder);
            }
        } else if (refObject instanceof LinkedHashMap) {
            ValueHolder valueHolder = new ValueHolder();
            valueHolder.setStartvalue(String.valueOf(((LinkedHashMap) refObject).getOrDefault("start", "")));
            valueHolder.setEndvalue(String.valueOf(((LinkedHashMap) refObject).getOrDefault("end", "")));
            values.add(valueHolder);
        }
        return values;
    }

    private List<ValueHolder> extractCodeValue(Object jsonDocument, String jsonpath, String code) {
        Object object;
        object = extractValue(jsonDocument, jsonpath);
        return explode(object, code);
    }

    private List<ValueHolder> extractIdentifier(Object jsonDocument, List<ValueHolder> values, String jsonpath) {
        int idenArrayLen = JsonPath.read(jsonDocument, jsonpath + ".length()");
        for (int sIndex = 0; sIndex < idenArrayLen; sIndex++) {
            ValueHolder valueHolder = new ValueHolder();
            valueHolder.setSystem((String) extractValue(jsonDocument, jsonpath + "[" + sIndex + "].system"));
            valueHolder.setCode((String) extractValue(jsonDocument, jsonpath + "[" + sIndex + "].value"));
            values.add(valueHolder);
        }
        return values;
    }

    public List<Search> populateSearch(List<ValueHolder> values, final String attribute, final String searchType, final String id, final  String patientId, final  String lastUpdated) {
        List<Search> searches = new ArrayList<>();
        for (ValueHolder value : values) {
            Search search = new Search();
            search.setId(id);
            search.setSystem(value.getSystem());
            search.setCode(value.getCode());
            search.setAttribute(attribute);
            search.setValue(value.getValue());
            search.setDatatype(searchType);
            search.setStartvalue(value.getStartvalue());
            search.setEndvalue(value.getEndvalue());
            search.setUnit(value.getUnit());
            search.setPatientId(patientId);
            search.setTrgtType(value.getTrgtType());
            search.setLastUpdated(lastUpdated);
            searches.add(search);
        }
        return searches;
    }

    public List<ValueHolder> explode(Object object, String valueType) {
        List<ValueHolder> values = new ArrayList<>();
        if (object instanceof net.minidev.json.JSONArray) {
            values.addAll(explode((net.minidev.json.JSONArray) object , valueType));
        } else {
            ValueHolder valueHolder = new ValueHolder();
            valueHolder = explodeCondition(valueType, valueHolder, object);
            values.add(valueHolder);
        }
        return values;
    }
    
    public List<ValueHolder> explode(net.minidev.json.JSONArray array , String valueType) {
        Iterator<Object> itor = array.iterator();
        List<ValueHolder> values = new ArrayList<>();

        while (itor.hasNext()) {
            Object object = itor.next();
            if (object instanceof net.minidev.json.JSONArray) {
                List<ValueHolder> childValues = explode((net.minidev.json.JSONArray) object , valueType);
                values.addAll(childValues);
            } else {
                ValueHolder valueHolder = new ValueHolder();
                valueHolder = explodeCondition(valueType, valueHolder, object);
                values.add(valueHolder);
            }
        }
        return values;
    }
    
    public ValueHolder explodeCondition(String valueType, ValueHolder valueHolder, Object object) {
   	 switch (valueType) {
        case VALUECONST :
            valueHolder.setValue((String.valueOf(object)));
            break;
        case "Code" :
            valueHolder.setCode((String.valueOf(object)));
            break;
        case STARTVALUE :
            valueHolder.setStartvalue((String.valueOf(object)));
            break;
        default:
            break;
    }
   	 return valueHolder;
   }

    public Object extractValue(final Object document, final String jsonPath) {
        Object value = "";
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (com.jayway.jsonpath.PathNotFoundException pnfe) {
            logger.debug("No value in json...");
        }
        return value;
    }

    public String extractStringValue(final Object document, final String jsonPath) {
        String value = null;
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (Exception e) {
            logger.debug("No value for StringValue...");
        }
        return value;
    }

    public String extractPatientId(final Object configDocument , final Object jsonDocument , final String jsonPath) {
        String value = "";
        try {
            value = explode(extractValue(jsonDocument, extractValue(configDocument, jsonPath).toString()), VALUECONST).toString().replaceAll("urn:uuid:|.*/|\\[|\\]", "");
        } catch (Exception e) {
            logger.debug("No value for PatientId...");
        }
        return value;
    }

}

package com.citiustech.fastplus.querybuilder;

import static com.citiustech.fastplus.util.AdapterUtil.getAliasedColumn;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.SelectQueryStructure;
import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.config.ResInfoLinkTableConfiguration;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.util.MainOuterQueryObject;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.InCondition;
import com.healthmarketscience.sqlbuilder.SelectQuery;
import com.healthmarketscience.sqlbuilder.dbspec.basic.DbTable;

/**
 * 
 * This class is an extension of deep nested SQL builder
 * Prominently used for Bulk FHIR API
 *
 */
@Component("bulkExportSqlBuilder")
public class BulkExportSQLBuilder extends DeepNestedSqlBuilder {

	/**
	 * This is a REFERENCE_PARAM field used to hold string ReferenceParam
	 */
	private static final String REFERENCE_PARAM = "reference";
	
	private static final String TARGET_PARAM = "target";
	
	private static final Logging LOGGER = LoggerFactory.getLogger(BulkExportSQLBuilder.class.getName());
	
	/**
	 *  returns queries for each parameter type and nested sub queries for requested criteria
	 * 
	 * @param resourceType
	 * @param searchParamMap
	 * @return query string
	 */
	@Override
	public String buildNestedQueriesForSearchParams(String resourceType, SearchParameterRequest searchParamMap) {
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
				fhirRepositoryTableConfiguration, resourceType);
		try {

			String groupId = (Objects.nonNull(searchParamMap) && Objects.nonNull(searchParamMap.getGroupId()))? searchParamMap.getGroupId() :null;
			if(Objects.nonNull(searchParamMap) && !searchParamMap.isEmpty()) {
				List<SelectQueryStructure> selectQueryStructures = getSelectQueryStructures(resourceType,
						searchParamMap, queryBuilder);

				return buildNestedQueryFromSubQueries(resourceType, selectQueryStructures, 
						
								groupId,queryBuilder);
			}else {

				return buildQueryWithoutParameters(queryBuilder, resourceType, groupId);
			}

		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"FHIRException thrown while building nested queries for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Exception thrown while building nested queries for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}

	/**
	 *  returns queries for each parameter type and nested sub queries for requested criteria
	 * 
	 * @param resourceType
	 * @param searchParamMap
	 * @return query string
	 */
	public String buildNestedQueriesToGetResponseJson(String resourceType, SearchParameterRequest searchParamMap) {
		FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
				fhirRepositoryTableConfiguration, resourceType);
		try {

			if(Objects.nonNull(searchParamMap) && !searchParamMap.isEmpty()) {
				List<SelectQueryStructure> selectQueryStructures = getSelectQueryStructures(resourceType,
						searchParamMap, queryBuilder);

				return buildNestedQueryFromSubQueriesToGetResponseJson(resourceType, selectQueryStructures, queryBuilder, fhirRepositoryTableConfiguration);
			}else {
				String groupId = (Objects.nonNull(searchParamMap) && Objects.nonNull(searchParamMap.getGroupId()))? searchParamMap.getGroupId() :null;
				return buildQueryWithoutParameters(queryBuilder, resourceType, groupId);
			}

		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"FHIRException thrown while building nested queries for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Exception thrown while building nested queries for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}

	/**
	 * returns nested query by for different conditions as given as search parameters
	 * all combinations as requested in search criteria are taken into consideration here
	 * 
	 * @param resourceType
	 * @param selectQueryStructures
	 * @param since
	 * @param groupId
	 * @param queryBuilder
	 * @return query string
	 */
	private String buildNestedQueryFromSubQueries(String resourceType,
			List<SelectQueryStructure> selectQueryStructures,String groupId,
			FHIRRepositoryBaseSQLQueryBuilder queryBuilder) {

		SelectQuery mainOuterQuery = null;
		List<CustomSql> listOfProjectionCol = new ArrayList<>();

		String mainQueryAlias = null;
		
		if(Objects.nonNull(groupId)) {
			SelectQuery selectQuery = new SelectQuery();
			String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();
			selectQuery.addFromTable(new DbTable(null, tableName, resourceType));
			SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceType, selectQuery,
					null, null, queryBuilder.isChainedParam());
			buildGroupSubquery(resourceType, groupId, selectQueryStructure.getSelectQuery(), resourceType);
			selectQueryStructures.add(selectQueryStructure);
		}

		
		MainOuterQueryObject mainOuterQueryObj = buildMainOuterQuery(resourceType, mainOuterQuery, mainQueryAlias, selectQueryStructures, queryBuilder, listOfProjectionCol);
		mainOuterQuery = mainOuterQueryObj.getMainOuterQuery();

		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
				"Nested query built "+mainOuterQuery);
		
		return mainOuterQuery.toString();

	}

	/**
	 * returns nested query by for different conditions as given as search parameters
	 * all combinations as requested in search criteria are taken into consideration here
	 * 
	 * @param resourceType
	 * @param selectQueryStructures
	 * @param since
	 * @param groupId
	 * @param queryBuilder
	 * @param fhirRepositoryTableConfiguration 
	 * @return query string
	 */
	private String buildNestedQueryFromSubQueriesToGetResponseJson(String resourceType,
			List<SelectQueryStructure> selectQueryStructures, FHIRRepositoryBaseSQLQueryBuilder queryBuilder, 
			FHIRRepositoryTableConfiguration tableConfig) {
		try {
			SelectQuery mainOuterQuery = null;
			List<CustomSql> listOfProjectionCol = new ArrayList<>();

			String mainQueryAlias = null;

			MainOuterQueryObject mainOuterQueryObj = buildMainOuterQuery(resourceType, mainOuterQuery, mainQueryAlias, selectQueryStructures, queryBuilder, listOfProjectionCol);

			return frameJsonRetrievalQuery(resourceType, tableConfig, mainOuterQueryObj.getMainOuterQuery());
		} catch (Exception e) {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}

	}
	
	/**
	 * @param resourceType
	 * @param queryBuilder
	 * @param tableConfig
	 * @param mainOuterQueryObj
	 */
	public String frameJsonRetrievalQuery(String resourceType, String id) {
		try {
			return frameJsonRetrievalQuery(resourceType, fhirRepositoryTableConfiguration, id);
		} catch (FHIRException e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"FHIRException thrown while framing json retrieval for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.findEnumCode(e.getMessage()), e);
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Exception thrown while framing json retrieval for bulk export");
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR, e);
		}
	}
	

	/**
	 * @param resourceType
	 * @param queryBuilder
	 * @param tableConfig
	 * @param mainOuterQueryObj
	 */
	private String frameJsonRetrievalQuery(String resourceType, FHIRRepositoryTableConfiguration tableConfig,  Object inCluase) {
		String tableAlias;
		String table = tableAlias = tableConfig.getResourceInfoTable().getTable().get(0);

		SelectQuery selectQuery = new SelectQuery();
			
		selectQuery.addFromTable(new DbTable(null, table,tableAlias));
		selectQuery.addCustomColumns(
				new CustomSql(tableConfig.getIdColumn()),
				new CustomSql(tableConfig.getJsonColumn()));

		Condition inCondition = new InCondition(new CustomSql(getAliasedColumn(
				tableAlias, tableConfig.getIdColumn())), inCluase);
		Condition resourceTypeCondition = BinaryCondition.equalTo(new CustomSql(
				getAliasedColumn(tableAlias, tableConfig.getResourceType())),
				resourceType);		
		selectQuery.addCondition(ComboCondition.and(resourceTypeCondition, inCondition));
		
		return selectQuery.validate().toString();
	}

	/**
	 * This method is used to Group level filter query
	 * 
	 * @param resourceType
	 * @param groupId
	 * @param mainOuterQuery
	 * @param mainQueryAlias
	 */
	private void buildGroupSubquery(String resourceType, String groupId, SelectQuery mainOuterQuery,
			String mainQueryAlias) {
		SelectQuery selectQuery = new SelectQuery();
		ResInfoLinkTableConfiguration configuration = fhirRepositoryTableConfiguration.getResourceLinkTable();
		String resourceLinkTbl = configuration.getTable().get(0); 
		String resLinkAlias = resourceLinkTbl.split("\\.")[1]; 
		selectQuery.addFromTable(new DbTable(null, resourceLinkTbl, resLinkAlias));
		selectQuery.addCustomColumns(new CustomSql(configuration.getColumnForType(resLinkAlias, REFERENCE_PARAM).get(2)));

		if(fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getProjections().size() >1) {
			
			String inQueryColumn = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getProjections().get(1);
			if(resourceType.equalsIgnoreCase(ResourceType.Provenance.name())) {
				inQueryColumn = configuration.getTypeColumnMap().get(REFERENCE_PARAM).get(4);
			}
			mainOuterQuery.addCondition(new InCondition(new CustomSql(getAliasedColumn(mainQueryAlias,
					inQueryColumn)),
					selectQuery.addCondition(ComboCondition.and(BinaryCondition.equalTo(new CustomSql(configuration.getColumnForType(resLinkAlias, REFERENCE_PARAM).get(1)),ResourceType.Group.name()),
							BinaryCondition.equalTo(new CustomSql(configuration.getColumnForType(resLinkAlias, REFERENCE_PARAM).get(0)),ResourceType.Patient.name()),
							BinaryCondition.equalTo(new CustomSql(configuration.getColumnForType(resLinkAlias, REFERENCE_PARAM).get(3)), groupId)))));
			if(resourceType.equalsIgnoreCase(ResourceType.Provenance.name())) {
				mainOuterQuery.addCondition(BinaryCondition.equalTo(fhirRepositoryTableConfiguration.getSearchAttributeColumn(mainQueryAlias), TARGET_PARAM));
			}
		}
	}

	/**
	 * This method is used to build a query when no search parameter is provided in search query
	 * 
	 * @param queryBuilder
	 * @param resourceType
	 * @param groupId
	 * @return query string
	 */
	private String buildQueryWithoutParameters(FHIRRepositoryBaseSQLQueryBuilder queryBuilder,
			String resourceType, String groupId) {
		if(Objects.isNull(groupId)) {
			return buildQueryWithoutParameters(queryBuilder, resourceType);
		}else {
			SelectQuery selectQuery = new SelectQuery();
			String tableName = fhirRepositoryTableConfiguration.getSearchTableMap().get(resourceType).getTable();

			selectQuery.addFromTable(new DbTable(null, tableName, resourceType));
			selectQuery.addCustomColumns(new CustomSql(getAliasedColumn(resourceType, fhirRepositoryTableConfiguration.getIdColumn())));
			selectQuery.setIsDistinct(true);

			SelectQueryStructure selectQueryStructure = new SelectQueryStructure(resourceType, selectQuery,
					null, null, queryBuilder.isChainedParam());

			buildGroupSubquery(resourceType, groupId, selectQueryStructure.getSelectQuery(), resourceType);
			
			String query = selectQueryStructure.getSelectQuery().toString();

			LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Nested query built "+query);
			
			return query;

		}
	}

}

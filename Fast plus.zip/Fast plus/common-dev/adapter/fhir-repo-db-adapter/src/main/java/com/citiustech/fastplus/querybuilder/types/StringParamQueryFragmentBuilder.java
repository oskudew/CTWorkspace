package com.citiustech.fastplus.querybuilder.types;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;
import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.custom.postgresql.PgBinaryCondition;

import ca.uhn.fhir.rest.param.StringParam;

/**
 * 
 * This is a class for StringParamQueryFragmentBuilder which used to build
 * query fragments for string search parameters
 * 
 */

@Component
public class StringParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<StringParam> {

	 /**
	 * This is a fhirRepositoryTableConfiguration field used to hold
	 * FHIRRepositoryTableConfiguration object
	 */
    private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

    /**
     * This is a commonQueryUtil field used to hold CommonQueryUtil object
     */
    private CommonQueryUtil commonQueryUtil;
    
    
    @Autowired
    public StringParamQueryFragmentBuilder(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			CommonQueryUtil commonQueryUtil) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.commonQueryUtil = commonQueryUtil;
	}
    
    public StringParamQueryFragmentBuilder() {
    	
    }
	/**
     * returns escaped value 
     * @param value
     */
    private String getEscapedValue(String value) {
        return value.replace("'", "''");
    }

    /**
     * returns binary conditions for contains modifier
     * 
     * @param param
     * @param value
     * @return BinaryCondition
     */
    public BinaryCondition contains(CustomSql param, String value) {
        return PgBinaryCondition.iLike(param, "%" + getEscapedValue(value) + "%");
    }

    /**
     * returns binary condition for starts with modifier
     * 
     * @param param
     * @param value
     * @return BinaryCondition
     */
    public BinaryCondition startsWith(CustomSql param, String value) {
        return PgBinaryCondition.iLike(param, getEscapedValue(value) + "%");
    }

    /**
     * returns binary condition for exact with modifier
     * 
     * @param param
     * @param value
     * @return BinaryCondition
     */
    public BinaryCondition exact(CustomSql param, String value) {
        return BinaryCondition.equalTo(param, getEscapedValue(value));
    }
    
    /**
     * returns replaced string based on input value
     * 
     * @param paramValue
     * @return String
     */
    private String replaceChar(String paramValue)
    {
    	String tempParamValue = paramValue;
    	if(tempParamValue.contains("_")) {
    		// replace underscore(_) with backslash underscore(\_) to avoid sql security attack 
    		tempParamValue = tempParamValue.replace ("_", "\\\\_");
    	} else if(tempParamValue.contains("\\")) {
    		// replace backslash(\) with two backslash (\\) to support the search of backslash 
    		tempParamValue = tempParamValue.replace("\\", "\\\\");
    	} else if(tempParamValue.contains("%")) {
    		// replace backslash(%) with backslash percent (\%) to avoid sql security attack
    		tempParamValue = tempParamValue.replace("%", "\\\\%");
    	}
    	return tempParamValue;
    }

    /**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
    @Override
    public Condition frameQueryFragment(QueryBuilder queryBuilder, String resurceType, String resurceTypeAlias, StringParam paramType, String paramName) {
	commonQueryUtil.validateParamValue(paramType.getValue(), true);
    	
    	String paramValue = replaceChar(paramType.getValue());
    	
        List<String> actualParamNames = fhirRepositoryTableConfiguration.getActualParamNames(resurceType, paramName);
        actualParamNames = Objects.nonNull(actualParamNames) && !actualParamNames.isEmpty() ?
                actualParamNames : Arrays.asList(paramName);

        List<Condition> orConditions = new ArrayList<>();
            for (String aParam : actualParamNames) {
                Condition condition = BinaryCondition.equalTo(
                        fhirRepositoryTableConfiguration.getSearchAttributeColumn(resurceTypeAlias), aParam);
                orConditions.add(condition);
            }
        CustomSql value = fhirRepositoryTableConfiguration.getSearchColumn(ParamType.STRING.getValue(),
                resurceType, resurceTypeAlias).get(0);
        
        if (paramType.isContains()) {
            return ComboCondition.and(queryBuilder.frameOrQueryAndReturn(orConditions), contains(value, paramValue));
        }
        else if (paramType.isExact()) {
            return ComboCondition.and(queryBuilder.frameOrQueryAndReturn(orConditions), exact(value, paramValue));
        }

        return ComboCondition.and(queryBuilder.frameOrQueryAndReturn(orConditions), startsWith(value, paramValue));
    }
}

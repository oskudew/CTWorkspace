package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.ExplanationOfBenefit;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.test.factory.ReferenceFactory;
import com.citiustech.fastplus.test.factory.TokenFactory;
import com.citiustech.fastplus.util.AdapterUtil;

import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;

@ExtendWith(MockitoExtension.class)
class AdapterUtilTest {

	@DisplayName("Test case for getParamList method for tokenParam")
	@Test
	void test_getParamListForTokenParam() {
		String id = "kern-pat-10002";
		List<String> expectedValue = new ArrayList<>();
		expectedValue.add(id);
		
		TokenAndListParam tokenAndListParam = new TokenFactory()
				.setReferenceValue(id).newInstance();
		
		List<String> actualValue = AdapterUtil.getParamList(tokenAndListParam);
		assertEquals(actualValue.toString(),expectedValue.toString());
	}
	
	@DisplayName("Test case for getParamList method for referenceParam")
	@Test
	void test_getParamListForReferenceParam() {
		String value = "QA-Loc-12ref";
		List<String> expectedValue = new ArrayList<>();
		expectedValue.add(value);
		
		ReferenceAndListParam referenceAndListParam = new ReferenceFactory()
				.setReferenceValue(value).newInstance();
		
		List<String> actualValue = AdapterUtil.getParamList(referenceAndListParam);
		assertEquals(actualValue.toString(),expectedValue.toString());
	}
	
	
}

package palindrome;

public interface CheckPalindrome {

}

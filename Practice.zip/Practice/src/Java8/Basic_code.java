package Java8;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Basic_code {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] num = {5,4,3,2,5,2,1};
		String str= "geeeksofgeeks";
		char c = 'g';
		
		List<Integer> list = Arrays.asList(num);
		Set s =new HashSet<Integer>();
		System.out.println(list.stream().reduce((a,b)->b).orElse(null));
		System.out.println(list.stream().filter(i->!s.add(i)).collect(Collectors.toSet()));
		System.out.println(str.chars().filter(ch->ch==c).count());
	}

}

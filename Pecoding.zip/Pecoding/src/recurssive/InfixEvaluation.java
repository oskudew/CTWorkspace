package recurssive;

import java.util.Stack;

public class InfixEvaluation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="2+(5-3*6/2)";
		
		Stack<Integer> num= new Stack<>();
		Stack<Character> operator= new Stack<>();
		
		for(int i=0;i<s.length();i++) {
			char ch=s.charAt(i);
			if(ch=='(') {
				operator.push(ch);
			}
			else if( ch==')') {
				while(operator.peek()!='(' ) {
					char c2=operator.pop();
					int v2=num.pop();
					int v1 =num.pop();
					int opr=operation(v1,v2,c2);
					num.push(opr);
					System.out.println("when ch =)"+ opr);
					
				}
				operator.pop();
				
			}
			else if(Character.isDigit(ch)) {
				num.push(ch-'0');
			}
			else if(ch=='+'|| ch=='-'|| ch=='*' || ch=='/'){
				while(operator.size()>0 && operator.peek()!='(' && precedence(ch)<=precedence(operator.peek())) {
					char c2=operator.pop();
					int v2=num.pop();
					int v1 =num.pop();
					int opr=operation(v1,v2,c2);
					num.push(opr);
					System.out.println("when ch =+-*/"+ opr);
				}
				operator.push(ch);
				
			}
					
			
		}
		while(operator.size()!=0){
			char c2=operator.pop();
			int v2=num.pop();
			int v1 =num.pop();
			int opr=operation(v1,v2,c2);
			num.push(opr);
			System.out.println("when opertor is not null"+ opr);
		}
		System.out.println(num.peek());
		
		
				
		
	}
	public static int precedence(char opr) {
		if(opr=='+') {
			return 1;
		}
		else if(opr =='-') {
			return 1;
			}
		else if(opr=='*') {
			return 2;
		}
		else {
			return 2;
		}
	}
	
	public static int operation(int v1, int v2,char opr) {
		if(opr=='+') {
			return v1+ v2;
		}
		else if(opr =='-') {
			return v1-v2;
			}
		else if(opr=='*') {
			return v1*v2;
		}
		else {
			return v1/v2;
		}
	}

}

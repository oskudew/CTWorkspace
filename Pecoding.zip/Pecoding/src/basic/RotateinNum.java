package basic;

import java.util.Scanner;

public class RotateinNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a= sc.nextInt();
		int b= sc.nextInt();
		int k=a;
		int temp =0;
		
		while(k>0) {
			k=k/10;
			temp++;
		}
		b=b%temp;
		if(b<0) {
			b=b+temp;
		}
		
		int mod=1;
		int div=1;
		for(int i=1;i<=temp;i++) {
			if(i<=b) {
				mod=mod*10;
			}
			else {
				div=div*10;
			}
			
		}
		
		int m=a%mod;
		int n= a/mod;
		
		int result =m*div+n;
		System.out.println(result);

	}

}

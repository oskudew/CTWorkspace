package com.citiustech.fastplus.security;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.security.oauth2.resource.ResourceServerProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.citiustech.fastplus.authpolicy.RoleBasedAccessControlProperties;
import com.citiustech.fastplus.authpolicy.RoleBasedAccessControlProperties.SecurityConstraint;
import com.citiustech.fastplus.identityprovider.IdentityProviderAccessTokenExtractor;

/**
 * SecurityConfigurer is to configure ResourceServer and HTTP Security.
 * <p>
 * Please make sure you check HTTP Security configuration and change is as per
 * your needs.
 * </p>
 *
 */

@Configuration
@EnableWebSecurity
@EnableResourceServer
@ConditionalOnProperty(prefix = "app.security", value = "enabled", havingValue = "true",matchIfMissing = true)
public class SecurityConfigurer implements ResourceServerConfigurer {

	/**
	 * This is a applicationContext fields used to hold ioc container
	 */
	@Autowired
	ApplicationContext applicationContext;

	/**
	 * This is a authPolicy fields used to hold role based access properties
	 */
	@Autowired
	RoleBasedAccessControlProperties authPolicy;

	/**
	 * This is a resourceServerProperties fields used to hold properties for
	 * resource server
	 */
	private ResourceServerProperties resourceServerProperties;

	/**
	 * parameterized constructor
	 * 
	 * @param resourceServerProperties
	 */
	public SecurityConfigurer(ResourceServerProperties resourceServerProperties) {
		this.resourceServerProperties = resourceServerProperties;
	}

	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.resourceId(resourceServerProperties.getResourceId());
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {

		http.anonymous().and()
				.authorizeRequests(this::setAuthPolicy)
				.oauth2ResourceServer(oauth2ResourceServer -> oauth2ResourceServer
						.jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter())))
				.cors().configurationSource(corsConfigurationSource());
	}

	/**
	 * sets authentication policies
	 * 
	 * @param authorizeRequests
	 * @return Object
	 */
	private Object setAuthPolicy(
			ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authorizeRequests) {

		if (!authPolicy.getPublicPatterns().isEmpty()) {
			authPolicy.getPublicPatterns().forEach(e -> authorizeRequests.antMatchers(e).permitAll());
		}

		if (!authPolicy.getSecurityConstraints().isEmpty()) {
			authPolicy.getSecurityConstraints().forEach(e -> setSecurityContraints(e, authorizeRequests));
		}

		authorizeRequests.anyRequest().authenticated();

		return null;
	}

	/**
	 * sets security constraints
	 * 
	 * @param constraint
	 * @param authorizeRequests
	 */
	private void setSecurityContraints(SecurityConstraint constraint,
			ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authorizeRequests) {
		
		String patterns = String.join(",", constraint.getPatterns());
		String authorities = "";
		
		if (authPolicy.getAuthPolicy().equals("role") && !constraint.getAuthRoles().isEmpty()) 
			authorities = String.join(",", constraint.getAuthRoles());
		
		if(authPolicy.getAuthPolicy().equals("scope") && !constraint.getScopes().isEmpty())
			authorities = authorities + String.join(",", constraint.getScopes());
		
		if(!authorities.isEmpty()) {
			if(Objects.nonNull(constraint.getMethod())) {
				authorizeRequests.antMatchers(constraint.getMethod(),patterns).hasAnyAuthority(authorities);
			}else {
				authorizeRequests.antMatchers(patterns).hasAnyAuthority(authorities);	
			}	
		}
		
	}

	private Converter<Jwt, ? extends AbstractAuthenticationToken> jwtAuthenticationConverter() {
		JwtAuthenticationConverter jwtConverter = new JwtAuthenticationConverter();
		jwtConverter.setJwtGrantedAuthoritiesConverter(getConverter(applicationContext));
		return jwtConverter;
	}

	/**
	 * returns IdentityProviderAccessTokenExtractor bean
	 */
	@Bean("tokenExtractor")
	IdentityProviderAccessTokenExtractor getConverter(ApplicationContext applicationContext) {
		return (IdentityProviderAccessTokenExtractor) applicationContext.getBean(authPolicy.getIdentityProvider());
	}

	/**
	 * returns JwtDecoder bean
	 */
	@Bean
	JwtDecoder jwtDecoder() {
		return NimbusJwtDecoder.withJwkSetUri(authPolicy.getJwksUri()).build();
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", authPolicy.getCorsConfiguration());
		return source;
	}
}

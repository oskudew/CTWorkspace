package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.r4.model.Organization;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import com.citiustech.fastplus.model.SearchResult;
import com.citiustech.fastplus.service.ISearchService;
import com.citiustech.fastplus.service.pagination.CustomBundleProvider;
import com.citiustech.fastplus.services.ProviderDirectoryService;
import com.citiustech.fastplus.util.exception.SearchServiceException;
import com.citiustech.fastplus.util.springcontext.SpringContext;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.param.TokenParam;
import ca.uhn.fhir.rest.server.exceptions.InternalErrorException;
import ca.uhn.fhir.rest.server.exceptions.InvalidRequestException;
@ExtendWith(MockitoExtension.class)
class ProviderDirectoryServiceTest {
	
	@InjectMocks
	ProviderDirectoryService providerDirectoryService;
	
	@Mock
	private ISearchService searchService;
	
	@Mock
	private MessageSource messageSource;
	
	@Spy
	SpringContext springContext;
	
	@Mock
	ApplicationContext appContext;
	
	
	@SuppressWarnings("unchecked")
	@DisplayName("Test case for getResources method for no include and revinclude params")
	@Test
	void test_getResources() {
		String resourceType = "Organization";
		String value = "Thailand";
		String paramName = Organization.SP_ADDRESS_CITY;
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam param = new StringAndListParam();
		param.addAnd(new StringParam(value));
		parameterMap.add(paramName,param);
		
		List<IdProjectionRow> idProjectionRows = new ArrayList<>();
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-coveragetest",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-ntwk-Net501",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org201",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org201_nw",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org202",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org203_nw",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org204_nw",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org205_nw",null));
		idProjectionRows.add(new IdProjectionRow(resourceType,"Kern-org-Org50011",null));
		
		when(searchService.findResourceIds(resourceType, parameterMap)).thenReturn(idProjectionRows);
		
		springContext.setApplicationContext(appContext);
		
		SearchResult searchResult =  new SearchResult(idProjectionRows, null, null);
		CustomBundleProvider customBundleProvider = new CustomBundleProvider(searchResult);
		
		when(appContext.getBean(Mockito.any(Class.class), Mockito.any(SearchResult.class))).thenReturn(customBundleProvider);
		
		IBundleProvider actualValue = providerDirectoryService.getResources(parameterMap,resourceType);
		assertTrue(actualValue instanceof CustomBundleProvider);
		
	}
	

	@SuppressWarnings("unchecked")
	@DisplayName("Test case for getResources method for include params")
	@Test
	void test_getResourcesForInclude() {
		String resourceType = "Organization";
		String value = "Orgtestchain";
		String paramName = IAnyResource.SP_RES_ID;
		String includeValue = "Organization:partof";
		
		TokenAndListParam param = new TokenAndListParam();
		TokenParam token = new TokenParam(value);
		param.addAnd(token);
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		parameterMap.add(paramName, param);
		
		Set<Include> includes = new HashSet<>();
		includes.add(new Include(includeValue,false));
		parameterMap.setIncludes(includes);
		
		Set<String> include = new HashSet<>();
		include.add(includeValue);
		
		List<IdProjectionRow> idProjectionRows = new ArrayList<>();
		idProjectionRows.add(new IdProjectionRow(resourceType,value,null));
		
		when(searchService.findResourceIds(resourceType, parameterMap)).thenReturn(idProjectionRows);
		
		springContext.setApplicationContext(appContext);
		
		SearchResult searchResult =  new SearchResult(idProjectionRows, include, null);
		CustomBundleProvider customBundleProvider = new CustomBundleProvider(searchResult);
		
		when(appContext.getBean(Mockito.any(Class.class), Mockito.any(SearchResult.class))).thenReturn(customBundleProvider);
		
		IBundleProvider actualValue = providerDirectoryService.getResources(parameterMap,resourceType);
		assertTrue(actualValue instanceof CustomBundleProvider);
		
	}
	
	@SuppressWarnings("unchecked")
	@DisplayName("Test case for getResources method for revinclude params")
	@Test
	void test_getResourcesForRevInclude() {
		String resourceType = "Organization";
		String value = "plannet-organization-920120";
		String paramName = IAnyResource.SP_RES_ID;
		String revIncludeValue = "OrganizationAffiliation:primary-organization";
		TokenAndListParam theId = new TokenAndListParam();
		TokenParam token = new TokenParam(value);
		theId.addAnd(token);
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		parameterMap.add(paramName, theId);
		
		Set<Include> revincludes = new HashSet<>();
		revincludes.add(new Include(revIncludeValue,false));
		parameterMap.setRevIncludes(revincludes);
		
		List<IdProjectionRow> idProjectionRows = new ArrayList<>();
		
		when(searchService.findResourceIds(resourceType, parameterMap)).thenReturn(idProjectionRows);
		
		springContext.setApplicationContext(appContext);
		
		Set<String> revInclude = new HashSet<>();
		revInclude.add(revIncludeValue);
		
		SearchResult searchResult =  new SearchResult(idProjectionRows, null, revInclude);
		CustomBundleProvider customBundleProvider = new CustomBundleProvider(searchResult);
		
		when(appContext.getBean(Mockito.any(Class.class), Mockito.any(SearchResult.class))).thenReturn(customBundleProvider);
		
		IBundleProvider actualValue = providerDirectoryService.getResources(parameterMap,resourceType);
		assertTrue(actualValue instanceof CustomBundleProvider);
		
	}

	@DisplayName("Test case for getResources method for InvalidRequestException")	
	@Test
	void test_getResourcesForInvalidRequestException() {
		String resourceType = "Organization";
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		
		InvalidRequestException exception = new InvalidRequestException("FPE-3003");
		
		when(searchService.findResourceIds(resourceType, parameterMap)).thenThrow(exception);
		when(messageSource.getMessage(exception.getMessage(),null, Locale.getDefault())).thenReturn("FPE-3003 : Invalid Parameter value");
		
		assertThrows(InvalidRequestException.class,() -> providerDirectoryService.getResources(parameterMap,resourceType));
		
	}
	
	@DisplayName("Test case for getResources method for SearchRequestException")	
	@Test
	void test_getResourcesForSearchRequestException() {
		String resourceType = "Organization";
		String value = "Thailand";
		String paramName = Organization.SP_ADDRESS_CITY;
		SearchParameterRequest parameterMap = new SearchParameterRequest();
		StringAndListParam param = new StringAndListParam();
		param.addAnd(new StringParam(value));
		parameterMap.add(paramName,param);
		
		SearchServiceException exception = new SearchServiceException("FPE-1002");
		
		when(searchService.findResourceIds(resourceType, parameterMap)).thenThrow(exception);
		when(messageSource.getMessage(exception.getMessage(),null, Locale.getDefault())).thenReturn("FPE-1002 : DB Connection Error");
		
		
		assertThrows(InternalErrorException.class,() -> providerDirectoryService.getResources(parameterMap,resourceType));
		
	}

}

package com.citiustech.fastplus.r4.model;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;
import org.hl7.fhir.r4.model.InsurancePlan;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Organization;

/**
 * This class will provide extra search parameter 
 * support based on the Davinci profile.
 */
@ResourceDef(name = "InsurancePlan", profile = "http://hl7.org/fhir/StructureDefinition/InsurancePlan")
public class DavinciInsurancePlan extends InsurancePlan {

    private static final long serialVersionUID = 1L;

    /**
     * This is a search parameter constant for coverage-area,
     * which specifies product offered in specified location
     */
    @SearchParamDefinition(name = "coverage-area", path = "InsurancePlan.coverageArea", description = "Product offered in specified location", type = "reference", target = {Location.class})
    public static final String SP_COVERAGE_AREA = "coverage-area";

    /**
     * This is a search parameter constant for network,
     * which select products associated with the specified 
     * health insurance provider network
     */
    @SearchParamDefinition(name = "network", path = "InsurancePlan.network", description = "Select products associated with the specified health insurance provider network", type = "reference", target = {Organization.class})
    public static final String SP_NETWORK = "network";

    /**
     * This is a search parameter constant for plan-type,
     * which specifies type of plan
     */
    @SearchParamDefinition(name = "plan-type", path = "InsurancePlan.plan.type", description = "Type of plan. For example, \"Platinum\" or \"High Deductable\".", type="token" )
    public static final String SP_PLAN_TYPE = "plan-type";
}

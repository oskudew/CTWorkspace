package recurssive;

import java.util.Scanner;

public class DiffeOfTwoArrayOptimise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int[] arr= new int[a];
		
		for(int i =0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		
		
		int b = sc.nextInt();
		
		int[] arr1= new int[b];
		
		for(int i =0;i<b;i++) {
			arr1[i]=sc.nextInt();
		} 

	}

}

package com.citiustech.fastplus.interceptors;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.OperationOutcome;
import org.hl7.fhir.r4.model.OperationOutcome.IssueSeverity;
import org.hl7.fhir.r4.model.OperationOutcome.OperationOutcomeIssueComponent;
import org.hl7.fhir.r4.model.Parameters;
import org.springframework.context.ApplicationContext;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

import com.citiustech.fastplus.identityprovider.IdentityProviderAccessTokenExtractor;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.model.audit.AuditEvent;
import com.citiustech.fastplus.model.trace.TraceEvent;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import ca.uhn.fhir.rest.server.exceptions.BaseServerResponseException;
import ca.uhn.fhir.rest.server.servlet.ServletRequestDetails;

/**
 * 
 * This is a class for FHIRAuditInterceptor used to act as an interceptor for
 * the purpose of auditing
 * 
 */

@Interceptor
public class FHIRAuditInterceptor {

	/**
	 * This is a logger field used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(FHIRAuditInterceptor.class.getName());

	/**
	 * This is a eventsStore field used to store audit events
	 */
	private Map<String, AuditEvent> eventsStore = new ConcurrentHashMap<>();

	/**
	 * This is a applicationContext field used to hold spring ioc container
	 */
	ApplicationContext applicationContext;

	/**
	 * No arguments constructor
	 */
	public FHIRAuditInterceptor() {
	}

	/**
	 * one argument constructor
	 * 
	 * @param applicationContext
	 */
	public FHIRAuditInterceptor(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	/**
	 * returns boolean after setting audit information
	 * 
	 * @param requestDetails
	 * @param servletRequestDetails
	 * @param responseDetails
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return boolean
	 */
	@Hook(Pointcut.SERVER_INCOMING_REQUEST_POST_PROCESSED)
	public boolean audit(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {

		AuditEvent auditEvent = new AuditEvent();
		auditEvent.setTimestamp(ZonedDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()));
		auditEvent.setAction(requestDetails.getRestOperationType().name());
		auditEvent.setNode(servletRequestDetails.getServer().getServerName());
		auditEvent.setRemoteIp(httpServletRequest.getRemoteAddr());
		auditEvent.setResourceType(requestDetails.getResourceName());
		auditEvent.setRequestURI(requestDetails.getCompleteUrl());
		auditEvent.setNode(httpServletRequest.getLocalAddr());

		setUserAndService(auditEvent, httpServletRequest);

		eventsStore.put(requestDetails.getRequestId(), auditEvent);

		LOGGER.logInfo(LoggingMarkers.AUDIT.getValue(), auditEvent.toString());
		return true;
	}

	/**
	 * sets user, application information for audit
	 * 
	 * @param auditEvent
	 * @param request
	 */
	private void setUserAndService(AuditEvent auditEvent, HttpServletRequest request) {

		try {
			auditEvent.setUser("anonymous");
			auditEvent.setService("application");

			if (Objects.nonNull(applicationContext) && applicationContext.containsBean("tokenExtractor")) {
				IdentityProviderAccessTokenExtractor extractor = (IdentityProviderAccessTokenExtractor) applicationContext
						.getBean("tokenExtractor");

				JwtAuthenticationToken authentication = ((JwtAuthenticationToken) request.getUserPrincipal());
				if (Objects.nonNull(authentication)) {
					Jwt jwt = authentication.getToken();
					auditEvent.setUser(extractor.getPreferredUsername(jwt));
					auditEvent.setService(extractor.getIssuedFor(jwt));
				}
			}

		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),
					"Error while extracting audit event related information from access token", e);
		}

	}

	/**
	 * performs audit for response of api
	 * 
	 * @param requestDetails
	 * @param servletRequestDetails
	 * @param resource
	 * @param responseDetails
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return boolean
	 */
	@Hook(Pointcut.SERVER_OUTGOING_RESPONSE)
	public boolean audit(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			IBaseResource resource, ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {


		AuditEvent auditEvent = eventsStore.get(requestDetails.getRequestId());
		 if(Objects.isNull(auditEvent.getStatusCode())) {

			 if("$export".equals(requestDetails.getOperation())) {
				auditEvent.setResourceIdsString(httpServletResponse.getHeader("Content-Location"));
			}
			else if("bulkstatus".equals(requestDetails.getResourceName())) {
				OperationOutcomeIssueComponent issue = ((OperationOutcome)resource).getIssue().get(0);
				if (IssueSeverity.INFORMATION.equals(issue.getSeverity())) {
					auditEvent.setResourceIdsString(issue.getDiagnostics());
				} else if (IssueSeverity.ERROR.equals(issue.getSeverity())) {
					auditEvent.setErrorCode(String.valueOf(responseDetails.getResponseCode()));
					auditEvent.setErrorMsg(issue.getDiagnostics());
				}
			} 
			else {
				auditEvent.setResourceIdsString(getResourceIds(resource));
			}
			auditEvent.setStatusCode(String.valueOf(responseDetails.getResponseCode()));
	
			LOGGER.logInfo(LoggingMarkers.AUDIT.getValue(), auditEvent.toString());
		 }
		return true;
	}

	/**
	 * returns resource ids for input resource
	 * 
	 * @param resource
	 * @return resource ids
	 */
	private String getResourceIds(IBaseResource resource) {
		if (Objects.nonNull(resource)) {
			if (resource instanceof Bundle) {
				Bundle bundle = (Bundle) resource;
				if (bundle.hasEntry()) {
					return bundle.getEntry().stream()
							.filter(be -> be.getResource() != null && be.getResource().getIdElement() != null
									&& be.getResource().getIdElement().getIdPart() != null)
							.map(be -> be.getResource().getIdElement().getIdPart()).collect(Collectors.joining(","));
				}
			} else if (resource instanceof Parameters){
				return ((Parameters)resource).getParameter().stream()
							.filter(param -> param.getName().equalsIgnoreCase("MemberPatient"))
							.map(param -> param.getResource().getIdElement().getIdPart())
							.collect(Collectors.joining(","));

			} else {
				if (resource.getIdElement() != null && resource.getIdElement().getIdPart() != null)
					return resource.getIdElement().getIdPart();
			}
		}
		return "";
	}

	/**
	 * returns boolean and performs auditing when exception occurs
	 * 
	 * @param requestDetails
	 * @param servletRequestDetails
	 * @param resource
	 * @param responseDetails
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param baseServerResponseException
	 * @return boolean
	 */
	@Hook(Pointcut.SERVER_HANDLE_EXCEPTION)
	public boolean exception(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			IBaseResource resource, ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, BaseServerResponseException baseServerResponseException) {
		AuditEvent auditEvent = eventsStore.get(requestDetails.getRequestId());
		if (auditEvent == null) {
			auditEvent = new AuditEvent();
			auditEvent.setTimestamp(ZonedDateTime.ofInstant(Instant.now(), ZoneId.systemDefault()));

			auditEvent.setNode(servletRequestDetails.getServer().getServerName());
			auditEvent.setRemoteIp(httpServletRequest.getRemoteAddr());
			auditEvent.setResourceType(requestDetails.getResourceName());
			auditEvent.setNode(httpServletRequest.getLocalAddr());
			auditEvent.setRequestURI(requestDetails.getCompleteUrl());

			setUserAndService(auditEvent, httpServletRequest);

			eventsStore.put(requestDetails.getRequestId(), auditEvent);
		}
		auditEvent.setStatusCode(String.valueOf(baseServerResponseException.getStatusCode()));
		auditEvent.setErrorCode(String.valueOf(baseServerResponseException.getStatusCode()));
		auditEvent.setErrorMsg(baseServerResponseException.getMessage());

		LOGGER.logInfo(LoggingMarkers.AUDIT.getValue(), auditEvent.toString());

		return true;
	}

	/**
	 * performs auditing after servers request processing is completed
	 * 
	 * @param requestDetails
	 * @param servletRequestDetails
	 * @param resource
	 * @param responseDetails
	 * @param httpServletRequest
	 * @param httpServletResponse
	 */
	@Hook(Pointcut.SERVER_PROCESSING_COMPLETED)
	public void completed(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			IBaseResource resource, ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		AuditEvent auditEvent = eventsStore.get(requestDetails.getRequestId());
		TraceEvent traceEvent = new TraceEvent();

		ZonedDateTime currentTime = ZonedDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		if (auditEvent == null) {
			auditEvent = new AuditEvent();
			setUserAndService(auditEvent, httpServletRequest);

		} else {
			traceEvent.setApplication(auditEvent.getService());
			traceEvent.setHttpStatus(auditEvent.getStatusCode());
			traceEvent.setRemoteAddress(auditEvent.getRemoteIp());
			traceEvent.setHttpMethod(requestDetails.getRequestType().name());
			traceEvent.setTimestamp(currentTime);
		}
		int responseTime = (int)(currentTime.toInstant().toEpochMilli() - auditEvent.getTimestamp().toInstant().toEpochMilli());
		traceEvent.setResponseTime(responseTime);
		auditEvent.setResponseTime(responseTime);

		LOGGER.logInfo(LoggingMarkers.TRACE.getValue(), traceEvent.toString());

		LOGGER.logInfo(LoggingMarkers.AUDIT.getValue(), auditEvent.toString());
	}

}

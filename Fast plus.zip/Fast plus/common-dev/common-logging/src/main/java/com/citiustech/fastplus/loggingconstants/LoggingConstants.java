package com.citiustech.fastplus.loggingconstants;

/**
 * LoggingConstants class for creating enums which are used as markers
 * to bifurcate different types of logs, also it provides string value of the
 * used enum
 */

public class LoggingConstants {

	/**
     * Enum created for listing different types of logs
     */
    public enum LoggingMarkers {
        APPLICATION("Application"), AUDIT("Audit"), TRACE("Trace");

        private final String key;

        /**
         * A constructor for assigning the value of the enum
         *
         * @param key
         */
        private LoggingMarkers(String key) {
            this.key = key;
        }

        /**
         * @return the key of String
         */
        public String getValue() {
            return key;
        }
    }

}

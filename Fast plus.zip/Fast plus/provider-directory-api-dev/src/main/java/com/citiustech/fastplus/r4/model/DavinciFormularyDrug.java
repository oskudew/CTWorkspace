package com.citiustech.fastplus.r4.model;

import org.hl7.fhir.r4.model.MedicationKnowledge;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;

@ResourceDef(name = "MedicationKnowledge", profile = "http://hl7.org/fhir/StructureDefinition/MedicationKnowledge")
public class DavinciFormularyDrug extends MedicationKnowledge {

	private static final long serialVersionUID = 1L;

	@SearchParamDefinition(name = "DrugName", path = "MedicationKnowledge.code.coding.display", description = "Accesses the Descriptive Name of a FormularyDrug", type = "string")
	public static final String SP_DRUGNAME = "DrugName";

	@SearchParamDefinition(name = "DrugPlan", path = "MedicationKnowledge.extension.where(url='http://hl7.org/fhir/us/davinci-drug-formulary/StructureDefinition/usdf-PlanID-extension').value", description = "Accesses the DrugPlan ID of a FormularyDrug", type = "token")
	public static final String SP_DRUGPLAN = "DrugPlan";

	@SearchParamDefinition(name = "DrugTier", path = "MedicationKnowledge.extension.where(url='http://hl7.org/fhir/us/davinci-drug-formulary/StructureDefinition/usdf-DrugTierID-extension').value", description = "Accesses the DrugTier ID of a FormularyDrug", type = "token")
	public static final String SP_DRUGTIER = "DrugTier";
}

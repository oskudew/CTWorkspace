package com.citiustech.fastplus.test.provider;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.ResourceType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.FHIRRepositoryBaseSQLQueryBuilder;
import com.citiustech.fastplus.querybuilder.types.ReferenceParamQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.ReferenceParam;

@ExtendWith(MockitoExtension.class)
class ReferenceParamQueryFragmentBuilderTest {

	@InjectMocks
	static ReferenceParamQueryFragmentBuilder referenceParamQueryFragmentBuilder;
	
	@Spy
	private static FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

	@Mock
    private static CommonQueryUtil commonQueryUtil;
	
	String resourceTypeAlias = "LocationIXYp";
	String resourceType= ResourceType.Location.name();
	String paramName = Location.SP_PARTOF;
	String value;
	
	@BeforeAll
	static void createFhirRepositoryTableConfigurationAndObjectIntialization() throws IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();
		fhirRepositoryTableConfiguration = objectMapper.readValue(TestConstants.tableConfigString,FHIRRepositoryTableConfiguration.class);
		 fhirRepositoryTableConfiguration.duplicateTypeMap();
		 referenceParamQueryFragmentBuilder = new ReferenceParamQueryFragmentBuilder(
                 fhirRepositoryTableConfiguration,commonQueryUtil);
		 
	}
	FHIRRepositoryBaseSQLQueryBuilder queryBuilder = new FHIRRepositoryBaseSQLQueryBuilder(
            fhirRepositoryTableConfiguration, resourceType);
	
	@DisplayName("Test case for reference param on frameQueryFragment method where targetList empty(null)")
	@Test
	void test_frameQueryFragmentForTargetListNull() {
		
		value = "QA-Loc-12ref";
		ReferenceParam paramType = new ReferenceParam(value);
		List<String> targetList = new ArrayList<>();
		
		queryBuilder.setParamType(ParamType.REFERENCE);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getIdPart(), true);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getResourceType(), false);
		
		when(commonQueryUtil.getTargetReferenceList(resourceType, paramName)).thenReturn(targetList);
		when(commonQueryUtil.findPrefixValue(paramType.getIdPart())).thenReturn(null);
		
		Condition actualValue = referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(LocationIXYp.attribute = 'partof') AND (LocationIXYp.value ILIKE NULL)");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for reference param on frameQueryFragment method with theResourceType parameter set")
	@Test
	void test_frameQueryFragmentForResourceType() {
		
		value = "Location/QA-Loc-12ref";
		ReferenceParam paramType = new ReferenceParam(value);
		
		queryBuilder.setParamType(ParamType.REFERENCE);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getIdPart(), true);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getResourceType(), false);
		
		when(commonQueryUtil.findPrefixValue(paramType.getResourceType(), paramType.getIdPart())).thenReturn("-loc-QA-Loc-12ref");
		
		Condition actualValue = referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("((LocationIXYp.attribute = 'partof') AND (LocationIXYp.trgttype = 'Location')) AND (LocationIXYp.value = '-loc-QA-Loc-12ref')");
		
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	
	@DisplayName("Test case for reference param on frameQueryFragment method where Isblank method true")
	@Test
	void test_frameQueryFragmentForIsBlank() {
		
		value = "";
		ReferenceParam paramType = new ReferenceParam(value);
		
		queryBuilder.setParamType(ParamType.REFERENCE);
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getIdPart(), true);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getResourceType(), false);
		
		Condition actualValue = referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName);
		Condition expectedValue = Condition.EMPTY;
		
		assertEquals(expectedValue,actualValue);
		
	}
	
	@DisplayName("Test case for reference param on frameQueryFragment method where target size is 1")
	@Test
	void test_frameQueryFragmentForTargetListSize1() {
		String resource = ResourceType.DocumentReference.name();
		String resourceAlias = "DocumentReferencevzcV";
		String paramName = DocumentReference.SP_PATIENT;
		List<String> targetList = new ArrayList<>();
		targetList.add("patient");
		ReferenceParam paramType = new ReferenceParam("7b7709ff-a107-49ea-8211-56771b65cd19");
		
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getIdPart(), true);
		doNothing().when(commonQueryUtil).validateParamValue(paramType.getResourceType(), false);
		
		when(commonQueryUtil.getTargetReferenceList(resource, paramName)).thenReturn(targetList);
		when(commonQueryUtil.findPrefixValue(targetList.get(0), paramType.getIdPart())).thenReturn("Kern-pat-7b7709ff-a107-49ea-8211-56771b65cd19");
		
		Condition actualValue = referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resource, resourceAlias, paramType, paramName);
		Condition expectedValue = ComboCondition.and("(DocumentReferencevzcV.attribute = 'patient') AND (DocumentReferencevzcV.value = 'Kern-pat-7b7709ff-a107-49ea-8211-56771b65cd19')");
		assertEquals(expectedValue.toString(),actualValue.toString());
		
	}
	
	@DisplayName("Test case for reference param on frameQueryFragment method for value is null and FHIRException thrown")
	@Test
	void test_frameQueryFragmentForException() {
		
		ReferenceParam paramType = new ReferenceParam();
		
		queryBuilder.setParamType(ParamType.REFERENCE);
		
		doThrow(new FHIRException("FPE-3003")).when(commonQueryUtil).validateParamValue(paramType.getIdPart(), true);
		
		FHIRException exception = Assertions.assertThrows(FHIRException.class, () -> referenceParamQueryFragmentBuilder.frameQueryFragment(queryBuilder, resourceType, resourceTypeAlias, paramType, paramName));
		assertEquals(ExceptionCodes.INVALID_PARAMETER_VALUE.getCode(), exception.getMessage());
	}
	
	
}

package com.citiustech.fastplus.querybuilder.types;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.config.FHIRRepositoryTableConfiguration;
import com.citiustech.fastplus.querybuilder.QueryBuilder;
import com.citiustech.fastplus.querybuilder.TypeQueryFragmentBuilder;
import com.citiustech.fastplus.util.CommonQueryUtil;
import com.citiustech.fastplus.util.ParamType;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.healthmarketscience.sqlbuilder.BinaryCondition;
import com.healthmarketscience.sqlbuilder.ComboCondition;
import com.healthmarketscience.sqlbuilder.Condition;

import ca.uhn.fhir.rest.param.TokenParam;

/**
 * 
 * This is a class for StringParamQueryFragmentBuilder which used to build
 * query fragments for token search parameters
 * 
 */

@Component
public class TokenParamQueryFragmentBuilder implements TypeQueryFragmentBuilder<TokenParam> {
    
    /**
     * This is a fhirRepositoryTableConfiguration field used to hold
     * FHIRRepositoryTableConfiguration object
     */
    private FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration;

    /**
     * This is a commonQueryUtil field used to hold CommonQueryUtil object
     */
    private CommonQueryUtil commonQueryUtil;
    
    /**
     * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
     */
    private FHIRErrorHandler fhirErrorHandler;
    
    
    @Autowired
    public TokenParamQueryFragmentBuilder(FHIRRepositoryTableConfiguration fhirRepositoryTableConfiguration,
			CommonQueryUtil commonQueryUtil, FHIRErrorHandler fhirErrorHandler) {
		super();
		this.fhirRepositoryTableConfiguration = fhirRepositoryTableConfiguration;
		this.commonQueryUtil = commonQueryUtil;
		this.fhirErrorHandler = fhirErrorHandler;
	}
    
    public TokenParamQueryFragmentBuilder() {
    	
    }
    
	/**
     * returns binary condition for missing
     * 
     * @param param
     * @param value
     * @return BinaryCondition
     */
    public BinaryCondition missing(String param) {
        return BinaryCondition.equalTo(param, null);
    }
    
    /**
	 * returns condition by framing query fragment using input parameters
	 * 
	 * @param queryBuilder
	 * @param resurceType
	 * @param alias
	 * @param paramType
	 * @param paramName
	 * @return Condition
	 */
    @Override
    public Condition frameQueryFragment(QueryBuilder queryBuilder, String resourceType, String resourceTypeAlias, TokenParam paramType, String paramName) {
	commonQueryUtil.validateParamValue(paramType.getSystem(), false);
	commonQueryUtil.validateParamValue(paramType.getValue(), false);

	if (StringUtils.isBlank(paramType.getSystem()) && StringUtils.isBlank(paramType.getValue())) {
	    throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_PARAMETER_VALUE);
	}

        Condition condition = BinaryCondition.equalTo(fhirRepositoryTableConfiguration
                .getSearchAttributeColumn(resourceTypeAlias), paramName);

        if (!StringUtils.isBlank(paramType.getSystem())) {
            condition = createCondition(condition, resourceType, resourceTypeAlias, paramType.getSystem(), 0);
        }

        if (!StringUtils.isBlank(paramType.getValue())) {
	    String value;
	    if ("_id".equals(paramName)) {
		value = commonQueryUtil.findPrefixValue(resourceType, paramType.getValue());
	    } else {
		value = paramType.getValue();
	    }
            
            condition = createCondition(condition, resourceType, resourceTypeAlias, value, 1);
        }
        return condition;
    }
    
    /**
     * returns condition by processing input parameters
     * 
     * @param condition
     * @param resourceType
     * @param resourceTypeAlias
     * @param paramValue
     * @param index
     * @return Condition
     */
	private Condition createCondition(Condition condition, String resourceType, String resourceTypeAlias, String paramValue,
			int index) {
		return ComboCondition
				.and(condition,
						BinaryCondition.equalTo(
								fhirRepositoryTableConfiguration
										.getSearchColumn(ParamType.TOKEN.getValue(), resourceType, resourceTypeAlias).get(index),
								paramValue));
	}
}

package com.citiustech.fastplus.util;

import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.util.constant.PrefixMapping;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;

/**
 * 
 * This is a class for CommonQueryUtil which provides utility methods for
 * performing validations
 * 
 */

@Component
@PropertySource("classpath:application.properties")
public class CommonQueryUtil {

	
	/**
   	 * This is a invalidSpecialCharacters field used to hold invalid char value 
   	 */
	@Value("${param.invalid.char:}")
	private String invalidSpecialCharacters;
	
	/**
   	 * This is a clientPrefix field used to hold client prefix value 
   	 */
	@Value("${fhir.client.prefix:}")
	private String clientPrefix;

	/**
	 * This is a customResourceUtil field used to hold CustomResourceUtil object
	 */
	private CustomResourceUtil customResourceUtil;
	
	/**
   	 * This is a fhirErrorHandler field used to hold FHIRErrorHandler object
   	 */
	private FHIRErrorHandler fhirErrorHandler;

	/**
	 * performs validation on input parameter
	 * 
	 * @param param
	 * @param isRequired
	 */
	
	
	@Autowired
	public CommonQueryUtil( FHIRErrorHandler fhirErrorHandler,CustomResourceUtil customResourceUtil) {
		super();
		this.fhirErrorHandler = fhirErrorHandler;
		this.customResourceUtil = customResourceUtil;
	}
	
	
	
	public CommonQueryUtil() {

	}



	public String getInvalidSpecialCharacters() {
		return invalidSpecialCharacters;
	}



	public void setInvalidSpecialCharacters(String invalidSpecialCharacters) {
		this.invalidSpecialCharacters = invalidSpecialCharacters;
	}



	public void validateParamValue(String param, boolean isRequired) {
		
		if (StringUtils.isBlank(param) && isRequired)
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_PARAMETER_VALUE);
		else if (StringUtils.isBlank(param))
			return;
	
		for (char ch : invalidSpecialCharacters.toCharArray()) {
			if (param.contains(Character.toString(ch)))
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.INVALID_PARAMETER_VALUE);
		}
	}
	
	/**
	 * used for validation Time Zone related dates.
	 * @param dateString
	 * @return
	 */
	public boolean isInvalidDateTime(String dateString) {
		boolean isInvalid = false;
		if(dateString.length()>24 && !dateString.matches(".*(\\+|-)\\d{2}(:?\\d{2})?$"))
			isInvalid = true;
		return isInvalid;
	}
	
	
	/**
	 * 
	 * @param resourceType
	 * @param paramName
	 * @return
	 */
	public List<String> getTargetReferenceList(String resourceType, String paramName) {
	    try {
		return customResourceUtil.getReferenceTargetList(resourceType, paramName);
	    } catch (NoSuchFieldException | ClassNotFoundException e) {
		throw fhirErrorHandler.handleErrorCode(ExceptionCodes.QUERY_ERROR);
	    }
	}
	
	/**
	 * 
	 * @param resourceType
	 * @param idValue
	 * @return
	 */
	public String findPrefixValue(String resourceType, String idValue) {
	    if (StringUtils.isBlank(clientPrefix)) {
		return idValue;
	    } else {
		String prefix = clientPrefix + "-" + PrefixMapping.valueOf(resourceType.toUpperCase(Locale.ROOT)) + "-";
		return idValue.startsWith(prefix) ? idValue : (prefix + idValue);
	    }
	}


	/**
	 * 
	 * @param idValue
	 * @return
	 */
	public String findPrefixValue(String idValue) {
	    if (StringUtils.isBlank(clientPrefix)) {
		return idValue;
	    } else {
		String prefix = clientPrefix + "-";
		return idValue.startsWith(prefix) ? idValue : (clientPrefix + "-%%-" + idValue);
	    }
	}
	

	public String getClientPrefix() {
		return clientPrefix;
	}
	public void setClientPrefix(String clientPrefix) {
		this.clientPrefix = clientPrefix;
	}


	
}

package com.citiustech.fastplus.validator;

import org.hl7.fhir.r5.model.CodeableConcept;

import java.util.List;

/**
 * Class which used for capture the FHIR Validation results
 */
public class ValidationResult {

    // the result for the FHIR validation.
    private boolean result;
    // the list of the code.
    private List<CodeableConcept> warnings;
    // the list of errors.
    private List<ErrorDetail> errors;

    /**
     * Constructor for the class.
     *
     * @param result   result of the FHIR validation.
     * @param warnings the list of codes
     * @param errors   the list of errors
     */
    public ValidationResult(boolean result, List<CodeableConcept> warnings, List<ErrorDetail> errors) {
        this.result = result;
        this.warnings = warnings;
        this.errors = errors;
    }

    /**
     * @return the list of errors for the FHIR validation
     */
    public List<ErrorDetail> getErrors() {
        return errors;
    }

    /**
     * @return the list of codes.
     */
    public List<CodeableConcept> getWarnings() {
        return warnings;
    }

    /**
     * @return the result of the FHIR validation.
     */
    public boolean isResult() {
        return result;
    }
}

package com.citiustech.fastplus.r4.model;

import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Organization;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.api.annotation.SearchParamDefinition;

@ResourceDef(name = "Organization", profile = "http://hl7.org/fhir/StructureDefinition/Organization")
public class DavinciOrganization extends Organization {

	private static final long serialVersionUID = 1L;

	@SearchParamDefinition(name = "coverage-area", path = "Organization.extension.where(url='http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/location-reference')", 
			description = "Select health insurance provider networks available in a region described by the specified location", type = "reference", target = {
			Location.class })
	public static final String SP_COVERAGE_AREA = "coverage-area";

}

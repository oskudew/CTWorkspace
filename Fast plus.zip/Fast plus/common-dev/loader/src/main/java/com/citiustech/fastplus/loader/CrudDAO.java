package com.citiustech.fastplus.loader;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.citiustech.fastplus.loader.entity.FhirResourceData;
import com.citiustech.fastplus.loader.entity.ReferenceLink;
import com.citiustech.fastplus.loader.entity.Search;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants.LoggingMarkers;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.FHIRErrorHandler;
import com.jayway.jsonpath.JsonPath;

import net.minidev.json.JSONArray;

@Service
public class CrudDAO {

	private static final Logging logger = LoggerFactory.getLogger(CrudDAO.class.getName());
	
	private static final String SUBSCRIPTION_RESOURCE_NAME = QueryConstants.SUBSCRIPTION_RESOURCE_NAME;
	
	/**
	 * This is a jdbcTemplate field used to hold jdbcTemplate object to execute
	 * queries
	 */
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * This is a fhirErrorHandler field used to hold fhirErrorHandler object
	 */
	@Autowired
	protected FHIRErrorHandler fhirErrorHandler;
	
	/**
	 * This is a namedParameterJdbcTemplate field used to hold namedParameterJdbcTemplate object to execute
	 * queries with namedParams
	 */
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	/**
	 * @param resourceType
	 * @param id
	 * @param json
	 * @param searches
	 * @param references
	 * @throws SQLException
	 */

	@Transactional(rollbackFor = { Exception.class })
	public void insert(FhirResourceData fhirResourceData){
		
		final String resourceType = fhirResourceData.getResourceName();
		final String id = fhirResourceData.getResourceId();
		final String json = fhirResourceData.getJsonStr();
		final List<Search> searches = fhirResourceData.getSearches();
		final List<ReferenceLink> references = fhirResourceData.getReferences();
		
		insertResourceInfo(id, resourceType, json);
		insertSearchParams(resourceType, searches);
		insertReferenceLink(references, resourceType);
		insertResource(resourceType, id);
		
		if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			insertSubscriptionDetails(id, json);
			insertSubscribedChannel(id, json);
			insertSubscribedPatient(id, json);
			insertSubscribedResource(id, json);
		}
	}
	
	/**
	 * @param resourceType
	 * @param id
	 * @throws SQLException
	 */
	@Transactional(rollbackFor = { Exception.class })
	public void delete(final String resourceType, final String id){
		insertResourceHistory(resourceType, id);
		deleteResourceAndSearchAndInfo(resourceType, id);
		if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
				deleteSubscriptionDetailsandPatient(id);
		}	
	}

	/**
	 * @param resourceType
	 * @param id
	 * @param json
	 * @param searches
	 * @param references
	 * @throws SQLException
	 */
	@Transactional(rollbackFor = { Exception.class })
	public void update(FhirResourceData fhirResourceData){
		
		final String resourceType = fhirResourceData.getResourceName();
		final String id = fhirResourceData.getResourceId();
		final String json = fhirResourceData.getJsonStr();
		final List<Search> searches = fhirResourceData.getSearches();
		final List<ReferenceLink> references = fhirResourceData.getReferences();

		int rowsAfftected = insertResourceHistory(resourceType, id);

		if (rowsAfftected > 0) {
			deleteResourceAndSearchAndInfo(resourceType, id);
			insertResourceInfo(id, resourceType, json);
			insertSearchParams(resourceType, searches);
			insertReferenceLink(references, resourceType);
			insertResource(resourceType, id);
		} else {
			throw fhirErrorHandler.handleErrorCode(ExceptionCodes.NO_RECORDS);
		}
		if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			if(getSubscriptionDetails(id) > 0) {
				deleteSubscriptionDetailsandPatient(id);
				insertSubscriptionDetails(id, json);
				insertSubscribedChannel(id, json);
				insertSubscribedPatient(id, json);
				insertSubscribedResource(id, json);
			}
			else {
				throw fhirErrorHandler.handleErrorCode(ExceptionCodes.NO_RECORDS);
			}
		}

	}

	public int getSubscriptionDetails(String id) {
		
		final String selectQuery = QueryConstants.GET_SUBSCRIPTION_COUNT;
		return jdbcTemplate.queryForObject(selectQuery, new Object[] {id}, Integer.class);
	}

	public void insertResource(final String resourceType, final String id){

		final String insertQuery = new StringBuilder(QueryConstants.INSERTINTO)
									.append(resourceType)
									.append(QueryConstants.RESOURCE_TABLE_QUERY).toString(); 
		int update = jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(insertQuery);
				ps.setString(1, id);
				return ps;
			}
		});
		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertResource Count ---> {}" + update);
	}

	/**
	 * @param id
	 * @param resourceType
	 * @param resourceText
	 * @throws SQLException
	 */
	public void insertResourceInfo(final String id, final String resourceType, final String resourceText){

		String resourceinfoTblName = QueryConstants.RESOURCEINFO;
		if (resourceType.equalsIgnoreCase(QueryConstants.PROVENANCE)) {
			resourceinfoTblName = QueryConstants.RESOURCEINFO_PROVENANCE;
		}else if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			resourceinfoTblName = QueryConstants.SUBSCRIPTION_INFO_TABLE; 
		}
		final String insertQuery = new StringBuilder(QueryConstants.INSERTINTO)
										.append(resourceinfoTblName)
										.append(QueryConstants.RESOURCEINFO_TABLE_QUERY).toString();
		
		int update = jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(insertQuery);
				ps.setString(1, id);
				ps.setString(2, resourceType);
				ps.setString(3, resourceText);
				return ps;
			}
		});

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertResourceInfo Count ---> {}" + update);
	}

	/**
	 * @param references
	 * @param resourceType
	 * @throws SQLException
	 */
	public void insertReferenceLink(final List<ReferenceLink> references, final String resourceType){

		String resourcelinkTblName = QueryConstants.RESOURCELINK;
		if (resourceType.equalsIgnoreCase(QueryConstants.PROVENANCE)) {
			resourcelinkTblName = QueryConstants.RESOURCELINK_PROVENANCE;
		}else if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			resourcelinkTblName = QueryConstants.SUBSCRIPTION_LINK_TABLE;
		}

		final String insertQuery = new StringBuilder(QueryConstants.INSERTINTO)
										.append(resourcelinkTblName)
										.append(QueryConstants.RESOURCELINK_TABLE_QUERY).toString(); 

		int[] count = jdbcTemplate.batchUpdate(insertQuery,
				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, references.get(i).getSrcId());
						ps.setString(2, references.get(i).getSrcType());
						ps.setString(3, references.get(i).getTgtId());
						ps.setString(4, references.get(i).getTgtType());
						ps.setString(5, references.get(i).getAttribute());
					}

					public int getBatchSize() {
						return references.size();
					}
				});

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertReferenceLink Count ---> {}" + Arrays.toString(count));
	}

	/**
	 * @param resourceType
	 * @param searches
	 * @throws SQLException
	 */
	public void insertSearchParams(final String resourceType, final List<Search> searches){

		final String insertQuery = new StringBuilder(QueryConstants.INSERTINTO)
										.append(resourceType.toLowerCase())
										.append(QueryConstants.SEARCH_TABLE_QUERY).toString(); 

		int[] count = jdbcTemplate.batchUpdate(insertQuery, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, searches.get(i).getId());
				ps.setString(2, searches.get(i).getDatatype());
				ps.setString(3, searches.get(i).getSystem());
				ps.setString(4, searches.get(i).getCode());
				ps.setString(5, searches.get(i).getValue());
				ps.setString(6, searches.get(i).getUnit());
				ps.setString(7, searches.get(i).getStartvalue());
				ps.setString(8, searches.get(i).getEndvalue());
				ps.setString(9, searches.get(i).getAttribute());
				ps.setString(10, searches.get(i).getPatientId());
				ps.setString(11, searches.get(i).getTrgtType());
				ps.setString(12, searches.get(i).getLastUpdated());
			}

			public int getBatchSize() {
				return searches.size();
			}
		});

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertSearchParams Count ---> {}" + Arrays.toString(count));

	}
	
	public void insertSubscriptionDetails(String id, String json) {
		JSONObject jsonObj = new JSONObject(json);
		String validFrom = getAttribute(jsonObj, DataConstants.STARTDATE);
		String validTo = getAttribute(jsonObj, DataConstants.ENDDATE);
		String status = getAttribute(jsonObj, DataConstants.STATUS);
		String subscriptionName = getAttribute(jsonObj, DataConstants.SUBSCRIPTION_NAME);
		String providerId = getAttribute(jsonObj, DataConstants.PROVIDERID);

		Map<String, Object> inParameters = new HashMap<>();
		inParameters.put("subscriptionName", subscriptionName);
		inParameters.put("id", id);
		inParameters.put("validFrom", validFrom);
		inParameters.put("validTo", validTo);
		inParameters.put("status", status);
		inParameters.put("providerId", providerId);
		
		int count  = namedParameterJdbcTemplate.update(QueryConstants.SUBSCRIPTION_DETAILS_INSERT_QUERY, inParameters);

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertSubscriptionDetails Count ---> {}"+ count);
		
	}


	public void insertSubscribedChannel(String id, String json) {
		JSONObject jsonObj = new JSONObject(json);
		String channelType = getAttribute(jsonObj, DataConstants.CHANNEL_TYPE);
		String channelendpoint = getAttribute(jsonObj, DataConstants.CHANNEL_ENDPOINT);
		JSONArray channelHeaders =  getAttributeArray(jsonObj, DataConstants.CHANNEL_HEADER);
		String channelHeader = "";
		if(!channelHeaders.isEmpty()) {
			 channelHeader = channelHeaders.get(0).toString();
		}
		
		Map<String, Object> inParameters = new HashMap<>();
		inParameters.put("channelType", channelType);
		inParameters.put("id", id);
		inParameters.put("channelendpoint", channelendpoint);
		inParameters.put("channelHeader", channelHeader);
		
		int count  = namedParameterJdbcTemplate.update(QueryConstants.SUBSCRIPTION_CHANNEL_INSERT_QUERY, inParameters);

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertSubscribedChannelDetails Count ---> {}"+ count);
	}

	public void insertSubscribedPatient(String id, String json) {
		JSONObject jsonObj = new JSONObject(json);
		JSONArray patientId = getAttributeArray(jsonObj, DataConstants.PATIENTID);
		List<String> patientIdList = new ArrayList<>();
		for(int i = 0;i < patientId.size(); i++) {
			String[] split = ((String)patientId.get(i)).split("/");
			patientIdList.add(split[split.length - 1]);
		}

		int[] count = jdbcTemplate.batchUpdate(QueryConstants.SUBSCRIPTION_PATIENT_INSERT_QUERY,

				new BatchPreparedStatementSetter() {
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						ps.setString(1, id);
						ps.setString(2, patientIdList.get(i));
					}

					public int getBatchSize() {
						return patientIdList.size();
					}
				});

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertSubscribedPatientDetails Count ---> {}"+ Arrays.toString(count));
	}
	
	public void insertSubscribedResource(String id, String json) {
		JSONObject jsonObj = new JSONObject(json);
		String resources =  getAttribute(jsonObj, DataConstants.RESOURCES);
		String[] patientIdList = resources.split(",");
		
		int[] count = jdbcTemplate.batchUpdate(QueryConstants.SUBSCRIPTION_RESOURCE_INSERT_QUERY,
				
				new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, id);
				ps.setString(2, patientIdList[i]);
			}
			
			public int getBatchSize() {
				return patientIdList.length;
			}
		});
		
		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertSubscribedResourceDetails Count ---> {}"+ Arrays.toString(count));
	}
	

	public void deleteResourceAndSearchAndInfo(final String resourceType, final String id){
		String resourceinfoTblName = QueryConstants.RESOURCEINFO;
		String resourcelinkTblName = QueryConstants.RESOURCELINK;
		if (resourceType.equalsIgnoreCase(QueryConstants.PROVENANCE)) {
			resourceinfoTblName = QueryConstants.RESOURCEINFO_PROVENANCE;
			resourcelinkTblName = QueryConstants.RESOURCELINK_PROVENANCE;
		}else if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			resourceinfoTblName = QueryConstants.SUBSCRIPTION_INFO_TABLE;
			resourcelinkTblName = QueryConstants.SUBSCRIPTION_LINK_TABLE;
		}

		final String deleteResourceTblQuery = new StringBuilder(QueryConstants.DELETEFROM)
													.append(resourceType)
													.append(" where id='")
													.append(id)
													.append("'").toString(); 
		final String deleteSearchTblQuery = new StringBuilder(QueryConstants.DELETEFROM)
													.append(resourceType)
													.append("search where id='")
													.append(id)
													.append("'").toString(); 
		final String deleteResourceInfoTblQuery = new StringBuilder(QueryConstants.DELETEFROM)
													.append(resourceinfoTblName)
													.append(" where id='")
													.append(id)
													.append("' and resourcetype='")
													.append(resourceType)
													.append("'").toString(); 
		final String deleteResourceLinkTblQuery =  new StringBuilder(QueryConstants.DELETEFROM)
													.append(resourcelinkTblName)
													.append(" where srcid='")
													.append(id)
													.append("' and srctype='")
													.append(resourceType)
													.append("'").toString(); 
		int[] count = jdbcTemplate.batchUpdate(deleteResourceTblQuery, deleteSearchTblQuery, deleteResourceInfoTblQuery,
				deleteResourceLinkTblQuery);

		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"deleteResourceAndSearchAndInfo Count ---> {}" + Arrays.toString(count));

	}

	public void deleteSubscriptionDetailsandPatient(String id) {

		String whereCondition = " where subscriptionid='" + id + "'";

		final String deletesubscriptionDetailsTblQuery = new StringBuilder(QueryConstants.DELETEFROM)
				.append(QueryConstants.SUBSCRIPTION_DETAILS_TABLE).append(whereCondition).toString();
		
		final String deletesubscribedPatientTblQuery = new StringBuilder(QueryConstants.DELETEFROM)
				.append(QueryConstants.SUBSCRIBED_PATIENT_TABLE).append(whereCondition).toString();
		
		final String deletesubscriptionResourceTblQuery =new StringBuilder(QueryConstants.DELETEFROM)
				.append(QueryConstants.SUBSCRIPTION_RESOURCE_TABLE).append(whereCondition).toString();
		
		final String deletesubscribedChannelTblQuery =new StringBuilder(QueryConstants.DELETEFROM)
				.append(QueryConstants.SUBSCRIBED_CHANNEL_TABLE).append(whereCondition).toString();

		int[] count = jdbcTemplate.batchUpdate(deletesubscriptionDetailsTblQuery, deletesubscribedPatientTblQuery,deletesubscriptionResourceTblQuery,deletesubscribedChannelTblQuery);
		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"deleteSubscriptionDetailsandPatient Count ---> {}"+ Arrays.toString(count));
	}

	public int insertResourceHistory(final String resourceType, final String id){

		String resourceinfoTblName = QueryConstants.RESOURCEINFO;
		if (resourceType.equalsIgnoreCase(QueryConstants.PROVENANCE)) {
			resourceinfoTblName = QueryConstants.RESOURCEINFO_PROVENANCE;
		}else if(SUBSCRIPTION_RESOURCE_NAME.equalsIgnoreCase(resourceType)) {
			resourceinfoTblName = QueryConstants.SUBSCRIPTION_INFO_TABLE;
		}

		final String insertQuery = new StringBuilder(QueryConstants.INSERTINTO)
				.append(resourceType)
				.append("_history (id, resourcetext, lastupdated) ")
				.append("select id, resourcetext, current_timestamp from ")
				.append(resourceinfoTblName)
				.append(" where id=? and resourcetype=?;").toString(); 

		int update = jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(insertQuery);
				ps.setString(1, id);
				ps.setString(2, resourceType);
				return ps;
			}
		});
		logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"insertResourceHistory Count ---> {} " + update);
		return update;
	}
	
	public String getAttribute(JSONObject json, String path) {
		String value = null;
		try {
			value = JsonPath.read(json.toString(), path);
		} catch(com.jayway.jsonpath.PathNotFoundException pnfe) {
			logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"No value in json...");
		}
		return value;
	}
	
	public JSONArray getAttributeArray(JSONObject json, String path) {
		JSONArray value = new JSONArray();
		try {
			value = JsonPath.read(json.toString(), path);
		} catch(com.jayway.jsonpath.PathNotFoundException pnfe) {
			logger.logDebug(LoggingMarkers.APPLICATION.getValue(),"No value in json...");
		}
		return value;
	}

}

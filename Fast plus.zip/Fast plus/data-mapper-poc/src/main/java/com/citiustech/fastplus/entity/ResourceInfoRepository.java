package com.citiustech.fastplus.entity;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ResourceInfoRepository extends CrudRepository<ResourceInfo, Integer>  {

}

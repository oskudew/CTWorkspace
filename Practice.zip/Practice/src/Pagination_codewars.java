
public class Pagination_codewars implements Runnable{
	
	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
//		Pagination_codewars pc = new Pagination_codewars();
//		pc.method1(2,3);
		Thread t = new Thread(new Pagination_codewars());
		t.start();
		t.start();
		t.start();
		System.out.println(t.getState());

	}

	public void run() {
		System.out.println("welcom");
	}
}


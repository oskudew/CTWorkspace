package com.citiustech.fastplus.util.exception;

/**
 * 
 * This is an enum ExceptionCodes used to define constant codes for different
 * exception scenarios
 *
 */

public enum ExceptionCodes {

	/**
	 * constant for invalid data code
	 */
	INVALID_DATA("FPE-1000"),

	/**
	 * constant for query error
	 */
	QUERY_ERROR("FPE-1001"),
	
	/**
	 * constant for Invalid Request error
	 */
	INVALID_REQUEST("FPE-1007"),

	/**
	 * constant for database connection error
	 */
	DB_CONNECTION_ERROR("FPE-1002"),

	/**
	 * constant for redis connection error
	 */
	REDIS_CONNECTION_ERROR("FPE-1003"),

	/**
	 * constant for illegal argument error
	 */
	ILLEGAL_ARGUMENT("FPE-1004"),
	
	/**
	 * constant for invalid headers
	 */
	INVALID_HEADER("FPE-1005"),
	
	/**
	 * constant for invalid type
	 */
	INVALID_TYPE("FPE-1006"),

	/**
	 * constant for authorization error
	 */
	AUTHORIZATION_ERROR("FPE-2000"),

	/**
	 * constant for FPE3000
	 */
	FPE3000("FPE-3000"),

	/**
	 * constant for missing parameter
	 */
	PARAMETER_MISSING("FPE-3001"),

	/**
	 * constant for invalid parameter value
	 */
	INVALID_PARAMETER_VALUE("FPE-3003"),

	/**
	 * constant for parsing error
	 */
	PARSING_ERROR("FPE-3002"),

	/**
	 * constant for patient parameter missing error
	 */
	PATIENT_PARAM_MISSING("FPE-3004"),

	/**
	 * constant for date format validation error
	 */
	INVALID_DATE_FORMAT("FPE-3005"),

	/**
	 * constant for no records
	 */
	NO_RECORDS("FPE-4000"),

	/**
	 * constant for consent server unavailable
	 */
	CONSENT_SERVER_UNAVAILABLE("FPE-5000"),

	/**
	 * constant for consent internal server error
	 */
	CONSENT_INTERNAL_SERVER("FPE-5001"),

	/**
	 * constant for misconfiguration in Consent validation
	 */
	CONSENT_VALIDATION_MISCONFIGURED("FPE-5002"),
	
	/**
	 * constant for IAM consent error
	 */
	IAM_CONSENT_VALIDATION_ERROR("FPE-5003"),
	
	/**
	 * constant for consent not found for patient
	 */
	CONSENT_NOT_FOUND_FOR_PATIENT("FPE-5004"),
	
	/**
	 * constant for consent not found
	 */
	CONSENT_NOT_FOUND("FPE-5005"),
	
	/**
	 * constant for download url expired
	 */
	DOWNLOAD_URL_EXPIRED("FPE-6000"),

	/**
	 * constant for file not found
	 */
	FILE_NOT_FOUND("FPE-6001"),

	/**
	 * constant for path not found
	 */
	PATH_NOT_FOUND("FPE-6002"),

	/**
	 * constant for resource validation failed
	 */
	RESOURCE_VALIDATION_FAILED("FPE-6003"),
	
	/**
	 * constant for resource insertion failed
	 */
	RESOURCE_INSERTION_FAILED("FPE-6006"),

	/**
	 * constant for file size exceeded
	 */
	MAX_FILE_SIZE_EXCEEDED("FPE-6004"),
	
	/**
	 * constant for file size exceeded
	 */
	NO_OR_MULTIPLE_MATCH_FOUND("FPE-7000"),
	
	/**
	 * constant for unauthorized download url access
	 */
	UNAUTHORIZED_USER("FPE-6005");
	
	/**
	 * This is a code field used to hold code value
	 */
	private String code;

	/**
	 * parameterized constructor
	 * 
	 * @param code
	 */
	ExceptionCodes(String code) {
		this.code = code;
	}

	/**
	 * returns code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * validates the input code is valid or not
	 * 
	 * @param code
	 * @return ExceptionCodes
	 */
	public static ExceptionCodes findEnumCode(String code) {
		for (ExceptionCodes b : ExceptionCodes.values()) {
			if (b.getCode().equalsIgnoreCase(code)) {
				return b;
			}
		}
		return ExceptionCodes.QUERY_ERROR;
	}

	/**
	 * returns string representation for this class
	 */
	@Override
	public String toString() {
		return this.code;
	}
}

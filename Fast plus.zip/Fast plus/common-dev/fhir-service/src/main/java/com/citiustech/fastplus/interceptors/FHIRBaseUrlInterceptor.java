package com.citiustech.fastplus.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Bundle;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.api.server.ResponseDetails;
import ca.uhn.fhir.rest.server.servlet.ServletRequestDetails;

@Component
@Interceptor
public class FHIRBaseUrlInterceptor {

	@Value("${server.baseUrl:}")
	private String serverBaseUrl;

	@Hook(Pointcut.SERVER_OUTGOING_RESPONSE)
	public boolean modifyPagingUrl(RequestDetails requestDetails, ServletRequestDetails servletRequestDetails,
			IBaseResource resource, ResponseDetails responseDetails, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {

		if (responseDetails.getResponseResource() instanceof Bundle) {
			Bundle bundle = (Bundle) responseDetails.getResponseResource();
			bundle.getLink().stream().forEach(link -> {
				String url = link.getUrl().replace(requestDetails.getFhirServerBase(), serverBaseUrl);
				link.setUrl(url);
			});

			bundle.getEntry().stream().forEach(entry -> {
				String url = entry.getFullUrl().replace(requestDetails.getFhirServerBase(), serverBaseUrl);
				entry.setFullUrl(url);
				if (entry.hasRequest()) {
					entry.getRequest().setUrl(
							entry.getRequest().getUrl().replace(requestDetails.getFhirServerBase(), serverBaseUrl));
				}

			});

		}

		requestDetails.setFhirServerBase(serverBaseUrl);

		return true;
	}
}

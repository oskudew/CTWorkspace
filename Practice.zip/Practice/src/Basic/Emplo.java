package Basic;

public interface Emplo {
  
	
}

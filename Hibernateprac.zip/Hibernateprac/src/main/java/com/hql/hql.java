package com.hql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import map.Question;

public class hql {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
		SessionFactory sf = con.buildSessionFactory();
		
		Session s = sf.openSession();
		Question q = new Question();		
		Query query = s.createQuery("from Question as q where q.Question_id=:x");
		
		query.setParameter("x", 101);
		//query.setParameter("y", 201);
		
		
		List<Question> list = query.list();
		
		for(Question ques: list) {
	//	System.out.println(ques.getQuestion_id()+" : "+ques.getQuestion()+": " + ques.getAnswer().getAnswer());
		}
		
		s.close();
		
		
		sf.close();

	}

}

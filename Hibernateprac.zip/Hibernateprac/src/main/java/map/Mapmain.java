package map;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Mapmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		
		Question q1 = new Question();
		q1.setQuestion_id(101);
		q1.setQuestion("What is a Programming Language");
		
		
		Answer a1 = new Answer();
		a1.setAnswer_Id(201);
		a1.setAnswer("Java is a programming language");
		//q1.setAnswer(a1);
		a1.setQuestion(q1);
		
		Question q2 = new Question();
		q2.setQuestion_id(102);
		q2.setQuestion("What is a String");
		
		Answer a2 = new Answer();
		a2.setAnswer_Id(202);
		a2.setAnswer("String is an immutable class");
		//q2.setAnswer(a2);
		a2.setQuestion(q2);
		

		Answer a3 = new Answer();
		a3.setAnswer_Id(302);
		a3.setAnswer("Java is Platform Independent");
		a3.setQuestion(q1);
		
		Answer a4 = new Answer();
		a4.setAnswer_Id(402);
		a4.setAnswer("Java is an Object oriented");
		a4.setQuestion(q1);
		
		List<Answer> list = new ArrayList();
		list.add(a1);
		list.add(a3);
		list.add(a4);
		q1.setAnswer(list);
		
		List<Answer> l2 = new ArrayList();
		l2.add(a2);
		q2.setAnswer(l2);
		
		Session s= sf.openSession();
		
		Transaction t = s.beginTransaction();
		
		s.save(q1);
		s.save(q2);
		
		
		t.commit();
		
		
		Question qget=(Question)s.get(Question.class, 101);
		System.out.println(qget.getQuestion());
			//	+" Answer: " + qget.getAnswer());
		
		Answer aget =(Answer)s.get(Answer.class, 201);
		System.out.println(aget);
		s.close();
		
		
		
		
	}

}

package com.citiustech.fastplus.config;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.citiustech.fastplus.util.AdapterUtil;
import com.healthmarketscience.sqlbuilder.CustomSql;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * This is a class for CommonTableConfiguration which holds data for common table
 * configuration
 * 
 */
@Getter
@Setter
public class ResInfoLinkTableConfiguration{
	/**
	 * This is a table field used to hold table name 
	 */
    private List<String> table;
    
    /**
	 * This is a projections field used to hold list of columns to be selected 
	 */
    private List<String> projections;
    
    /**
	 * This is a typeColumnMap field used to hold type of column 
	 */
    private Map<String, List<String>> typeColumnMap;
    
    /**
	 * This is a nestedsearchAttributes field used to hold nested search attributes 
	 */
    private Map<String, List<String>> nestedsearchAttributes;
    
    private List<String> periodSearchAttribute;

    /**
     * no argument constructor
     */
    public ResInfoLinkTableConfiguration() {
    }

    /**
     * parameterized constructor to initialize object with required values
     * 
     * @param table
     * @param projections
     */
    public ResInfoLinkTableConfiguration(List<String> table, List<String> projections) {
        this.table = table;
        this.projections = projections;
    }

	/**
     * returns aliased columns from projection 
     */
    public List<CustomSql> getProjectionsAliased(String table) {
        return projections
                .stream()
                .map(p -> new CustomSql(AdapterUtil.getAliasedColumn(table, p)))
                .collect(Collectors.toList());
    }

    /**
     * returns list of columns for input type
     * 
     * @param type
     * @return list of String
     */
    public List<String> getColumnForType(String table,String type) {
        return this.typeColumnMap.get(type)
                .stream()
                .map(p -> AdapterUtil.getAliasedColumn(table, p))
                .collect(Collectors.toList());

    }

    /**
     * returns columns with aliases based on input type
     * 
     * @param type
     * @return list of CustomSql
     */
    public List<CustomSql> getColumnWithAliasForType(String table,String type) {
        return this.typeColumnMap.get(type)
                .stream()
                .map(p -> new CustomSql(AdapterUtil.getAliasedColumn(table, p)))
                .collect(Collectors.toList());
    }


    /**
     * returns list of columns to be selected 
     */
    public List<String> getProjections() {
        return projections;
    }

    /**
     * sets list of columns to be selected
     * 
     * @param projections
     */
    public void setProjections(List<String> projections) {
        this.projections = projections;
    }

    /**
     * returns map of nested search attributes
     */
    public Map<String, List<String>> getNestedsearchAttributes() {
        return nestedsearchAttributes;
    }

    /**
     * sets map of nested search attributes
     * @param nestedsearchAttributes
     */
    public void setNestedsearchAttributes(
            Map<String, List<String>> nestedsearchAttributes) {
        this.nestedsearchAttributes = nestedsearchAttributes;
    }
    
    /**
     * returns type and columns in the form of map 
     */
    public Map<String, List<String>> getTypeColumnMap() {
        return typeColumnMap;
    }

    /**
     * sets map of type and column
     * @param typeColumnMap
     */
    public void setTypeColumnMap(
            Map<String, List<String>> typeColumnMap) {
        this.typeColumnMap = typeColumnMap;
    }
    
    public void setPeriodSearchAttribute(List<String> periodsearchAttributes) {
        this.periodSearchAttribute = periodsearchAttributes;
    }
    
    public   List<String> getPeriodSearchAttribute() {
        return this.periodSearchAttribute;
    }
    
    
}

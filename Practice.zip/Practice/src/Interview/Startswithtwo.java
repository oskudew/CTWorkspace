package Interview;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Startswithtwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,3,4,24,2,26,88,2222};
		String[] str = Arrays.stream(arr).mapToObj(String::valueOf).toArray(String[]::new); 
		List<String> l = Arrays.asList(str);
		List<String> l1=l.stream().filter(x->x.startsWith("2", 0)).collect(Collectors.toList());
		//int[] convert = l1.stream().mapToInt(Integer::intValue).toArray();
		
		l1.forEach(x->System.out.println(x));

	}

}

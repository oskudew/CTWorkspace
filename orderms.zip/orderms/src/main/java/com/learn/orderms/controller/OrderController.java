package com.learn.orderms.controller;

import com.learn.orderms.model.Order;
import com.learn.orderms.repo.OrderRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class OrderController {

    @Autowired
    OrderRepo orderRepo;

    @GetMapping("/orders")
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    @PostMapping("/saveOrder")
    public Order saveOrder(@RequestBody Order order) {
        return orderRepo.save(order);
    }

    @DeleteMapping("/deleteOrder")
    public void deleteOrder(@RequestParam("orderName") String orderName) {
        System.out.println(orderName);
        Optional<Order> order1 = orderRepo.deleteByName(orderName);
    }
}
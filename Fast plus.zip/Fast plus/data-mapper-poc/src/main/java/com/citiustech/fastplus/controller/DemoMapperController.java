package com.citiustech.fastplus.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.fastplus.entity.ResourceInfo;
import com.citiustech.fastplus.entity.ResourceInfoRepository;
import com.citiustech.fastplus.service.DemoMapperService;

@RestController
@RequestMapping("/mapper")
public class DemoMapperController {

	
	@Autowired
	private DemoMapperService demoMapperService;

	@Autowired
	private ResourceInfoRepository resourceInfoRepository;
	
	@GetMapping("/hello")
	public String helloWorld() {
		
		ResourceInfo resourceInfo = new ResourceInfo(1,"test");
		resourceInfoRepository.save(resourceInfo);
		
		return "Hello World";
	}
	
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public String convertToFHIRBundle(@RequestBody String inputJson,
			HttpServletResponse response) throws Exception {
		
		String bundle =  demoMapperService.convertToFHIRBundle(inputJson);
		return bundle;
		
	}
	@PostMapping(path="/patient",produces =MediaType.APPLICATION_JSON_VALUE)
	public String convertToFHIRPatient(@RequestBody String inputJson, HttpServletResponse response) throws Exception{
		String patient = demoMapperService.convertToFHIRPatient(inputJson);
		return patient;
	}
}

package com.citiustech.fastplus.test.provider;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.CodeType;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.DiagnosticReport;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.InstantType;
import org.hl7.fhir.r4.model.Reference;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.filereader.resource.DiagnosticReportReader;

@ExtendWith(MockitoExtension.class)
class DignosticReportReaderTest {
	
	@InjectMocks
	private DiagnosticReportReader diagnosticReader;
	
	@Mock
	private FileReaderUtils readerUtil;
	
	@DisplayName(value = "Test case for document without attachment")
	@Test
	void test_readAttachment_withoutAttachment() {
		List<IBaseResource> expected_resources = new ArrayList<>();
		CodeableConcept codeableConcept = mock(CodeableConcept.class);
		DiagnosticReport diagnosticReport = new DiagnosticReport();
		DateTimeType date = new DateTimeType(); 
		
		
		diagnosticReport.addCategory(codeableConcept);		
		diagnosticReport.setEffective(date);
		diagnosticReport.setEncounter(new Reference("urn:uuid:92ef1e6b-4415-4e68-adfc-5b252738e2a7"));
		diagnosticReport.setId(new IdType("DiagnosticReport/kern-diagnostic-11111"));
		diagnosticReport.setIssuedElement(new InstantType("2007-03-05T16:22:00.046-05:00"));
		
		expected_resources.add(diagnosticReport);
		
		diagnosticReader.readAttachment(expected_resources);
		verify(readerUtil, never()).setAttachmentdata(any(Attachment.class), anyLong());
		
	}
	
	@DisplayName(value = "Test case for document with attachment")
	@Test
	void test_readAttachment_withAttachment() {
		List<IBaseResource> expected_resources = new ArrayList<>();
		CodeableConcept codeableConcept = mock(CodeableConcept.class);
		DiagnosticReport diagnosticReport = new DiagnosticReport();
		DateTimeType date = new DateTimeType(); 
		
		diagnosticReport.addCategory(codeableConcept);		
		diagnosticReport.setEffective(date);
		diagnosticReport.setEncounter(new Reference("urn:uuid:92ef1e6b-4415-4e68-adfc-5b252738e2a7"));
		diagnosticReport.setId(new IdType("DiagnosticReport/kern-diagnostic-11111"));
		diagnosticReport.setIssuedElement(new InstantType("2007-03-05T16:22:00.046-05:00"));
		
		List<Attachment> thePresentedForm = new ArrayList<>();
		Attachment attachment = new Attachment();
		attachment.setUrl("/file_3.txt");
		attachment.setContentTypeElement(new CodeType("text/plain"));
		thePresentedForm.add(attachment);
		diagnosticReport.setPresentedForm(thePresentedForm);
		
		expected_resources.add(diagnosticReport);
		
		lenient().when(readerUtil.setAttachmentdata(any(Attachment.class),anyLong())).thenReturn(0L);
				
		diagnosticReader.readAttachment(expected_resources);
		verify(readerUtil, times(1)).setAttachmentdata(any(Attachment.class), anyLong());
	}
}

package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * This class is the HealthcareService resource provider class
 * which will serves all supported read and search requests
 * for HealthcareService resource
 * 
 */
@Component
public class HealthcareServiceResourceProvider implements IResourceProvider{

	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
    private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
    private static final Logging LOGGER = LoggerFactory.getLogger(HealthcareServiceResourceProvider.class.getName());
    
	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return HealthcareService.class;
	}
	
	/**
	 * This method will return HealthcareService resource based on the provided id
	 * @param theId
	 * @return a single resource
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
        return service.getResourceById(theId.getIdPart(), ResourceType.HealthcareService.name());
	}
	
	/**
	 * This method will return the bundle of resources based on
	 * the search parameters passed in the request
	 * @param id
	 * @param coverageArea,chainParameters{Location.SP_IDENTIFIER}
	 * @param endpoint,chainParameters{Endpoint.SP_IDENTIFIER,
	 * Endpoint.SP_CONNECTION_TYPE}
	 * @param location,chainParameters{Location.SP_IDENTIFIER, 
	 * Location.SP_ADDRESS, Location.SP_TYPE}
	 * @param name
	 * @param organization,chainParameters{Organization.SP_IDENTIFIER, 
	 * Organization.SP_NAME, Organization.SP_TYPE, Organization.SP_ADDRESS}
	 * @param serviceCategory
	 * @param serviceType
	 * @param specialty
	 * @param includes{"HealthcareService:location", 
	 * "HealthcareService:coverage-area", 
	 * "HealthcareService:organization", 
	 * "HealthcareService:endpoint" }
	 * @param revIncludes{"PractitionerRole:service", 
	 * "OrganizationAffiliation:service"}
	 * @return bundle of resources
	 */
	@Search()
	public IBundleProvider searchHealthcareProvider(
			@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = HealthcareService.SP_COVERAGE_AREA, chainWhitelist =  {"", Location.SP_IDENTIFIER}) ReferenceAndListParam coverageArea,
			@OptionalParam(name = HealthcareService.SP_ENDPOINT, chainWhitelist =  {"", Endpoint.SP_IDENTIFIER,Endpoint.SP_CONNECTION_TYPE}) ReferenceAndListParam endpoint,
			@OptionalParam(name = HealthcareService.SP_LOCATION, chainWhitelist =  {"", Location.SP_IDENTIFIER, Location.SP_ADDRESS, Location.SP_TYPE}) ReferenceAndListParam location,
			@OptionalParam(name = HealthcareService.SP_NAME) StringAndListParam name,
			@OptionalParam(name = HealthcareService.SP_ORGANIZATION, chainWhitelist =  {"",  Organization.SP_IDENTIFIER, Organization.SP_NAME, Organization.SP_TYPE, Organization.SP_ADDRESS}) ReferenceAndListParam organization,
			@OptionalParam(name = HealthcareService.SP_SERVICE_CATEGORY) TokenAndListParam serviceCategory,
			@OptionalParam(name = HealthcareService.SP_SERVICE_TYPE) TokenAndListParam serviceType,
			@OptionalParam(name = HealthcareService.SP_SPECIALTY) TokenAndListParam specialty,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@IncludeParam(allow = {
					"HealthcareService:location", "HealthcareService:coverage-area", "HealthcareService:organization", "HealthcareService:endpoint" }) Set<Include> includes,
			@IncludeParam(reverse = true, allow = {"PractitionerRole:service", "OrganizationAffiliation:service"}) Set<Include> revIncludes
			) {

		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(IAnyResource.SP_RES_ID, theId);
		paramMap.add(HealthcareService.SP_COVERAGE_AREA, coverageArea);
		paramMap.add(HealthcareService.SP_ENDPOINT, endpoint);
		paramMap.add(HealthcareService.SP_LOCATION, location);
		paramMap.add(HealthcareService.SP_NAME, name);
		paramMap.add(HealthcareService.SP_ORGANIZATION, organization);
		paramMap.add(HealthcareService.SP_SERVICE_CATEGORY, serviceCategory);
		paramMap.add(HealthcareService.SP_SERVICE_TYPE, serviceType);
		paramMap.add(HealthcareService.SP_SPECIALTY, specialty);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		if (revIncludes != null && !revIncludes.isEmpty()) {
			paramMap.setRevIncludes(revIncludes);
		}
		if (includes != null && !includes.isEmpty()) {
			paramMap.setIncludes(includes);
		}	
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
        return service.getResources(paramMap, ResourceType.HealthcareService.name());
	}
}
package com.citiustech.fastplus.filereader.attachment;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.filereader.resource.IResourceReader;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.util.exception.ExceptionCodes;
import com.citiustech.fastplus.util.exception.SearchServiceException;

/**
 * This is a class for Staging Folder AttachmentReader used as implementation
 * for IAttachmentReader to read resource attachment data from shared location.
 *
 */
@Component(value = "staging")
public class StagingFolderAttachmentReader implements IAttachmentReader {

	private static final Logging LOGGER = LoggerFactory.getLogger(StagingFolderAttachmentReader.class.getName());

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	FileReaderUtils readerUtil;
	
	IResourceReader reader ;

	@Value("${attachments.available.resources:}")
	Set<String> attachments;

	@Override
	public void readAttachmentsData(List<IBaseResource> resources, String resourceType) {

		if (Objects.nonNull(attachments) && attachments.contains(resourceType)) {
			 reader = getResourceReader(resourceType);
			reader.readAttachment(resources);
		}

	}

	@Override
	public void readAttachmentsData(List<Attachment> attachments) {
		long totalAttachmentSize = 0;
		for (Attachment attachment : attachments) {
			totalAttachmentSize = readerUtil.setAttachmentdata(attachment, totalAttachmentSize);
		}
	}

	/**
	 * returns IResourceReader using resource type.
	 * 
	 * @param resourceType
	 * @return
	 */
	private IResourceReader getResourceReader(String resourceType) {
		reader = null;
		try {
			reader = (IResourceReader) applicationContext.getBean(resourceType + "Reader");
		} catch (Exception e) {
			LOGGER.logError(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), e.getMessage());
			throw new SearchServiceException(ExceptionCodes.INVALID_DATA.toString(), e);

		}
		return reader;
	}

	@Override
	public void readAttachmentsData(IBaseResource resource, String resourceType) {

		List<IBaseResource> iBaseResourceList = new ArrayList<>();
		iBaseResourceList.add(resource);
		this.readAttachmentsData(iBaseResourceList, resourceType);

	}

}

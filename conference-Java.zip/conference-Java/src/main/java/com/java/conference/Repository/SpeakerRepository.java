package com.java.conference.Repository;

import java.util.List;

import com.java.conference.model.Speaker;

public interface SpeakerRepository {

	List<Speaker> findAll();

}
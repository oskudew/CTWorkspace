package map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Answer {

	@Id
	private int Answer_Id;
	private String Answer;
	
	//@OneToOne(mappedBy="answer")
	@ManyToOne
	private Question question;
	
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public int getAnswer_Id() {
		return Answer_Id;
	}
	public void setAnswer_Id(int answer_Id) {
		Answer_Id = answer_Id;
	}
	public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		Answer = answer;
	}
	@Override
	public String toString() {
		return "Answer [Answer_Id=" + Answer_Id + ", Answer=" + Answer + "]";
	}
	
}

package leetcode;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] b = Solution("BAABA",new int[] {2,4,1,1,2});
		for(int a=0;a<2;a++) {
	     System.out.print(b[a]+" ");
		}

	}
	public static int[] Solution(String R, int[]v) {
		int mina=0;
		int minb=0;
		int balA=0;
		int balB=0;
		
		for(int i=0;i<R.length();i++) {
			if(R.charAt(i)=='A') {
				balA=balA+v[i];
				balB=balB-v[i];
				if(minb>balB) {
					minb=balB;
				}
			}
			else if(R.charAt(i)=='B') {
				balB=balB+v[i];
				balA=balA-v[i];
				if(mina>balA) mina=balA;
			}
		}
		
		
		return new int[] {-mina,-minb};
	}

}

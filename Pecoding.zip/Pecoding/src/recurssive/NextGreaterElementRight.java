package recurssive;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class NextGreaterElementRight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		int[] arr= new int[a];
		int[] arr1= new int[a];
		
		for(int i =0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		
		Stack stack = new Stack();
		
		for(int i=a-1;i>=0;i--) {
			
			while(!stack.isEmpty() && arr[i]>=(int)stack.peek()) {
			stack.pop();
			}
			
			if(stack.isEmpty()) {
				arr1[i]=-1;
			}else {
				arr1[i]=(int)stack.peek();
			}
			
			stack.push(arr[i]);
		}
		
		System.out.println(Arrays.toString(arr1));
		
		

	}

}

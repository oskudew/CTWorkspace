package com.citiustech.fastplus.util.transformation;

public class TestJsonTransformation {

    public void testJSONTransform() throws Exception {
        JsonTransformation jsonTransformation = new JsonTransformation();
        String input = "{\r\n" +
                "	\"id\": \"plannet-location-1230085657\",\r\n" +
                "	\"meta\": {\r\n" +
                "		\"id\": \"1\",\r\n" +
                "		\"extension\": \"1234\",\r\n" +
                "		\"versionId\": \"1\",\r\n" +
                "		\"lastUpdated\": \"2020-09-07T15:18:30.567+05:30\",\r\n" +
                "		\"source\": \"source\",\r\n" +
                "		\"profile\": [\r\n" +
                "			\"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/plannet-Practitioner\"\r\n" +
                "		],\r\n" +
                "		\"security\": \"security\",\r\n" +
                "		\"tag\": \"tag\"\r\n" +
                "	},\r\n" +
                "	\"implicitRules\": {\r\n" +
                "		\"key\": \"value\"\r\n" +
                "	},\r\n" +
                "	\"language\": \"en-US\",\r\n" +
                "	\"text\": {\r\n" +
                "		\"status\": \"generated\",\r\n" +
                "		\"div\": \"<div xmlns=\\\"http://www.w3.org/1999/xhtml\\\" xml:lang=\\\"en-US\\\" lang=\\\"en-US\\\"><p><b>Generated Narrative</b></p><p><b>id</b>: Counselor</p><p><b>meta</b>: </p><p><b>language</b>: en-US</p><p><b>identifier</b>: id: NPI3238</p><p><b>active</b>: true</p><p><b>name</b>: Susie Smith, LPC</p><h3>Qualifications</h3><table class=\\\"grid\\\"><tr><td>-</td><td><b>Extension</b></td><td><b>Code</b></td><td><b>Issuer</b></td></tr><tr><td>*</td><td></td><td><span title=\\\"Codes: \\\">IL</span></td><td><span>State of Illinois</span></td></tr></table><p><b>communication</b>: <span title=\\\"Codes: {urn:ietf:bcp:47 ru}\\\">Russian</span></p></div>\"\r\n" +
                "	},\r\n" +
                "	\"contained\": [\r\n" +
                "		{\r\n" +
                "			\"resourceType\": \"Location\",\r\n" +
                "			\"id\": \"DenBurg\",\r\n" +
                "			\"description\": \"Greater Denburg area\",\r\n" +
                "			\"mode\": \"instance\",\r\n" +
                "			\"physicalType\": {\r\n" +
                "				\"coding\": [\r\n" +
                "					{\r\n" +
                "						\"code\": \"area\",\r\n" +
                "						\"display\": \"Area\"\r\n" +
                "					}\r\n" +
                "				]\r\n" +
                "			}\r\n" +
                "		}\r\n" +
                "	],\r\n" +
                "	\"extension\": [\r\n" +
                "		{\r\n" +
                "			\"url\": \"http://hl7.org/fhir/uv/vhdir/StructureDefinition/accessibility\",\r\n" +
                "			\"valueCodeableConcept\": {\r\n" +
                "				\"coding\": [\r\n" +
                "					{\r\n" +
                "						\"system\": \"http://hl7.org/fhir/uv/vhdir/CodeSystem/accessibility\",\r\n" +
                "						\"code\": \"handiaccess\",\r\n" +
                "						\"display\": \"handicap accessible\"\r\n" +
                "					}\r\n" +
                "				],\r\n" +
                "				\"text\": \"Offers a variety of services and programs for persons with disabilities\"\r\n" +
                "			}\r\n" +
                "		},\r\n" +
                "		{\r\n" +
                "			\"extension\": [\r\n" +
                "				{\r\n" +
                "					\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/plannet-AcceptingPatients-extension\",\r\n" +
                "					\"valueBoolean\": false\r\n" +
                "				}\r\n" +
                "			],\r\n" +
                "			\"url\": \"http://hl7.org/fhir/us/davinci-pdex-plan-net/StructureDefinition/plannet-NewPatients-extension\"\r\n" +
                "		},\r\n" +
                "		{\r\n" +
                "			\"url\": \"http://hl7.org/fhir/uv/vhdir/StructureDefinition/newpatientprofile\",\r\n" +
                "			\"valueString\": \"This location accepts all types of patients\"\r\n" +
                "		}\r\n" +
                "	],	\r\n" +
                "	\"modifierExtension\": \"text\",\r\n" +
                "	\"identifier\": [\r\n" +
                "		{\r\n" +
                "		    \"id\": \"1\",\r\n" +
                "			\"extension\": [\r\n" +
                "				{\r\n" +
                "					\"extension\": [\r\n" +
                "						{\r\n" +
                "							\"url\": \"allDay\",\r\n" +
                "							\"valueBoolean\": true\r\n" +
                "						}\r\n" +
                "					],\r\n" +
                "					\"url\": \"http://hl7.org/fhir/uv/vhdir/StructureDefinition/contactpoint-availabletime\"\r\n" +
                "				}\r\n" +
                "			],\r\n" +
                "			\"use\": \"secondary\",\r\n" +
                "			\"type\": \"type\",\r\n" +
                "			\"system\": \"https://bayside-endoscopy-llc.com\",\r\n" +
                "			\"value\": \"main campus\",\r\n" +
                "			\"period\": {\r\n" +
                "				\"start\": \"2018-05-04\",\r\n" +
                "				\"end\": \"2021-05-04\"\r\n" +
                "			},\r\n" +
                "			\"assigner\": {\r\n" +
                "				\"reference\": \"Organization/plannet-organization-1230085657\",\r\n" +
                "				\"display\": \"BAYSIDE ENDOSCOPY, LLC\"\r\n" +
                "			}\r\n" +
                "		}\r\n" +
                "	],\r\n" +
                "	\"status\": \"active\",\r\n" +
                "	\"operationalStatus\": \"operationalStatusText\",\r\n" +
                "	\"name\": \"BAYSIDE ENDOSCOPY, LLC\",\r\n" +
                "	\"alias\": [\r\n" +
                "		{\r\n" +
                "			\"key\": \"value\"\r\n" +
                "	    }\r\n" +
                "	],\r\n" +
                "	\"description\": \"Main campus of BAYSIDE ENDOSCOPY, LLC\",\r\n" +
                "	\"mode\": \"instance\",\r\n" +
                "	\"type\": \"both\",\r\n" +
                "	\"telecom\": [\r\n" +
                "		{\r\n" +
                "			\"id\": \"1\",\r\n" +
                "			\"extension\": [\r\n" +
                "				{\r\n" +
                "					\"extension\": [\r\n" +
                "						{\r\n" +
                "							\"url\": \"allDay\",\r\n" +
                "							\"valueBoolean\": true\r\n" +
                "						}\r\n" +
                "					],\r\n" +
                "					\"url\": \"http://hl7.org/fhir/uv/vhdir/StructureDefinition/contactpoint-availabletime\"\r\n" +
                "				}\r\n" +
                "			],\r\n" +
                "			\"system\": \"phone\",\r\n" +
                "			\"value\": \"1-814-663-9839 x894\",\r\n" +
                "			\"use\": \"work\",\r\n" +
                "			\"rank\": 1,\r\n" +
                "			\"period\": {\r\n" +
                "				\"start\": \"2018-05-04\",\r\n" +
                "				\"end\": \"2021-05-04\"\r\n" +
                "			}\r\n" +
                "		},\r\n" +
                "		{\r\n" +
                "			\"extension\": [\r\n" +
                "				{\r\n" +
                "					\"extension\": [\r\n" +
                "						{\r\n" +
                "							\"url\": \"allDay\",\r\n" +
                "							\"valueBoolean\": true\r\n" +
                "						}\r\n" +
                "					],\r\n" +
                "					\"url\": \"http://hl7.org/fhir/uv/vhdir/StructureDefinition/contactpoint-availabletime\"\r\n" +
                "				}\r\n" +
                "			],\r\n" +
                "			\"system\": \"fax\",\r\n" +
                "			\"value\": \"1-260-825-4154 x92850\",\r\n" +
                "			\"use\": \"work\"\r\n" +
                "		}\r\n" +
                "	],\r\n" +
                "	\"address\": {\r\n" +
                "		\"id\": \"DenBurg\",\r\n" +
                "		\"extension\": \"extensionText\",\r\n" +
                "		\"use\": \"work\",\r\n" +
                "		\"type\": \"both\",\r\n" +
                "		\"text\": \"33 STANIFORD ST, PROVIDENCE, RI 029053105\",\r\n" +
                "		\"line\": [\r\n" +
                "			\"33 STANIFORD ST\"\r\n" +
                "		],\r\n" +
                "		\"city\": \"PROVIDENCE\",\r\n" +
                "		\"district\": \"ARIZONA\",\r\n" +
                "		\"state\": \"RI\",\r\n" +
                "		\"postalCode\": \"029053105\",\r\n" +
                "		\"country\": \"USA\",\r\n" +
                "		\"period\": {\r\n" +
                "			\"start\": \"2010-03-23\",\r\n" +
                "			\"end\": \"2010-07-01\"\r\n" +
                "		}\r\n" +
                "	},\r\n" +
                "	\"physicalType\": {\r\n" +
                "		\"coding\": [\r\n" +
                "			{\r\n" +
                "				\"code\": \"area\",\r\n" +
                "				\"display\": \"Area\"\r\n" +
                "			}\r\n" +
                "		]\r\n" +
                "	},\r\n" +
                "	\"position\": {\r\n" +
                "		\"id\": \"DenBurg\",\r\n" +
                "		\"extension\": \"extensionText\",\r\n" +
                "		\"modifierExtension\": \"modifierExtensionText\",\r\n" +
                "		\"longitude\": -71.41177,\r\n" +
                "		\"latitude\": 41.809006,\r\n" +
                "		\"altitude\": \"100\"\r\n" +
                "	},\r\n" +
                "	\"managingOrganization\": {\r\n" +
                "		\"reference\": \"Organization/plannet-organization-1230085657\",\r\n" +
                "		\"display\": \"BAYSIDE ENDOSCOPY, LLC\"\r\n" +
                "	},\r\n" +
                "	\"partOf\": \"partOfText\",\r\n" +
                "	\"hoursOfOperation\": [\r\n" +
                "		{\r\n" +
                "			\"id\": \"DenBurg\",\r\n" +
                "			\"extension\": \"extensionText\",\r\n" +
                "			\"modifierExtension\": \"modifierExtensionText\",\r\n" +
                "			\"daysOfWeek\": [\r\n" +
                "				\"mon\",\r\n" +
                "				\"tue\",\r\n" +
                "				\"wed\",\r\n" +
                "				\"thu\",\r\n" +
                "				\"fri\",\r\n" +
                "				\"sat\",\r\n" +
                "				\"sun\"\r\n" +
                "			],\r\n" +
                "			\"allDay\": true,\r\n" +
                "			\"openingTime\": \"12:00:00\",\r\n" +
                "			\"closingTime\": \"12:00:00\"\r\n" +
                "		}\r\n" +
                "	],\r\n" +
                "	\"availabilityExceptions\": \"visiting hours from 6:00 am - 10:00 pm\",\r\n" +
                "	\"endpoint\": \"endpointText\",\r\n" +
                "	\"resourceType\": \"Location\"\r\n" +
                "}";
        jsonTransformation.transform(input, "Location", "DaVinci");
    }
}

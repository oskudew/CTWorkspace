package com.citiustech.fastplus.test.provider;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.never;

import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.Contract;
import org.hl7.fhir.r4.model.Contract.ComputableLanguageComponent;
import org.hl7.fhir.r4.model.Contract.LegalLanguageComponent;
import org.hl7.fhir.r4.model.DocumentReference;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.filereader.resource.ContractReader;

@ExtendWith(MockitoExtension.class)
class ContractReaderTest {

	
	@InjectMocks
	private ContractReader contractReader;
	
	@Mock
	FileReaderUtils readerUtil;
	
	
	@DisplayName("Test case for reading c0ntract attachments")
	@Test
	void test_readAttachmentsData() {
	
		long totalAttachmentSize = 0L;
		DocumentReference documentReference = mock(DocumentReference.class);
		Contract contract1 = mock(Contract.class);
		
		LegalLanguageComponent legal = mock(LegalLanguageComponent.class);
		ComputableLanguageComponent component = mock(ComputableLanguageComponent.class);
		
		Attachment attachment = mock(Attachment.class);
		
		List<LegalLanguageComponent> legals = new ArrayList<>();
		legals.add(legal);
		
		List<ComputableLanguageComponent> components = new ArrayList<>();
		components.add(component);
		
		when(legal.hasContentAttachment()).thenReturn(Boolean.TRUE);
		when(component.hasContentAttachment()).thenReturn(Boolean.TRUE);
		
		when(legal.getContentAttachment()).thenReturn(attachment);
		when(component.getContentAttachment()).thenReturn(attachment);
		
		when(contract1.getLegal()).thenReturn(legals); // LegalLanguageComponent
		when(contract1.getRule()).thenReturn(components); // LegalLanguageComponent
		
		List<IBaseResource> resources = new ArrayList<>();
		resources.add(documentReference);
		resources.add(contract1);
		
		
		contractReader.readAttachment(resources);
		
		verify(readerUtil,times(2)).setAttachmentdata(any(Attachment.class), eq(totalAttachmentSize));
	}
	
	@DisplayName("Test case for reading contract attachments where attachments are absent")
	@Test
	void test_readAttachmentsDataWhenAttachmentsAbsent() {
		
		long totalAttachmentSize = 0L;
		DocumentReference documentReference = mock(DocumentReference.class);
		Contract contract1 = mock(Contract.class);
		
		LegalLanguageComponent legal = mock(LegalLanguageComponent.class);
		ComputableLanguageComponent component = mock(ComputableLanguageComponent.class);
		
		List<LegalLanguageComponent> legals = new ArrayList<>();
		legals.add(legal);
		
		List<ComputableLanguageComponent> components = new ArrayList<>();
		components.add(component);
		
		when(contract1.getLegal()).thenReturn(legals); // LegalLanguageComponent
		when(contract1.getRule()).thenReturn(components); // LegalLanguageComponent
		
		List<IBaseResource> resources = new ArrayList<>();
		resources.add(documentReference);
		resources.add(contract1);
		
		
		contractReader.readAttachment(resources);
		
		verify(readerUtil,never()).setAttachmentdata(any(Attachment.class), eq(totalAttachmentSize));
	}
	
	
}

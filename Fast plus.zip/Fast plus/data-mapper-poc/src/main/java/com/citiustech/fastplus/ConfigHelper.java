package com.citiustech.fastplus;

import java.io.IOException;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citiustech.fastplus.validator.FHIRValidator;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.parser.IParser;

@Configuration
public class ConfigHelper {

	
	@Value("${validation.package.uscore:}")
	private String usCoreStructure;
	
	@Bean("USCoreValidator")
	public FHIRValidator getUsCoreVaildator(RestTemplateBuilder builder) throws IOException, URISyntaxException {
		return new FHIRValidator(usCoreStructure, "");
	}
	
	@Bean
    public FhirContext getFhirContext() {
        return FhirContext.forR4();
    }
	
	@Bean
    public IParser iParser() {
        return getFhirContext().newJsonParser();
    }
}

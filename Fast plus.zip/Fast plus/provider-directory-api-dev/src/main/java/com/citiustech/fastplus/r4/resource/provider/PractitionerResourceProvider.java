package com.citiustech.fastplus.r4.resource.provider;

import ca.uhn.fhir.model.api.Include;
import ca.uhn.fhir.rest.annotation.*;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.StringAndListParam;
import ca.uhn.fhir.rest.param.TokenAndListParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import com.citiustech.fastplus.SearchParameterRequest;
import com.citiustech.fastplus.logging.LoggerFactory;
import com.citiustech.fastplus.logging.Logging;
import com.citiustech.fastplus.loggingconstants.LoggingConstants;
import com.citiustech.fastplus.r4.model.CommonSearchParam;
import com.citiustech.fastplus.services.ProviderDirectoryService;

import org.hl7.fhir.instance.model.api.IAnyResource;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * 
 * This class is the  Practitioner resource provider class which will
 *  serves all supported read and search requests for Practitioner resource
 *
 */
@Component
public class PractitionerResourceProvider implements IResourceProvider{
	
	/**
	 * This field is the service instance 
	 * to call methods from service layer
	 */
	@Autowired
	private ProviderDirectoryService service;
	
	/**
	 * This is the logger field which
	 * will be used to logged the messages
	 */
	private static final Logging LOGGER = LoggerFactory.getLogger(PractitionerResourceProvider.class.getName());
	
	@Override
	public Class<? extends IBaseResource> getResourceType() {
		return Practitioner.class;
	}
	
	/**
	 * This method will return Practitioner resource based on the provided id
	 * @param theId
	 * @return a single resource
	 */
	@Read()
	public IBaseResource getResourceById(@IdParam IdType theId) {
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(), "Read operation for id " + theId.getIdPart());
		return service.getResourceById(theId.getIdPart(), ResourceType.Practitioner.name());
	}

	/**
	 * This method will return the bundle of resources based on the search parameters passed in the request
	 * @param theId
	 * @param family
	 * @param given
	 * @param name
	 * @param revIncludes{"PractitionerRole:practitioner" }
	 * @return bundle of resources
	 */
	@Search()
	public IBundleProvider searchPractitioner(
			@OptionalParam(name = IAnyResource.SP_RES_ID) TokenAndListParam theId,
			@OptionalParam(name = Practitioner.SP_FAMILY) StringAndListParam family,
			@OptionalParam(name = Practitioner.SP_GIVEN) StringAndListParam given,
			@OptionalParam(name = Practitioner.SP_NAME) StringAndListParam name,
			@OptionalParam(name = CommonSearchParam.SP_LAST_UPDATED) DateRangeParam lastUpdated,
			@IncludeParam(reverse = true, allow = {"PractitionerRole:practitioner" }) Set<Include> revIncludes
	) {
		
		SearchParameterRequest paramMap = new SearchParameterRequest();
		paramMap.add(IAnyResource.SP_RES_ID, theId);
		paramMap.add(Practitioner.SP_FAMILY, family);
		paramMap.add(Practitioner.SP_GIVEN, given);
		paramMap.add(Practitioner.SP_NAME, name);
		paramMap.add(CommonSearchParam.SP_LAST_UPDATED, lastUpdated);
		if (revIncludes != null && !revIncludes.isEmpty()){
			paramMap.setRevIncludes(revIncludes);
		}
        
		LOGGER.logDebug(LoggingConstants.LoggingMarkers.APPLICATION.getValue(),"Search operation for parameters "+ paramMap.toString());
		return service.getResources(paramMap, ResourceType.Practitioner.name());
	}	
}

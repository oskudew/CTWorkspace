package com.citiustech.fastplus.adapter.functional;

import com.citiustech.fastplus.adapter.structure.IdProjectionRow;
import org.springframework.jdbc.core.RowMapper;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * 
 * This is a class for IdProjectionFunction which act as mapper to build
 * IdProjectionRow object by extracting ResultSet
 * 
 */

public class IdProjectionFunction implements RowMapper<IdProjectionRow> {

    @Override
    public IdProjectionRow mapRow(ResultSet resultSet, int index) throws SQLException {
    	
    	ResultSetMetaData rsmd = resultSet.getMetaData();
        return new IdProjectionRow("",
                (Serializable) resultSet.getObject(1),
                (Serializable) (rsmd.getColumnCount() > 1  ? resultSet.getObject(2): null));
    }
}

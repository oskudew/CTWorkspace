package basic;

public class Primenotillno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		prime(2);

	}
	
	public static void prime(int a) {
		if(a>2) {
		for(int i=2;i<a;i++) {
			int flag=0;
			for(int j=2;j<i;j++) {
				if(i%j==0) flag++;
			}
			if(flag==0) {
				System.out.print(" "+ i);	
			}
			
		}
	}
		else {
			System.out.println("2");
		}
}

}

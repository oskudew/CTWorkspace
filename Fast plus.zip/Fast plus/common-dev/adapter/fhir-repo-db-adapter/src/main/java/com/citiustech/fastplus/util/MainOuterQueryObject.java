package com.citiustech.fastplus.util;

import java.util.List;

import com.healthmarketscience.sqlbuilder.CustomSql;
import com.healthmarketscience.sqlbuilder.SelectQuery;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MainOuterQueryObject {

	private SelectQuery mainOuterQuery;
	private String mainQueryAlias;
	private List<CustomSql> listOfProjectionCol;
}

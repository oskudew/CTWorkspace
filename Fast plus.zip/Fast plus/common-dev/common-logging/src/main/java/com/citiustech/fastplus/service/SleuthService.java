package com.citiustech.fastplus.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import brave.Span;
import brave.Tracer;

/**
 * A service class for creating new span id using tracer interface which
 * is provided by Spring Sleuth
 */
@Service
public class SleuthService {

    @Autowired
    private Tracer tracer;

    /**
     * Method to create a new span id
     */
    public void createNewSpanId() {
        Span newSpan = tracer.nextSpan().name("newSpan").start();
        tracer.withSpanInScope(newSpan);
        
    }
}

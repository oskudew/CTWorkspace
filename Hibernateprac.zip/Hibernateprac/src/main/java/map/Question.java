package map;

import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)
public class Question {

	@Id
	private int Question_id;
	private String Question;
	
	//@OneToOne
	//@JoinColumn(name="a_Id")
	@OneToMany(mappedBy="question")
	@Cascade(CascadeType.ALL)
//	@JoinTable(
//			name="A_id",
//			joinColumns= @JoinColumn(name="QuestionID", referencedColumnName="Question_id"),
//			inverseJoinColumns=@JoinColumn(name="AnswerID", referencedColumnName="Answer_Id")
//			)
	private List<Answer> answer;
	
	
//	public Answer getAnswer() {
//		return answer;
//	}
//
//	public void setAnswer(Answer answer) {
//		this.answer = answer;
//	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	public int getQuestion_id() {
		return Question_id;
	}
	
	public void setQuestion_id(int question_id) {
		Question_id = question_id;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	@Override
	public String toString() {
		return "Question [Question_id=" + Question_id + ", Question=" + Question + "]";
	}
	
	
	
	
	
}

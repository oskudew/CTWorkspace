package com.citiustech.fastplus.test.factory;

import ca.uhn.fhir.rest.param.ReferenceAndListParam;
import ca.uhn.fhir.rest.param.ReferenceOrListParam;
import ca.uhn.fhir.rest.param.ReferenceParam;

public class ReferenceFactory {

	
	ReferenceAndListParam  referenceAndListParam = new ReferenceAndListParam();
	
	ReferenceOrListParam referenceOrListParam ;
	
	ReferenceParam referenceParam ;
	
	
	public ReferenceFactory() {
	
		referenceOrListParam = new ReferenceOrListParam();
		referenceAndListParam.addAnd(referenceOrListParam);
	}
	
	
	
	public ReferenceAndListParam newInstance(){
		return referenceAndListParam;
	}
	
	public ReferenceFactory setReferenceValue(String theValue) {
		referenceParam = new ReferenceParam(theValue);
		referenceOrListParam.add(referenceParam);
		return this;
	}
	
	public ReferenceFactory addReferenceParam(ReferenceParam referenceParam) {
		referenceOrListParam.add(referenceParam);
		return this;
	}
	
}

package com.citiustech.fastplus.loader.entity;

public class ReferenceLink {
    private String srcId;
    private String srcType;
    private String tgtId;
    private String tgtType;
    private String attribute;

    public String getSrcId() {
        return srcId;
    }

    public void setSrcId(String srcId) {
        this.srcId = srcId;
    }

    public String getSrcType() {
        return srcType;
    }

    public void setSrcType(String srcType) {
        this.srcType = srcType;
    }

    public String getTgtId() {
        return tgtId;
    }

    public void setTgtId(String tgtId) {
        this.tgtId = tgtId;
    }

    public String getTgtType() {
        return tgtType;
    }

    public void setTgtType(String tgtType) {
        this.tgtType = tgtType;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }
}

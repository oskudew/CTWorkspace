package Hibpractices.Hibernateprac;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
    	Employee emp =  new Employee();
    	emp.setId(101);
    	emp.setName("Arun");
    	emp.setColour("black");
    	
    	Address adr = new Address();
    	adr.setAddressID(1001);
    	adr.setCity("Pune");
    	adr.setGetDate(new Date());
 
    	FileInputStream io = new FileInputStream("src/main/java/citius logo.png");
    	byte[] br =new byte[io.available()];
    	io.read(br);
    	adr.setImage(br);
    	
    	Configuration con = new Configuration().configure().addAnnotatedClass(Employee.class);
    	ServiceRegistry sr = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
    	SessionFactory sf=con.buildSessionFactory(sr);
    	Session s = sf.openSession();
    	Transaction tr = s.beginTransaction();
    	s.save(emp);
    	s.save(adr);
    	tr.commit();
        System.out.println( "Hello World!" );
    }
}

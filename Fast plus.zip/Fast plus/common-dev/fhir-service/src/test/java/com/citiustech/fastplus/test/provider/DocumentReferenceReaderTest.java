package com.citiustech.fastplus.test.provider;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import java.util.ArrayList;
import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Attachment;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.DocumentReference.DocumentReferenceContentComponent;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.citiustech.fastplus.filereader.FileReaderUtils;
import com.citiustech.fastplus.filereader.resource.DocumentReferenceReader;

@ExtendWith(MockitoExtension.class)
class DocumentReferenceReaderTest {

	@InjectMocks
	private DocumentReferenceReader documentReferenceReader;
	
	@Mock
	private FileReaderUtils readerUtil;
	
	@DisplayName(value = "Test case for empty Attachment")
	@Test
	void test_readAttachment() {
		List<IBaseResource> resources = new ArrayList<>();
		DocumentReference expected_docRef = mock(DocumentReference.class);
		
		resources.add(expected_docRef);
		
		documentReferenceReader.readAttachment(resources);
		verify(readerUtil, never()).setAttachmentdata(any(Attachment.class), anyLong());
		
	}
	
	@DisplayName(value = "Test case for given Attachment")
	@Test
	void test_readAttachment_WithAttachment() {
		List<IBaseResource> resources = new ArrayList<>();
		DocumentReference expected_docRef = new DocumentReference();
		DocumentReferenceContentComponent attachmentDoc = new DocumentReferenceContentComponent();
		List<DocumentReferenceContentComponent> theContent = new ArrayList<>();
		Attachment value = mock(Attachment.class);
		
		attachmentDoc.setAttachment(value);
		theContent.add(attachmentDoc);
		expected_docRef.setContent(theContent);
		resources.add(expected_docRef);
		
		documentReferenceReader.readAttachment(resources);
		verify(readerUtil, times(1)).setAttachmentdata(any(Attachment.class), anyLong());
	}
	
}

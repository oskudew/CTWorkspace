package com.citiustech.fastplus.mapper;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;

import org.apache.commons.codec.binary.Base64;
import org.hl7.fhir.r4.model.BooleanType;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeType;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.DecimalType;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.InstantType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Money;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.UriType;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

import com.jayway.jsonpath.JsonPath;

import ca.uhn.fhir.model.api.TemporalPrecisionEnum;
import net.minidev.json.JSONArray;
import net.sf.saxon.ma.trie.Tuple2;

public abstract class AbstractResourceMapper implements ResourceMapper {
	
	
//	private final String usCoreStructure = "hl7.fhir.us.core#3.1.1";
//	protected FHIRValidator fhirValidator;

    protected String dateTimeZonePattern;

    protected String datePattern = "yyyy-MM-dd";

    public void setDatePattern(final String datePattern) {
        this.dateTimeZonePattern = datePattern;
    }
    	
//    public AbstractResourceMapper() throws URISyntaxException, IOException {
//    	this.fhirValidator  = new FHIRValidator(usCoreStructure, "");
//    }
    public List<Identifier> extractIdentifier(final Object document, final String jsonPath) {
        List<Identifier> identifierList = new ArrayList<>();
        int identifierLength = 0;
        try {
            identifierLength = JsonPath.read(document, "$.identifier.length()");
        } catch (Exception e) {
        }
        for (int index = 0; index < identifierLength; index++) {
            Identifier mainIdentifier = new Identifier();
            mainIdentifier.setType(extractCodeableConcept(extractValue(document, "$." + jsonPath + "[" + index + "].type")));
            mainIdentifier.setValue(extractString(document, "$." + jsonPath + "[" + index + "].value"));
            mainIdentifier.setSystem(extractString(document, "$." + jsonPath + "[" + index + "].system"));
            identifierList.add(mainIdentifier);
        }
        return identifierList;
    }

    public Object extractValue(final Object document, final String jsonPath) {
        Object value = "";
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (Exception pnfe) {
        }
        return value;
    }

    public String extractString(final Object document, final String jsonPath) {
        Object value = null;
        String valueString = null;
        try {
            if (checkIfValuePresent(document, jsonPath))
                value = JsonPath.read(document, jsonPath);
            	if(value == null || value =="") {
            		return valueString;
            	}else {
            		valueString  = value.toString();
            	}
            
        } catch (Exception e) {
            //  e.printStackTrace();;
        }
        return valueString;
    }

    public Double extractDouble(final Object document, final String jsonPath) {
        Double value = null;
        try {
            if (checkIfValuePresent(document, jsonPath))
                value = JsonPath.read(document, jsonPath);

        } catch (Exception e) {
            //  e.printStackTrace();;
        }
        return value;
    }

    public Date extractDate(final Object document, final String jsonPath) {
        Date date = null;
        String value = null;
        try {
            value = Objects.nonNull(JsonPath.read(document, jsonPath)) ? JsonPath.read(document, jsonPath) : null;

            String dateTimeRegex = "^([0-9]([0-9]([0-9][1-9]|[1-9]0)|[1-9]00)|[1-9]000)(-(0[1-9]|1[0-2])(-(0[1-9]|[1-2][0-9]|3[0-1])))$";

            if (Objects.nonNull(value)) {
                if (value.matches(dateTimeRegex)) {
                    date = DateTime.parse(value, DateTimeFormat.forPattern(datePattern)).toDate();
                } else {
                    date = DateTime.parse(value, DateTimeFormat.forPattern(dateTimeZonePattern)).toDate();
                }
            }

        } catch (Exception e) {
        }
        return date;
    }

    public Boolean extractBoolean(final Object document, final String jsonPath) {
        Boolean value = null;
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (Exception e) {
            //  e.printStackTrace();;
        }
        return value;
    }

    public Integer extractInteger(final Object document, final String jsonPath) {
        Integer value = null;
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (Exception e) {
            //  e.printStackTrace();;
        }
        return value;
    }

    public Double extractNumberValue(final Object document, final String jsonPath) {
        Number value = null;
        Double dValue = null;
        try {
            if (checkIfValuePresent(document, jsonPath))
                value = JsonPath.read(document, jsonPath);
            if("Integer".equalsIgnoreCase(value.getClass().getSimpleName())){
                dValue = Double.parseDouble(value.toString());
            }else if("Double".equalsIgnoreCase(value.getClass().getSimpleName())){
                dValue=(Double)value;
            }

        } catch (Exception e) {
            // e.printStackTrace();
        }
        return dValue;
    }

    public Meta extractMeta(final Object document) {
        Meta meta = new Meta();
        meta.addProfile(extractString(document, "$.meta.profile"));
        if (checkIfValuePresent(document, "$.meta.lastupdated"))
            meta.setLastUpdatedElement(extractInstant(document, "$.meta.lastupdated"));
        if (checkIfValuePresent(document, "$.meta.lastUpdated"))
            meta.setLastUpdatedElement(extractInstant(document, "$.meta.lastUpdated"));
        //System.out.println("metasecurity");
        meta.setSecurity(extractSecurity(document,"$.meta.security"));
        return meta;
    }

    private List<Coding> extractSecurity(final Object document,final String jsonPath) {
        List<Coding> lstSecurityLab = new ArrayList<>();
        //System.out.println("extractSecurity");
        int partOfLength = length(document,"$.meta.security.length()");
        for (int index = 0; index < partOfLength; index++) {
            lstSecurityLab.add(extractCodingsMD(extractValue(document, "$.meta.security["+index+"]")));

        }

        return lstSecurityLab;
    }

    public Coding extractCodingsMD(final Object codingObj) {
        Coding coding = new Coding();
        coding.setCode(extractString(codingObj, "$.code"));

        if(checkIfValuePresent(codingObj, "$.display"))
            coding.setDisplay(extractString(codingObj, "$.display"));
        else if(checkIfValuePresent(codingObj, "$.text"))
            coding.setDisplay(extractString(codingObj, "$.text"));

        if (checkIfValuePresent(codingObj, "$.url")) {
            coding.setSystem(extractString(codingObj, "$.url"));
        } else if (checkIfValuePresent(codingObj, "$.system")) {
            coding.setSystem(extractString(codingObj, "$.system"));
        }
        coding.setExtension(extractExtensionsMD(extractValue(codingObj,"$.extension")));
        return coding;
    }

    public List<Extension> extractExtensionsMD(final Object extensionObj) {

        List<Extension> extensions = new ArrayList<Extension>();
        int ccLength = length(extensionObj, "$.length()");

        for (int index = 0; index < ccLength; index++) {
            Extension extension = new Extension();
            extension.setUrl(extractString(extensionObj, "$.[" + index + "].url"));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueCoding")){
                Coding id =new Coding();
                id.setSystem(extractString(extensionObj, "$.[" + index + "].valueCoding.system"));

                id.setCode(extractString(extensionObj, "$.[" + index + "].valueCoding.code"));

                extension.setValue(id);
            }

            extensions.add(extension);
        }
        return extensions;
    }
//
//    @Override
//    public String validate(final ValidationEngine validator,
//                           final boolean disableValidation,
//                           final String resourceString) throws Exception {
//    	
//    	IBaseOperationOutcome oo = fhirValidator.validate(resourceString);
//    	
//        if (oo==null )
//            return resourceString;
//        else
//            throw new Exception("Errors encountered in FHIR resource validation. Please verify input JSON to see if " +
//                    "its FHIR compliant.\n Printing the list of validation errors now - Error Count :: " );
//    }

    public Bundle createBundle(final Resource resource) {
        //
        Bundle.BundleEntryRequestComponent bundleEntryRequest = new Bundle.BundleEntryRequestComponent();
        bundleEntryRequest.setMethod(Bundle.HTTPVerb.POST);
        bundleEntryRequest.setUrl(resource.getResourceType().name());
        //
        Bundle bundle = new Bundle();
        bundle.setType(Bundle.BundleType.TRANSACTION);
        Bundle.BundleEntryComponent entryComponent = new Bundle.BundleEntryComponent();
        entryComponent.setResource(resource);
        entryComponent.setFullUrlElement(new UriType("urn:uuid:" + resource.getId()));
        entryComponent.setRequest(bundleEntryRequest);
        bundle.addEntry(entryComponent);
        //
        return bundle;
    }

    public int length(final Object document, final String jsonpath) {
        int length = 0;
        try {
            length = JsonPath.read(document, jsonpath);
        } catch (Exception e) {

        }
        return length;
    }

    public Reference extractReference(final Object document, final String jsonPath) {
        return new Reference(extractString(document, jsonPath));
    }

    public Coding extractCoding(final Object document, final String systemJsonPath, final String codeJsonPath, final String displayPath) {
        return new Coding(extractString(document, systemJsonPath), extractString(document, codeJsonPath), extractString(document, displayPath));
    }

    public Period extractPeriod(final Object document, final String jsonPathstartDt, final String jsonPathEndDt) {
        Period period = new Period();
        if (checkIfValuePresent(document, jsonPathstartDt))
            period.setStartElement(extractDateTimeType(document, jsonPathstartDt));

        if (checkIfValuePresent(document, jsonPathEndDt))
            period.setEndElement(extractDateTimeType(document, jsonPathEndDt));

        return period;
    }

    public boolean checkIfValuePresent(final Object document, final String jsonPath) {
        boolean flag = false;
        try {
            flag = Objects.nonNull(JsonPath.read(document, jsonPath)) ? true : false;
        } catch (com.jayway.jsonpath.PathNotFoundException pnfe) {
        }
        return flag;
    }

    public InstantType extractInstant(final Object document, final String jsonPath) {
        InstantType instant = null;
        if (checkIfValuePresent(document, jsonPath)) {
            Tuple2<Date, TimeZone> tup = extractTimezone(document, jsonPath);
            instant = new InstantType(tup._1, TemporalPrecisionEnum.SECOND, tup._2);
        }
        return instant;
    }
    public Tuple2<Date, TimeZone> extractTimezone(final Object document, final String jsonPath) {
        DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss XXX");
        ZonedDateTime zonedDateTime = ZonedDateTime.parse(extractString(document, jsonPath), sdf);
        TimeZone tz = TimeZone.getTimeZone(zonedDateTime.getZone());
        return new Tuple2<>(Date.from(zonedDateTime.toLocalDateTime().toInstant(zonedDateTime.getOffset())), tz);
    }
    public DateTimeType extractDateTimeType(final Object document, final String jsonPath) {
        DateTimeType dateTime = null;
        if (checkIfValuePresent(document, jsonPath)) {
            Tuple2<Date, TimeZone> tup = extractTimezone(document, jsonPath);
            dateTime = new DateTimeType(tup._1, TemporalPrecisionEnum.SECOND, tup._2);
        }
        return dateTime;
    }

    public CodeableConcept extractCodeableConcept(final Object codeDoc) {
        CodeableConcept code = null;
        if (codeDoc != null) {
            code = new CodeableConcept();

            Object codingObj = extractValue(codeDoc, "$.coding");
            if (codingObj instanceof JSONArray) {
                code.setCoding(extractCoding(codingObj));
            } else {
                code.addCoding(extractCodings(codingObj));
            }

            code.setText(extractString(codeDoc, "$.text"));
        }
        return code;
    }

    public Coding extractCodings(final Object codingObj) {
        Coding coding = new Coding();
        coding.setCode(extractString(codingObj, "$.code"));

        if(checkIfValuePresent(codingObj, "$.display"))
            coding.setDisplay(extractString(codingObj, "$.display"));
        else if(checkIfValuePresent(codingObj, "$.text"))
            coding.setDisplay(extractString(codingObj, "$.text"));

        if (checkIfValuePresent(codingObj, "$.url")) {
            coding.setSystem(extractString(codingObj, "$.url"));
        } else if (checkIfValuePresent(codingObj, "$.system")) {
            coding.setSystem(extractString(codingObj, "$.system"));
        }
        return coding;
    }

    public List<Coding> extractCoding(final Object codingObj) {
        List<Coding> codings = new ArrayList<>();
        int ccLength = length(codingObj, "$.length()");
        for (int index = 0; index < ccLength; index++) {
            Coding coding = new Coding();
            coding.setCode(extractString(codingObj, "$.["+ index +"].code"));
            if(checkIfValuePresent(codingObj, "$.["+ index +"].display"))
                coding.setDisplay(extractString(codingObj, "$.["+ index +"].display"));
            else if(checkIfValuePresent(codingObj, "$.["+ index +"].text"))
                coding.setDisplay(extractString(codingObj, "$.["+ index +"].text"));

            if (checkIfValuePresent(codingObj, "$.["+ index +"].url")) {
                coding.setSystem(extractString(codingObj, "$.["+ index +"].url"));
            } else if (checkIfValuePresent(codingObj, "$.["+ index +"].system")) {
                coding.setSystem(extractString(codingObj, "$.["+ index +"].system"));
            }
            codings.add(coding);
        }
        return codings;
    }

    public List<Extension> extractExtensions(Object extensionObj) {

        List<Extension> extensions = new ArrayList<Extension>();
        int ccLength = length(extensionObj, "$.length()");
        for (int index = 0; index < ccLength; index++) {
            Extension extension = new Extension();
            extension.setUrl(extractString(extensionObj, "$.[" + index + "].url"));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueBoolean"))
                extension.setValue(new BooleanType(extractBoolean(extensionObj, "$.[" + index + "].valueBoolean")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueReference.reference"))
                extension.setValue(extractReference(extensionObj, "$.[" + index + "].valueReference.reference"));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueMoney")) {
                Money valueMoney = new Money();
                valueMoney.setCurrency(extractString(extensionObj, "$.[" + index + "].valueMoney.currency"));
                valueMoney.setValue(extractDouble(extensionObj, "$.[" + index + "].valueMoney.value"));
                extension.setValue(valueMoney);
            }

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].extension"))
                extension.setExtension(extractExtensions(extractValue(extensionObj, "$.[" + index + "].extension")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueCode"))
                extension.setValue(new CodeType(extractString(extensionObj, "$.[" + index + "].valueCode")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueCodeableConcept"))
                extension.setValue(extractCodeableConcept(extractValue(extensionObj, "$.[" + index + "].valueCodeableConcept")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valuecodeableconcept"))
                extension.setValue(extractCodeableConcept(extractValue(extensionObj, "$.[" + index + "].valuecodeableconcept")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueDecimal")
                    && Objects.nonNull(extractDouble(extensionObj, "$.[" + index + "].valueDecimal")))
                extension.setValue(new DecimalType(extractDouble(extensionObj, "$.[" + index + "].valueDecimal")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].valueString"))
                extension.setValue(new StringType(extractString(extensionObj, "$.[" + index + "].valueString")));

            if (checkIfValuePresent(extensionObj, "$.[" + index + "].value"))
                extension.setValue(new StringType(extractString(extensionObj, "$.[" + index + "].value")));

            extensions.add(extension);
        }
        return extensions;
    }

    public List<CodeableConcept> extractCodeableConcepts(Object catDoc) {
        List<CodeableConcept> codeableConcepts = new ArrayList<>();

        if (Objects.nonNull(catDoc)) {
            int ccLength = length(catDoc, "$.length()");
            for (int index = 0; index < ccLength; index++) {
                codeableConcepts.add(extractCodeableConcept(extractValue(catDoc, "$.[" + index + "]")));
            }
        }

        return codeableConcepts;
    }

//    public List<ContactPoint> extractTelecom(final Object document, final String jsonPath) {
//        List<ContactPoint> telecomList = new ArrayList<>();
//        int telecomLength = length(document, jsonPath + ".length()");
//
//        for (int i = 0; i < telecomLength; i++) {
//            ContactPoint contactPoint = new ContactPoint();
//            contactPoint.setRank(extractInteger(document, jsonPath + "[" + i + "].rank"));
//            contactPoint.setSystem(ContactPoint.ContactPointSystem.fromCode(extractString(document, jsonPath + "[" + i + "].system")));
//            contactPoint.setValue(extractString(document, jsonPath + "[" + i + "].value"));
//            contactPoint.setUse(ContactPoint.ContactPointUse.fromCode(extractString(document, "$.[" + i + "].use")));
//
//            int extLength = length(document, jsonPath + "[" + i + "].extension.length()");
//            for (int index = 0; index < extLength; index++) {
//                List<Extension> extensionList = new ArrayList<>();
//                String telExtPath = jsonPath + "[" + i + "].extension[" + index + "]";
//                int ext1Length = length(document, telExtPath + ".extension.length()");
//                for (int index1 = 0; index1 < ext1Length; index1++) {
//                    Extension extension = new Extension();
//                    if (checkIfValuePresent(document, telExtPath + ".extension[" + index1 + "].valuetype")) {
//                        String valueType = extractString(document, telExtPath + ".extension[" + index1 + "].valuetype");
//                        String value = extractString(document, telExtPath + ".extension[" + index1 + "].value");
//                        Type typeClass = ExtensionValueType.getExtensionType(valueType, value);
//                        extension.setValue(typeClass);
//                    }
//                    extension.setUrl(extractString(document, telExtPath + ".extension[" + index1 + "].url"));
//                    extensionList.add(extension);
//                }
//                Extension mainExtension = new Extension();
//                mainExtension.setExtension(extensionList);
//                mainExtension.setUrl(extractString(document, telExtPath + ".url"));
//                contactPoint.addExtension(mainExtension);
//            }
//            telecomList.add(contactPoint);
//        }
//        return telecomList;
//    }

    public Long extractLong(final Object document, final String jsonPath) {
        Long value = null;
        try {
            value = Long.parseLong(JsonPath.read(document, jsonPath));
        } catch (Exception e) {
        }
        return value;
    }

    public byte[] extractBytes(final Object document, final String jsonPath) {
        String value = null;
        try {
            value = JsonPath.read(document, jsonPath);
        } catch (Exception e) {
        }

        return Base64.decodeBase64(value);
    }

}

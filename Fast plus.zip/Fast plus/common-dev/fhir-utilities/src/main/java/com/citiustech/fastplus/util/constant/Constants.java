package com.citiustech.fastplus.util.constant;

public final class Constants {
	
	private Constants() {
		
	}

	public static final String ONE = "1";
	public static final String HYPHEN = "-";
	public static final String FORWARD_SLASH = "/";
	public static final String BLANK_SPACE = "";
	
}

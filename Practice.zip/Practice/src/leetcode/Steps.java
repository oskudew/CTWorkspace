package leetcode;

public class Steps {
	public static void main(String[] args) {

	 int[] arr = {2,6,8,9,6};    
	    System.out.println("result : " + findMaxDistance(arr));
	}

	static int findMaxDistance(int[] arr){
		   
		   int N = arr.length;
		   int[] leftMax = new int[N];
		   int[] rightMax = new int[N];

		   int i = 1 ;   
		   leftMax[i-1]=0;

		  while( i < arr.length ) {
		      // previous is greater than current
		     if(arr[i] >= arr[i -1]) {
		        leftMax[i] = leftMax[i-1] + 1;    //0,1,0,0,1,0,1,0,1
		     } else {
		         leftMax[i] = 0;
		     }

		    i++; //2,3,4,5,6

		  }

		 rightMax[N-1] = 0 ;  // 
		 int j = N-2;
		  while( j >= 0 ) {
		      // next is greater than current
		     if(arr[j] >= arr[j + 1]) {
		        rightMax[j] = rightMax[j+1] + 1;//0,0,1,0,1,0,1,2,0-->0,2,1,0,1,0,1,0,0
		     } else {
		         rightMax[j] = 0;
		     }

		    j--;

		  }
		  for(int p=0;p<N;p++) {
			  System.out.println("left"+leftMax[p]+"--"+rightMax[p]);
		  }

		int maxD = 0 ;

		for(int k = 0 ; k < N ; k++ ){
		    maxD = Math.max(maxD , leftMax[k] + rightMax[k] + 1);//1,3,1,0,2,0,,2,0,1

		} 

		return maxD; 

		}
}

package com.citiustech.fastplus.util;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class BulkExportData {

	private String resourceType;
	private String exportQuery;
	private Integer executionSequence;
	
}

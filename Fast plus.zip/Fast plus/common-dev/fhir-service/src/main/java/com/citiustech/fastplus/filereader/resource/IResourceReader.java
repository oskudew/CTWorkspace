package com.citiustech.fastplus.filereader.resource;

import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;

/**
 * 
 * This is an interface for Resource individual implementation for reading and set the file data using URL.
 *
 */
public interface IResourceReader {

	/**
	 * used to set attachment data using URL.
	 * @param resources
	 */
	void readAttachment(List<IBaseResource> resources);
}
